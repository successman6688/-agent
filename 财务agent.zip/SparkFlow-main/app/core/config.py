"""Core configuration management."""

from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    """Application settings."""

    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        case_sensitive=True,
        extra='ignore'  # 忽略额外的环境变量
    )

    # LLM Configuration
    API_TYPE: str = "anthropic"  # Options: "openai", "anthropic"
    MODEL_NAME: str = "claude-sonnet-4-20250514"

    # OpenAI API
    OPENAI_API_KEY: str = ""

    # Anthropic API
    ANTHROPIC_API_KEY: str = ""
    ANTHROPIC_API_BASE: str = "https://api.anthropic.com"

    # Twitter API (Optional)
    TWITTER_API_KEY: str = ""
    TWITTER_API_SECRET: str = ""
    TWITTER_ACCESS_TOKEN: str = ""
    TWITTER_ACCESS_SECRET: str = ""
    TWITTER_BEARER_TOKEN: str = ""

    # Reddit API (Optional)
    REDDIT_CLIENT_ID: str = ""
    REDDIT_CLIENT_SECRET: str = ""
    REDDIT_USER_AGENT: str = "sparkflow/1.0"

    # Database
    DATABASE_URL: str = "postgresql+asyncpg://user:password@localhost:5432/sparkflow"
    REDIS_URL: str = "redis://localhost:6379"

    # Application
    APP_ENV: str = "development"
    APP_DEBUG: bool = True
    APP_PORT: int = 8000
    LOG_LEVEL: str = "INFO"

    # Streamlit
    STREAMLIT_SERVER_PORT: int = 8501
    STREAMLIT_SERVER_ADDRESS: str = "localhost"


# Global settings instance
settings = Settings()
