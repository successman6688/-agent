"""LLM client factory for different providers."""

from typing import Optional
from langchain_anthropic import ChatAnthropic
from langchain_openai import ChatOpenAI
from langchain_core.language_models.chat_models import BaseChatModel

from app.core.config import settings
from app.core.logging import get_logger

logger = get_logger(__name__)


def create_llm(
    model: Optional[str] = None,
    temperature: float = 0.7,
    max_tokens: int = 2000,
) -> BaseChatModel:
    """
    Create LLM instance based on API_TYPE setting.

    Args:
        model: Model name (optional, defaults to settings.MODEL_NAME)
        temperature: Sampling temperature
        max_tokens: Maximum tokens to generate

    Returns:
        LLM instance
    """
    api_type = settings.API_TYPE
    model_name = model or settings.MODEL_NAME

    logger.info(f"Creating LLM: type={api_type}, model={model_name}")

    if api_type == "anthropic":
        return ChatAnthropic(
            model=model_name,
            anthropic_api_key=settings.ANTHROPIC_API_KEY,
            anthropic_api_url=settings.ANTHROPIC_API_BASE,
            temperature=temperature,
            max_tokens=max_tokens,
        )
    elif api_type == "openai":
        if not settings.OPENAI_API_KEY:
            raise ValueError("OPENAI_API_KEY is required when API_TYPE is 'openai'")

        return ChatOpenAI(
            model=model_name,
            openai_api_key=settings.OPENAI_API_KEY,
            temperature=temperature,
            max_tokens=max_tokens,
        )
    else:
        raise ValueError(f"Unsupported API_TYPE: {api_type}")


def get_default_model() -> str:
    """Get the default model name."""
    return settings.MODEL_NAME


def get_api_type() -> str:
    """Get the current API type."""
    return settings.API_TYPE
