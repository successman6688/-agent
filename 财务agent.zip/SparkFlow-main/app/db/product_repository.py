"""异步数据库访问层 - 用于产品管理"""

from typing import List, Optional, Dict, Any
from datetime import datetime
from uuid import UUID

from sqlalchemy import select, and_, desc, func, update, delete
from sqlalchemy.ext.asyncio import AsyncSession

from app.db import ProductDB
from app.models.product import (
    Product,
    ProductCreate,
    ProductUpdate,
    ProductFilters,
    ProductType,
    ProductStatus,
)
from app.core.logging import get_logger

logger = get_logger(__name__)


class ProductRepository:
    """产品仓储（异步数据库访问）"""

    def __init__(self, session: AsyncSession):
        self.session = session

    # ============== CRUD Operations ==============

    async def create_product(self, product_data: Dict[str, Any]) -> ProductDB:
        """创建新产品"""
        db_product = ProductDB(**product_data)
        self.session.add(db_product)
        await self.session.commit()
        await self.session.refresh(db_product)
        logger.info(f"Created product: {db_product.name} ({db_product.id})")
        return db_product

    async def get_product(self, product_id: str) -> Optional[ProductDB]:
        """根据ID获取产品"""
        result = await self.session.execute(
            select(ProductDB).where(ProductDB.id == product_id)
        )
        return result.scalar_one_or_none()

    async def list_products(
        self,
        filters: Optional[ProductFilters] = None,
        limit: int = 100,
        offset: int = 0
    ) -> List[ProductDB]:
        """
        获取产品列表

        Args:
            filters: 筛选条件
            limit: 返回数量限制
            offset: 偏移量

        Returns:
            产品列表（数据库模型）
        """
        query = select(ProductDB)

        # 应用筛选
        if filters:
            conditions = []

            if filters.type:
                conditions.append(ProductDB.type == filters.type)
            if filters.status:
                conditions.append(ProductDB.status == filters.status)
            if filters.category:
                conditions.append(ProductDB.category == filters.category)
            if filters.is_active is not None:
                conditions.append(ProductDB.is_active == filters.is_active)
            if filters.search:
                search_term = f"%{filters.search}%"
                conditions.append(
                    (ProductDB.name.ilike(search_term)) |
                    (ProductDB.description.ilike(search_term))
                )
            if filters.tags:
                # JSON数组包含查询
                for tag in filters.tags:
                    conditions.append(ProductDB.tags.contains([tag]))

            if conditions:
                query = query.where(and_(*conditions))

        # 按创建时间倒序
        query = query.order_by(desc(ProductDB.created_at))

        # 分页
        query = query.limit(limit).offset(offset)

        result = await self.session.execute(query)
        return list(result.scalars().all())

    async def update_product(
        self,
        product_id: str,
        update_data: Dict[str, Any]
    ) -> Optional[ProductDB]:
        """更新产品"""
        # 只更新提供的字段，自动更新updated_at
        update_data['updated_at'] = datetime.utcnow()

        stmt = (
            update(ProductDB)
            .where(ProductDB.id == product_id)
            .values(**update_data)
            .returning(ProductDB)
        )
        result = await self.session.execute(stmt)
        await self.session.commit()

        return result.scalar_one_or_none()

    async def delete_product(self, product_id: str) -> bool:
        """删除产品"""
        stmt = delete(ProductDB).where(ProductDB.id == product_id)
        result = await self.session.execute(stmt)
        await self.session.commit()
        return result.rowcount > 0

    # ============== Active Product Management ==============

    async def set_active_product(self, product_id: str) -> Optional[ProductDB]:
        """
        设置激活产品（取消其他产品的激活状态）

        Args:
            product_id: 产品ID

        Returns:
            激活的产品
        """
        # 取消所有产品的激活状态
        await self.session.execute(
            update(ProductDB)
            .where(ProductDB.is_active == True)
            .values(is_active=False, status="inactive")
        )

        # 激活指定产品
        stmt = (
            update(ProductDB)
            .where(ProductDB.id == product_id)
            .values(
                is_active=True,
                status="active",
                updated_at=datetime.utcnow()
            )
            .returning(ProductDB)
        )
        result = await self.session.execute(stmt)
        await self.session.commit()

        logger.info(f"Set active product: {product_id}")

        return result.scalar_one_or_none()

    async def get_active_product(self) -> Optional[ProductDB]:
        """获取当前激活的产品"""
        result = await self.session.execute(
            select(ProductDB)
            .where(ProductDB.is_active == True)
            .limit(1)
        )
        return result.scalar_one_or_none()

    async def clear_active_products(self) -> int:
        """清除所有产品的激活状态"""
        stmt = (
            update(ProductDB)
            .where(ProductDB.is_active == True)
            .values(is_active=False, status="inactive")
        )
        result = await self.session.execute(stmt)
        await self.session.commit()
        return result.rowcount

    # ============== Statistics ==============

    async def get_product_count(self) -> int:
        """获取产品总数"""
        result = await self.session.execute(
            select(func.count(ProductDB.id))
        )
        return result.scalar() or 0

    async def get_active_product_count(self) -> int:
        """获取激活产品数量"""
        result = await self.session.execute(
            select(func.count(ProductDB.id))
            .where(ProductDB.is_active == True)
        )
        return result.scalar() or 0

    async def get_products_by_type(self, product_type: ProductType) -> List[ProductDB]:
        """按类型获取产品"""
        result = await self.session.execute(
            select(ProductDB)
            .where(ProductDB.type == product_type)
            .order_by(desc(ProductDB.created_at))
        )
        return list(result.scalars().all())

    async def increment_content_count(self, product_id: str) -> None:
        """增加产品的内容计数"""
        stmt = (
            update(ProductDB)
            .where(ProductDB.id == product_id)
            .values(content_count=ProductDB.content_count + 1)
        )
        await self.session.execute(stmt)
        await self.session.commit()

    async def increment_publish_count(self, product_id: str) -> None:
        """增加产品的发布计数"""
        stmt = (
            update(ProductDB)
            .where(ProductDB.id == product_id)
            .values(publish_count=ProductDB.publish_count + 1)
        )
        await self.session.execute(stmt)
        await self.session.commit()
