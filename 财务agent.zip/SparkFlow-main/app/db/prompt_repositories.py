"""异步数据库访问层 - 用于提示词管理"""

from typing import List, Optional, Dict, Any
from datetime import datetime, timedelta

from sqlalchemy import select, and_, desc, func, update
from sqlalchemy.ext.asyncio import AsyncSession

from app.db import PromptTemplateDB, PromptExecutionLogDB, UserFeedbackDB, PromptStatsDB
from app.core.logging import get_logger

logger = get_logger(__name__)


class PromptTemplateRepository:
    """提示词模板仓储（异步）"""

    def __init__(self, session: AsyncSession):
        self.session = session

    async def create(self, template_data: Dict[str, Any]) -> PromptTemplateDB:
        """创建新模板"""
        db_template = PromptTemplateDB(**template_data)
        self.session.add(db_template)
        await self.session.commit()
        await self.session.refresh(db_template)
        return db_template

    async def get_by_id(self, template_id: str) -> Optional[PromptTemplateDB]:
        """根据ID获取模板"""
        result = await self.session.execute(
            select(PromptTemplateDB).filter(PromptTemplateDB.id == template_id)
        )
        return result.scalar_one_or_none()

    async def get_by_strategy(
        self,
        strategy_type: str,
        category: str = "default",
        active_only: bool = True
    ) -> List[PromptTemplateDB]:
        """根据策略类型获取模板"""
        query = select(PromptTemplateDB).filter(
            PromptTemplateDB.strategy_type == strategy_type,
            PromptTemplateDB.category == category
        )

        if active_only:
            query = query.filter(PromptTemplateDB.is_active == True)

        query = query.order_by(
            PromptTemplateDB.is_default.desc(),
            PromptTemplateDB.created_at.desc()
        )

        result = await self.session.execute(query)
        return list(result.scalars().all())

    async def get_default_by_strategy(self, strategy_type: str) -> Optional[PromptTemplateDB]:
        """获取指定策略类型的默认模板"""
        result = await self.session.execute(
            select(PromptTemplateDB).filter(
                PromptTemplateDB.strategy_type == strategy_type,
                PromptTemplateDB.is_default == True,
                PromptTemplateDB.is_active == True
            )
        )
        return result.scalar_one_or_none()

    async def list_all(
        self,
        strategy_type: Optional[str] = None,
        active_only: bool = False
    ) -> List[PromptTemplateDB]:
        """列出所有模板"""
        query = select(PromptTemplateDB)

        if strategy_type:
            query = query.filter(PromptTemplateDB.strategy_type == strategy_type)

        if active_only:
            query = query.filter(PromptTemplateDB.is_active == True)

        query = query.order_by(PromptTemplateDB.created_at.desc())

        result = await self.session.execute(query)
        return list(result.scalars().all())

    async def update_stats(
        self,
        template_id: str,
        usage_count: int,
        success_rate: float,
        avg_quality_score: float
    ):
        """更新模板统计数据"""
        await self.session.execute(
            update(PromptTemplateDB)
            .where(PromptTemplateDB.id == template_id)
            .values(
                usage_count=usage_count,
                success_rate=success_rate,
                avg_quality_score=avg_quality_score,
                updated_at=datetime.utcnow()
            )
        )
        await self.session.commit()
        logger.info(f"Updated stats for template {template_id}")

    async def increment_usage(self, template_id: str, success: bool):
        """增加使用计数（简单版本）"""
        result = await self.session.execute(
            select(PromptTemplateDB).filter(PromptTemplateDB.id == template_id)
        )
        template = result.scalar_one_or_none()

        if template:
            template.usage_count += 1
            # 更新成功率
            if success:
                template.success_rate = (
                    (template.success_rate * (template.usage_count - 1) + 1.0) /
                    template.usage_count
                )
            else:
                template.success_rate = (
                    (template.success_rate * (template.usage_count - 1)) /
                    template.usage_count
                )
            template.updated_at = datetime.utcnow()
            await self.session.commit()


class PromptExecutionLogRepository:
    """提示词执行日志仓储（异步）"""

    def __init__(self, session: AsyncSession):
        self.session = session

    async def create(self, log_data: Dict[str, Any]) -> PromptExecutionLogDB:
        """创建执行日志"""
        db_log = PromptExecutionLogDB(**log_data)
        self.session.add(db_log)
        await self.session.commit()
        await self.session.refresh(db_log)
        return db_log

    async def get_recent_logs(
        self,
        template_id: str,
        hours: int = 24,
        limit: int = 100
    ) -> List[PromptExecutionLogDB]:
        """获取最近的执行日志"""
        since = datetime.utcnow() - timedelta(hours=hours)

        result = await self.session.execute(
            select(PromptExecutionLogDB)
            .filter(
                PromptExecutionLogDB.template_id == template_id,
                PromptExecutionLogDB.created_at >= since
            )
            .order_by(desc(PromptExecutionLogDB.created_at))
            .limit(limit)
        )
        return list(result.scalars().all())

    async def get_success_rate(
        self,
        template_id: str,
        hours: int = 24
    ) -> float:
        """获取指定时间段内的成功率"""
        since = datetime.utcnow() - timedelta(hours=hours)

        # 总数
        total_result = await self.session.execute(
            select(PromptExecutionLogDB)
            .filter(
                PromptExecutionLogDB.template_id == template_id,
                PromptExecutionLogDB.created_at >= since
            )
        )
        total = len(total_result.scalars().all())

        if total == 0:
            return 0.0

        # 成功数
        success_result = await self.session.execute(
            select(PromptExecutionLogDB)
            .filter(
                PromptExecutionLogDB.template_id == template_id,
                PromptExecutionLogDB.created_at >= since,
                PromptExecutionLogDB.parse_success == True
            )
        )
        success = len(success_result.scalars().all())

        return success / total


class UserFeedbackRepository:
    """用户反馈仓储（异步）"""

    def __init__(self, session: AsyncSession):
        self.session = session

    async def create(
        self,
        item_id: str,
        prompt_id: str,
        feedback_type: str,
        feedback_value: Any,
        user_id: Optional[str] = None,
        session_id: Optional[str] = None
    ) -> UserFeedbackDB:
        """创建用户反馈"""
        feedback = UserFeedbackDB(
            item_id=item_id,
            prompt_id=prompt_id,
            feedback_type=feedback_type,
            feedback_value=feedback_value,
            user_id=user_id,
            session_id=session_id
        )
        self.session.add(feedback)
        await self.session.commit()
        await self.session.refresh(feedback)
        return feedback

    async def get_stats_by_prompt(
        self,
        prompt_id: str,
        days: int = 7
    ) -> Dict[str, Any]:
        """获取指定提示词的反馈统计"""
        since = datetime.utcnow() - timedelta(days=days)

        result = await self.session.execute(
            select(UserFeedbackDB).filter(
                UserFeedbackDB.prompt_id == prompt_id,
                UserFeedbackDB.created_at >= since
            )
        )
        feedbacks = list(result.scalars().all())

        stats = {
            "total_count": len(feedbacks),
            "thumbs_up": 0,
            "thumbs_down": 0,
            "useful": 0,
            "not_useful": 0,
            "ratings": [],
            "avg_rating": None
        }

        for f in feedbacks:
            if f.feedback_type == "thumbs_up":
                stats["thumbs_up"] += 1
            elif f.feedback_type == "thumbs_down":
                stats["thumbs_down"] += 1
            elif f.feedback_type == "useful":
                stats["useful"] += 1
            elif f.feedback_type == "not_useful":
                stats["not_useful"] += 1
            elif f.feedback_type == "rating" and f.feedback_value:
                stats["ratings"].append(f.feedback_value)

        if stats["ratings"]:
            stats["avg_rating"] = sum(stats["ratings"]) / len(stats["ratings"])

        return stats
