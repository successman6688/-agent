"""数据库访问层"""

from typing import List, Optional, Dict, Any
from datetime import datetime, timedelta
from sqlalchemy.orm import Session
from sqlalchemy import and_, desc, func

from app.db.models import (
    PromptTemplateDB,
    PromptExecutionLogDB,
    UserFeedbackDB,
    PromptStatsDB
)
from app.models.intelligence import PromptTemplate, PromptExecutionLog
from app.core.logging import get_logger

logger = get_logger(__name__)


class PromptTemplateRepository:
    """提示词模板仓储"""

    def __init__(self, db: Session):
        self.db = db

    def create(self, template: PromptTemplate) -> PromptTemplateDB:
        """创建新模板"""
        db_template = PromptTemplateDB(
            id=template.id,
            name=template.name,
            description=template.description,
            strategy_type=template.strategy_type,
            category=template.category,
            system_prompt=template.system_prompt,
            user_prompt_template=template.user_prompt_template,
            output_schema=template.output_schema,
            variables=[v.dict() for v in template.variables],
            version=template.version,
            is_active=template.is_active,
            is_default=template.is_default,
            usage_count=template.usage_count,
            success_rate=template.success_rate,
            avg_quality_score=template.avg_quality_score,
            created_by=template.created_by
        )
        self.db.add(db_template)
        self.db.commit()
        self.db.refresh(db_template)
        return db_template

    def get_by_id(self, template_id: str) -> Optional[PromptTemplateDB]:
        """根据ID获取模板"""
        return self.db.query(PromptTemplateDB).filter(
            PromptTemplateDB.id == template_id
        ).first()

    def get_by_strategy(
        self,
        strategy_type: str,
        category: str = "default",
        active_only: bool = True
    ) -> List[PromptTemplateDB]:
        """根据策略类型获取模板"""
        query = self.db.query(PromptTemplateDB).filter(
            PromptTemplateDB.strategy_type == strategy_type,
            PromptTemplateDB.category == category
        )

        if active_only:
            query = query.filter(PromptTemplateDB.is_active == True)

        return query.order_by(
            PromptTemplateDB.is_default.desc(),
            PromptTemplateDB.created_at.desc()
        ).all()

    def get_default_by_strategy(self, strategy_type: str) -> Optional[PromptTemplateDB]:
        """获取指定策略类型的默认模板"""
        return self.db.query(PromptTemplateDB).filter(
            PromptTemplateDB.strategy_type == strategy_type,
            PromptTemplateDB.is_default == True,
            PromptTemplateDB.is_active == True
        ).first()

    def list_all(
        self,
        strategy_type: Optional[str] = None,
        active_only: bool = False
    ) -> List[PromptTemplateDB]:
        """列出所有模板"""
        query = self.db.query(PromptTemplateDB)

        if strategy_type:
            query = query.filter(PromptTemplateDB.strategy_type == strategy_type)

        if active_only:
            query = query.filter(PromptTemplateDB.is_active == True)

        return query.order_by(PromptTemplateDB.created_at.desc()).all()

    def update_stats(
        self,
        template_id: str,
        usage_count: int,
        success_rate: float,
        avg_quality_score: float
    ):
        """更新模板统计数据"""
        template = self.get_by_id(template_id)
        if template:
            template.usage_count = usage_count
            template.success_rate = success_rate
            template.avg_quality_score = avg_quality_score
            template.updated_at = datetime.utcnow()
            self.db.commit()
            logger.info(f"Updated stats for template {template_id}")

    def increment_usage(self, template_id: str, success: bool):
        """增加使用计数"""
        template = self.get_by_id(template_id)
        if template:
            template.usage_count += 1
            # 简单更新成功率
            if success:
                template.success_rate = (
                    (template.success_rate * (template.usage_count - 1) + 1.0) /
                    template.usage_count
                )
            else:
                template.success_rate = (
                    (template.success_rate * (template.usage_count - 1)) /
                    template.usage_count
                )
            template.updated_at = datetime.utcnow()
            self.db.commit()


class PromptExecutionLogRepository:
    """提示词执行日志仓储"""

    def __init__(self, db: Session):
        self.db = db

    def create(self, log: PromptExecutionLog) -> PromptExecutionLogDB:
        """创建执行日志"""
        db_log = PromptExecutionLogDB(
            id=log.id,
            template_id=log.template_id,
            template_version=log.template_version,
            topic_id=log.topic_id,
            topic_name=log.topic_name,
            strategy_type=log.strategy_type,
            variables_used=log.variables_used,
            llm_response=log.llm_response,
            parsed_result=log.parsed_result,
            parse_success=log.parse_success,
            response_time_ms=log.response_time_ms,
            token_count=log.token_count,
            user_rating=log.user_rating,
            user_feedback=log.user_feedback
        )
        self.db.add(db_log)
        self.db.commit()
        self.db.refresh(db_log)
        return db_log

    def get_recent_logs(
        self,
        template_id: str,
        hours: int = 24,
        limit: int = 100
    ) -> List[PromptExecutionLogDB]:
        """获取最近的执行日志"""
        since = datetime.utcnow() - timedelta(hours=hours)
        return self.db.query(PromptExecutionLogDB).filter(
            PromptExecutionLogDB.template_id == template_id,
            PromptExecutionLogDB.created_at >= since
        ).order_by(desc(PromptExecutionLogDB.created_at)).limit(limit).all()

    def get_success_rate(
        self,
        template_id: str,
        hours: int = 24
    ) -> float:
        """获取指定时间段内的成功率"""
        since = datetime.utcnow() - timedelta(hours=hours)

        total = self.db.query(PromptExecutionLogDB).filter(
            PromptExecutionLogDB.template_id == template_id,
            PromptExecutionLogDB.created_at >= since
        ).count()

        if total == 0:
            return 0.0

        success = self.db.query(PromptExecutionLogDB).filter(
            PromptExecutionLogDB.template_id == template_id,
            PromptExecutionLogDB.created_at >= since,
            PromptExecutionLogDB.parse_success == True
        ).count()

        return success / total


class UserFeedbackRepository:
    """用户反馈仓储"""

    def __init__(self, db: Session):
        self.db = db

    def create(
        self,
        item_id: str,
        prompt_id: str,
        feedback_type: str,
        feedback_value: Any,
        user_id: Optional[str] = None,
        session_id: Optional[str] = None
    ) -> UserFeedbackDB:
        """创建用户反馈"""
        feedback = UserFeedbackDB(
            item_id=item_id,
            prompt_id=prompt_id,
            feedback_type=feedback_type,
            feedback_value=feedback_value,
            user_id=user_id,
            session_id=session_id
        )
        self.db.add(feedback)
        self.db.commit()
        self.db.refresh(feedback)
        return feedback

    def get_stats_by_prompt(
        self,
        prompt_id: str,
        days: int = 7
    ) -> Dict[str, Any]:
        """获取指定提示词的反馈统计"""
        since = datetime.utcnow() - timedelta(days=days)

        feedbacks = self.db.query(UserFeedbackDB).filter(
            UserFeedbackDB.prompt_id == prompt_id,
            UserFeedbackDB.created_at >= since
        ).all()

        stats = {
            "total_count": len(feedbacks),
            "thumbs_up": 0,
            "thumbs_down": 0,
            "useful": 0,
            "not_useful": 0,
            "ratings": [],
            "avg_rating": None
        }

        for f in feedbacks:
            if f.feedback_type == "thumbs_up":
                stats["thumbs_up"] += 1
            elif f.feedback_type == "thumbs_down":
                stats["thumbs_down"] += 1
            elif f.feedback_type == "useful":
                stats["useful"] += 1
            elif f.feedback_type == "not_useful":
                stats["not_useful"] += 1
            elif f.feedback_type == "rating" and f.feedback_value:
                stats["ratings"].append(f.feedback_value)

        if stats["ratings"]:
            stats["avg_rating"] = sum(stats["ratings"]) / len(stats["ratings"])

        return stats


class PromptStatsRepository:
    """提示词统计仓储"""

    def __init__(self, db: Session):
        self.db = db

    def update_or_create(
        self,
        prompt_id: str,
        total_score: float,
        count: int,
        success_count: int,
        failure_count: int
    ):
        """更新或创建统计数据"""
        stats = self.db.query(PromptStatsDB).filter(
            PromptStatsDB.prompt_id == prompt_id
        ).first()

        if stats:
            stats.total_score = total_score
            stats.count = count
            stats.success_count = success_count
            stats.failure_count = failure_count
            stats.last_updated = datetime.utcnow()
        else:
            stats = PromptStatsDB(
                prompt_id=prompt_id,
                total_score=total_score,
                count=count,
                success_count=success_count,
                failure_count=failure_count
            )
            self.db.add(stats)

        self.db.commit()

    def get_top_prompts(self, limit: int = 5) -> List[tuple]:
        """获取表现最好的提示词"""
        return self.db.query(
            PromptStatsDB.prompt_id,
            func.coalesce(PromptStatsDB.total_score / PromptStatsDB.count, 0.0).label('avg_score')
        ).filter(
            PromptStatsDB.count >= 10  # 至少10个样本
        ).order_by(
            desc('avg_score')
        ).limit(limit).all()
