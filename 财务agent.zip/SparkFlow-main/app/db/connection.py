"""Database connection and session management."""

from contextlib import asynccontextmanager
from typing import AsyncGenerator, Optional

from sqlalchemy.ext.asyncio import create_async_engine, AsyncSession
from sqlalchemy.orm import sessionmaker
from redis import asyncio as aioredis

from app.core.config import settings
from app.core.logging import get_logger
from app.db import Base

logger = get_logger(__name__)


# ============== PostgreSQL ==============

# 创建异步引擎
engine = None
async_session_maker = None


def get_database_url() -> str:
    """获取数据库连接URL"""
    return settings.DATABASE_URL


async def init_database():
    """
    初始化数据库连接
    """
    global engine, async_session_maker

    database_url = get_database_url()
    logger.info(f"Initializing PostgreSQL database: {database_url.split('@')[1] if '@' in database_url else 'localhost'}")

    # 创建异步引擎
    engine = create_async_engine(
        database_url,
        echo=settings.APP_DEBUG,  # 调试模式打印SQL
        pool_size=10,  # 连接池大小
        max_overflow=20,  # 最大溢出连接数
    )

    # 创建会话工厂
    async_session_maker = sessionmaker(
        engine,
        class_=AsyncSession,
        expire_on_commit=False,
        autocommit=False,
        autoflush=False,
    )

    # 导入所有模型以确保它们被注册到Base.metadata中
    from app.db import Base  # noqa: F401

    # 创建所有表
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)

    logger.info("Database initialized successfully")


@asynccontextmanager
async def get_db_session() -> AsyncGenerator[AsyncSession, None]:
    """
    获取数据库会话（上下文管理器）

    用法:
        async with get_db_session() as session:
            # 使用session进行数据库操作
            pass
    """
    global async_session_maker

    if async_session_maker is None:
        raise RuntimeError("Database not initialized. Call init_database() first.")

    async with async_session_maker() as session:
        try:
            yield session
            await session.commit()
        except Exception:
            await session.rollback()
            raise
        finally:
            await session.close()


async def get_db():
    """
    FastAPI依赖注入：获取数据库会话

    用法:
        @router.get("/endpoint")
        async def endpoint(session: AsyncSession = Depends(get_db)):
            # 使用session进行数据库操作
            pass
    """
    global async_session_maker

    if async_session_maker is None:
        raise RuntimeError("Database not initialized. Call init_database() first.")

    async with async_session_maker() as session:
        try:
            yield session
            await session.commit()
        except Exception:
            await session.rollback()
            raise
        finally:
            await session.close()


# ============== Redis ==============

redis_client: Optional[aioredis.Redis] = None


async def init_redis():
    """
    初始化Redis连接
    """
    global redis_client

    logger.info(f"Initializing Redis: {settings.REDIS_URL}")

    redis_client = await aioredis.from_url(
        settings.REDIS_URL,
        encoding="utf-8",
        decode_responses=True,
        max_connections=50,  # 连接池大小
    )

    # 测试连接
    await redis_client.ping()
    logger.info("Redis initialized successfully")


def get_redis_client() -> aioredis.Redis:
    """
    获取Redis客户端

    用法:
        client = get_redis_client()
        await client.set('key', 'value')
        value = await client.get('key')
    """
    global redis_client
    if redis_client is None:
        raise RuntimeError("Redis not initialized. Call init_redis() first.")
    return redis_client


# ============== ChromaDB ==============

chroma_client = None


async def init_chroma():
    """
    初始化ChromaDB连接
    """
    global chroma_client

    import chromadb
    from pathlib import Path

    # ChromaDB存储路径
    chroma_path = Path("data/chromadb")
    chroma_path.mkdir(parents=True, exist_ok=True)

    logger.info(f"Initializing ChromaDB: {chroma_path}")

    chroma_client = chromadb.PersistentClient(path=str(chroma_path))

    logger.info("ChromaDB initialized successfully")


def get_chroma_client():
    """
    获取ChromaDB客户端

    用法:
        client = get_chroma_client()
        collection = client.get_or_create_collection("intelligence")
    """
    global chroma_client
    if chroma_client is None:
        raise RuntimeError("ChromaDB not initialized. Call init_chroma() first.")
    return chroma_client


# ============== File Storage ==============

class FileStorageService:
    """
    本地文件存储服务
    用于存储图片、附件等文件
    """

    def __init__(self, base_path: str = "data/files"):
        """
        初始化文件存储服务

        Args:
            base_path: 基础存储路径
        """
        from pathlib import Path

        self.base_path = Path(base_path)
        self.base_path.mkdir(parents=True, exist_ok=True)

        # 子目录
        (self.base_path / "images").mkdir(exist_ok=True)
        (self.base_path / "attachments").mkdir(exist_ok=True)
        (self.base_path / "exports").mkdir(exist_ok=True)

    def save_file(self, file_data: bytes, filename: str, category: str = "images") -> str:
        """
        保存文件到本地

        Args:
            file_data: 文件二进制数据
            filename: 文件名
            category: 子目录名称 (images, attachments, exports)

        Returns:
            文件保存路径
        """
        from pathlib import Path
        from datetime import datetime
        import uuid

        # 生成唯一文件名
        file_ext = Path(filename).suffix
        unique_name = f"{datetime.utcnow().strftime('%Y%m%d')}_{uuid.uuid4().hex[:8]}{file_ext}"

        # 构建完整路径
        file_path = self.base_path / category / unique_name

        # 保存文件
        with open(file_path, 'wb') as f:
            f.write(file_data)

        logger.info(f"File saved: {file_path}")
        return str(file_path)

    def get_file_path(self, filename: str) -> str:
        """
        获取文件的完整路径

        Args:
            filename: 文件名

        Returns:
            文件完整路径
        """
        return str(self.base_path / filename)

    def delete_file(self, file_path: str) -> bool:
        """
        删除文件

        Args:
            file_path: 文件路径

        Returns:
            是否删除成功
        """
        from pathlib import Path

        path = Path(file_path)
        if path.exists() and path.is_file():
            path.unlink()
            logger.info(f"File deleted: {file_path}")
            return True
        return False


# 全局文件存储服务实例
_file_storage_service: Optional[FileStorageService] = None


def get_file_storage() -> FileStorageService:
    """获取文件存储服务实例（单例）"""
    global _file_storage_service
    if _file_storage_service is None:
        _file_storage_service = FileStorageService()
    return _file_storage_service


# ============== Initialization ==============

async def init_all_databases():
    """
    初始化所有数据库连接
    """
    logger.info("Initializing all databases...")

    # PostgreSQL
    await init_database()

    # Redis
    try:
        await init_redis()
    except Exception as e:
        logger.warning(f"Redis initialization failed (continuing without cache): {e}")

    # ChromaDB
    try:
        await init_chroma()
    except Exception as e:
        logger.warning(f"ChromaDB initialization failed (continuing without vector store): {e}")

    logger.info("All databases initialized successfully")


async def close_all_databases():
    """
    关闭所有数据库连接
    """
    global redis_client

    # PostgreSQL
    if engine:
        await engine.dispose()

    # Redis
    if redis_client:
        await redis_client.close()
        redis_client = None

    logger.info("All databases closed")
