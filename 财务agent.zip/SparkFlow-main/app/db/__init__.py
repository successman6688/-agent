"""Database models for SQLAlchemy ORM."""

from datetime import datetime
from uuid import uuid4

from sqlalchemy import DateTime, String, Text, Float, Integer, Boolean, JSON, Column, ForeignKey
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, relationship


class Base(DeclarativeBase):
    """Base class for all database models"""


# ============== Product Models ==============

class ProductDB(Base):
    """产品表"""
    __tablename__ = "products"

    id: Mapped[str] = mapped_column(UUID(as_uuid=True), primary_key=True, default=lambda: uuid4())
    name: Mapped[str] = mapped_column(String(200), nullable=False, index=True)
    type: Mapped[str] = mapped_column(String(50), nullable=False)
    description: Mapped[str] = mapped_column(Text, nullable=False)
    target_audience: Mapped[str] = mapped_column(String(200), nullable=False)

    # 营销信息
    selling_points: Mapped[list] = mapped_column(JSON, nullable=False, default=list)
    website_url: Mapped[str | None] = mapped_column(String(500))
    cta_text: Mapped[str | None] = mapped_column(String(200))
    cta_link: Mapped[str | None] = mapped_column(String(500))

    # 平台信息
    wechat_appid: Mapped[str | None] = mapped_column(String(100))
    wechat_path: Mapped[str | None] = mapped_column(String(500))
    app_store_url: Mapped[str | None] = mapped_column(String(500))
    google_play_url: Mapped[str | None] = mapped_column(String(500))
    yingyongbao_url: Mapped[str | None] = mapped_column(String(500))
    download_links: Mapped[dict] = mapped_column(JSON, default=dict)

    # 价格信息
    price: Mapped[str | None] = mapped_column(String(100))
    pricing_model: Mapped[str | None] = mapped_column(String(50))

    # 标签
    category: Mapped[str | None] = mapped_column(String(100))
    tags: Mapped[list[str]] = mapped_column(JSON, default=list)

    # 状态
    status: Mapped[str] = mapped_column(String(50), nullable=False, default="inactive")
    is_active: Mapped[bool] = mapped_column(Boolean, default=False, index=True)

    # 统计
    content_count: Mapped[int] = mapped_column(Integer, default=0)
    publish_count: Mapped[int] = mapped_column(Integer, default=0)

    # 时间戳
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)


# ============== Intelligence Models ==============

class IntelligenceTopicDB(Base):
    """情报主题表"""
    __tablename__ = "intelligence_topics"

    id: Mapped[str] = mapped_column(UUID(as_uuid=True), primary_key=True, default=lambda: uuid4())
    name: Mapped[str] = mapped_column(String(200), nullable=False, index=True)
    keywords: Mapped[list[str]] = mapped_column(JSON, nullable=False, default=list)
    description: Mapped[str | None] = mapped_column(Text)

    # 配置
    sources: Mapped[list] = mapped_column(JSON, nullable=False, default=list)  # SourceConfig
    schedule: Mapped[str] = mapped_column(String(50), nullable=False, default="daily")
    config: Mapped[dict] = mapped_column(JSON, nullable=False)  # TopicConfig
    is_active: Mapped[bool] = mapped_column(Boolean, default=True, index=True)

    # 统计
    total_items: Mapped[int] = mapped_column(Integer, default=0)
    today_items: Mapped[int] = mapped_column(Integer, default=0)
    weekly_items: Mapped[int] = mapped_column(Integer, default=0)

    # 运行状态
    last_run_time: Mapped[datetime | None] = mapped_column(DateTime)
    last_status: Mapped[str | None] = mapped_column(String(100))

    # 时间戳
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    # 关系
    items: Mapped[list["IntelligenceItemDB"]] = relationship("IntelligenceItemDB", back_populates="topic", cascade="all, delete-orphan")
    reports: Mapped[list["IntelligenceReportDB"]] = relationship("IntelligenceReportDB", back_populates="topic", cascade="all, delete-orphan")


class IntelligenceItemDB(Base):
    """情报项表"""
    __tablename__ = "intelligence_items"

    id: Mapped[str] = mapped_column(UUID(as_uuid=True), primary_key=True, default=lambda: uuid4())
    topic_id: Mapped[str] = mapped_column(UUID(as_uuid=True), ForeignKey("intelligence_topics.id", ondelete="CASCADE"), nullable=False, index=True)

    # 原始内容
    title: Mapped[str] = mapped_column(Text, nullable=False)
    content: Mapped[str] = mapped_column(Text, nullable=False)
    url: Mapped[str] = mapped_column(String(1000), nullable=False)
    source: Mapped[str] = mapped_column(String(200), nullable=False)
    author: Mapped[str | None] = mapped_column(String(200))

    # 元数据
    published_at: Mapped[datetime] = mapped_column(DateTime, nullable=False, index=True)
    collected_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)

    # 评分
    relevance_score: Mapped[float] = mapped_column(Float, default=0.0, index=True)
    timeliness_score: Mapped[float] = mapped_column(Float, default=0.0)
    authority_score: Mapped[float] = mapped_column(Float, default=0.0)
    overall_score: Mapped[float] = mapped_column(Float, default=0.0, index=True)

    # AI处理
    ai_summary: Mapped[str | None] = mapped_column(Text)
    key_insights: Mapped[list[str]] = mapped_column(JSON, default=list)
    tags: Mapped[list[str]] = mapped_column(JSON, default=list)

    # 去重标识
    guid: Mapped[str | None] = mapped_column(String(500), index=True)
    url_hash: Mapped[str] = mapped_column(String(64), nullable=False, index=True)
    content_hash: Mapped[str | None] = mapped_column(String(64))

    # 向量
    embedding_id: Mapped[str | None] = mapped_column("embedding_id", String(100))

    # 扩展元数据
    data_metadata: Mapped[dict] = mapped_column("data_metadata", JSON, default=dict)

    # 时间戳
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)

    # 关系
    topic: Mapped["IntelligenceTopicDB"] = relationship("IntelligenceTopicDB", back_populates="items")


class IntelligenceReportDB(Base):
    """情报报告表"""
    __tablename__ = "intelligence_reports"

    id: Mapped[str] = mapped_column(UUID(as_uuid=True), primary_key=True, default=lambda: uuid4())
    topic_id: Mapped[str] = mapped_column(UUID(as_uuid=True), ForeignKey("intelligence_topics.id", ondelete="CASCADE"), nullable=False, index=True)

    # 统计周期
    period_start: Mapped[datetime] = mapped_column(DateTime, nullable=False)
    period_end: Mapped[datetime] = mapped_column(DateTime, nullable=False)

    # 统计信息
    total_items: Mapped[int] = mapped_column(Integer, default=0)
    new_items: Mapped[int] = mapped_column(Integer, default=0)
    sources_breakdown: Mapped[dict] = mapped_column(JSON, default=dict)

    # AI分析
    summary: Mapped[str | None] = mapped_column(Text)
    key_trends: Mapped[list[str]] = mapped_column(JSON, default=list)
    hot_topics: Mapped[list[str]] = mapped_column(JSON, default=list)
    sentiment: Mapped[str | None] = mapped_column(String(50))

    # Top情报
    top_items: Mapped[list[str]] = mapped_column(JSON, default=list)

    # 时间戳
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)

    # 关系
    topic: Mapped["IntelligenceTopicDB"] = relationship("IntelligenceTopicDB", back_populates="reports")


# ============== Content Models (Future) ==============

class ContentDB(Base):
    """内容表（未来扩展）"""
    __tablename__ = "contents"

    id: Mapped[str] = mapped_column(UUID(as_uuid=True), primary_key=True, default=lambda: uuid4())
    title: Mapped[str] = mapped_column(String(500), nullable=False)
    body: Mapped[str] = mapped_column(Text, nullable=False)
    platform: Mapped[str] = mapped_column(String(50), nullable=False)  # twitter, reddit, blog, etc.
    status: Mapped[str] = mapped_column(String(50), default="draft")  # draft, pending_review, approved, published

    # 关联
    product_id: Mapped[str | None] = mapped_column(UUID(as_uuid=True), ForeignKey("products.id"))

    # 元数据
    report_metadata: Mapped[dict] = mapped_column("report_metadata", JSON, default=dict)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)


# ============== AI Prompt Evolution Models ==============

class PromptTemplateDB(Base):
    """提示词模板表"""
    __tablename__ = "prompt_templates"

    id: Mapped[str] = mapped_column(UUID(as_uuid=True), primary_key=True, default=lambda: uuid4())
    name: Mapped[str] = mapped_column(String(255), nullable=False)
    description: Mapped[str | None] = mapped_column(Text)

    # 分类
    strategy_type: Mapped[str] = mapped_column(String(50), nullable=False, index=True)  # finance/technology/startup/general
    category: Mapped[str] = mapped_column(String(100), default="default")

    # 模板内容
    system_prompt: Mapped[str] = mapped_column(Text, nullable=False)
    user_prompt_template: Mapped[str] = mapped_column(Text, nullable=False)
    output_schema: Mapped[dict] = mapped_column(JSON, nullable=False)

    # 变量定义
    variables: Mapped[list] = mapped_column(JSON, default=list)

    # 版本管理
    version: Mapped[str] = mapped_column(String(20), default="1.0")
    is_active: Mapped[bool] = mapped_column(Boolean, default=True, index=True)
    is_default: Mapped[bool] = mapped_column(Boolean, default=False)

    # 性能指标
    usage_count: Mapped[int] = mapped_column(Integer, default=0)
    success_rate: Mapped[float] = mapped_column(Float, default=0.0)
    avg_quality_score: Mapped[float] = mapped_column(Float, default=0.0)

    # 元数据
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    created_by: Mapped[str] = mapped_column(String(100), default="system")

    # 关系
    execution_logs: Mapped[list["PromptExecutionLogDB"]] = relationship("PromptExecutionLogDB", back_populates="template")


class PromptExecutionLogDB(Base):
    """提示词执行日志表"""
    __tablename__ = "prompt_execution_logs"

    id: Mapped[str] = mapped_column(UUID(as_uuid=True), primary_key=True, default=lambda: uuid4())
    template_id: Mapped[str] = mapped_column(UUID(as_uuid=True), ForeignKey("prompt_templates.id"), nullable=False)
    template_version: Mapped[str] = mapped_column(String(20), nullable=False)

    # 执行上下文
    topic_id: Mapped[str] = mapped_column(String(255), nullable=False)
    topic_name: Mapped[str | None] = mapped_column(String(255))
    strategy_type: Mapped[str] = mapped_column(String(50), nullable=False)

    # 输入输出
    variables_used: Mapped[dict] = mapped_column(JSON, nullable=False)
    llm_response: Mapped[str] = mapped_column(Text, nullable=False)
    parsed_result: Mapped[dict | None] = mapped_column(JSON)
    parse_success: Mapped[bool] = mapped_column(Boolean, nullable=False, index=True)

    # 性能指标
    response_time_ms: Mapped[float] = mapped_column(Float, nullable=False)
    token_count: Mapped[int | None] = mapped_column(Integer)

    # 反馈
    user_rating: Mapped[int | None] = mapped_column(Integer)
    user_feedback: Mapped[str | None] = mapped_column(Text)

    # 时间戳
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, index=True)

    # 关系
    template: Mapped["PromptTemplateDB"] = relationship("PromptTemplateDB", back_populates="execution_logs")


class UserFeedbackDB(Base):
    """用户反馈表"""
    __tablename__ = "user_feedbacks"

    id: Mapped[str] = mapped_column(UUID(as_uuid=True), primary_key=True, default=lambda: uuid4())

    # 关联
    item_id: Mapped[str] = mapped_column(String(255), nullable=False, index=True)
    prompt_id: Mapped[str] = mapped_column(String(255), nullable=False, index=True)

    # 反馈信息
    feedback_type: Mapped[str] = mapped_column(String(50), nullable=False)  # thumbs_up/thumbs_down/rating/useful/not_useful
    feedback_value: Mapped[dict | None] = mapped_column(JSON)  # 存储反馈值（评分、True/False等）

    # 用户信息
    user_id: Mapped[str | None] = mapped_column(String(255))
    session_id: Mapped[str | None] = mapped_column(String(255))  # 匿名用户的session_id

    # 元数据
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, index=True)
    ip_address: Mapped[str | None] = mapped_column(String(50))  # 可选：用于防止刷单


class PromptStatsDB(Base):
    """提示词统计汇总表（定期更新）"""
    __tablename__ = "prompt_stats"

    id: Mapped[str] = mapped_column(UUID(as_uuid=True), primary_key=True, default=lambda: uuid4())
    prompt_id: Mapped[str] = mapped_column(String(255), unique=True, nullable=False, index=True)

    # 统计数据
    total_score: Mapped[float] = mapped_column(Float, default=0.0)
    count: Mapped[int] = mapped_column(Integer, default=0)
    success_count: Mapped[int] = mapped_column(Integer, default=0)
    failure_count: Mapped[int] = mapped_column(Integer, default=0)

    # 细分统计
    thumbs_up_count: Mapped[int] = mapped_column(Integer, default=0)
    thumbs_down_count: Mapped[int] = mapped_column(Integer, default=0)
    avg_rating: Mapped[float | None] = mapped_column(Float)
    total_ratings: Mapped[int] = mapped_column(Integer, default=0)

    # 时间范围
    stats_date: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, index=True)

    # 元数据
    last_updated: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
