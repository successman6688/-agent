"""Repository pattern for database access."""

from typing import List, Optional, Type, TypeVar, Generic
from datetime import datetime
from uuid import UUID

from sqlalchemy import select, update, delete
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.logging import get_logger
from app.db import Base, ProductDB, IntelligenceTopicDB, IntelligenceItemDB, IntelligenceReportDB

logger = get_logger(__name__)

ModelType = TypeVar("ModelType", bound=Base)


class BaseRepository(Generic[ModelType]):
    """
    基础Repository

    提供通用的CRUD操作
    """

    def __init__(self, model: Type[ModelType]):
        """
        初始化Repository

        Args:
            model: SQLAlchemy模型类
        """
        self.model = model

    async def get(
        self,
        session: AsyncSession,
        id: UUID | str
    ) -> Optional[ModelType]:
        """
        根据ID获取对象

        Args:
            session: 数据库会话
            id: 对象ID

        Returns:
            对象，不存在返回None
        """
        result = await session.execute(
            select(self.model).where(self.model.id == id)
        )
        return result.scalar_one_or_none()

    async def list(
        self,
        session: AsyncSession,
        limit: int = 100,
        offset: int = 0,
        **filters
    ) -> List[ModelType]:
        """
        获取对象列表

        Args:
            session: 数据库会话
            limit: 限制数量
            offset: 偏移量
            **filters: 过滤条件

        Returns:
            对象列表
        """
        query = select(self.model)

        # 应用过滤
        for key, value in filters.items():
            if hasattr(self.model, key):
                query = query.where(getattr(self.model, key) == value)

        # 应用排序（按创建时间倒序）
        if hasattr(self.model, "created_at"):
            query = query.order_by(self.model.created_at.desc())

        # 应用分页
        query = query.limit(limit).offset(offset)

        result = await session.execute(query)
        return list(result.scalars().all())

    async def create(
        self,
        session: AsyncSession,
        **data
    ) -> ModelType:
        """
        创建对象

        Args:
            session: 数据库会话
            **data: 对象数据

        Returns:
            创建的对象
        """
        obj = self.model(**data)
        session.add(obj)
        await session.flush()
        logger.info(f"Created {self.model.__name__}: {obj.id}")
        return obj

    async def update(
        self,
        session: AsyncSession,
        id: UUID | str,
        **data
    ) -> Optional[ModelType]:
        """
        更新对象

        Args:
            session: 数据库会话
            id: 对象ID
            **data: 更新数据

        Returns:
            更新后的对象，不存在返回None
        """
        # 排除None值
        update_data = {k: v for k, v in data.items() if v is not None}

        result = await session.execute(
            update(self.model)
            .where(self.model.id == id)
            .values(**update_data)
            .returning(self.model)
        )
        obj = result.scalar_one_or_none()

        if obj:
            await session.flush()
            logger.info(f"Updated {self.model.__name__}: {id}")

        return obj

    async def delete(
        self,
        session: AsyncSession,
        id: UUID | str
    ) -> bool:
        """
        删除对象

        Args:
            session: 数据库会话
            id: 对象ID

        Returns:
            是否删除成功
        """
        result = await session.execute(
            delete(self.model).where(self.model.id == id)
        )
        success = result.rowcount > 0

        if success:
            await session.flush()
            logger.info(f"Deleted {self.model.__name__}: {id}")

        return success

    async def count(
        self,
        session: AsyncSession,
        **filters
    ) -> int:
        """
        统计对象数量

        Args:
            session: 数据库会话
            **filters: 过滤条件

        Returns:
            对象数量
        """
        query = select(self.model)

        for key, value in filters.items():
            if hasattr(self.model, key):
                query = query.where(getattr(self.model, key) == value)

        result = await session.execute(query)
        return len(result.all())


class ProductRepository(BaseRepository[ProductDB]):
    """产品Repository"""

    def __init__(self):
        super().__init__(ProductDB)

    async def get_active(self, session: AsyncSession) -> Optional[ProductDB]:
        """获取当前激活的产品"""
        result = await session.execute(
            select(ProductDB)
            .where(ProductDB.is_active == True)
            .order_by(ProductDB.updated_at.desc())
            .limit(1)
        )
        return result.scalar_one_or_none()

    async def set_active(
        self,
        session: AsyncSession,
        id: UUID | str
    ) -> Optional[ProductDB]:
        """
        设置激活产品

        Args:
            session: 数据库会话
            id: 产品ID

        Returns:
            激活的产品
        """
        # 取消之前的激活产品
        await session.execute(
            update(ProductDB)
            .where(ProductDB.is_active == True)
            .values(is_active=False)
        )

        # 激活新产品
        return await self.update(session, id, is_active=True, status="active")

    async def clear_active(self, session: AsyncSession) -> None:
        """清除激活产品"""
        await session.execute(
            update(ProductDB)
            .where(ProductDB.is_active == True)
            .values(is_active=False, status="inactive")
        )


class IntelligenceTopicRepository(BaseRepository[IntelligenceTopicDB]):
    """情报主题Repository"""

    def __init__(self):
        super().__init__(IntelligenceTopicDB)

    async def get_active(self, session: AsyncSession) -> List[IntelligenceTopicDB]:
        """获取所有激活的主题"""
        return await self.list(session, is_active=True)


class IntelligenceItemRepository(BaseRepository[IntelligenceItemDB]):
    """情报项Repository"""

    def __init__(self):
        super().__init__(IntelligenceItemDB)

    async def get_by_topic(
        self,
        session: AsyncSession,
        topic_id: UUID | str,
        limit: int = 100,
        min_score: float = 0.0,
        offset: int = 0,
    ) -> List[IntelligenceItemDB]:
        """
        获取主题的情报项

        Args:
            session: 数据库会话
            topic_id: 主题ID
            limit: 限制数量
            min_score: 最小评分
            offset: 偏移量

        Returns:
            情报项列表
        """
        query = (
            select(IntelligenceItemDB)
            .where(IntelligenceItemDB.topic_id == topic_id)
            .where(IntelligenceItemDB.overall_score >= min_score)
            .order_by(IntelligenceItemDB.overall_score.desc())
        )

        result = await session.execute(query.limit(limit).offset(offset))
        return list(result.scalars().all())

    async def count_by_topic(
        self,
        session: AsyncSession,
        topic_id: UUID | str
    ) -> int:
        """统计主题的情报数量"""
        return await self.count(session, topic_id=topic_id)


class IntelligenceReportRepository(BaseRepository[IntelligenceReportDB]):
    """情报报告Repository"""

    def __init__(self):
        super().__init__(IntelligenceReportDB)

    async def get_latest_by_topic(
        self,
        session: AsyncSession,
        topic_id: UUID | str
    ) -> Optional[IntelligenceReportDB]:
        """获取主题的最新报告"""
        result = await session.execute(
            select(IntelligenceReportDB)
            .where(IntelligenceReportDB.topic_id == topic_id)
            .order_by(IntelligenceReportDB.created_at.desc())
            .limit(1)
        )
        return result.scalar_one_or_none()


# ============== Global Repository Instances ==============

product_repository = ProductRepository()
intelligence_topic_repository = IntelligenceTopicRepository()
intelligence_item_repository = IntelligenceItemRepository()
intelligence_report_repository = IntelligenceReportRepository()
