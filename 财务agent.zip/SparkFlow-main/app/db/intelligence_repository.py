"""异步数据库访问层 - 用于情报管理"""

from typing import List, Optional, Dict, Any
from datetime import datetime, timedelta
from uuid import UUID

from sqlalchemy import select, and_, desc, func, update, delete
from sqlalchemy.ext.asyncio import AsyncSession

from app.db import IntelligenceTopicDB, IntelligenceItemDB, IntelligenceReportDB
from app.models.intelligence import (
    IntelligenceTopic,
    IntelligenceItem,
    IntelligenceReport,
    IntelligenceTopicCreate,
    IntelligenceTopicUpdate,
    SourceConfig,
    ScheduleType,
    TopicConfig,
    CollectionResponse
)
from app.core.logging import get_logger

logger = get_logger(__name__)


class IntelligenceRepository:
    """情报仓储（异步数据库访问）"""

    def __init__(self, session: AsyncSession):
        self.session = session

    def _convert_datetime_fields(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """
        转换带时区的 datetime 为 naive datetime（去掉时区信息）
        并截断过长的字段以适应数据库限制
        """
        # 转换时区
        datetime_fields = ['published_at', 'collected_at', 'created_at', 'updated_at', 'last_run_time']
        for field in datetime_fields:
            if field in data and isinstance(data[field], datetime):
                if data[field].tzinfo is not None:
                    data[field] = data[field].replace(tzinfo=None)

        # 截断过长的字段
        # guid 字段限制 500 字符
        if data.get('guid') and len(data['guid']) > 500:
            data['guid'] = data['guid'][:500]

        # url 字段限制 1000 字符
        if data.get('url') and len(data['url']) > 1000:
            data['url'] = data['url'][:1000]

        # author 字段限制 200 字符
        if data.get('author') and len(data['author']) > 200:
            data['author'] = data['author'][:200]

        return data

    # ============== Topic Operations ==============

    async def create_topic(self, topic_data: Dict[str, Any]) -> IntelligenceTopicDB:
        """创建新主题"""
        # 转换带时区的 datetime 为 naive datetime
        topic_data = self._convert_datetime_fields(topic_data)
        db_topic = IntelligenceTopicDB(**topic_data)
        self.session.add(db_topic)
        await self.session.commit()
        await self.session.refresh(db_topic)
        logger.info(f"Created topic: {db_topic.name}")
        return db_topic

    async def get_topic(self, topic_id: str) -> Optional[IntelligenceTopicDB]:
        """根据ID获取主题"""
        result = await self.session.execute(
            select(IntelligenceTopicDB).where(IntelligenceTopicDB.id == topic_id)
        )
        return result.scalar_one_or_none()

    async def list_topics(self) -> List[IntelligenceTopicDB]:
        """列出所有主题"""
        result = await self.session.execute(
            select(IntelligenceTopicDB).order_by(desc(IntelligenceTopicDB.created_at))
        )
        return list(result.scalars().all())

    async def update_topic(self, topic_id: str, update_data: Dict[str, Any]) -> Optional[IntelligenceTopicDB]:
        """更新主题"""
        # 转换带时区的 datetime 为 naive datetime
        update_data = self._convert_datetime_fields(update_data)
        # 只更新提供的字段
        stmt = (
            update(IntelligenceTopicDB)
            .where(IntelligenceTopicDB.id == topic_id)
            .values(**update_data)
            .returning(IntelligenceTopicDB)
        )
        result = await self.session.execute(stmt)
        await self.session.commit()

        return result.scalar_one_or_none()

    async def delete_topic(self, topic_id: str) -> bool:
        """删除主题（级联删除关联的items和reports）"""
        stmt = delete(IntelligenceTopicDB).where(IntelligenceTopicDB.id == topic_id)
        result = await self.session.execute(stmt)
        await self.session.commit()
        return result.rowcount > 0

    async def update_topic_stats(
        self,
        topic_id: str,
        total_items: int,
        today_items: int,
        last_run_time: datetime,
        last_status: str
    ):
        """更新主题统计信息"""
        await self.update_topic(topic_id, {
            "total_items": total_items,
            "today_items": today_items,
            "last_run_time": last_run_time,
            "last_status": last_status,
            "updated_at": datetime.utcnow()
        })

    # ============== Item Operations ==============

    async def create_item(self, item_data: Dict[str, Any]) -> IntelligenceItemDB:
        """创建新情报项"""
        # 过滤掉数据库模型中不存在的字段（如 sentiment）
        filtered_data = {k: v for k, v in item_data.items() if k != 'sentiment'}

        # 转换带时区的 datetime 为 naive datetime（去掉时区信息）
        filtered_data = self._convert_datetime_fields(filtered_data)

        db_item = IntelligenceItemDB(**filtered_data)
        self.session.add(db_item)
        await self.session.commit()
        await self.session.refresh(db_item)
        return db_item

    async def create_items(self, items_data: List[Dict[str, Any]]) -> int:
        """批量创建情报项"""
        # 过滤掉数据库模型中不存在的字段（如 sentiment）
        # 并转换带时区的 datetime 为 naive datetime
        filtered_data_list = []
        for data in items_data:
            filtered = {k: v for k, v in data.items() if k != 'sentiment'}
            filtered = self._convert_datetime_fields(filtered)
            filtered_data_list.append(filtered)

        db_items = [IntelligenceItemDB(**data) for data in filtered_data_list]
        self.session.add_all(db_items)
        await self.session.commit()
        logger.info(f"Created {len(db_items)} items")
        return len(db_items)

    async def get_item(self, item_id: str) -> Optional[IntelligenceItemDB]:
        """根据ID获取情报项"""
        result = await self.session.execute(
            select(IntelligenceItemDB).where(IntelligenceItemDB.id == item_id)
        )
        return result.scalar_one_or_none()

    async def get_items_by_topic(
        self,
        topic_id: str,
        date: Optional[str] = None,
        limit: int = 100,
        min_score: float = 0.0
    ) -> List[IntelligenceItemDB]:
        """
        获取主题的情报项

        Args:
            topic_id: 主题ID
            date: 日期（YYYY-MM-DD），默认今天
            limit: 最大数量
            min_score: 最低相关性分数
        """
        query = select(IntelligenceItemDB).where(
            and_(
                IntelligenceItemDB.topic_id == topic_id,
                IntelligenceItemDB.overall_score >= min_score
            )
        )

        # 如果指定了日期，过滤该日期
        if date:
            target_date = datetime.strptime(date, "%Y-%m-%d").date()
            next_date = target_date + timedelta(days=1)
            query = query.where(
                and_(
                    IntelligenceItemDB.published_at >= target_date,
                    IntelligenceItemDB.published_at < next_date
                )
            )

        # 按发布时间倒序，取前N条
        query = query.order_by(desc(IntelligenceItemDB.published_at)).limit(limit)

        result = await self.session.execute(query)
        return list(result.scalars().all())

    async def get_item_count_by_topic(self, topic_id: str) -> int:
        """获取主题的情报项总数"""
        result = await self.session.execute(
            select(func.count(IntelligenceItemDB.id))
            .where(IntelligenceItemDB.topic_id == topic_id)
        )
        return result.scalar() or 0

    async def get_today_item_count(self, topic_id: str) -> int:
        """获取主题今天的情报项数量"""
        today = datetime.utcnow().date()
        tomorrow = today + timedelta(days=1)

        result = await self.session.execute(
            select(func.count(IntelligenceItemDB.id))
            .where(
                and_(
                    IntelligenceItemDB.topic_id == topic_id,
                    IntelligenceItemDB.published_at >= today,
                    IntelligenceItemDB.published_at < tomorrow
                )
            )
        )
        return result.scalar() or 0

    async def check_url_exists(self, topic_id: str, url_hash: str) -> bool:
        """检查URL是否已存在（去重）"""
        result = await self.session.execute(
            select(IntelligenceItemDB)
            .where(
                and_(
                    IntelligenceItemDB.topic_id == topic_id,
                    IntelligenceItemDB.url_hash == url_hash
                )
            )
            .limit(1)
        )
        return result.scalar_one_or_none() is not None

    async def check_guid_exists(self, topic_id: str, guid: str) -> bool:
        """检查GUID是否已存在（去重）"""
        if not guid:
            return False
        result = await self.session.execute(
            select(IntelligenceItemDB)
            .where(
                and_(
                    IntelligenceItemDB.topic_id == topic_id,
                    IntelligenceItemDB.guid == guid
                )
            )
            .limit(1)
        )
        return result.scalar_one_or_none() is not None

    # ============== Report Operations ==============

    async def create_report(self, report_data: Dict[str, Any]) -> IntelligenceReportDB:
        """创建新报告"""
        db_report = IntelligenceReportDB(**report_data)
        self.session.add(db_report)
        await self.session.commit()
        await self.session.refresh(db_report)
        return db_report

    async def get_latest_report(self, topic_id: str) -> Optional[IntelligenceReportDB]:
        """获取主题的最新报告"""
        result = await self.session.execute(
            select(IntelligenceReportDB)
            .where(IntelligenceReportDB.topic_id == topic_id)
            .order_by(desc(IntelligenceReportDB.created_at))
            .limit(1)
        )
        return result.scalar_one_or_none()

    async def get_reports_by_topic(
        self,
        topic_id: str,
        limit: int = 10
    ) -> List[IntelligenceReportDB]:
        """获取主题的报告列表"""
        result = await self.session.execute(
            select(IntelligenceReportDB)
            .where(IntelligenceReportDB.topic_id == topic_id)
            .order_by(desc(IntelligenceReportDB.created_at))
            .limit(limit)
        )
        return list(result.scalars().all())

    # ============== Statistics ==============

    async def get_topic_statistics(self, topic_id: str) -> Dict[str, Any]:
        """获取主题统计信息"""
        total = await self.get_item_count_by_topic(topic_id)
        today = await self.get_today_item_count(topic_id)

        # 计算本周数量
        week_ago = datetime.utcnow() - timedelta(days=7)
        result = await self.session.execute(
            select(func.count(IntelligenceItemDB.id))
            .where(
                and_(
                    IntelligenceItemDB.topic_id == topic_id,
                    IntelligenceItemDB.published_at >= week_ago
                )
            )
        )
        weekly = result.scalar() or 0

        return {
            "total_items": total,
            "today_items": today,
            "weekly_items": weekly
        }
