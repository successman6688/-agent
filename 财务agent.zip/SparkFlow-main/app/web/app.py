"""SparkFlow Web Application - Streamlit Interface (中文版)."""

import streamlit as st
from datetime import datetime
from typing import List, Dict, Any

from app.models.content import (
    ProductConfig,
    Topic,
    Content,
    Platform,
    ContentStatus
)

# 导入产品管理模块
from app.web.product_pages import (
    render_product_list,
    render_product_form,
    render_product_detail
)
from app.services.product_service import get_active_product_for_streamlit

# ==============================================================================
# 页面配置
# ==============================================================================

st.set_page_config(
    page_title="SparkFlow - AI 营销自动化",
    page_icon="🚀",
    layout="wide",
    initial_sidebar_state="expanded"
)

# 自定义 CSS
st.markdown("""
<style>
    .main-header {
        font-size: 2.5rem;
        font-weight: 700;
        color: #1f77b4;
        margin-bottom: 1rem;
    }
    .metric-card {
        background: #f0f2f6;
        padding: 1rem;
        border-radius: 0.5rem;
        margin: 0.5rem 0;
    }
    .success-box {
        padding: 1rem;
        background-color: #d4edda;
        border: 1px solid #c3e6cb;
        border-radius: 0.25rem;
        color: #155724;
    }
</style>
""", unsafe_allow_html=True)


# ==============================================================================
# 会话状态初始化
# ==============================================================================

def init_session_state():
    """初始化会话状态变量（简化版 - 不依赖URL参数）。"""
    # 初始化基本状态
    if "product_config" not in st.session_state:
        st.session_state.product_config = None

    if "topics" not in st.session_state:
        st.session_state.topics = []

    if "contents" not in st.session_state:
        st.session_state.contents = []

    if "publications" not in st.session_state:
        st.session_state.publications = []

    # 页面状态初始化
    if "current_page" not in st.session_state:
        st.session_state.current_page = "dashboard"

    # 产品管理相关状态
    if "product_page" not in st.session_state:
        st.session_state.product_page = "list"  # list, add, edit, detail

    if "detail_product_id" not in st.session_state:
        st.session_state.detail_product_id = None

    if "product_name" not in st.session_state:
        st.session_state.product_name = None

    if "editing_product_id" not in st.session_state:
        st.session_state.editing_product_id = None


def update_url_params():
    """（暂时禁用）URL参数更新功能在Streamlit 1.54中有bug。"""
    # Streamlit 1.54 的 st.query_params 不会更新浏览器 URL
    # 暂时移除此功能，完全使用 session_state
    pass


init_session_state()


# ==============================================================================
# 模拟数据函数（用于演示）
# ==============================================================================

def get_mock_topics() -> List[Dict[str, Any]]:
    """获取模拟热点话题。"""
    return [
        {
            "title": "AI Agent 正在彻底改变营销自动化",
            "source": "hackernews",
            "viral_score": 85,
            "relevance_score": 90,
            "description": "关于 AI Agent 如何改变营销工作流程的讨论"
        },
        {
            "title": "2024年独立开发者最佳生产力工具",
            "source": "reddit",
            "viral_score": 72,
            "relevance_score": 85,
            "description": "Reddit 上关于独立开发者生产力工具的讨论"
        },
        {
            "title": "如何用 AI 自动化创业公司的增长",
            "source": "twitter",
            "viral_score": 78,
            "relevance_score": 88,
            "description": "关于 AI 驱动的增长自动化的热门推文"
        }
    ]


def get_mock_content() -> List[Dict[str, Any]]:
    """获取模拟生成内容。"""
    return [
        {
            "platform": "twitter",
            "content": "🚀 刚发现了一个用 AI 自动化营销的神奇方法！\n\n如果你厌倦了花几个小时创作内容，一定要看看这个。它对我的创业公司来说是颠覆性的。\n\n#AI #营销 #自动化 #创业",
            "status": "approved",
            "created_at": datetime.now()
        },
        {
            "platform": "reddit",
            "title": "我是如何用 AI 自动化整个营销流程的",
            "content": "大家好，\n\n我想分享一下我是如何从每周花 10+ 小时在营销上，到现在几乎零投入，但效果反而更好...\n\n[完整内容会在这里]",
            "status": "pending_review",
            "created_at": datetime.now()
        }
    ]


# ==============================================================================
# 页面组件
# ==============================================================================

def render_dashboard():
    """渲染仪表盘页面。"""
    st.markdown('<h1 class="main-header">📊 数据仪表盘</h1>', unsafe_allow_html=True)

    # 指标数据
    col1, col2, col3, col4 = st.columns(4)

    with col1:
        st.metric(
            label="话题总数",
            value="12",
            delta="+3 今天"
        )

    with col2:
        st.metric(
            label="已生成内容",
            value="24",
            delta="+5 今天"
        )

    with col3:
        st.metric(
            label="已发布",
            value="18",
            delta="+2 今天"
        )

    with col4:
        st.metric(
            label="互动率",
            value="4.2%",
            delta="+0.8%"
        )

    st.markdown("---")

    # 最近活动
    col1, col2 = st.columns(2)

    with col1:
        st.subheader("🔥 热门话题")
        topics = get_mock_topics()
        for i, topic in enumerate(topics[:5], 1):
            with st.expander(f"{i}. {topic['title']}"):
                st.write(f"**来源**: {topic['source']}")
                st.write(f"**传播分数**: {topic['viral_score']}/100")
                st.write(f"**相关度**: {topic['relevance_score']}/100")
                st.write(f"**描述**: {topic['description']}")

    with col2:
        st.subheader("📝 最近内容")
        contents = get_mock_content()
        for content in contents[:5]:
            st.markdown(f"**平台**: {content['platform'].upper()}")
            st.markdown(f"**状态**: :green[{content['status']}]")
            st.markdown(f"**内容**: {content['content'][:100]}...")
            st.markdown("---")


def render_product_config():
    """渲染产品配置页面。"""
    st.markdown('<h1 class="main-header">⚙️ 产品配置</h1>', unsafe_allow_html=True)

    st.info("👋 配置你的产品信息，这些信息将用于生成营销内容。")

    with st.form("product_config_form"):
        st.subheader("基本信息")

        col1, col2 = st.columns(2)

        with col1:
            product_name = st.text_input(
                "产品名称*",
                value="SparkFlow",
                help="你的产品或服务名称"
            )

            target_audience = st.text_input(
                "目标用户*",
                value="独立开发者和创业团队",
                help="你想触达谁？"
            )

            website_url = st.text_input(
                "网站地址",
                placeholder="https://yourproduct.com"
            )

        with col2:
            product_desc = st.text_area(
                "产品描述*",
                value="AI 驱动的营销自动化平台",
                help="简要描述你的产品",
                height=100
            )

        st.subheader("产品卖点")
        st.write("输入你的核心卖点（每行一个）：")
        selling_points = st.text_area(
            "产品卖点",
            value="自动内容生成\n多平台发布\nAI 驱动优化",
            height=120,
            help="你的产品有什么独特之处？"
        )

        st.subheader("行动号召")
        col1, col2 = st.columns(2)

        with col1:
            cta_text = st.text_input(
                "CTA 文本",
                value="免费试用",
                help="按钮文字"
            )

        with col2:
            cta_link = st.text_input(
                "CTA 链接",
                value="https://sparkflow.example.com/signup",
                help="用户应该去哪里"
            )

        st.subheader("附加信息")
        col1, col2 = st.columns(2)

        with col1:
            category = st.text_input(
                "分类",
                placeholder="例如：SaaS、生产力工具、营销"
            )

        with col2:
            tags_input = st.text_input(
                "标签（逗号分隔）",
                placeholder="AI、营销、自动化"
            )

        submitted = st.form_submit_button("💾 保存配置", type="primary")

        if submitted:
            # 解析卖点
            points_list = [p.strip() for p in selling_points.split('\n') if p.strip()]
            tags_list = [t.strip() for t in tags_input.split(',') if t.strip()] if tags_input else []

            # 创建产品配置
            config = ProductConfig(
                name=product_name,
                description=product_desc,
                target_audience=target_audience,
                selling_points=points_list,
                website_url=website_url,
                cta_text=cta_text,
                cta_link=cta_link,
                category=category,
                tags=tags_list
            )

            st.session_state.product_config = config

            st.markdown('<div class="success-box">✅ 配置保存成功！</div>', unsafe_allow_html=True)

            st.json(config.model_dump())


def render_topics():
    """渲染话题页面。"""
    st.markdown('<h1 class="main-header">🔥 热门话题</h1>', unsafe_allow_html=True)

    st.info("👀 发现与你产品相关的热门话题")

    # 筛选器
    col1, col2, col3 = st.columns(3)

    with col1:
        source_filter = st.multiselect(
            "来源",
            ["twitter", "reddit", "hackernews"],
            default=["twitter", "reddit", "hackernews"]
        )

    with col2:
        min_viral = st.slider("最低传播分数", 0, 100, 50)

    with col3:
        min_relevance = st.slider("最低相关度", 0, 100, 50)

    # 刷新按钮
    if st.button("🔄 刷新话题"):
        st.session_state.topics = get_mock_topics()
        st.success("话题已刷新！")

    # 显示话题
    if not st.session_state.topics:
        st.session_state.topics = get_mock_topics()

    st.subheader(f"找到 {len(st.session_state.topics)} 个相关话题")

    for i, topic in enumerate(st.session_state.topics, 1):
        with st.expander(f"{i}. {topic['title']}"):
            col1, col2, col3 = st.columns(3)

            with col1:
                st.metric("传播分数", f"{topic['viral_score']}/100")

            with col2:
                st.metric("相关度", f"{topic['relevance_score']}/100")

            with col3:
                st.metric("来源", topic['source'].upper())

            st.write(f"**描述**: {topic.get('description', '暂无')}")

            col1, col2 = st.columns(2)

            with col1:
                if st.button(f"📝 生成内容", key=f"generate_{i}"):
                    st.session_state.current_page = "generate"
                    st.rerun()

            with col2:
                if st.button(f"❌ 忽略", key=f"dismiss_{i}"):
                    st.success("话题已忽略")


def render_content_generator():
    """渲染内容生成页面。"""
    st.markdown('<h1 class="main-header">📝 内容生成</h1>', unsafe_allow_html=True)

    if not st.session_state.product_config:
        st.warning("⚠️ 请先配置你的产品信息！")
        st.info("前往 **产品配置** 页面设置产品信息。")
        return

    st.info("✅ 产品已配置")
    st.json(st.session_state.product_config.model_dump())

    st.markdown("---")

    # 选择话题
    st.subheader("选择话题")
    topics = get_mock_topics()

    topic_options = {f"{t['title']} ({t['source']})": t for t in topics}
    selected_topic_name = st.selectbox("选择要生成内容的话题：", list(topic_options.keys()))
    selected_topic = topic_options[selected_topic_name]

    # 选择平台
    st.subheader("选择发布平台")
    platform_names = {
        Platform.TWITTER: "推特 (Twitter)",
        Platform.REDDIT: "Reddit",
        Platform.BLOG: "博客"
    }
    platforms = st.multiselect(
        "要发布到哪些平台？",
        [Platform.TWITTER, Platform.REDDIT, Platform.BLOG],
        default=[Platform.TWITTER],
        format_func=lambda x: platform_names.get(x, x.value)
    )

    # 内容变体数量
    st.subheader("内容变体")
    num_variants = st.slider("生成内容变体数量", 1, 5, 3)

    # 生成按钮
    st.markdown("---")
    if st.button(f"✨ 生成 {num_variants} 个内容版本", type="primary"):
        with st.spinner("🤖 AI 正在生成内容..."):
            import time
            time.sleep(2)  # 模拟 AI 生成

        st.success(f"✅ 已生成 {num_variants} 个内容版本！")

        # 显示生成的内容
        for i in range(num_variants):
            st.markdown(f"### 版本 {i+1}")

            tabs = st.tabs([platform_names.get(p, p.value.upper()) for p in platforms])

            for tab, platform in zip(tabs, platforms):
                with tab:
                    if platform == Platform.TWITTER:
                        content = f"""🚀 {selected_topic['title']}

如果你是 {st.session_state.product_config.target_audience}，这对你很重要：

{st.session_state.product_config.name} 能帮你：
✓ {st.session_state.product_config.selling_points[0]}
✓ {st.session_state.product_config.selling_points[1]}
✓ {st.session_state.product_config.selling_points[2]}

👉 {st.session_state.product_config.cta_text}：{st.session_state.product_config.cta_link}

#AI #营销 #自动化"""

                        st.text_area(
                            "内容",
                            content,
                            height=200,
                            key=f"content_{i}_{platform}_twitter"
                        )

                    elif platform == Platform.REDDIT:
                        content = f"""## {selected_topic['title']}

大家好，

我想分享一些对 {st.session_state.product_config.target_audience} 非常有帮助的东西。

**问题所在**
{selected_topic['description']}

**解决方案**
我一直在使用 {st.session_state.product_config.name} - {st.session_state.product_config.description}。

主要优势：
- {st.session_state.product_config.selling_points[0]}
- {st.session_state.product_config.selling_points[1]}
- {st.session_state.product_config.selling_points[2]}

**效果**
使用以来，我节省了数小时的手工工作，但获得了更好的互动效果。

如果你有兴趣：{st.session_state.product_config.cta_link}

大家都在用什么工具做营销自动化？"""

                        st.text_area(
                            "内容",
                            content,
                            height=300,
                            key=f"content_{i}_{platform}_reddit"
                        )

                    elif platform == Platform.BLOG:
                        content = f"""# {selected_topic['title']}

## 为什么 {st.session_state.product_config.target_audience} 需要关注

在当今快节奏的环境中，{st.session_state.product_config.target_audience} 面临着前所未有的挑战。

## {st.session_state.product_config.name} 如何提供帮助

{st.session_state.product_config.description} 是一个专为 {st.session_state.product_config.target_audience} 设计的解决方案。

### 核心优势

1. **{st.session_state.product_config.selling_points[0]}**
   详细说明...

2. **{st.session_state.product_config.selling_points[1]}**
   详细说明...

3. **{st.session_state.product_config.selling_points[2]}**
   详细说明...

## 开始使用

{st.session_state.product_config.cta_text}：{st.session_state.product_config.cta_link}"""

                        st.text_area(
                            "内容",
                            content,
                            height=400,
                            key=f"content_{i}_{platform}_blog"
                        )

            col1, col2, col3 = st.columns(3)

            with col1:
                if st.button(f"✅ 批准版本 {i+1}", key=f"approve_{i}"):
                    st.success("版本已批准，准备发布！")

            with col2:
                if st.button(f"✏️ 编辑版本 {i+1}", key=f"edit_{i}"):
                    st.info("编辑模式已启用")

            with col3:
                if st.button(f"🗑️ 删除版本 {i+1}", key=f"delete_{i}"):
                    st.warning("版本已删除")

            st.markdown("---")


def render_publish():
    """渲染发布页面。"""
    st.markdown('<h1 class="main-header">🚀 内容发布</h1>', unsafe_allow_html=True)

    st.info("审核并批准内容进行发布")

    # 筛选器
    status_filter = st.selectbox(
        "按状态筛选",
        ["全部", "待审核", "已批准", "已发布"]
    )

    # 模拟已批准内容
    approved_contents = get_mock_content()

    if not approved_contents:
        st.warning("没有待发布内容。请先生成一些内容！")
        return

    st.subheader(f"待发布：{len(approved_contents)} 项")

    for i, content in enumerate(approved_contents):
        platform_name = {
            "twitter": "推特",
            "reddit": "Reddit",
            "blog": "博客"
        }.get(content['platform'], content['platform'])

        with st.expander(f"{platform_name} - {content['created_at'].strftime('%Y-%m-%d %H:%M')}"):
            if content.get('title'):
                st.markdown(f"**标题**: {content['title']}")

            st.text_area(
                "内容",
                content['content'],
                height=150,
                key=f"publish_content_{i}",
                disabled=True
            )

            col1, col2, col3 = st.columns(3)

            with col1:
                if st.button(f"🚀 立即发布", key=f"publish_{i}"):
                    with st.spinner(f"正在发布到 {platform_name}..."):
                        import time
                        time.sleep(1)
                    st.success(f"✅ 已发布到 {platform_name}！")

            with col2:
                schedule_time = st.time_input(
                    "定时发布",
                    key=f"schedule_{i}"
                )

            with col3:
                if st.button(f"📅 安排发布", key=f"schedule_btn_{i}"):
                    st.success(f"已安排在 {schedule_time} 发布")

            st.markdown("---")


def render_analytics():
    """渲染分析页面。"""
    st.markdown('<h1 class="main-header">📈 数据分析</h1>', unsafe_allow_html=True)

    # 日期范围
    col1, col2 = st.columns(2)

    with col1:
        start_date = st.date_input("开始日期")

    with col2:
        end_date = st.date_input("结束日期")

    # 总结指标
    st.subheader("整体表现")

    col1, col2, col3, col4 = st.columns(4)

    with col1:
        st.metric("总曝光量", "12,450", "+2,340")

    with col2:
        st.metric("总互动", "892", "+156")

    with col3:
        st.metric("平均互动率", "7.2%", "+1.1%")

    with col4:
        st.metric("总点击", "234", "+45")

    st.markdown("---")

    # 平台细分
    st.subheader("各平台表现")

    platforms_data = {
        "推特": {
            "impressions": 8450,
            "engagement": 567,
            "rate": 6.7,
            "clicks": 145
        },
        "Reddit": {
            "impressions": 3200,
            "engagement": 289,
            "rate": 9.0,
            "clicks": 67
        },
        "博客": {
            "impressions": 800,
            "engagement": 36,
            "rate": 4.5,
            "clicks": 22
        }
    }

    for platform, data in platforms_data.items():
        with st.expander(f"📊 {platform}"):
            col1, col2, col3, col4 = st.columns(4)

            with col1:
                st.metric("曝光量", f"{data['impressions']:,}")

            with col2:
                st.metric("互动数", f"{data['engagement']:,}")

            with col3:
                st.metric("互动率", f"{data['rate']}%")

            with col4:
                st.metric("点击数", f"{data['clicks']:,}")


# ==============================================================================
# 侧边栏导航
# ==============================================================================

def render_sidebar():
    """渲染侧边栏导航（支持URL参数恢复）。"""
    with st.sidebar:
        st.markdown("# 🚀 SparkFlow")
        st.markdown("---")

        # 页面选项列表
        page_options = [
            "📊 数据仪表盘",
            "📦 产品管理",
            "🔥 热门话题",
            "📝 内容生成",
            "🚀 内容发布",
            "📈 数据分析"
        ]

        # 从 session_state 获取当前页面，确定初始索引
        current_page = st.session_state.get("current_page", "dashboard")

        # 映射英文标识到中文显示名称
        page_map = {
            "dashboard": "📊 数据仪表盘",
            "products": "📦 产品管理",
            "topics": "🔥 热门话题",
            "content": "📝 内容生成",
            "publish": "🚀 内容发布",
            "analytics": "📈 数据分析"
        }

        # 根据当前页面确定初始索引
        default_index = 0
        if current_page in page_map:
            default_index = page_options.index(page_map[current_page])

        # 渲染导航菜单
        page = st.radio(
            "导航菜单",
            page_options,
            index=default_index,
            key="sidebar_navigation"  # 固定 key，widget state 会在页面改变时被清除
        )

        # 更新 session_state
        if page:
            # 反向映射：从中文名称到英文标识
            reverse_map = {v: k for k, v in page_map.items()}
            st.session_state.current_page = reverse_map.get(page, "dashboard")

        st.markdown("---")

        # 快速统计
        st.subheader("快速统计")
        st.metric("今日话题", "12", "+3")
        st.metric("已生成内容", "24", "+5")
        st.metric("已发布", "18", "+2")

        st.markdown("---")

        # 当前激活产品
        active_product = st.runtime.function(get_active_product_for_streamlit)()

        if active_product:
            st.subheader("⭐ 当前产品")
            st.text(active_product.name)
            st.caption(f"{active_product.type_label}")
        else:
            st.warning("⚠️ 未激活产品\n请到产品管理激活")

    return page


# ==============================================================================
# 主应用
# ==============================================================================

def main():
    """主应用入口。"""
    # 渲染侧边栏（会更新 session_state.current_page）
    page = render_sidebar()

    # 更新URL参数以反映当前状态（在侧边栏之后调用，以捕获最新的状态）
    update_url_params()

    # 产品管理页面路由
    if page == "📦 产品管理":
        product_page = st.session_state.get("product_page", "list")

        if product_page == "list":
            render_product_list()
        elif product_page == "add":
            render_product_form(mode="add")
        elif product_page == "edit":
            render_product_form(mode="edit")
        elif product_page == "detail":
            product_id = st.session_state.get("detail_product_id")
            if product_id:
                render_product_detail(product_id)
            else:
                st.session_state.product_page = "list"
                render_product_list()
        else:
            render_product_list()
        return

    # 路由到其他页面
    page_map = {
        "📊 数据仪表盘": render_dashboard,
        "⚙️ 产品配置": render_product_config,
        "🔥 热门话题": render_topics,
        "📝 内容生成": render_content_generator,
        "🚀 内容发布": render_publish,
        "📈 数据分析": render_analytics
    }

    # 渲染选中的页面
    page_func = page_map.get(page, render_dashboard)
    page_func()


if __name__ == "__main__":
    main()
