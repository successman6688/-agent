"""Product management pages for Streamlit (Database Version)."""

import streamlit as st
from typing import List, Optional

from app.models.product import (
    Product,
    ProductCreate,
    ProductUpdate,
    ProductType,
    ProductStatus,
    PricingModel
)
from app.services.product_service import get_products_for_streamlit, get_active_product_for_streamlit
from app.services.product_scraper import get_product_scraper


async def _list_products_async():
    """异步获取产品列表"""
    from app.services.product_service import ProductService
    from app.db.connection import get_db_session
    async with get_db_session() as session:
        service = ProductService(session)
        return await service.list_products()


async def _get_product_async(product_id: str):
    """异步获取单个产品"""
    from app.services.product_service import ProductService
    from app.db.connection import get_db_session
    async with get_db_session() as session:
        service = ProductService(session)
        return await service.get_product(product_id)


async def _create_product_async(data: dict):
    """异步创建产品"""
    from app.services.product_service import ProductService
    from app.db.connection import get_db_session
    async with get_db_session() as session:
        service = ProductService(session)
        return await service.create_product(ProductCreate(**data))


async def _update_product_async(product_id: str, data: dict):
    """异步更新产品"""
    from app.services.product_service import ProductService
    from app.db.connection import get_db_session
    async with get_db_session() as session:
        service = ProductService(session)
        return await service.update_product(product_id, ProductUpdate(**data))


async def _delete_product_async(product_id: str):
    """异步删除产品"""
    from app.services.product_service import ProductService
    from app.db.connection import get_db_session
    async with get_db_session() as session:
        service = ProductService(session)
        return await service.delete_product(product_id)


async def _set_active_product_async(product_id: str):
    """异步设置激活产品"""
    from app.services.product_service import ProductService
    from app.db.connection import get_db_session
    async with get_db_session() as session:
        service = ProductService(session)
        return await service.set_active_product(product_id)


def render_product_list():
    """渲染产品列表页面。"""
    st.markdown('<h1 class="main-header">📦 产品管理</h1>', unsafe_allow_html=True)

    # 获取产品列表
    products = st.runtime.function(_list_products_async)()

    # 操作栏
    col1, col2, col3, col4 = st.columns([2, 2, 2, 1])

    with col1:
        # 类型筛选
        type_filter = st.selectbox(
            "产品类型",
            options=["all", "saas", "app", "content"],
            format_func=lambda x: {"all": "全部", "saas": "SaaS", "app": "App", "content": "内容"}[x]
        )

    with col2:
        # 状态筛选
        status_filter = st.selectbox(
            "产品状态",
            options=["all", "active", "inactive"],
            format_func=lambda x: {
                "all": "全部",
                "active": "激活",
                "inactive": "未激活"
            }[x]
        )

    with col3:
        # 搜索框
        search_query = st.text_input("🔍 搜索产品")

    with col4:
        # 新建按钮
        if st.button("➕ 新建产品", use_container_width=True):
            st.session_state.current_page = "product_form"
            st.rerun()

    # 应用筛选
    filtered_products = products
    if type_filter != "all":
        filtered_products = [p for p in filtered_products if p.type == type_filter]
    if status_filter != "all":
        is_active = status_filter == "active"
        filtered_products = [p for p in filtered_products if p.is_active == is_active]
    if search_query:
        filtered_products = [
            p for p in filtered_products
            if search_query.lower() in p.name.lower() or
               search_query.lower() in p.description.lower()
        ]

    # 显示产品列表
    if filtered_products:
        for product in filtered_products:
            with st.expander(f"📦 {product.name} - {product.type_label}"):
                col1, col2, col3 = st.columns([3, 2, 2])

                with col1:
                    st.markdown(f"**描述**: {product.description}")
                    st.markdown(f"**目标用户**: {product.target_audience}")
                    if product.tags:
                        tags_str = ", ".join([f"`{tag}`" for tag in product.tags])
                        st.markdown(f"**标签**: {tags_str}")

                with col2:
                    st.markdown(f"**状态**: {'🟢 激活' if product.is_active else '⚪ 未激活'}")
                    if product.website_url:
                        st.markdown(f"**网站**: [{product.website_url}]({product.website_url})")
                    if product.price:
                        st.markdown(f"**价格**: {product.price}")
                    if product.cta_text:
                        st.markdown(f"**CTA**: {product.cta_text}")

                with col3:
                    if st.button("👁 查看", key=f"view_{product.id}"):
                        st.session_state.selected_product_id = product.id
                        st.session_state.current_page = "product_detail"
                        st.rerun()

                    if not product.is_active:
                        if st.button("⭐ 激活", key=f"activate_{product.id}"):
                            result = st.runtime.function(_set_active_product_async)(product.id)
                            if result:
                                st.success(f"✅ 已激活 {product.name}")
                                st.rerun()

                    if st.button("✏️ 编辑", key=f"edit_{product.id}"):
                        st.session_state.editing_product_id = product.id
                        st.session_state.current_page = "product_form"
                        st.rerun()

                    if st.button("🗑️ 删除", key=f"delete_{product.id}"):
                        if st.confirm(f"确定要删除产品 '{product.name}' 吗？"):
                            result = st.runtime.function(_delete_product_async)(product.id)
                            if result:
                                st.success(f"✅ 已删除 {product.name}")
                                st.rerun()
    else:
        st.info("📭 暂无产品")


def render_product_form():
    """渲染产品表单页面。"""
    st.markdown('<h1 class="main-header">📝 产品编辑</h1>', unsafe_allow_html=True)

    # 确定是编辑还是新建
    editing_id = st.session_state.get("editing_product_id")

    if editing_id:
        # 编辑模式 - 加载现有产品
        product = st.runtime.function(_get_product_async)(editing_id)
        if not product:
            st.error(f"❌ 产品不存在: {editing_id}")
            st.session_state.editing_product_id = None
            st.rerun()
            return
        title = f"编辑产品: {product.name}"
    else:
        # 新建模式
        title = "新建产品"
        product = None

    st.subheader(title)

    # 表单
    with st.form(key="product_form"):
        col1, col2 = st.columns(2)

        with col1:
            name = st.text_input("产品名称*", value=product.name if product else "")
            type_ = st.selectbox(
                "产品类型*",
                options=["saas", "app", "content"],
                index=0 if not product else ["saas", "app", "content"].index(product.type),
                format_func=lambda x: {"saas": "SaaS", "app": "App", "content": "内容"}[x]
            )
            description = st.text_area(
                "产品描述*",
                value=product.description if product else "",
                height=100
            )
            target_audience = st.text_input("目标用户*", value=product.target_audience if product else "")
            category = st.text_input("分类", value=product.category or "")

            tags_input = st.text_input("标签（逗号分隔）", value=", ".join(product.tags) if product and product.tags else "")
            tags = [t.strip() for t in tags_input.split(",")] if tags_input else []

        with col2:
            website_url = st.text_input("网站URL", value=product.website_url or "")
            cta_text = st.text_input("CTA文本", value=product.cta_text or "")
            cta_link = st.text_input("CTA链接", value=product.cta_link or "")
            price = st.text_input("价格", value=product.price or "")
            pricing_model = st.selectbox(
                "定价模式",
                options=["free", "freemium", "paid", "subscription"],
                index=0 if not product or not product.pricing_model else ["free", "freium", "paid", "subscription"].index(product.pricing_model),
                format_func=lambda x: {
                    "free": "免费",
                    "freemium": "免费增值",
                    "paid": "付费",
                    "subscription": "订阅"
                }[x] if x else "免费"
            )

        # 提交按钮
        col1, col2, col3 = st.columns([1, 1, 1])

        with col1:
            submit = st.form_submit_button("💾 保存", use_container_width=True)

        with col2:
            if st.form_submit_button("❌ 取消", use_container_width=True):
                st.session_state.editing_product_id = None
                st.session_state.current_page = "product_list"
                st.rerun()

        with col3:
            if st.form_submit_button("🧪 测试抓取", use_container_width=True):
                with st.spinner("正在抓取产品信息..."):
                    scraper = get_product_scraper()
                    test_url = st.text_input("产品URL（用于测试）", value=website_url or "")
                    if test_url:
                        try:
                            product_info = scraper.fetch_product_info(test_url)
                            st.json(product_info)
                        except Exception as e:
                            st.error(f"抓取失败: {e}")

    # 处理提交
    if submit:
        if not name or not description:
            st.error("❌ 请填写必填字段")
            return

        # 构建产品数据
        product_data = {
            "name": name,
            "type": type_,
            "description": description,
            "target_audience": target_audience,
            "website_url": website_url or None,
            "cta_text": cta_text or None,
            "cta_link": cta_link or None,
            "price": price or None,
            "pricing_model": pricing_model or None,
            "category": category or None,
            "tags": tags
        }

        try:
            if editing_id:
                # 更新产品
                updated = st.runtime.function(_update_product_async)(editing_id, product_data)
                if updated:
                    st.success(f"✅ 产品已更新: {updated.name}")
                    st.session_state.editing_product_id = None
                    st.session_state.current_page = "product_list"
                    st.rerun()
                else:
                    st.error(f"❌ 产品不存在: {editing_id}")
            else:
                # 创建产品
                created = st.runtime.function(_create_product_async)(product_data)
                if created:
                    st.success(f"✅ 产品已创建: {created.name}")
                    st.session_state.current_page = "product_list"
                    st.rerun()
                else:
                    st.error("❌ 创建失败")
        except Exception as e:
            st.error(f"❌ 操作失败: {e}")


def render_product_detail():
    """渲染产品详情页面。"""
    product_id = st.session_state.get("selected_product_id")

    if not product_id:
        st.error("❌ 未选择产品")
        st.session_state.current_page = "product_list"
        st.rerun()
        return

    # 加载产品
    product = st.runtime.function(_get_product_async)(product_id)

    if not product:
        st.error(f"❌ 产品不存在: {product_id}")
        st.session_state.current_page = "product_list"
        st.rerun()
        return

    st.markdown('<h1 class="main-header">📦 产品详情</h1>', unsafe_allow_html=True)

    # 返回按钮
    if st.button("← 返回列表"):
        st.session_state.selected_product_id = None
        st.session_state.current_page = product_list
        st.rerun()

    # 产品信息
    col1, col2 = st.columns([2, 1])

    with col1:
        st.markdown(f"## {product.name}")
        st.markdown(f"**类型**: {product.type_label}")
        st.markdown(f"**状态**: {'🟢 激活' if product.is_active else '⚪ 未激活'}")

        st.markdown("---")
        st.markdown(f"**产品描述**")
        st.markdown(product.description)

        st.markdown(f"**目标用户**: {product.target_audience}")

        if product.selling_points:
            st.markdown("**核心卖点**")
            for point in product.selling_points:
                st.markdown(f"- {point}")

    with col2:
        st.markdown("**产品信息**")

        if product.website_url:
            st.markdown(f"**网站**: [{product.website_url}]({product.website_url})")

        if product.price:
            st.markdown(f"**价格**: {product.price}")
            st.markdown(f"**定价**: {product.pricing_model_label}")

        if product.cta_text:
            st.markdown(f"**CTA**: {product.cta_text}")
            if product.cta_link:
                st.markdown(f"**链接**: [{product.cta_link}]({product.cta_link})")

        if product.tags:
            tags_str = ", ".join([f"`{tag}`" for tag in product.tags])
            st.markdown(f"**标签**: {tags_str}")

        if product.category:
            st.markdown(f"**分类**: {product.category}")

        st.markdown("---")

        # 操作按钮
        if not product.is_active:
            if st.button("⭐ 激活产品", use_container_width=True):
                result = st.runtime.function(_set_active_product_async)(product_id)
                if result:
                    st.success(f"✅ 已激活 {product.name}")
                    st.rerun()

        if st.button("✏️ 编辑产品", use_container_width=True):
            st.session_state.editing_product_id = product_id
            st.session_state.current_page = "product_form"
            st.rerun()

        if st.button("🗑️ 删除产品", use_container_width=True):
            if st.confirm(f"确定要删除产品 '{product.name}' 吗？"):
                result = st.runtime.function(_delete_product_async)(product_id)
                if result:
                    st.success(f"✅ 已删除 {product.name}")
                    st.session_state.selected_product_id = None
                    st.session_state.current_page = "product_list"
                    st.rerun()
