"""Product API endpoints (Database Version)."""

from typing import List, Optional

from fastapi import APIRouter, HTTPException, Query, Depends, status
from sqlalchemy.ext.asyncio import AsyncSession

from app.models.product import (
    Product,
    ProductCreate,
    ProductUpdate,
    ProductFilters,
    ProductType,
    ProductStatus,
)
from app.services.product_service import ProductService
from app.db.connection import get_db

router = APIRouter()


# ============== Helper Functions ==============

def get_product_service(session: AsyncSession) -> ProductService:
    """获取ProductService实例（依赖注入）"""
    return ProductService(session)


# ============== Product CRUD ==============

@router.get("", response_model=List[Product])
async def list_products(
    type: Optional[ProductType] = Query(None, description="Filter by product type"),
    status: Optional[ProductStatus] = Query(None, description="Filter by status"),
    category: Optional[str] = Query(None, description="Filter by category"),
    tags: Optional[List[str]] = Query(None, description="Filter by tags"),
    search: Optional[str] = Query(None, description="Search in name and description"),
    is_active: Optional[bool] = Query(None, description="Filter by active status"),
    limit: int = Query(100, ge=1, le=1000, description="Number of results to return"),
    offset: int = Query(0, ge=0, description="Number of results to skip"),
    session: AsyncSession = Depends(get_db)
) -> List[Product]:
    """
    Get list of products.

    Supports filtering by type, status, category, tags, and text search.
    """
    service = get_product_service(session)
    filters = ProductFilters(
        type=type,
        status=status,
        category=category,
        tags=tags,
        search=search,
        is_active=is_active
    )
    products = await service.list_products(filters=filters, limit=limit, offset=offset)
    return products


@router.post("", response_model=Product, status_code=status.HTTP_201_CREATED)
async def create_product(
    data: ProductCreate,
    session: AsyncSession = Depends(get_db)
) -> Product:
    """
    Create a new product.

    The product will be created with INACTIVE status by default.
    """
    service = get_product_service(session)
    product = await service.create_product(data)
    return product


@router.get("/active/current", response_model=Product)
async def get_current_active_product(
    session: AsyncSession = Depends(get_db)
) -> Product:
    """
    Get the currently active product.

    Raises 404 if no product is currently active.
    """
    service = get_product_service(session)
    product = await service.get_active_product()
    if not product:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="No active product found"
        )
    return product


@router.post("/active/{product_id}", response_model=Product)
async def set_active_product(
    product_id: str,
    session: AsyncSession = Depends(get_db)
) -> Product:
    """
    Set a product as the active product.

    This will deactivate all other products.
    """
    service = get_product_service(session)
    product = await service.set_active_product(product_id)
    if not product:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Product not found: {product_id}"
        )
    return product


@router.get("/{product_id}", response_model=Product)
async def get_product(
    product_id: str,
    session: AsyncSession = Depends(get_db)
) -> Product:
    """
    Get product details by ID.

    Raises 404 if product not found.
    """
    service = get_product_service(session)
    product = await service.get_product(product_id)
    if not product:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Product not found: {product_id}"
        )
    return product


@router.put("/{product_id}", response_model=Product)
async def update_product(
    product_id: str,
    data: ProductUpdate,
    session: AsyncSession = Depends(get_db)
) -> Product:
    """
    Update product by ID.

    Raises 404 if product not found.
    Only updates fields that are provided.
    """
    service = get_product_service(session)
    product = await service.update_product(product_id, data)
    if not product:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Product not found: {product_id}"
        )
    return product


@router.delete("/{product_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_product(
    product_id: str,
    session: AsyncSession = Depends(get_db)
) -> None:
    """
    Delete product by ID.

    Raises 404 if product not found.
    """
    service = get_product_service(session)
    success = await service.delete_product(product_id)
    if not success:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Product not found: {product_id}"
        )


@router.get("/stats/summary")
async def get_product_stats(
    session: AsyncSession = Depends(get_db)
) -> dict:
    """
    Get product statistics summary.

    Returns total count and active count.
    """
    service = get_product_service(session)
    total = await service.get_product_count()
    active = await service.get_active_product_count()

    return {
        "total_products": total,
        "active_products": active
    }
