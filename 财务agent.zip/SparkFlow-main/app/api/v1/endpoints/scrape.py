"""Product scraping API endpoints."""

from typing import Dict, Any, Optional

from fastapi import APIRouter, HTTPException, status
from pydantic import BaseModel

from app.services.product_scraper import get_product_scraper

router = APIRouter()


# ============== Request/Response Models ==============

class ScrapeRequest(BaseModel):
    """Request model for product scraping."""
    url: str


class ScrapeResponse(BaseModel):
    """Response model for scraped product data."""
    name: Optional[str] = None
    type: Optional[str] = None
    description: Optional[str] = None
    target_audience: Optional[str] = None
    selling_points: list = []
    website_url: Optional[str] = None
    cta_text: Optional[str] = None
    cta_link: Optional[str] = None
    app_store_url: Optional[str] = None
    google_play_url: Optional[str] = None
    price: Optional[str] = None
    pricing_model: Optional[str] = None
    category: Optional[str] = None
    tags: list = []
    metadata: Dict[str, Any] = {}


# ============== Scraping Endpoints ==============

@router.post("/product", response_model=ScrapeResponse)
async def scrape_product(request: ScrapeRequest) -> Dict[str, Any]:
    """
    Scrape product information from a URL.

    Automatically detects the URL type (App Store, Google Play, or generic website)
    and extracts relevant product information.

    Supported URL types:
    - App Store (apps.apple.com)
    - Google Play (play.google.com)
    - Generic websites (extracts metadata)

    Returns scraped product data that can be used to create a product.
    """
    scraper = get_product_scraper()

    result = scraper.fetch_from_url_sync(request.url)

    if result is None:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to scrape product. The URL may not be supported."
        )

    return result


@router.post("/app-store", response_model=ScrapeResponse)
async def scrape_app_store(request: ScrapeRequest) -> Dict[str, Any]:
    """
    Scrape iOS app information from App Store.

    Extracts app name, description, screenshots, price, etc.
    """
    scraper = get_product_scraper()

    result = scraper.fetch_from_url_sync(request.url)

    if result is None:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to scrape App Store app"
        )

    return result


@router.post("/google-play", response_model=ScrapeResponse)
async def scrape_google_play(request: ScrapeRequest) -> Dict[str, Any]:
    """
    Scrape Android app information from Google Play Store.

    Extracts app name, description, screenshots, price, etc.
    """
    scraper = get_product_scraper()

    result = scraper.fetch_from_url_sync(request.url)

    if result is None:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to scrape Google Play app"
        )

    return result


@router.post("/website", response_model=ScrapeResponse)
async def scrape_website(request: ScrapeRequest) -> Dict[str, Any]:
    """
    Scrape generic website metadata.

    Extracts title, description, keywords, and other metadata.
    """
    scraper = get_product_scraper()

    result = scraper.fetch_from_url_sync(request.url)

    if result is None:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to scrape website"
        )

    return result
