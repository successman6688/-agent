"""Intelligence API endpoints - Database Version."""

import asyncio
from typing import List, Optional
from pydantic import BaseModel, Field

from fastapi import APIRouter, HTTPException, status, Query, WebSocket, WebSocketDisconnect, Depends
from fastapi.responses import JSONResponse
from sqlalchemy.ext.asyncio import AsyncSession

from app.models.intelligence import (
    IntelligenceTopic,
    IntelligenceTopicCreate,
    IntelligenceTopicUpdate,
    IntelligenceItem,
    IntelligenceReport,
    CollectionRequest,
    CollectionResponse,
    SourceConfig,
    SourceType,
    ScheduleType,
)
from app.services.intelligence import (
    get_intelligence_scheduler,
    get_keyword_analyzer,
)
from app.db.intelligence_repository import IntelligenceRepository
from app.db.connection import get_db, get_db_session
from app.services.intelligence.coordinator import IntelligenceCoordinator
from app.services.intelligence.task_manager import get_task_manager
from app.services.intelligence.websocket import get_websocket_manager
from app.core.logging import get_logger

logger = get_logger(__name__)

router = APIRouter()
scheduler = get_intelligence_scheduler()
task_manager = get_task_manager()
ws_manager = get_websocket_manager()


# ============== Helper Functions ==============

def db_to_pynamo_topic(db_topic) -> IntelligenceTopic:
    """Convert DB model to Pydantic model"""
    return IntelligenceTopic(
        id=str(db_topic.id),
        name=db_topic.name,
        keywords=db_topic.keywords,
        sources=[SourceConfig(**s) for s in db_topic.sources],
        schedule=db_topic.schedule,
        description=db_topic.description,
        is_active=db_topic.is_active,
        last_run_time=db_topic.last_run_time.isoformat() if db_topic.last_run_time else None,
        last_status=db_topic.last_status,
        total_items=db_topic.total_items,
        config=db_topic.config,
        today_items=db_topic.today_items,
        weekly_items=db_topic.weekly_items,
        created_at=db_topic.created_at.isoformat() if db_topic.created_at else None,
        updated_at=db_topic.updated_at.isoformat() if db_topic.updated_at else None,
    )

def db_to_pynamo_item(db_item) -> IntelligenceItem:
    """Convert DB model to Pydantic model"""
    return IntelligenceItem(
        id=str(db_item.id),
        topic_id=str(db_item.topic_id),
        title=db_item.title,
        content=db_item.content,
        url=db_item.url,
        source=db_item.source,
        author=db_item.author,
        published_at=db_item.published_at.isoformat() if db_item.published_at else None,
        collected_at=db_item.collected_at.isoformat() if db_item.collected_at else None,
        relevance_score=db_item.relevance_score,
        timeliness_score=db_item.timeliness_score,
        authority_score=db_item.authority_score,
        overall_score=db_item.overall_score,
        ai_summary=db_item.ai_summary,
        key_insights=db_item.key_insights or [],
        tags=db_item.tags or [],
        guid=db_item.guid,
        url_hash=db_item.url_hash,
        content_hash=db_item.content_hash,
        embedding_id=db_item.embedding_id,
        metadata=db_item.data_metadata or {},
    )


# ============== Request/Response Models ==============

class KeywordAnalysisRequest(BaseModel):
    """关键词分析请求"""
    keywords: str = Field(..., description="用户输入的关键词")
    language: str = Field(default="zh", description="语言 (zh/en)")


# ============== Topic Management ==============

@router.get("/topics", response_model=List[IntelligenceTopic])
async def list_topics(
    session: AsyncSession = Depends(get_db)
) -> List[IntelligenceTopic]:
    """
    获取所有情报主题列表
    """
    try:
        repo = IntelligenceRepository(session)
        db_topics = await repo.list_topics()
        return [db_to_pynamo_topic(t) for t in db_topics]
    except Exception as e:
        logger.error(f"Error listing topics: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to list topics: {str(e)}"
        )


@router.post("/topics", response_model=IntelligenceTopic, status_code=status.HTTP_201_CREATED)
async def create_topic(
    data: IntelligenceTopicCreate,
    session: AsyncSession = Depends(get_db)
) -> IntelligenceTopic:
    """
    创建新的情报主题

    Example:
    ```json
    {
        "name": "AI大模型动态",
        "keywords": ["GPT", "Claude", "大模型", "AI"],
        "sources": [
            {
                "type": "google_news",
                "name": "Google News",
                "query": "AI大模型"
            }
        ],
        "schedule": "daily",
        "description": "监控AI大模型领域的最新动态"
    }
    ```
    """
    try:
        repo = IntelligenceRepository(session)

        # 准备主题数据
        from datetime import datetime
        topic_data = data.model_dump()
        topic_data['created_at'] = datetime.utcnow()
        topic_data['updated_at'] = datetime.utcnow()

        db_topic = await repo.create_topic(topic_data)
        logger.info(f"Created topic: {db_topic.name} ({db_topic.id})")

        return db_to_pynamo_topic(db_topic)

    except Exception as e:
        logger.error(f"Error creating topic: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to create topic: {str(e)}"
        )


@router.get("/topics/{topic_id}", response_model=IntelligenceTopic)
async def get_topic(
    topic_id: str,
    session: AsyncSession = Depends(get_db)
) -> IntelligenceTopic:
    """
    获取主题详情
    """
    repo = IntelligenceRepository(session)
    db_topic = await repo.get_topic(topic_id)

    if not db_topic:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Topic not found: {topic_id}"
        )

    return db_to_pynamo_topic(db_topic)


@router.put("/topics/{topic_id}", response_model=IntelligenceTopic)
async def update_topic(topic_id: str, data: IntelligenceTopicUpdate) -> IntelligenceTopic:
    """
    更新主题
    """
    topic = await storage.load_topic(topic_id)

    if not topic:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Topic not found: {topic_id}"
        )

    # 更新字段
    update_data = data.model_dump(exclude_unset=True)
    for key, value in update_data.items():
        if hasattr(topic, key):
            setattr(topic, key, value)

    topic.updated_at = datetime.utcnow()

    await storage.save_topic(topic)

    logger.info(f"Updated topic: {topic.name} ({topic_id})")
    return topic


@router.delete("/topics/{topic_id}")
async def delete_topic(
    topic_id: str,
    session: AsyncSession = Depends(get_db)
):
    """
    删除主题及其所有相关数据

    删除内容包括：
    - 主题配置
    - 所有情报数据
    - 所有报告（级联删除）
    - 定时任务（如果存在）
    """
    repository = IntelligenceRepository(session)

    # 检查主题是否存在
    topic = await repository.get_topic(topic_id)

    if not topic:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Topic not found: {topic_id}"
        )

    topic_name = topic.name

    # 从调度器中移除（如果存在）
    await scheduler.unschedule_topic(topic_id)

    # 删除主题（数据库会级联删除相关数据）
    success = await repository.delete_topic(topic_id)

    if success:
        logger.info(f"Deleted topic: {topic_name} ({topic_id})")
        return {
            "status": "deleted",
            "topic_id": topic_id,
            "topic_name": topic_name,
            "message": f"主题 '{topic_name}' 及其所有数据已成功删除"
        }
    else:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to delete topic: {topic_id}"
        )


@router.delete("/topics")
async def delete_all_topics(
    session: AsyncSession = Depends(get_db)
):
    """
    删除所有主题和数据

    ⚠️ 危险操作：会删除所有主题、情报数据和报告
    """
    repository = IntelligenceRepository(session)

    # 获取所有主题
    topics = await repository.list_topics()
    count = len(topics)

    # 删除所有主题
    for topic in topics:
        await repository.delete_topic(str(topic.id))

    # 清空调度器
    await scheduler.unschedule_all()

    return {
        "status": "deleted",
        "count": count,
        "message": f"已删除 {count} 个主题及其所有数据"
    }


# ============== Intelligence Collection ==============

class AsyncCollectionResponse(BaseModel):
    """异步收集响应"""
    task_id: str = Field(..., description="任务ID")
    status: str = Field(..., description="任务状态")
    message: str = Field(..., description="提示信息")


@router.post("/topics/{topic_id}/collect", response_model=AsyncCollectionResponse)
async def collect_intelligence_async(
    topic_id: str,
    force: bool = Query(False),
    session: AsyncSession = Depends(get_db)
) -> AsyncCollectionResponse:
    """
    触发情报收集（异步模式）

    立即返回任务ID，后台执行收集。使用 /tasks/{task_id} 查询任务状态。

    Args:
        topic_id: 主题ID
        force: 是否强制刷新
    """
    repo = IntelligenceRepository(session)

    # 加载主题
    db_topic = await repo.get_topic(topic_id)

    if not db_topic:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Topic not found: {topic_id}"
        )

    if not db_topic.is_active:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Topic is not active: {topic_id}"
        )

    # 转换为Pydantic模型
    topic = db_to_pynamo_topic(db_topic)

    # 创建异步任务（使用数据库版本的coordinator）
    async def collection_task():
        # 创建新的coordinator实例，使用当前session
        coordinator = IntelligenceCoordinator(session)
        return await coordinator.collect_intelligence(topic, force_refresh=force)

    # 创建协程任务
    coro = asyncio.create_task(collection_task())

    # 注册到任务管理器
    task_id = await task_manager.create_task(topic_id, coro)

    return AsyncCollectionResponse(
        task_id=task_id,
        status="pending",
        message=f"情报收集任务已创建，正在后台执行。任务ID: {task_id}"
    )


@router.get("/tasks/{task_id}")
async def get_task_status(task_id: str):
    """
    查询任务状态

    Args:
        task_id: 任务ID

    Returns:
        任务状态和结果
    """
    task = task_manager.get_task(task_id)

    if not task:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Task not found: {task_id}"
        )

    return task.to_dict()


@router.post("/topics/{topic_id}/collect-sync", response_model=CollectionResponse)
async def collect_intelligence_sync(topic_id: str, force: bool = Query(False)) -> CollectionResponse:
    """
    触发情报收集（同步模式，已废弃）

    Args:
        topic_id: 主题ID
        force: 是否强制刷新

    Note: 建议使用异步接口 /topics/{topic_id}/collect
    """
    # 加载主题
    topic = await storage.load_topic(topic_id)

    if not topic:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Topic not found: {topic_id}"
        )

    if not topic.is_active:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Topic is not active: {topic_id}"
        )

    # 执行收集
    response = await coordinator.collect_intelligence(topic, force_refresh=force)

    return response


# ============== Intelligence Items ==============

@router.get("/topics/{topic_id}/items", response_model=List[IntelligenceItem])
async def get_topic_items(
    topic_id: str,
    date: Optional[str] = Query(None, description="日期 (YYYY-MM-DD)"),
    limit: int = Query(50, ge=1, le=200, description="最大数量"),
    min_score: float = Query(0.0, ge=0.0, le=1.0, description="最小评分"),
    session: AsyncSession = Depends(get_db)
) -> List[IntelligenceItem]:
    """
    获取主题的情报列表

    Args:
        topic_id: 主题ID
        date: 日期，默认今天
        limit: 最大数量
        min_score: 最小评分过滤
    """
    repo = IntelligenceRepository(session)

    # 检查主题是否存在
    db_topic = await repo.get_topic(topic_id)
    if not db_topic:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Topic not found: {topic_id}"
        )

    # 从数据库加载情报（已按时间倒序排序）
    db_items = await repo.get_items_by_topic(topic_id, date=date, limit=limit, min_score=min_score)

    # 转换为Pydantic模型
    return [db_to_pynamo_item(item) for item in db_items]


@router.get("/items/{item_id}", response_model=IntelligenceItem)
async def get_item(item_id: str) -> IntelligenceItem:
    """
    获取情报详情

    注意：当前版本从存储中查找，需要遍历所有文件
    生产环境应该使用数据库
    """
    # TODO: 实现从存储中查找单个item的逻辑
    # 当前版本先返回404
    raise HTTPException(
        status_code=status.HTTP_501_NOT_IMPLEMENTED,
        detail="Get item by ID not yet implemented"
    )


# ============== Reports ==============

@router.get("/topics/{topic_id}/reports/latest", response_model=IntelligenceReport)
async def get_latest_report(topic_id: str) -> IntelligenceReport:
    """
    获取主题的最新报告
    """
    report = await storage.load_latest_report(topic_id)

    if not report:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"No report found for topic: {topic_id}"
        )

    return report


# ============== Quick Start Examples ==============

@router.post("/quick-start", response_model=IntelligenceTopic)
async def create_quick_start_topic(
    query: str = Query(..., description="搜索关键词"),
    name: Optional[str] = Query(None, description="主题名称")
) -> IntelligenceTopic:
    """
    快速创建主题（仅Google News RSS）

    Example:
    POST /api/v1/intelligence/quick-start?query=人工智能&name=AI动态
    """
    from datetime import datetime

    if not name:
        name = f"{query}情报监控"

    topic = IntelligenceTopic(
        name=name,
        keywords=[query],
        sources=[
            SourceConfig(
                type=SourceType.RSS,
                name="Google News",
                query=query,
                params={
                    "hl": "zh-CN",
                    "gl": "CN",
                    "ceid": "CN:zh"
                }
            )
        ],
        schedule=ScheduleType.DAILY,
        description=f"自动监控关于'{query}'的最新情报"
    )

    await storage.save_topic(topic)

    logger.info(f"Created quick-start topic: {topic.name} ({topic.id})")
    return topic


# ============== AI Keyword Analysis ==============

@router.post("/analyze-keywords")
async def analyze_keywords(request: KeywordAnalysisRequest):
    """
    AI智能分析关键词

    输入关键词后，AI自动：
    1. 提取核心关键词
    2. 扩展相关词汇
    3. 推荐最佳数据源
    4. 生成主题名称和描述
    5. 优化搜索查询

    Example:
    POST /api/v1/intelligence/analyze-keywords
    {
        "keywords": "黄金 金价 中国",
        "language": "zh"
    }
    """
    try:
        analyzer = get_keyword_analyzer()

        analysis = await analyzer.analyze_keywords(
            user_input=request.keywords,
            language=request.language
        )

        logger.info(f"Keyword analysis completed for: {request.keywords}")
        return analysis

    except Exception as e:
        logger.error(f"Error analyzing keywords: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to analyze keywords: {str(e)}"
        )


@router.post("/create-from-analysis")
async def create_topic_from_analysis(
    request: KeywordAnalysisRequest
) -> IntelligenceTopic:
    """
    基于AI分析自动创建主题

    流程：
    1. AI分析输入的关键词
    2. 自动生成优化的配置
    3. 创建主题
    4. 可选：自动执行第一次采集

    Example:
    POST /api/v1/intelligence/create-from-analysis
    {
        "keywords": "黄金 金价",
        "language": "zh"
    }
    """
    try:
        # 1. AI分析
        analyzer = get_keyword_analyzer()
        analysis = await analyzer.analyze_keywords(
            user_input=request.keywords,
            language=request.language
        )

        # 2. 构建数据源配置
        sources = []
        for source_rec in analysis.get("recommended_sources", []):
            source_type = source_rec.get("type", "rss")
            source_name = source_rec.get("name", "Google News")
            source_query = source_rec.get("query", request.keywords)

            # 从search_queries中找到对应的优化查询
            for sq in analysis.get("search_queries", []):
                if sq.get("source") == source_type or sq.get("source") == source_name.lower().replace(" ", "_"):
                    source_query = sq.get("query", source_query)
                    break

            source_config = SourceConfig(
                type=SourceType.RSS if source_type == "rss" else SourceType.WEB,
                name=source_name,
                query=source_query,
                params={
                    "hl": "zh-CN" if request.language == "zh" else "en",
                    "gl": "CN" if request.language == "zh" else "US",
                    "ceid": "CN:zh" if request.language == "zh" else "US:en"
                }
            )
            sources.append(source_config)

        # 如果没有推荐源，使用默认
        if not sources:
            sources.append(
                SourceConfig(
                    type=SourceType.RSS,
                    name="Google News",
                    query=request.keywords,
                    params={
                        "hl": "zh-CN" if request.language == "zh" else "en",
                        "gl": "CN" if request.language == "zh" else "US",
                        "ceid": "CN:zh" if request.language == "zh" else "US:en"
                    }
                )
            )

        # 3. 创建主题
        topic = IntelligenceTopic(
            name=analysis.get("topic_name", f"{request.keywords}监控"),
            keywords=analysis.get("primary_keywords", [request.keywords]),
            sources=sources,
            schedule=ScheduleType.DAILY,  # 默认每日
            description=analysis.get(
                "topic_description",
                f"自动监控关于'{request.keywords}'的最新情报"
            ),
            config={
                "enable_ai_summary": True,
                "max_items": 50,
                "min_relevance": 0.3,
                # 保存AI分析结果
                "_ai_analysis": analysis
            }
        )

        await storage.save_topic(topic)

        logger.info(
            f"Created topic from AI analysis: {topic.name} ({topic.id}) "
            f"with keywords: {topic.keywords}"
        )

        return topic

    except Exception as e:
        logger.error(f"Error creating topic from analysis: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to create topic from analysis: {str(e)}"
        )


# ============== Scheduler Management ==============

@router.post("/scheduler/start")
async def start_scheduler():
    """
    启动调度器

    启动后，所有激活的主题将按照设定的频率自动收集情报
    """
    try:
        if not scheduler.is_running():
            scheduler.start()

            # 自动调度所有激活的主题
            count = await scheduler.schedule_all_active_topics()

            return {
                "status": "started",
                "scheduled_topics": count,
                "message": f"Scheduler started with {count} active topics"
            }
        else:
            return {
                "status": "already_running",
                "message": "Scheduler is already running"
            }
    except Exception as e:
        logger.error(f"Error starting scheduler: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to start scheduler: {str(e)}"
        )


@router.post("/scheduler/stop")
async def stop_scheduler():
    """
    停止调度器

    停止后，定时任务将不再执行，但可以手动触发收集
    """
    try:
        if scheduler.is_running():
            scheduler.stop()
            return {
                "status": "stopped",
                "message": "Scheduler stopped successfully"
            }
        else:
            return {
                "status": "not_running",
                "message": "Scheduler is not running"
            }
    except Exception as e:
        logger.error(f"Error stopping scheduler: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to stop scheduler: {str(e)}"
        )


@router.get("/scheduler/status")
async def get_scheduler_status():
    """
    获取调度器状态

    Returns:
        调度器状态信息
    """
    try:
        jobs = scheduler.get_scheduled_topics()

        return {
            "is_running": scheduler.is_running(),
            "total_jobs": len(jobs),
            "jobs": jobs
        }
    except Exception as e:
        logger.error(f"Error getting scheduler status: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to get scheduler status: {str(e)}"
        )


@router.post("/topics/{topic_id}/schedule", response_model=dict)
async def schedule_topic(topic_id: str):
    """
    为主题添加定时任务

    根据主题的schedule设置自动创建定时任务
    """
    try:
        topic = await storage.load_topic(topic_id)

        if not topic:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Topic not found: {topic_id}"
            )

        success = await scheduler.schedule_topic(topic)

        if success:
            return {
                "status": "scheduled",
                "topic_id": topic_id,
                "schedule": topic.schedule,
                "message": f"Topic '{topic.name}' scheduled successfully"
            }
        else:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"Failed to schedule topic: {topic_id}"
            )
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error scheduling topic: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to schedule topic: {str(e)}"
        )


@router.delete("/topics/{topic_id}/schedule", response_model=dict)
async def unschedule_topic(topic_id: str):
    """
    移除主题的定时任务

    主题仍然保留，但不会自动收集
    """
    try:
        success = await scheduler.unschedule_topic(topic_id)

        if success:
            return {
                "status": "unscheduled",
                "topic_id": topic_id,
                "message": f"Topic {topic_id} unscheduled successfully"
            }
        else:
            return {
                "status": "no_job",
                "topic_id": topic_id,
                "message": f"No scheduled job found for topic: {topic_id}"
            }
    except Exception as e:
        logger.error(f"Error unscheduling topic: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to unschedule topic: {str(e)}"
        )


@router.post("/scheduler/sync-all", response_model=dict)
async def sync_all_topics():
    """
    同步所有激活的主题到调度器

    为所有激活的主题创建定时任务
    """
    try:
        count = await scheduler.schedule_all_active_topics()

        return {
            "status": "synced",
            "scheduled_count": count,
            "message": f"Successfully synced {count} active topics to scheduler"
        }
    except Exception as e:
        logger.error(f"Error syncing topics: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to sync topics: {str(e)}"
        )


# ============== WebSocket ==============

@router.websocket("/ws/topics/{topic_id}")
async def websocket_endpoint(websocket: WebSocket, topic_id: str):
    """
    WebSocket 端点 - 实时接收主题更新

    连接到此端点以接收主题的实时更新，包括：
    - 收集任务状态更新
    - 新情报通知
    - 报告生成通知

    Args:
        websocket: WebSocket 连接
        topic_id: 主题ID
    """
    logger.info(f"[WS] New WebSocket connection request for topic {topic_id}")

    try:
        await ws_manager.connect(websocket, topic_id)
        logger.info(f"[WS] WebSocket connection ACCEPTED and established for topic {topic_id}")
    except Exception as e:
        logger.error(f"[WS] Failed to accept WebSocket connection: {e}")
        return

    try:
        # 保持连接活跃，不需要客户端发送消息
        while True:
            # 使用 ping/pong 保持连接
            await asyncio.sleep(1)
    except WebSocketDisconnect:
        logger.info(f"[WS] WebSocket disconnected (client closed) for topic {topic_id}")
        ws_manager.disconnect(websocket, topic_id)
    except Exception as e:
        logger.error(f"[WS] WebSocket error for topic {topic_id}: {e}", exc_info=True)
        ws_manager.disconnect(websocket, topic_id)
