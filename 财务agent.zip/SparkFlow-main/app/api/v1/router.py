"""API v1 router aggregation."""

from fastapi import APIRouter

from app.api.v1.endpoints import products, scrape, intelligence
from app.api.v1 import feedback, evolution

# Create API v1 router
api_router = APIRouter()

# Include endpoint routers
api_router.include_router(products.router, prefix="/products", tags=["products"])
api_router.include_router(scrape.router, prefix="/scraping", tags=["scraping"])
api_router.include_router(intelligence.router, prefix="/intelligence", tags=["intelligence"])
api_router.include_router(feedback.router, prefix="/intelligence", tags=["feedback"])
api_router.include_router(evolution.router, prefix="/intelligence", tags=["evolution"])
