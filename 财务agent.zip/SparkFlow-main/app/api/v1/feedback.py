"""情报反馈API"""

from fastapi import APIRouter, Depends, HTTPException
from typing import Optional, Any
from pydantic import BaseModel, Field

from app.services.intelligence.evolution_engine import (
    get_evolution_engine,
    FeedbackType
)
from app.core.logging import get_logger

logger = get_logger(__name__)

router = APIRouter()


class FeedbackRequest(BaseModel):
    """反馈请求"""
    item_id: str = Field(..., description="情报项ID")
    prompt_id: Optional[str] = Field(None, description="提示词ID（可选）")
    feedback_type: str = Field(..., description="反馈类型")
    value: Any = Field(..., description="反馈值")
    user_id: Optional[str] = Field(None, description="用户ID（可选）")


class FeedbackResponse(BaseModel):
    """反馈响应"""
    success: bool
    message: str


@router.post("/feedback", response_model=FeedbackResponse)
async def submit_feedback(request: FeedbackRequest):
    """
    提交用户反馈

    反馈类型：
    - thumbs_up: 👍 点赞
    - thumbs_down: 👎 点踩
    - rating: ⭐ 评分（1-5）
    - useful: ✓ "这个建议有用"
    - not_useful: ✗ "这个建议没用"
    """
    try:
        engine = get_evolution_engine()

        # 映射反馈类型
        feedback_type_map = {
            "thumbs_up": FeedbackType.EXPLICIT_THUMBS,
            "thumbs_down": FeedbackType.EXPLICIT_THUMBS,
            "rating": FeedbackType.EXPLICIT_RATING,
            "useful": FeedbackType.IMPLICIT_ACTION,
            "not_useful": FeedbackType.IMPLICIT_ACTION
        }

        if request.feedback_type not in feedback_type_map:
            raise HTTPException(status_code=400, detail=f"Invalid feedback type: {request.feedback_type}")

        feedback_type = feedback_type_map[request.feedback_type]

        # 转换值
        value = request.value
        if request.feedback_type == "thumbs_up":
            value = True
        elif request.feedback_type == "thumbs_down":
            value = False
        elif request.feedback_type == "useful":
            value = True
        elif request.feedback_type == "not_useful":
            value = False

        await engine.collect_feedback(
            item_id=request.item_id,
            prompt_id=request.prompt_id or "default",
            feedback_type=feedback_type,
            value=value,
            user_id=request.user_id
        )

        logger.info(f"Feedback collected: {request.feedback_type} for item {request.item_id}")

        return FeedbackResponse(
            success=True,
            message="Feedback submitted successfully"
        )

    except Exception as e:
        logger.error(f"Error submitting feedback: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/prompts/stats")
async def get_prompts_stats():
    """
    获取所有提示词的统计数据

    返回各提示词的性能指标
    """
    try:
        engine = get_evolution_engine()
        top_prompts = engine.get_top_prompts(top_n=10)

        stats = []
        for prompt_id, avg_score in top_prompts:
            prompt_stats = engine.get_performance_report(prompt_id)
            if prompt_stats:
                stats.append({
                    "prompt_id": prompt_id,
                    "avg_score": round(avg_score, 2),
                    "total_count": prompt_stats["total_count"],
                    "success_rate": round(prompt_stats["success_rate"] * 100, 2),
                    "last_updated": prompt_stats["last_updated"].isoformat() if prompt_stats["last_updated"] else None
                })

        return {
            "success": True,
            "stats": stats
        }

    except Exception as e:
        logger.error(f"Error getting prompt stats: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/prompts/top")
async def get_top_prompts(limit: int = 5):
    """
    获取表现最好的提示词

    Args:
        limit: 返回数量
    """
    try:
        engine = get_evolution_engine()
        top_prompts = engine.get_top_prompts(top_n=limit)

        return {
            "success": True,
            "top_prompts": [
                {"prompt_id": pid, "avg_score": round(score, 2)}
                for pid, score in top_prompts
            ]
        }

    except Exception as e:
        logger.error(f"Error getting top prompts: {e}")
        raise HTTPException(status_code=500, detail=str(e))
