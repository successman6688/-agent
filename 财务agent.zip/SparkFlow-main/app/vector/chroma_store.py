"""ChromaDB vector storage service."""

from typing import List, Optional, Dict, Any
from uuid import UUID

from app.db.connection import get_chroma_client
from app.core.logging import get_logger

logger = get_logger(__name__)


class ChromaVectorStore:
    """
    ChromaDB向量存储服务

    用于情报内容的向量化存储和语义检索
    """

    # 集合名称
    INTELLIGENCE_COLLECTION = "intelligence_items"

    def __init__(self):
        """初始化向量存储服务"""
        self.client = get_chroma_client()
        self.collection = None

    def _get_or_create_collection(self):
        """获取或创建集合"""
        if self.collection is None:
            self.collection = self.client.get_or_create_collection(
                name=self.INTELLIGENCE_COLLECTION,
                metadata={"hnsw:space": "cosine"}  # 使用余弦相似度
            )
        return self.collection

    async def add_item(
        self,
        item_id: str,
        content: str,
        metadata: Optional[Dict[str, Any]] = None
    ) -> str:
        """
        添加情报项到向量存储

        Args:
            item_id: 情报项ID
            content: 内容文本
            metadata: 元数据

        Returns:
            向量ID
        """
        try:
            collection = self._get_or_create_collection()

            # 添加文档
            collection.add(
                documents=[content],
                ids=[item_id],
                metadatas=[metadata or {}]
            )

            logger.debug(f"Added item to vector store: {item_id}")
            return item_id

        except Exception as e:
            logger.error(f"Error adding item to vector store: {e}")
            raise

    async def add_items_batch(
        self,
        items: List[Dict[str, Any]]
    ) -> List[str]:
        """
        批量添加情报项

        Args:
            items: 情报项列表，每个item包含 id, content, metadata

        Returns:
            向量ID列表
        """
        try:
            collection = self._get_or_create_collection()

            ids = [item["id"] for item in items]
            documents = [item["content"] for item in items]
            metadatas = [item.get("metadata", {}) for item in items]

            collection.add(
                documents=documents,
                ids=ids,
                metadatas=metadatas
            )

            logger.info(f"Added {len(items)} items to vector store")
            return ids

        except Exception as e:
            logger.error(f"Error batch adding items to vector store: {e}")
            raise

    async def search(
        self,
        query: str,
        n_results: int = 10,
        where: Optional[Dict[str, Any]] = None
    ) -> List[Dict[str, Any]]:
        """
        语义搜索

        Args:
            query: 查询文本
            n_results: 返回结果数量
            where: 元数据过滤条件

        Returns:
            搜索结果列表，包含 id, document, metadata, distance
        """
        try:
            collection = self._get_or_create_collection()

            # 执行查询
            results = collection.query(
                query_texts=[query],
                n_results=n_results,
                where=where
            )

            # 格式化结果
            formatted_results = []
            for idx, (doc, metadata, distance) in enumerate(zip(
                results['documents'][0],
                results['metadatas'][0],
                results['distances'][0]
            )):
                formatted_results.append({
                    "id": results['ids'][0][idx],
                    "document": doc,
                    "metadata": metadata,
                    "distance": distance,
                    "similarity": 1 - distance,  # 转换为相似度
                })

            logger.info(f"Vector search: query='{query[:50]}...', found={len(formatted_results)}")
            return formatted_results

        except Exception as e:
            logger.error(f"Error performing vector search: {e}")
            return []

    async def delete_item(self, item_id: str) -> bool:
        """
        从向量存储中删除情报项

        Args:
            item_id: 情报项ID

        Returns:
            是否删除成功
        """
        try:
            collection = self._get_or_create_collection()
            collection.delete(ids=[item_id])

            logger.debug(f"Deleted item from vector store: {item_id}")
            return True

        except Exception as e:
            logger.error(f"Error deleting item from vector store: {e}")
            return False

    async def get_item_by_id(self, item_id: str) -> Optional[Dict[str, Any]]:
        """
        根据ID获取情报项

        Args:
            item_id: 情报项ID

        Returns:
            情报项数据，不存在返回None
        """
        try:
            collection = self._get_or_create_collection()
            result = collection.get(ids=[item_id])

            if result and result['ids']:
                idx = result['ids'].index(item_id)
                return {
                    "id": result['ids'][idx],
                    "document": result['documents'][idx],
                    "metadata": result['metadatas'][idx],
                    "embedding": result['embeddings'][idx] if 'embeddings' in result else None,
                }
            return None

        except Exception as e:
            logger.error(f"Error getting item from vector store: {e}")
            return None

    async def update_item(
        self,
        item_id: str,
        content: str,
        metadata: Optional[Dict[str, Any]] = None
    ) -> bool:
        """
        更新情报项

        Args:
            item_id: 情报项ID
            content: 新的内容
            metadata: 新的元数据

        Returns:
            是否更新成功
        """
        try:
            # ChromaDB不支持直接更新，需要先删除再添加
            await self.delete_item(item_id)
            await self.add_item(item_id, content, metadata)

            logger.debug(f"Updated item in vector store: {item_id}")
            return True

        except Exception as e:
            logger.error(f"Error updating item in vector store: {e}")
            return False

    async def count_items(self) -> int:
        """
        统计情报项数量

        Returns:
            数量
        """
        try:
            collection = self._get_or_create_collection()
            return collection.count()
        except Exception as e:
            logger.error(f"Error counting items in vector store: {e}")
            return 0

    async def clear_collection(self) -> bool:
        """
        清空集合

        Returns:
            是否清空成功
        """
        try:
            collection = self._get_or_create_collection()
            client = get_chroma_client()

            # 删除并重新创建集合
            client.delete_collection(name=self.INTELLIGENCE_COLLECTION)
            self.collection = None
            self._get_or_create_collection()

            logger.info("Cleared vector store collection")
            return True

        except Exception as e:
            logger.error(f"Error clearing vector store collection: {e}")
            return False


# 全局向量存储服务实例
_vector_store: Optional[ChromaVectorStore] = None


def get_vector_store() -> ChromaVectorStore:
    """获取向量存储服务实例（单例）"""
    global _vector_store
    if _vector_store is None:
        _vector_store = ChromaVectorStore()
    return _vector_store
