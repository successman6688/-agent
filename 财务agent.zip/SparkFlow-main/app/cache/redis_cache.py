"""Redis caching layer."""

import json
from typing import Optional, Any, List
from datetime import timedelta

from app.db.connection import get_redis_client
from app.core.logging import get_logger

logger = get_logger(__name__)


class RedisCache:
    """
    Redis缓存服务
    """

    # 默认缓存时间（秒）
    DEFAULT_TTL = 3600  # 1小时

    # 缓存键前缀
    KEY_PREFIX = "sparkflow"

    def _make_key(self, key: str) -> str:
        """生成完整的缓存键"""
        return f"{self.KEY_PREFIX}:{key}"

    async def get(self, key: str) -> Optional[Any]:
        """
        获取缓存

        Args:
            key: 缓存键

        Returns:
            缓存值，不存在返回None
        """
        try:
            client = get_redis_client()
            full_key = self._make_key(key)

            value = await client.get(full_key)
            if value is None:
                return None

            # 反序列化JSON
            return json.loads(value)

        except Exception as e:
            logger.error(f"Redis get error: {e}")
            return None

    async def set(
        self,
        key: str,
        value: Any,
        ttl: Optional[int] = None
    ) -> bool:
        """
        设置缓存

        Args:
            key: 缓存键
            value: 缓存值
            ttl: 过期时间（秒），None表示使用默认值

        Returns:
            是否设置成功
        """
        try:
            client = get_redis_client()
            full_key = self._make_key(key)

            # 序列化JSON
            serialized_value = json.dumps(value, ensure_ascii=False)

            if ttl is None:
                ttl = self.DEFAULT_TTL

            await client.setex(full_key, ttl, serialized_value)
            return True

        except Exception as e:
            logger.error(f"Redis set error: {e}")
            return False

    async def delete(self, key: str) -> bool:
        """
        删除缓存

        Args:
            key: 缓存键

        Returns:
            是否删除成功
        """
        try:
            client = get_redis_client()
            full_key = self._make_key(key)

            result = await client.delete(full_key)
            return result > 0

        except Exception as e:
            logger.error(f"Redis delete error: {e}")
            return False

    async def exists(self, key: str) -> bool:
        """
        检查缓存是否存在

        Args:
            key: 缓存键

        Returns:
            是否存在
        """
        try:
            client = get_redis_client()
            full_key = self._make_key(key)

            result = await client.exists(full_key)
            return result > 0

        except Exception as e:
            logger.error(f"Redis exists error: {e}")
            return False

    async def clear_pattern(self, pattern: str) -> int:
        """
        批量删除缓存（支持通配符）

        Args:
            pattern: 匹配模式

        Returns:
            删除的键数量
        """
        try:
            client = get_redis_client()
            full_pattern = self._make_key(pattern)

            keys = []
            async for key in client.iscan(match=f"{full_pattern}*"):
                keys.append(key)

            if keys:
                await client.delete(*keys)
                logger.info(f"Cleared {len(keys)} cache keys matching: {pattern}")
                return len(keys)

            return 0

        except Exception as e:
            logger.error(f"Redis clear pattern error: {e}")
            return 0


# 全局缓存服务实例
_cache_service: Optional[RedisCache] = None


def get_cache_service() -> RedisCache:
    """获取缓存服务实例（单例）"""
    global _cache_service
    if _cache_service is None:
        _cache_service = RedisCache()
    return _cache_service


# ============== 缓存装饰器 ==============

def cached(ttl: int = 3600, key_prefix: str = ""):
    """
    缓存装饰器

    用法:
        @cached(ttl=1800, key_prefix="product")
        async def get_product(product_id: str):
            # ...
            pass

    Args:
        ttl: 缓存时间（秒）
        key_prefix: 键前缀
    """
    def decorator(func):
        async def wrapper(*args, **kwargs):
            # 生成缓存键
            cache_key = f"{key_prefix}:{func.__name__}:{args}:{kwargs}"

            cache = get_cache_service()

            # 尝试从缓存获取
            cached_value = await cache.get(cache_key)
            if cached_value is not None:
                logger.debug(f"Cache hit: {cache_key}")
                return cached_value

            # 缓存未命中，执行函数
            result = await func(*args, **kwargs)

            # 存入缓存
            await cache.set(cache_key, result, ttl=ttl)

            return result

        return wrapper
    return decorator
