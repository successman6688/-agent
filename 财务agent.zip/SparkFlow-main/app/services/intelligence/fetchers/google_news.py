"""Google News RSS fetcher implementation."""

import asyncio
import hashlib
from typing import List, Optional
from datetime import datetime

import aiohttp
import feedparser

from app.models.intelligence import IntelligenceItem, SourceConfig, IntelligenceTopic
from app.services.intelligence.fetchers.base import BaseFetcher, FetcherFactory
from app.core.logging import get_logger

logger = get_logger(__name__)


class GoogleNewsRSSFetcher(BaseFetcher):
    """
    Google News RSS 采集器

    使用Google News RSS API获取新闻数据
    """

    # Google News RSS 基础URL
    BASE_URL = "https://news.google.com/rss/search"

    # 默认参数
    DEFAULT_PARAMS = {
        "hl": "zh-CN",  # 界面语言
        "gl": "CN",     # 地理位置
        "ceid": "CN:zh" # 版本ID
    }

    def __init__(self, config: SourceConfig, topic: IntelligenceTopic):
        """
        初始化Google News RSS采集器

        Args:
            config: 数据源配置
            topic: 情报主题
        """
        super().__init__(config, topic)
        self.query = config.query or " ".join(topic.keywords)

        # 构建URL参数
        self.params = {
            **self.DEFAULT_PARAMS,
            "q": self.query
        }

        # 覆盖自定义参数
        if config.params:
            self.params.update(config.params)

        # 构建完整URL
        self.url = self._build_url()

    def validate_config(self) -> bool:
        """验证配置"""
        if not self.query:
            logger.error("Google News RSS: query is required")
            return False
        return True

    def _build_url(self) -> str:
        """
        构建RSS URL

        Returns:
            完整的RSS URL
        """
        from urllib.parse import urlencode

        # 如果配置中指定了完整URL，直接使用
        if self.config.url:
            return self.config.url

        # 否则构建URL
        return f"{self.BASE_URL}?{urlencode(self.params)}"

    async def fetch(self) -> List[IntelligenceItem]:
        """
        抓取Google News RSS数据

        Returns:
            情报项列表
        """
        if not self.validate_config():
            return []

        try:
            logger.info(f"Fetching Google News RSS: {self.url}")

            # 使用aiohttp异步抓取
            async with aiohttp.ClientSession() as session:
                async with session.get(
                    self.url,
                    timeout=aiohttp.ClientTimeout(total=30)
                ) as response:
                    if response.status != 200:
                        logger.error(
                            f"Google News RSS fetch failed: "
                            f"status={response.status}"
                        )
                        return []

                    feed_content = await response.text()

            # 解析RSS
            feed = feedparser.parse(feed_content)

            if not feed.entries:
                logger.warning(f"No entries found in feed: {self.url}")
                return []

            # 转换为情报项
            items = []
            for entry in feed.entries:
                try:
                    item = self._parse_entry(entry)
                    if item:
                        items.append(item)
                except Exception as e:
                    logger.error(f"Error parsing entry: {e}")
                    continue

            logger.info(
                f"Google News RSS: fetched {len(items)} items "
                f"from {self.source_name}"
            )

            return items

        except asyncio.TimeoutError:
            logger.error(f"Timeout fetching Google News RSS: {self.url}")
            return []
        except Exception as e:
            logger.error(f"Error fetching Google News RSS: {e}", exc_info=True)
            return []

    def _parse_entry(self, entry) -> Optional[IntelligenceItem]:
        """
        解析RSS条目

        Args:
            entry: feedparser条目

        Returns:
            情报项，解析失败返回None
        """
        # 提取基本信息
        title = entry.get('title', '')
        link = entry.get('link', '')
        summary = entry.get('summary', '')

        # 清理HTML标签
        content = self._clean_html(summary)

        # 提取GUID
        guid = entry.get('guid', entry.get('id', ''))

        # 解析发布时间
        published_at = self._parse_date(entry.get('published'))

        # 提取来源
        source = entry.get('source', '')
        if hasattr(source, 'title'):
            source = source.title

        # 创建情报项
        return self._create_item(
            title=title,
            content=content or title,  # 如果没有摘要，使用标题
            url=link,
            published_at=published_at,
            guid=guid,
            author=source,
            metadata={
                'feed_source': 'google_news',
                'raw_entry': self._safe_dict(entry)
            }
        )

    def _clean_html(self, html: str) -> str:
        """
        清理HTML标签

        Args:
            html: HTML字符串

        Returns:
            纯文本
        """
        if not html:
            return ""

        # 简单的HTML标签清理
        import re

        # 移除HTML标签
        text = re.sub(r'<[^>]+>', '', html)

        # 解码HTML实体
        import html as html_module
        text = html_module.unescape(text)

        # 清理多余空白
        text = ' '.join(text.split())

        return text

    def _safe_dict(self, obj) -> dict:
        """
        安全地转换为字典

        Args:
            obj: 任意对象

        Returns:
            字典
        """
        try:
            return dict(obj)
        except:
            return str(obj)


# 注册采集器
FetcherFactory.register("rss", GoogleNewsRSSFetcher)
FetcherFactory.register("google_news", GoogleNewsRSSFetcher)
