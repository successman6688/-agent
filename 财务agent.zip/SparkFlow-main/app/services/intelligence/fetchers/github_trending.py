"""GitHub Trending fetcher."""

import asyncio
from typing import List, Optional
from datetime import datetime, timedelta

import httpx
from bs4 import BeautifulSoup

from app.models.intelligence import IntelligenceItem, IntelligenceTopic, SourceConfig
from app.core.logging import get_logger
from app.services.intelligence.fetchers.base import BaseFetcher

logger = get_logger(__name__)


class GitHubTrendingFetcher(BaseFetcher):
    """
    GitHub Trending采集器

    抓取GitHub Trending页面，获取热门项目信息
    """

    BASE_URL = "https://github.com/trending"

    def __init__(self, source_config: SourceConfig, topic: IntelligenceTopic):
        """
        初始化采集器

        Args:
            source_config: 数据源配置
            topic: 情报主题
        """
        super().__init__(source_config, topic)
        self.client = httpx.AsyncClient(
            headers={
                "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36",
                "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
                "Accept-Language": "zh-CN,zh;q=0.9,en;q=0.8",
            },
            timeout=30.0,
            follow_redirects=True
        )

    def validate_config(self) -> bool:
        """
        验证配置是否有效

        Returns:
            配置是否有效
        """
        # GitHub Trending不需要特殊配置
        return True

    async def fetch(self) -> List[IntelligenceItem]:
        """
        采集GitHub Trending

        Returns:
            情报项列表
        """
        try:
            # 构建查询参数
            params = self._build_params()

            logger.info(f"Fetching GitHub Trending: {params}")

            # 发送请求
            response = await self.client.get(self.BASE_URL, params=params)
            response.raise_for_status()

            # 解析HTML
            soup = BeautifulSoup(response.text, 'html.parser')

            # 提取项目信息
            items = await self._parse_repositories(soup)

            logger.info(f"Fetched {len(items)} items from GitHub Trending")
            return items

        except httpx.HTTPError as e:
            logger.error(f"HTTP error fetching GitHub Trending: {e}")
            return []
        except Exception as e:
            logger.error(f"Error fetching GitHub Trending: {e}", exc_info=True)
            return []
        finally:
            await self.client.aclose()

    def _build_params(self) -> dict:
        """
        构建查询参数

        Returns:
            查询参数字典
        """
        params = {}

        # 语言过滤
        if self.config.params and self.config.params.get("language"):
            params["language"] = self.config.params["language"]
        else:
            # 从关键词中推断语言
            language_map = {
                "python": "Python",
                "javascript": "JavaScript",
                "java": "Java",
                "go": "Go",
                "rust": "Rust",
                "typescript": "TypeScript",
                "cpp": "C++",
                "c": "C",
            }
            for keyword in self.topic.keywords:
                if keyword.lower() in language_map:
                    params["language"] = language_map[keyword.lower()]
                    break

        # 时间范围（默认今天）
        since_map = {
            "daily": "daily",
            "weekly": "weekly",
            "monthly": "monthly"
        }
        time_range = self.config.params.get("time_range", "daily") if self.config.params else "daily"
        params["since"] = since_map.get(time_range, "daily")

        return params

    async def _parse_repositories(self, soup: BeautifulSoup) -> List[IntelligenceItem]:
        """
        解析仓库列表

        Args:
            soup: BeautifulSoup对象

        Returns:
            情报项列表
        """
        items = []
        repo_articles = soup.select("article.Box-row")

        logger.info(f"Found {len(repo_articles)} repositories")

        for article in repo_articles:
            try:
                item = await self._parse_repository(article)
                if item:
                    items.append(item)
            except Exception as e:
                logger.error(f"Error parsing repository: {e}")
                continue

        return items

    async def _parse_repository(self, article) -> Optional[IntelligenceItem]:
        """
        解析单个仓库

        Args:
            article: BeautifulSoup元素

        Returns:
            情报项或None
        """
        try:
            # 提取仓库信息
            title_element = article.select_one("h2 a")
            if not title_element:
                return None

            # 仓库名称
            repo_name = title_element.get_text().strip().replace("\n", "").replace(" ", "")
            repo_url = "https://github.com" + title_element.get("href")

            # 描述
            description_element = article.select_one("p")
            description = description_element.get_text().strip() if description_element else "暂无描述"

            # 编程语言
            language_element = article.select_one("span[itemprop='programmingLanguage']")
            language = language_element.get_text().strip() if language_element else "Unknown"

            # 星标数
            stars_element = article.select_one("a[href*='/stargazers']")
            stars_text = stars_element.get_text().strip() if stars_element else "0"
            stars = self._parse_number(stars_text)

            # Fork数
            forks_element = article.select_one("a[href*='/forks']")
            forks_text = forks_element.get_text().strip() if forks_element else "0"
            forks = self._parse_number(forks_text)

            # 今日星标
            today_stars_element = article.select_one("span.d-inline-block.float-sm-right")
            today_stars = 0
            if today_stars_element:
                today_stars_text = today_stars_element.get_text().strip()
                today_stars = self._parse_number(today_stars_text) if today_stars_text else 0

            # 构建内容
            content = f"""{description}

📊 项目统计:
⭐ 星标: {stars} ({today_stars} today)
🍴 Fork: {forks}
💻 语言: {language}
🔗 链接: {repo_url}"""

            # 生成URL哈希
            import hashlib
            url_hash = hashlib.md5(repo_url.encode()).hexdigest()

            # 使用日期作为GUID的一部分，确保每天都能采集到新数据
            today = datetime.utcnow().strftime("%Y-%m-%d")

            # 创建情报项
            item = IntelligenceItem(
                topic_id=self.topic.id,
                title=f"🔥 {repo_name} - {description[:50]}...",
                content=content,
                url=repo_url,
                source="GitHub Trending",
                author=repo_name.split("/")[0] if "/" in repo_name else "Unknown",
                published_at=datetime.utcnow(),  # GitHub Trending是实时的
                url_hash=url_hash,
                guid=f"github_{repo_name}_{today}",  # 使用 仓库名_日期 作为GUID
                metadata={
                    "repo_name": repo_name,
                    "language": language,
                    "stars": stars,
                    "forks": forks,
                    "today_stars": today_stars,
                    "description": description,
                    "collected_date": today  # 记录采集日期
                }
            )

            return item

        except Exception as e:
            logger.error(f"Error parsing repository element: {e}")
            return None

    def _parse_number(self, text: str) -> int:
        """
        解析数字文本（如 "1.2k" -> 1200）

        Args:
            text: 数字文本

        Returns:
            整数
        """
        if not text:
            return 0

        text = text.lower().replace(",", "").strip()

        # 处理k（千）
        if "k" in text:
            return int(float(text.replace("k", "")) * 1000)

        # 处理m（百万）
        if "m" in text:
            return int(float(text.replace("m", "")) * 1000000)

        # 直接转换
        try:
            return int(text)
        except ValueError:
            return 0
