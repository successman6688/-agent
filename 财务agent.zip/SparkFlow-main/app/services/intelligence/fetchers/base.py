"""Base fetcher interface for extensible data sources."""

from abc import ABC, abstractmethod
from typing import List, Optional, Dict, Any
from datetime import datetime

from app.models.intelligence import IntelligenceItem, SourceConfig, IntelligenceTopic
from app.core.logging import get_logger

logger = get_logger(__name__)


class BaseFetcher(ABC):
    """
    数据源采集器基类

    所有数据源采集器都应该继承这个基类，实现统一的接口。
    这样可以轻松扩展新的数据源。
    """

    def __init__(self, config: SourceConfig, topic: IntelligenceTopic):
        """
        初始化采集器

        Args:
            config: 数据源配置
            topic: 情报主题
        """
        self.config = config
        self.topic = topic
        self.source_name = config.name

    @abstractmethod
    async def fetch(self) -> List[IntelligenceItem]:
        """
        抓取数据

        Returns:
            情报项列表

        Raises:
            Exception: 抓取失败时抛出异常
        """
        pass

    @abstractmethod
    def validate_config(self) -> bool:
        """
        验证配置是否有效

        Returns:
            配置是否有效
        """
        pass

    def _create_item(
        self,
        title: str,
        content: str,
        url: str,
        published_at: datetime,
        **kwargs
    ) -> IntelligenceItem:
        """
        创建情报项的辅助方法

        Args:
            title: 标题
            content: 内容
            url: 链接
            published_at: 发布时间
            **kwargs: 其他字段

        Returns:
            情报项
        """
        import hashlib

        # 计算URL哈希（用于去重）
        url_hash = hashlib.md5(url.encode()).hexdigest()

        # 计算内容哈希（可选，用于深度去重）
        content_hash = None
        if content:
            content_hash = hashlib.md5(
                content[:500].encode()
            ).hexdigest()

        return IntelligenceItem(
            topic_id=self.topic.id,
            title=title,
            content=content,
            url=url,
            source=self.source_name,
            published_at=published_at,
            collected_at=datetime.utcnow(),
            url_hash=url_hash,
            content_hash=content_hash,
            guid=kwargs.get('guid'),
            author=kwargs.get('author'),
            metadata=kwargs.get('metadata', {})
        )

    def _parse_date(self, date_str: Optional[str]) -> datetime:
        """
        解析日期字符串

        Args:
            date_str: 日期字符串

        Returns:
            datetime对象
        """
        if not date_str:
            return datetime.utcnow()

        try:
            from email.utils import parsedate_to_datetime
            return parsedate_to_datetime(date_str)
        except:
            try:
                return datetime.fromisoformat(date_str)
            except:
                logger.warning(f"Failed to parse date: {date_str}")
                return datetime.utcnow()


class FetcherFactory:
    """
    采集器工厂类

    用于根据数据源类型创建对应的采集器实例
    """

    _fetchers: Dict[str, type] = {}

    @classmethod
    def register(cls, source_type: str, fetcher_class: type):
        """
        注册采集器

        Args:
            source_type: 数据源类型
            fetcher_class: 采集器类
        """
        cls._fetchers[source_type] = fetcher_class
        logger.info(f"Registered fetcher: {source_type} -> {fetcher_class.__name__}")

    @classmethod
    def create(
        cls,
        config: SourceConfig,
        topic: IntelligenceTopic
    ) -> BaseFetcher:
        """
        创建采集器实例

        Args:
            config: 数据源配置
            topic: 情报主题

        Returns:
            采集器实例

        Raises:
            ValueError: 不支持的数据源类型
        """
        fetcher_class = cls._fetchers.get(config.type)

        if not fetcher_class:
            raise ValueError(f"Unsupported source type: {config.type}")

        return fetcher_class(config, topic)

    @classmethod
    def list_supported_types(cls) -> List[str]:
        """
        获取支持的数据源类型列表

        Returns:
            数据源类型列表
        """
        return list(cls._fetchers.keys())
