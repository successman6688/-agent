"""Intelligence fetchers package."""

from app.services.intelligence.fetchers.base import BaseFetcher, FetcherFactory
from app.services.intelligence.fetchers.google_news import GoogleNewsRSSFetcher
from app.services.intelligence.fetchers.github_trending import GitHubTrendingFetcher

# 注册采集器
FetcherFactory.register("rss", GoogleNewsRSSFetcher)
FetcherFactory.register("github_trending", GitHubTrendingFetcher)

__all__ = [
    "BaseFetcher",
    "FetcherFactory",
    "GoogleNewsRSSFetcher",
    "GitHubTrendingFetcher",
]
