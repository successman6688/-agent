"""Intelligence service package."""

from app.services.intelligence.coordinator import (
    IntelligenceCoordinator,
)
from app.services.intelligence.storage import IntelligenceStorage
from app.services.intelligence.deduplicator import Deduplicator
from app.services.intelligence.scorer import RelevanceScorer
from app.services.intelligence.analyzer import AIAnalyzer, get_ai_analyzer
from app.services.intelligence.scheduler import IntelligenceScheduler, get_intelligence_scheduler
from app.services.intelligence.keyword_analyzer import KeywordAnalyzer, get_keyword_analyzer
from app.services.intelligence.fetchers import (
    FetcherFactory,
    GoogleNewsRSSFetcher,
    GitHubTrendingFetcher,
)

__all__ = [
    "IntelligenceCoordinator",
    "IntelligenceStorage",
    "Deduplicator",
    "RelevanceScorer",
    "AIAnalyzer",
    "get_ai_analyzer",
    "IntelligenceScheduler",
    "get_intelligence_scheduler",
    "KeywordAnalyzer",
    "get_keyword_analyzer",
    "FetcherFactory",
    "GoogleNewsRSSFetcher",
    "GitHubTrendingFetcher",
]
