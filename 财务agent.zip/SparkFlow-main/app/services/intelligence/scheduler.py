"""Intelligence collection scheduler using APScheduler."""

from typing import Dict, Optional, List
from datetime import datetime
import asyncio

from apscheduler.schedulers.asyncio import AsyncIOScheduler
from apscheduler.triggers.interval import IntervalTrigger
from apscheduler.triggers.cron import CronTrigger
from apscheduler.jobstores.memory import MemoryJobStore
from apscheduler.executors.asyncio import AsyncIOExecutor
from sqlalchemy.ext.asyncio import AsyncSession

from app.models.intelligence import (
    IntelligenceTopic,
    ScheduleType,
    CollectionResponse,
)
from app.services.intelligence.coordinator import IntelligenceCoordinator
from app.db.intelligence_repository import IntelligenceRepository
from app.db.connection import get_db_session
from app.db import IntelligenceTopicDB
from sqlalchemy import select
from app.core.logging import get_logger

logger = get_logger(__name__)


class IntelligenceScheduler:
    """
    情报收集调度器

    使用APScheduler实现定时任务调度，支持：
    - 每小时、每天、每周自动收集
    - 动态添加/删除任务
    - 任务执行状态追踪
    """

    def __init__(self):
        """初始化调度器"""
        # 配置调度器
        jobstores = {
            'default': MemoryJobStore()
        }
        executors = {
            'default': AsyncIOExecutor()
        }
        job_defaults = {
            'coalesce': True,  # 合并错过的执行
            'max_instances': 1,  # 最大并发实例数
            'misfire_grace_time': 3600  # 错过执行的宽限时间（秒）
        }

        self.scheduler = AsyncIOScheduler(
            jobstores=jobstores,
            executors=executors,
            job_defaults=job_defaults,
            timezone='Asia/Shanghai'
        )

        # 任务ID前缀
        self.job_id_prefix = "intelligence_"

        logger.info("Intelligence scheduler initialized")

    def start(self):
        """启动调度器"""
        if not self.scheduler.running:
            self.scheduler.start()
            logger.info("Scheduler started")

    def stop(self):
        """停止调度器"""
        if self.scheduler.running:
            self.scheduler.shutdown(wait=False)
            logger.info("Scheduler stopped")

    def is_running(self) -> bool:
        """
        检查调度器是否运行中

        Returns:
            是否运行中
        """
        return self.scheduler.running

    async def schedule_topic(
        self,
        topic: IntelligenceTopic
    ) -> bool:
        """
        为主题添加定时收集任务

        Args:
            topic: 情报主题

        Returns:
            是否成功添加
        """
        try:
            # 如果主题未激活，不添加任务
            if not topic.is_active:
                logger.warning(f"Topic {topic.id} is not active, skipping scheduling")
                return False

            # 移除旧任务（如果存在）
            await self.unschedule_topic(topic.id)

            # 根据调度类型创建触发器
            trigger = self._create_trigger(topic.schedule)

            if trigger is None:
                logger.warning(f"Unsupported schedule type: {topic.schedule}")
                return False

            # 添加任务
            job_id = f"{self.job_id_prefix}{topic.id}"

            self.scheduler.add_job(
                self._collect_wrapper,
                trigger=trigger,
                id=job_id,
                args=[topic.id],
                name=f"Intelligence collection for {topic.name}",
                replace_existing=True
            )

            logger.info(
                f"Scheduled topic '{topic.name}' ({topic.id}) "
                f"with schedule: {topic.schedule}"
            )

            # 更新主题的最后调度时间
            async with get_db_session() as session:
                repo = IntelligenceRepository(session)
                await repo.update_topic(topic.id, {
                    "last_run_time": datetime.utcnow()
                })

            return True

        except Exception as e:
            logger.error(f"Error scheduling topic {topic.id}: {e}")
            return False

    async def unschedule_topic(self, topic_id: str) -> bool:
        """
        移除主题的定时任务

        Args:
            topic_id: 主题ID

        Returns:
            是否成功移除
        """
        try:
            job_id = f"{self.job_id_prefix}{topic_id}"

            if self.scheduler.get_job(job_id):
                self.scheduler.remove_job(job_id)
                logger.info(f"Unscheduled topic: {topic_id}")
                return True
            else:
                logger.debug(f"No job found for topic: {topic_id}")
                return False

        except Exception as e:
            logger.error(f"Error unscheduling topic {topic_id}: {e}")
            return False

    async def schedule_all_active_topics(self) -> int:
        """
        调度所有激活的主题

        Returns:
            成功调度的主题数量
        """
        async with get_db_session() as session:
            repo = IntelligenceRepository(session)
            db_topics = await repo.list_topics()

        # Convert DB models to Pydantic models
        from app.api.v1.endpoints.intelligence import db_to_pynamo_topic
        active_topics = [db_to_pynamo_topic(t) for t in db_topics if t.is_active]

        count = 0
        for topic in active_topics:
            success = await self.schedule_topic(topic)
            if success:
                count += 1

        logger.info(f"Scheduled {count}/{len(active_topics)} active topics")
        return count

    async def unschedule_all(self) -> int:
        """
        移除所有调度任务

        Returns:
            移除的任务数量
        """
        count = 0
        for job in self.scheduler.get_jobs():
            if job.id.startswith(self.job_id_prefix):
                self.scheduler.remove_job(job.id)
                count += 1

        logger.info(f"Unscheduled {count} topics")
        return count

    def get_scheduled_topics(self) -> List[Dict]:
        """
        获取所有调度任务列表

        Returns:
            任务信息列表
        """
        jobs = []
        for job in self.scheduler.get_jobs():
            if job.id.startswith(self.job_id_prefix):
                topic_id = job.id.replace(self.job_id_prefix, "")
                jobs.append({
                    "topic_id": topic_id,
                    "job_id": job.id,
                    "name": job.name,
                    "next_run_time": job.next_run_time.isoformat() if job.next_run_time else None,
                })
        return jobs

    def _create_trigger(self, schedule_type: ScheduleType):
        """
        根据调度类型创建触发器

        Args:
            schedule_type: 调度类型

        Returns:
            触发器对象或None
        """
        if schedule_type == ScheduleType.HOURLY:
            return IntervalTrigger(hours=1)
        elif schedule_type == ScheduleType.DAILY:
            # 每天早上8点执行（优化：比9点更早，用户上班就能看到）
            return CronTrigger(hour=8, minute=0)
        elif schedule_type == ScheduleType.WEEKLY:
            # 每周一早上8点执行
            return CronTrigger(day_of_week='mon', hour=8, minute=0)
        elif schedule_type == ScheduleType.MANUAL:
            # 手动触发，不添加定时任务
            return None
        else:
            return None

    async def _collect_wrapper(self, topic_id: str):
        """
        情报收集包装函数（用于任务执行）

        Args:
            topic_id: 主题ID
        """
        logger.info(f"Scheduled collection started for topic: {topic_id}")

        try:
            # 加载主题
            async with get_db_session() as session:
                repo = IntelligenceRepository(session)
                db_topic = await repo.get_topic(topic_id)

                if not db_topic:
                    logger.error(f"Topic not found: {topic_id}")
                    return

                if not db_topic.is_active:
                    logger.warning(f"Topic is not active: {topic_id}")
                    return

                # Convert to Pydantic model
                from app.api.v1.endpoints.intelligence import db_to_pynamo_topic
                topic = db_to_pynamo_topic(db_topic)

                # 创建协调器并执行收集
                coordinator = IntelligenceCoordinator(session)
                response = await coordinator.collect_intelligence(topic)

                logger.info(
                    f"Scheduled collection completed for topic '{topic.name}': "
                    f"{response.new_items} new items, "
                    f"status: {response.status}"
                )

        except Exception as e:
            logger.error(f"Error in scheduled collection for topic {topic_id}: {e}")

    async def trigger_collection(self, topic_id: str) -> Optional[CollectionResponse]:
        """
        手动触发收集（不等待定时任务）

        Args:
            topic_id: 主题ID

        Returns:
            收集响应或None
        """
        try:
            async with get_db_session() as session:
                repo = IntelligenceRepository(session)
                db_topic = await repo.get_topic(topic_id)

                if not db_topic:
                    logger.error(f"Topic not found: {topic_id}")
                    return None

                if not db_topic.is_active:
                    logger.warning(f"Topic is not active: {topic_id}")
                    return None

                # Convert to Pydantic model
                from app.api.v1.endpoints.intelligence import db_to_pynamo_topic
                topic = db_to_pynamo_topic(db_topic)

                logger.info(f"Manual collection triggered for topic: {topic_id}")

                # 创建协调器并执行收集
                coordinator = IntelligenceCoordinator(session)
                response = await coordinator.collect_intelligence(topic)
                return response

        except Exception as e:
            logger.error(f"Error in manual collection for topic {topic_id}: {e}")
            return None


# 全局调度器实例
_scheduler: Optional[IntelligenceScheduler] = None


def get_intelligence_scheduler() -> IntelligenceScheduler:
    """获取情报调度器实例（单例）"""
    global _scheduler
    if _scheduler is None:
        _scheduler = IntelligenceScheduler()
    return _scheduler
