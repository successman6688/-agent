"""异步任务管理器"""

import asyncio
from typing import Dict, Optional, Any, Callable
from datetime import datetime
from enum import Enum

from app.core.logging import get_logger
from app.services.intelligence.websocket import get_websocket_manager

logger = get_logger(__name__)


class TaskStatus(str, Enum):
    """任务状态"""
    PENDING = "pending"      # 待执行
    RUNNING = "running"      # 执行中
    COMPLETED = "completed"  # 完成
    FAILED = "failed"        # 失败


class AsyncTask:
    """异步任务"""

    def __init__(
        self,
        task_id: str,
        topic_id: str,
        coro: asyncio.Task
    ):
        self.task_id = task_id
        self.topic_id = topic_id
        self.coro = coro
        self.status = TaskStatus.PENDING
        self.created_at = datetime.utcnow()
        self.started_at: Optional[datetime] = None
        self.completed_at: Optional[datetime] = None
        self.result: Optional[Dict[str, Any]] = None
        self.error: Optional[str] = None

    def to_dict(self) -> Dict[str, Any]:
        """转换为字典"""
        return {
            "task_id": self.task_id,
            "topic_id": self.topic_id,
            "status": self.status.value,
            "created_at": self.created_at.isoformat(),
            "started_at": self.started_at.isoformat() if self.started_at else None,
            "completed_at": self.completed_at.isoformat() if self.completed_at else None,
            "result": self.result,
            "error": self.error
        }


class TaskManager:
    """
    异步任务管理器

    管理后台长时间运行的任务，支持：
    - 创建任务
    - 查询任务状态
    - 获取任务结果
    """

    def __init__(self):
        """初始化任务管理器"""
        self.tasks: Dict[str, AsyncTask] = {}
        self._cleanup_interval = 3600  # 1小时清理一次旧任务

    async def create_task(
        self,
        topic_id: str,
        coro: asyncio.Task
    ) -> str:
        """
        创建新任务

        Args:
            topic_id: 主题ID
            coro: 协程任务

        Returns:
            任务ID
        """
        import uuid
        task_id = str(uuid.uuid4())

        task = AsyncTask(task_id, topic_id, coro)
        self.tasks[task_id] = task

        logger.info(f"Created task {task_id} for topic {topic_id}")

        # 启动任务
        asyncio.create_task(self._run_task(task))

        return task_id

    async def _run_task(self, task: AsyncTask):
        """
        运行任务

        Args:
            task: 任务对象
        """
        task.status = TaskStatus.RUNNING
        task.started_at = datetime.utcnow()

        # 获取 WebSocket 管理器
        ws_manager = get_websocket_manager()

        # 通知任务开始
        await ws_manager.send_task_update(
            task.topic_id,
            task.task_id,
            TaskStatus.RUNNING.value
        )

        try:
            # 等待任务完成
            result = await task.coro

            # 将 Pydantic 模型转换为字典
            if hasattr(result, 'model_dump'):
                task.result = result.model_dump()
            elif hasattr(result, 'dict'):
                task.result = result.dict()
            else:
                task.result = result

            task.status = TaskStatus.COMPLETED
            task.completed_at = datetime.utcnow()

            # 获取 new_items 数量
            new_items = 0
            if isinstance(task.result, dict):
                new_items = task.result.get('new_items', 0)
            elif hasattr(task.result, 'new_items'):
                new_items = task.result.new_items

            logger.info(
                f"Task {task.task_id} completed: "
                f"{new_items} items"
            )

            # 通知任务完成
            await ws_manager.send_task_update(
                task.topic_id,
                task.task_id,
                TaskStatus.COMPLETED.value,
                result=task.result
            )

        except Exception as e:
            task.status = TaskStatus.FAILED
            task.error = str(e)
            task.completed_at = datetime.utcnow()

            logger.error(f"Task {task.task_id} failed: {e}", exc_info=True)

            # 通知任务失败
            await ws_manager.send_task_update(
                task.topic_id,
                task.task_id,
                TaskStatus.FAILED.value,
                error=task.error
            )

    def get_task(self, task_id: str) -> Optional[AsyncTask]:
        """
        获取任务

        Args:
            task_id: 任务ID

        Returns:
            任务对象，不存在返回None
        """
        return self.tasks.get(task_id)

    def get_tasks_by_topic(self, topic_id: str) -> list[AsyncTask]:
        """
        获取主题的所有任务

        Args:
            topic_id: 主题ID

        Returns:
            任务列表
        """
        return [
            task for task in self.tasks.values()
            if task.topic_id == topic_id
        ]

    async def cleanup_old_tasks(self, max_age_seconds: int = 86400):
        """
        清理旧任务

        Args:
            max_age_seconds: 最大保留时间（秒），默认24小时
        """
        from datetime import timedelta

        cutoff = datetime.utcnow() - timedelta(seconds=max_age_seconds)

        old_tasks = [
            task_id for task_id, task in self.tasks.items()
            if task.created_at < cutoff
        ]

        for task_id in old_tasks:
            del self.tasks[task_id]

        if old_tasks:
            logger.info(f"Cleaned up {len(old_tasks)} old tasks")


# 全局任务管理器实例
_task_manager: Optional[TaskManager] = None


def get_task_manager() -> TaskManager:
    """获取任务管理器实例（单例）"""
    global _task_manager
    if _task_manager is None:
        _task_manager = TaskManager()
    return _task_manager
