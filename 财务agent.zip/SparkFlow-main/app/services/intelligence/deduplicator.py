"""Intelligence deduplicator."""

import hashlib
from typing import List, Set, Optional
from difflib import SequenceMatcher

from app.models.intelligence import IntelligenceItem
from app.core.logging import get_logger

logger = get_logger(__name__)


class Deduplicator:
    """
    情报去重器

    实现三重去重策略：
    1. GUID去重（适用于RSS）
    2. URL哈希去重
    3. 内容相似度去重（可选）
    """

    def __init__(self, enable_content_dedup: bool = False):
        """
        初始化去重器

        Args:
            enable_content_dedup: 是否启用内容相似度去重
        """
        self.enable_content_dedup = enable_content_dedup

        # 去重缓存
        self.seen_guids: Set[str] = set()
        self.seen_urls: Set[str] = set()
        self.seen_content: Set[str] = set()

    def deduplicate(
        self,
        items: List[IntelligenceItem]
    ) -> List[IntelligenceItem]:
        """
        对情报列表进行去重

        Args:
            items: 情报列表

        Returns:
            去重后的情报列表
        """
        unique_items = []

        for item in items:
            # 第一层: GUID去重
            if self._is_duplicate_by_guid(item):
                logger.debug(f"Duplicate by GUID: {item.guid}")
                continue

            # 第二层: URL哈希去重
            if self._is_duplicate_by_url(item):
                logger.debug(f"Duplicate by URL: {item.url}")
                continue

            # 第三层: 内容哈希去重（可选）
            if self.enable_content_dedup:
                if self._is_duplicate_by_content(item):
                    logger.debug(f"Duplicate by content: {item.title[:50]}")
                    continue
                self._add_content_cache(item)

            # 通过所有去重检查
            unique_items.append(item)

            # 记录已见
            self._add_cache(item)

        logger.info(
            f"Deduplication: {len(items)} -> {len(unique_items)} "
            f"(removed {len(items) - len(unique_items)} duplicates)"
        )

        return unique_items

    def _is_duplicate_by_guid(self, item: IntelligenceItem) -> bool:
        """检查GUID是否重复"""
        if not item.guid:
            return False
        return item.guid in self.seen_guids

    def _is_duplicate_by_url(self, item: IntelligenceItem) -> bool:
        """检查URL是否重复"""
        return item.url_hash in self.seen_urls

    def _is_duplicate_by_content(self, item: IntelligenceItem) -> bool:
        """
        检查内容是否相似（基于内容哈希）

        Args:
            item: 情报项

        Returns:
            是否重复
        """
        if not item.content_hash:
            return False

        # 检查精确匹配
        if item.content_hash in self.seen_content:
            return True

        # 检查相似度（可选，性能开销较大）
        # 这里可以添加更复杂的相似度算法
        return False

    def _add_cache(self, item: IntelligenceItem):
        """添加到去重缓存"""
        if item.guid:
            self.seen_guids.add(item.guid)
        self.seen_urls.add(item.url_hash)

        if self.enable_content_dedup and item.content_hash:
            self.seen_content.add(item.content_hash)

    def _add_content_cache(self, item: IntelligenceItem):
        """添加内容缓存（用于第三层去重）"""
        if item.content_hash:
            self.seen_content.add(item.content_hash)

    def clear(self):
        """清空所有缓存"""
        self.seen_guids.clear()
        self.seen_urls.clear()
        self.seen_content.clear()
        logger.info("Deduplicator cache cleared")

    def get_stats(self) -> dict:
        """
        获取去重统计信息

        Returns:
            统计信息字典
        """
        return {
            "seen_guids": len(self.seen_guids),
            "seen_urls": len(self.seen_urls),
            "seen_content": len(self.seen_content),
        }
