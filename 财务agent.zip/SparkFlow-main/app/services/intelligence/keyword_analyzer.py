"""AI-powered keyword analyzer for intelligence topics."""

import json
from typing import List, Dict, Any, Optional
from datetime import datetime

from app.integrations.llm.base import create_llm
from app.core.logging import get_logger

logger = get_logger(__name__)


class KeywordAnalyzer:
    """
    关键词智能分析器

    用户输入关键词后，AI自动：
    1. 分析关键词意图
    2. 扩展相关关键词
    3. 推荐最佳数据源
    4. 生成主题名称和描述
    5. 优化搜索查询
    """

    def __init__(self):
        """初始化分析器"""
        self.llm = create_llm(temperature=0.3, max_tokens=1500)
        logger.info("Keyword Analyzer initialized")

    async def analyze_keywords(
        self,
        user_input: str,
        language: str = "zh"
    ) -> Dict[str, Any]:
        """
        分析用户输入的关键词

        Args:
            user_input: 用户输入的关键词
            language: 语言 (zh/en)

        Returns:
            分析结果字典
        """
        logger.info(f"Analyzing keywords: {user_input}")

        prompt = self._build_analysis_prompt(user_input, language)

        try:
            response = await self.llm.ainvoke(prompt)
            response_text = response.content.strip()

            # 解析JSON响应
            if response_text.startswith("```"):
                response_text = response_text.split("```")[1]
                if response_text.startswith("json"):
                    response_text = response_text[4:]

            analysis = json.loads(response_text.strip())

            # 验证和补充默认值
            analysis = self._validate_and_enrich(analysis, user_input)

            logger.info(f"Keyword analysis completed: {analysis.get('primary_keywords', [])}")
            return analysis

        except json.JSONDecodeError as e:
            logger.error(f"Failed to parse AI response as JSON: {e}")
            return self._get_fallback_analysis(user_input)
        except Exception as e:
            logger.error(f"Error analyzing keywords: {e}")
            return self._get_fallback_analysis(user_input)

    def _build_analysis_prompt(self, user_input: str, language: str) -> str:
        """
        构建分析提示词

        Args:
            user_input: 用户输入
            language: 语言

        Returns:
            提示词字符串
        """
        if language == "zh":
            prompt = f"""你是一个专业的情报分析专家。请分析用户输入的关键词，提供智能建议。

用户输入: {user_input}

请按以下JSON格式返回分析结果：
{{
    "primary_keywords": ["关键词1", "关键词2", "关键词3"],
    "expanded_keywords": ["扩展词1", "扩展词2", "扩展词3", "扩展词4", "扩展词5"],
    "search_queries": [
        {{"source": "google_news", "query": "优化后的搜索查询1"}},
        {{"source": "google_news", "query": "优化后的搜索查询2"}}
    ],
    "recommended_sources": [
        {{"type": "rss", "name": "Google News", "reason": "覆盖全球新闻，实时更新"}}
    ],
    "topic_name": "建议的主题名称",
    "topic_description": "建议的主题描述",
    "schedule": "daily",
    "category": "财经/科技/社会等",
    "insights": ["洞察1", "洞察2", "洞察3"],
    "data_sources_tips": "数据源选择建议"
}}

要求：
1. primary_keywords: 从用户输入中提取2-4个最核心的关键词
2. expanded_keywords: 基于核心关键词扩展5-10个相关词汇（同义词、相关概念、行业术语）
3. search_queries: 针对不同数据源优化的搜索查询，提高搜索准确度
4. recommended_sources: 根据主题推荐最合适的数据源（google_news, github_trending等）
5. topic_name: 简洁明确的主题名称（15字以内）
6. topic_description: 详细说明监控目标和价值（50字以内）
7. schedule: 建议的更新频率（hourly/daily/weekly）
8. category: 主题分类
9. insights: 3个关于为什么这些关键词重要的洞察
10. data_sources_tips: 关于如何选择数据源的专业建议

只返回JSON，不要其他内容。
"""
        else:  # English
            prompt = f"""You are an intelligence analysis expert. Analyze the user's keywords and provide smart suggestions.

User input: {user_input}

Return the analysis in this JSON format:
{{
    "primary_keywords": ["keyword1", "keyword2", "keyword3"],
    "expanded_keywords": ["expanded1", "expanded2", "expanded3", "expanded4", "expanded5"],
    "search_queries": [
        {{"source": "google_news", "query": "optimized query 1"}},
        {{"source": "google_news", "query": "optimized query 2"}}
    ],
    "recommended_sources": [
        {{"type": "rss", "name": "Google News", "reason": "Covers global news, real-time updates"}}
    ],
    "topic_name": "Suggested topic name",
    "topic_description": "Suggested topic description",
    "schedule": "daily",
    "category": "Finance/Tech/Society etc",
    "insights": ["insight1", "insight2", "insight3"],
    "data_sources_tips": "Tips for data source selection"
}}

Requirements:
1. primary_keywords: Extract 2-4 core keywords from user input
2. expanded_keywords: Expand to 5-10 related terms (synonyms, related concepts, industry terms)
3. search_queries: Optimize queries for different data sources
4. recommended_sources: Recommend best data sources (google_news, github_trending, etc.)
5. topic_name: Concise topic name (under 15 words)
6. topic_description: Detailed description of monitoring goals (under 50 words)
7. schedule: Suggested update frequency (hourly/daily/weekly)
8. category: Topic category
9. insights: 3 insights about why these keywords matter
10. data_sources_tips: Professional advice on data source selection

Return JSON only, no other content.
"""

        return prompt

    def _validate_and_enrich(
        self,
        analysis: Dict[str, Any],
        user_input: str
    ) -> Dict[str, Any]:
        """
        验证并补充分析结果

        Args:
            analysis: AI分析结果
            user_input: 用户输入

        Returns:
            验证后的分析结果
        """
        # 确保必需字段存在
        required_fields = [
            "primary_keywords",
            "expanded_keywords",
            "search_queries",
            "recommended_sources",
            "topic_name",
            "topic_description",
            "schedule",
            "category",
            "insights"
        ]

        for field in required_fields:
            if field not in analysis:
                analysis[field] = []

        # 特殊处理
        if not analysis["primary_keywords"]:
            analysis["primary_keywords"] = [user_input]

        if not analysis["expanded_keywords"]:
            analysis["expanded_keywords"] = [user_input]

        if not analysis["topic_name"]:
            analysis["topic_name"] = f"{user_input}监控"

        if not analysis["topic_description"]:
            analysis["topic_description"] = f"自动监控关于'{user_input}'的最新情报"

        if not analysis["schedule"]:
            analysis["schedule"] = "daily"

        # 添加时间戳
        analysis["analyzed_at"] = datetime.utcnow().isoformat()
        analysis["user_input"] = user_input

        return analysis

    def _get_fallback_analysis(self, user_input: str) -> Dict[str, Any]:
        """
        获取后备分析结果（当AI分析失败时）

        Args:
            user_input: 用户输入

        Returns:
            后备分析结果
        """
        # 改进的关键词提取逻辑
        keywords = []

        # 按多种分隔符分割
        import re
        # 分割中文逗号、顿号、空格等
        parts = re.split(r'[,，、\s]+', user_input)
        keywords = [kw.strip() for kw in parts if kw.strip()]

        # 如果分割后只有一个关键词，尝试智能提取
        if len(keywords) <= 1:
            # 尝试提取引用的内容
            # 例如："黄金投资" -> "黄金", "投资"
            # 例如："黄金价格走势" -> "黄金价格", "走势"
            keywords = []
            for pattern in [r'([^\s]+)(?:投资|价格|走势|监控|市场|新闻)', r'([^\s]+)(?:的分析)?']:
                matches = re.findall(pattern, user_input)
                if matches:
                    keywords.extend(matches)
                    break

            # 如果还是没有，至少提取一个主要词
            if not keywords:
                # 提取主要的名词短语
                main_match = re.search(r'([\u4e00-\u9fa5]{2,4}|[a-zA-Z]{2,10})', user_input)
                if main_match:
                    keywords.append(main_match.group(1))
                else:
                    keywords = [user_input[:20]]  # 前20个字符

        # 生成扩展关键词
        expanded_keywords = set(keywords)
        if keywords:
            # 为每个关键词生成一些扩展
            for kw in keywords[:3]:  # 最多处理前3个
                expanded_keywords.add(kw)
                # 添加一些常见相关的词
                if '黄金' in kw or '金价' in kw:
                    expanded_keywords.update(['现货黄金', '黄金期货', '纸黄金', '实物黄金'])
                elif 'AI' in kw or '人工智能' in kw:
                    expanded_keywords.update(['大模型', 'ChatGPT', '机器学习', '深度学习'])
                elif '投资' in kw:
                    expanded_keywords.update(['价值投资', '技术分析', '基本面'])

        # 去重并限制数量
        expanded_keywords = list(expanded_keywords)[:10]

        # 生成优化的搜索查询
        search_queries = []
        if len(keywords) >= 2:
            # 多个关键词，使用OR连接
            query_str = ' OR '.join([f'"{kw}"' for kw in keywords])
            search_queries.append({
                "source": "google_news",
                "query": query_str
            })
        elif keywords:
            # 单个关键词，直接使用
            search_queries.append({
                "source": "google_news",
                "query": keywords[0]
            })

        # 生成主题名称
        if len(keywords) >= 2:
            topic_name = f"{keywords[0]}、{keywords[1]}监控"
        elif keywords:
            topic_name = f"{keywords[0]}监控"
        else:
            topic_name = f"{user_input[:20]}监控"

        return {
            "user_input": user_input,
            "primary_keywords": keywords if keywords else [user_input],
            "expanded_keywords": expanded_keywords if expanded_keywords else keywords,
            "search_queries": search_queries,
            "recommended_sources": [
                {
                    "type": "rss",
                    "name": "Google News",
                    "reason": "通用新闻源，覆盖面广"
                }
            ],
            "topic_name": topic_name,
            "topic_description": f"监控关于'{', '.join(keywords[:3])}'的最新情报和动态",
            "schedule": "daily",
            "category": "通用",
            "insights": [
                f"检测到 {len(keywords)} 个核心关键词：{', '.join(keywords[:3])}",
                "建议关注实时新闻和动态更新",
                "系统已自动优化搜索查询以提高数据覆盖率"
            ],
            "data_sources_tips": "建议先使用Google News，后续可根据需要添加更多数据源",
            "analyzed_at": datetime.utcnow().isoformat(),
            "fallback": True,
            "improved_fallback": True  # 标记这是改进的fallback
        }


# 全局分析器实例
_analyzer: Optional[KeywordAnalyzer] = None


def get_keyword_analyzer() -> KeywordAnalyzer:
    """获取关键词分析器实例（单例）"""
    global _analyzer
    if _analyzer is None:
        _analyzer = KeywordAnalyzer()
    return _analyzer
