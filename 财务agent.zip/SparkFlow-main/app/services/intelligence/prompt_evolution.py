"""提示词自动演化服务

让AI自动分析和优化提示词，实现自我进化
"""

import json
from typing import List, Dict, Any, Optional
from datetime import datetime

from app.integrations.llm.base import create_llm
from app.core.logging import get_logger

logger = get_logger(__name__)


class PromptEvolutionService:
    """
    提示词自动演化服务

    功能：
    1. 分析提示词性能问题
    2. 使用LLM生成改进版本
    3. 评估新版本质量
    4. 推荐最佳版本
    """

    def __init__(self):
        """初始化演化服务"""
        self.llm = create_llm(temperature=0.7, max_tokens=2000)
        logger.info("Prompt Evolution Service initialized")

    async def analyze_prompt_problems(
        self,
        prompt: Dict[str, Any],
        execution_logs: List[Dict[str, Any]],
        user_feedbacks: List[Dict[str, Any]]
    ) -> Dict[str, Any]:
        """
        分析提示词存在的问题

        Args:
            prompt: 提示词信息
            execution_logs: 执行日志
            user_feedbacks: 用户反馈

        Returns:
            分析报告
        """
        # 计算统计数据
        total_executions = len(execution_logs)
        success_count = sum(1 for log in execution_logs if log.get("parse_success"))
        success_rate = success_count / total_executions if total_executions > 0 else 0

        # 获取失败的例子
        failed_logs = [
            log for log in execution_logs
            if not log.get("parse_success")
        ][:5]  # 最近5个失败案例

        # 用户反馈统计
        positive_feedback = sum(1 for f in user_feedbacks if self._is_positive_feedback(f))
        negative_feedback = sum(1 for f in user_feedbacks if self._is_negative_feedback(f))

        # 构建分析prompt
        analysis_prompt = f"""你是一个提示词工程专家。请分析以下提示词存在的问题。

**当前提示词：**
名称: {prompt.get('name')}
策略类型: {prompt.get('strategy_type')}
系统提示: {prompt.get('system_prompt')[:200]}...
用户提示: {prompt.get('user_prompt_template')[:300]}...

**性能数据：**
- 总执行次数: {total_executions}
- 成功率: {success_rate:.1%}
- 正面反馈: {positive_feedback}
- 负面反馈: {negative_feedback}

**失败案例（最近5个）：**
{self._format_failed_logs(failed_logs)}

**问题分析：**
请分析可能存在的问题：
1. JSON格式问题
2. 输出质量问题
3. 逻辑错误
4. 其他问题

请以JSON格式返回：
{{
    "problems": [
        {{
            "type": "问题类型（json_format/output_quality/logic/other）",
            "description": "问题描述",
            "severity": "high/medium/low",
            "evidence": "证据"
        }}
    ],
    "suggested_improvements": [
        "改进建议1",
        "改进建议2"
    ],
    "overall_score": 1-10分
}}

只返回JSON，不要其他内容。"""

        try:
            response = await self.llm.ainvoke(analysis_prompt)
            response_text = response.content.strip()

            # 清理markdown标记
            if response_text.startswith("```"):
                response_text = response_text.split("```")[1]
                if response_text.startswith("json"):
                    response_text = response_text[4:]

            analysis = json.loads(response_text.strip())
            return analysis

        except Exception as e:
            logger.error(f"Failed to analyze prompt: {e}")
            return self._get_default_analysis()

    async def generate_improved_versions(
        self,
        current_prompt: Dict[str, Any],
        problems: List[Dict[str, Any]],
        num_versions: int = 3
    ) -> List[Dict[str, Any]]:
        """
        生成改进版本的提示词

        Args:
            current_prompt: 当前提示词
            problems: 问题列表
            num_versions: 生成数量

        Returns:
            改进版本列表
        """
        evolution_prompt = f"""你是一个顶级提示词工程师。请基于以下信息，生成{num_versions}个改进版本的提示词。

**当前提示词：**
{json.dumps(current_prompt, ensure_ascii=False, indent=2)}

**发现的问题：**
{json.dumps(problems, ensure_ascii=False, indent=2)}

**要求：**
1. 针对每个问题进行改进
2. 保持原有的核心功能
3. 优化输出格式和清晰度
4. 增强鲁棒性（处理边界情况）
5. 保持与原提示词相同的输出格式

请生成{num_versions}个改进版本，每个版本包含：
- name: 版本名称（如"财经分析v2.1"）
- system_prompt: 改进的系统提示
- user_prompt_template: 改进的用户提示模板

以JSON数组格式返回：
[
    {{
        "name": "改进版本1名称",
        "system_prompt": "...",
        "user_prompt_template": "...",
        "improvements": ["改进点1", "改进点2"]
    }},
    ...
]

只返回JSON，不要其他内容。"""

        try:
            response = await self.llm.ainvoke(evolution_prompt)
            response_text = response.content.strip()

            # 清理markdown标记
            if response_text.startswith("```"):
                response_text = response_text.split("```")[1]
                if response_text.startswith("json"):
                    response_text = response_text[4:]

            versions = json.loads(response_text.strip())

            # 添加元数据
            for version in versions:
                version["version"] = self._increment_version(current_prompt.get("version", "1.0"))
                version["parent_id"] = current_prompt.get("id")
                version["created_at"] = datetime.utcnow().isoformat()

            return versions

        except Exception as e:
            logger.error(f"Failed to generate improved versions: {e}")
            return []

    async def evaluate_prompt_quality(
        self,
        prompt: Dict[str, Any],
        test_cases: List[Dict[str, Any]] = None
    ) -> Dict[str, Any]:
        """
        评估提示词质量

        Args:
            prompt: 提示词
            test_cases: 测试用例（可选）

        Returns:
            质量评估报告
        """
        if not test_cases:
            test_cases = self._get_default_test_cases(prompt.get("strategy_type", "general"))

        evaluation_prompt = f"""你是一个提示词质量评估专家。请评估以下提示词的质量。

**提示词：**
{json.dumps(prompt, ensure_ascii=False, indent=2)}

**评估维度：**
1. 清晰度：指令是否清晰明确？
2. 完整性：是否包含所有必要信息？
3. 鲁棒性：能否处理边界情况？
4. 创新性：是否有独特的设计？
5. 实用性：是否能解决实际问题？

请以JSON格式返回评估结果：
{{
    "clarity": {{"score": 1-10, "comment": "评价"}},
    "completeness": {{"score": 1-10, "comment": "评价"}},
    "robustness": {{"score": 1-10, "comment": "评价"}},
    "innovation": {{"score": 1-10, "comment": "评价"}},
    "practicality": {{"score": 1-10, "comment": "评价"}},
    "overall_score": 1-10,
    "strengths": ["优点1", "优点2"],
    "weaknesses": ["缺点1", "缺点2"],
    "recommendation": "deploy/test/improve"
}}

只返回JSON，不要其他内容。"""

        try:
            response = await self.llm.ainvoke(evaluation_prompt)
            response_text = response.content.strip()

            # 清理markdown标记
            if response_text.startswith("```"):
                response_text = response_text.split("```")[1]
                if response_text.startswith("json"):
                    response_text = response_text[4:]

            evaluation = json.loads(response_text.strip())
            return evaluation

        except Exception as e:
            logger.error(f"Failed to evaluate prompt: {e}")
            return self._get_default_evaluation()

    def _format_failed_logs(self, failed_logs: List[Dict]) -> str:
        """格式化失败日志"""
        if not failed_logs:
            return "无失败案例"

        formatted = []
        for i, log in enumerate(failed_logs, 1):
            response_preview = log.get("llm_response", "")[:200]
            formatted.append(f"{i}. {response_preview}...")

        return "\n".join(formatted)

    def _is_positive_feedback(self, feedback: Dict) -> bool:
        """判断是否为正面反馈"""
        feedback_type = feedback.get("feedback_type")
        value = feedback.get("feedback_value")

        if feedback_type in ["thumbs_up", "useful"]:
            return True
        if feedback_type == "rating" and value and value >= 4:
            return True
        return False

    def _is_negative_feedback(self, feedback: Dict) -> bool:
        """判断是否为负面反馈"""
        feedback_type = feedback.get("feedback_type")
        value = feedback.get("feedback_value")

        if feedback_type in ["thumbs_down", "not_useful"]:
            return True
        if feedback_type == "rating" and value and value <= 2:
            return True
        return False

    def _increment_version(self, version: str) -> str:
        """增加版本号"""
        try:
            parts = version.split(".")
            if len(parts) == 2:
                major, minor = int(parts[0]), int(parts[1])
                return f"{major}.{minor + 1}"
        except:
            pass
        return "2.0"

    def _get_default_test_cases(self, strategy_type: str) -> List[Dict]:
        """获取默认测试用例"""
        return [
            {
                "input": "测试情报内容",
                "expected_output": {"core_conclusion": "...", "priority_actions": [...]}
            }
        ]

    def _get_default_analysis(self) -> Dict:
        """获取默认分析"""
        return {
            "problems": [
                {
                    "type": "unknown",
                    "description": "无法分析具体问题",
                    "severity": "medium",
                    "evidence": "分析失败"
                }
            ],
            "suggested_improvements": ["建议人工审查提示词"],
            "overall_score": 5
        }

    def _get_default_evaluation(self) -> Dict:
        """获取默认评估"""
        return {
            "clarity": {"score": 5, "comment": "无法评估"},
            "completeness": {"score": 5, "comment": "无法评估"},
            "robustness": {"score": 5, "comment": "无法评估"},
            "innovation": {"score": 5, "comment": "无法评估"},
            "practicality": {"score": 5, "comment": "无法评估"},
            "overall_score": 5,
            "strengths": [],
            "weaknesses": ["需要人工评估"],
            "recommendation": "test"
        }


# 全局实例
_evolution_service: Optional[PromptEvolutionService] = None


def get_prompt_evolution_service() -> PromptEvolutionService:
    """获取提示词演化服务实例（单例）"""
    global _evolution_service
    if _evolution_service is None:
        _evolution_service = PromptEvolutionService()
    return _evolution_service
