"""增强版AI情报分析器"""

import json
from typing import List, Dict, Any
from datetime import datetime, timedelta
import time

from app.models.intelligence import IntelligenceItem, TopicConfig
from app.core.logging import get_logger
from app.services.intelligence.prompt_manager import get_prompt_manager

logger = get_logger(__name__)


class EnhancedAIAnalyzer:
    """
    增强版AI情报分析器

    特点：
    1. 根据主题类型定制分析策略
    2. 提取量化数据（价格、百分比、时间）
    3. 提供可行动的建议
    4. 多维度深度分析
    """

    @staticmethod
    def _repair_json(json_str: str) -> str:
        """
        尝试修复LLM生成的常见JSON错误

        Args:
            json_str: 可能有错误的JSON字符串

        Returns:
            修复后的JSON字符串
        """
        # 移除BOM标记
        json_str = json_str.strip('\ufeff')

        # 尝试找到第一个 { 和最后一个 }
        start = json_str.find('{')
        end = json_str.rfind('}')

        if start >= 0 and end > start:
            json_str = json_str[start:end + 1]

        return json_str

    # 主题分析策略配置
    ANALYSIS_STRATEGIES = {
        "finance": {
            "name": "财经分析",
            "focus_areas": ["价格走势", "市场情绪", "影响因素", "交易机会"],
            "key_metrics": ["涨跌幅", "成交量", "相关指数"],
            "action_oriented": True
        },
        "technology": {
            "name": "技术分析",
            "focus_areas": ["技术突破", "产品发布", "创新模式", "行业趋势"],
            "key_metrics": ["版本更新", "用户增长", "市场份额"],
            "action_oriented": False
        },
        "startup": {
            "name": "创业投资分析",
            "focus_areas": ["融资动态", "产品发布", "团队扩张", "市场份额"],
            "key_metrics": ["融资金额", "估值", "用户规模"],
            "action_oriented": True
        },
        "general": {
            "name": "通用分析",
            "focus_areas": ["关键信息", "主要观点", "重要趋势"],
            "key_metrics": [],
            "action_oriented": False
        }
    }

    def __init__(self):
        """初始化分析器"""
        from app.integrations.llm.base import create_llm
        self.llm = create_llm(temperature=0.3, max_tokens=2000)
        self.prompt_manager = get_prompt_manager()
        logger.info("Enhanced AI Analyzer initialized with prompt manager")

    async def analyze_items(
        self,
        items: List[IntelligenceItem],
        topic_name: str = "",
        topic_keywords: List[str] = [],
        config: TopicConfig = None
    ) -> List[IntelligenceItem]:
        """
        增强版情报分析

        Args:
            items: 情报列表
            topic_name: 主题名称
            topic_keywords: 关键词
            config: 主题配置
        """
        config = config or TopicConfig()

        if not config.enable_ai_summary:
            return items

        # 判断主题类型
        strategy = self._detect_strategy(topic_name, topic_keywords)

        # 过滤需要分析的项目
        items_to_analyze = [
            item for item in items
            if not item.ai_summary or not item.key_insights
        ]

        if not items_to_analyze:
            return items

        logger.info(f"Enhanced AI analysis for {len(items_to_analyze)} items (strategy: {strategy['name']})")

        # 批量分析
        for item in items_to_analyze:
            try:
                content = self._prepare_content_with_context(item, strategy)
                analysis = await self._generate_enhanced_analysis(content, strategy, item)

                # 映射新字段到 IntelligenceItem
                item.ai_summary = analysis.get("core_conclusion")
                # 将 priority_actions 作为 key_insights（用于前端显示）
                item.key_insights = analysis.get("priority_actions", [])
                item.sentiment = analysis.get("overall_sentiment")
                item.tags = analysis.get("tags", [])
                item.metadata = item.metadata or {}
                # 保存完整的分析详情（包括 key_evidence, data_points 等）
                item.metadata["analysis_details"] = analysis

            except Exception as e:
                logger.error(f"Error in enhanced analysis: {e}")
                # 设置默认值
                item.ai_summary = item.content[:200] + "..." if len(item.content) > 200 else item.content
                item.key_insights = []
                item.sentiment = "neutral"
                item.tags = []

        return items

    def _detect_strategy(self, topic_name: str, keywords: List[str]) -> Dict[str, Any]:
        """检测主题分析策略"""
        # 创业类关键词（优先检测，因为"投资"、"融资"等词也可能出现在财经中）
        startup_keywords = [
            '创业', '初创', '孵化', '加速器', 'VC', '天使轮', '种子轮',
            'A轮', 'B轮', 'C轮', '估值', '融资金额', '投资方', 'ARR',
            '项目', '赛道', '商业模式', '产品发布'
        ]

        # 技术类关键词
        tech_keywords = [
            'AI', '人工智能', '算法', '模型', '框架', '编程', '开发',
            '漫剧', 'AIGC', '大模型', 'LLM', '技术突破', '版本发布',
            'API', '代码', '上下文', '语音交互'
        ]

        # 财经类关键词
        finance_keywords = [
            '黄金', '金价', '股票', '基金', '财报', '营收', '涨跌',
            '买入', '卖出', '持仓', '止损', '目标价', '交易', '行情'
        ]

        # 检测关键词
        all_text = topic_name + " " + " ".join(keywords)
        all_text = all_text.lower()

        # 按优先级检测
        if any(kw.lower() in all_text for kw in startup_keywords):
            return self.ANALYSIS_STRATEGIES["startup"]
        elif any(kw.lower() in all_text for kw in tech_keywords):
            return self.ANALYSIS_STRATEGIES["technology"]
        elif any(kw.lower() in all_text for kw in finance_keywords):
            return self.ANALYSIS_STRATEGIES["finance"]
        else:
            return self.ANALYSIS_STRATEGIES["general"]

    def _prepare_content_with_context(self, item: IntelligenceItem, strategy: Dict) -> str:
        """准备带有上下文的分析内容"""
        # 基本信息
        parts = [
            f"情报标题: {item.title}",
            f"情报来源: {item.source}",
            f"发布时间: {item.published_at.strftime('%Y-%m-%d %H:%M') if item.published_at else 'N/A'}",
        ]

        # 内容摘要
        content_preview = item.content[:500] if item.content else ""
        parts.append(f"内容摘要: {content_preview}")

        # 策略相关的上下文
        if strategy["action_oriented"]:
            parts.append(f"\n分析重点: {', '.join(strategy['focus_areas'])}")

        return "\n".join(parts)

    async def _generate_enhanced_analysis(
        self,
        content: str,
        strategy: Dict,
        item: IntelligenceItem
    ) -> Dict[str, Any]:
        """生成增强版分析（使用 PromptManager）"""

        strategy_name = strategy["name"]

        # 映射策略名称到策略类型
        strategy_type_map = {
            "财经分析": "finance",
            "技术分析": "technology",
            "创业投资分析": "startup",
            "通用分析": "general"
        }
        strategy_type = strategy_type_map.get(strategy_name, "general")

        # 从 PromptManager 获取模板
        template = self.prompt_manager.get_template(strategy_type)
        if not template:
            logger.error(f"No template found for strategy type: {strategy_type}")
            return self._get_enhanced_default(strategy, item)

        # 渲染提示词
        try:
            prompt = self.prompt_manager.render_prompt(
                template=template,
                variables={"content": content}
            )
        except ValueError as e:
            logger.error(f"Failed to render prompt: {e}")
            return self._get_enhanced_default(strategy, item)

        # 记录开始时间
        start_time = time.time()

        try:
            # 调用 LLM
            response = await self.llm.ainvoke(prompt)
            response_text = response.content.strip()

            # 计算响应时间
            response_time_ms = (time.time() - start_time) * 1000

            # 解析JSON - 更健壮的处理
            if response_text.startswith("```"):
                parts = response_text.split("```")
                if len(parts) >= 2:
                    response_text = parts[1]
                    if response_text.startswith("json"):
                        response_text = response_text[4:]
                    response_text = response_text.strip()

            # 尝试修复和解析JSON
            parse_success = False
            parsed_result = None

            try:
                repaired_json = self._repair_json(response_text)
                analysis = json.loads(repaired_json)
                parse_success = True
                parsed_result = analysis
            except json.JSONDecodeError as je:
                # 记录原始响应用于调试
                logger.warning(f"JSON parse error after repair attempt: {je}")
                logger.debug(f"Raw response: {response_text[:500]}")
                raise je

            # 添加分析元数据
            analysis["analysis_strategy"] = strategy_name
            analysis["analyzed_at"] = datetime.utcnow().isoformat()

            # 记录执行日志
            await self.prompt_manager.log_execution(
                template_id=template.id,
                template_version=template.version,
                topic_id=item.topic_id,
                topic_name=item.metadata.get("topic_name", "unknown"),
                strategy_type=strategy_type,
                variables_used={"content": content[:200]},
                llm_response=response_text,
                parsed_result=parsed_result,
                parse_success=parse_success,
                response_time_ms=response_time_ms
            )

            return analysis

        except Exception as e:
            logger.error(f"Enhanced analysis failed: {e}")
            logger.debug(f"Response text: {response_text[:300] if 'response_text' in locals() else 'N/A'}")

            # 记录失败日志
            await self.prompt_manager.log_execution(
                template_id=template.id,
                template_version=template.version,
                topic_id=item.topic_id,
                topic_name=item.metadata.get("topic_name", "unknown"),
                strategy_type=strategy_type,
                variables_used={"content": content[:200]},
                llm_response=response_text if 'response_text' in locals() else "",
                parsed_result=None,
                parse_success=False,
                response_time_ms=(time.time() - start_time) * 1000
            )

            return self._get_enhanced_default(strategy, item)

    def _build_finance_prompt(self, content: str, item: IntelligenceItem) -> str:
        """构建财经分析prompt"""
        return f"""你是一个专业的金融情报分析师。请分析以下情报，提供投资决策支持。

{content}

请按以下JSON格式返回分析结果：
{{
    "core_conclusion": "一句话核心结论（直接说清楚这意味着什么，该买入/卖出/观望）",
    "priority_actions": [
        "立即行动建议1（具体、可执行，如：现在可以买入，目标价2050美元）",
        "立即行动建议2（具体、可执行）",
        "风险提示（如果适用）"
    ],
    "key_evidence": [
        {{
            "fact": "关键事实1（具体数字、事件、数据）",
            "impact": "对价格/投资的影响"
        }},
        {{
            "fact": "关键事实2",
            "impact": "影响"
        }}
    ],
    "data_points": {{
        "price_target": "价格目标（如果有）",
        "change_percent": "涨跌幅（如果有）",
        "related_symbols": "相关标的（如果有）"
    }},
    "overall_sentiment": "bullish/bearish/neutral",
    "tags": ["金融", "投资", "黄金", ...]
}}

核心要求：
1. **core_conclusion必须直接明确**：告诉用户该买入、卖出还是观望，不要模糊
2. **priority_actions必须具体可执行**：现在应该做什么？目标价多少？止损位在哪？
3. **key_evidence要有具体数字**：用数据支撑你的结论
4. 先给结论，再给行动建议，最后是证据

只返回JSON，不要其他内容。"""

    def _build_tech_prompt(self, content: str, item: IntelligenceItem) -> str:
        """构建技术分析prompt"""
        return f"""你是一个技术趋势分析师。请分析以下情报，提供技术决策参考。

{content}

请按以下JSON格式返回分析结果：
{{
    "core_conclusion": "一句话核心结论（这个技术/产品意味着什么机会或威胁）",
    "priority_actions": [
        "立即行动建议1（具体：学习/采用/投资/观望/避开）",
        "立即行动建议2（具体）",
        "关注重点（如果适用）"
    ],
    "key_evidence": [
        {{
            "fact": "关键技术事实（版本号、性能指标、功能特性）",
            "impact": "对业务/市场/技术选型的影响"
        }},
        {{
            "fact": "关键技术事实2",
            "impact": "影响"
        }}
    ],
    "technical_data": {{
        "version": "版本信息（如果有）",
        "metrics": "关键指标（如果有）",
        "growth_rate": "增长率（如果有）"
    }},
    "overall_sentiment": "positive/neutral/negative",
    "tags": ["技术", "AI", "产品", "..."]
}}

核心要求：
1. **core_conclusion直接明确**：这个技术/产品意味着什么机会？需要立即行动吗？
2. **priority_actions必须具体**：开发者/创业者现在应该做什么？学习、采用、投资还是观望？
3. **key_evidence要有具体数据**：版本号、性能指标、用户数等
4. 先给结论，再给行动建议，最后是技术事实

只返回JSON，不要其他内容。"""

    def _build_startup_prompt(self, content: str, item: IntelligenceItem) -> str:
        """构建创业投资分析prompt"""
        return f"""你是一个风险投资和创业分析专家。请分析以下情报，提供投资决策参考。

{content}

请按以下JSON格式返回分析结果：
{{
    "core_conclusion": "一句话核心结论（这个项目/融资是否值得关注，为什么）",
    "priority_actions": [
        "立即行动建议1（具体：联系投资/跟进项目/学习借鉴/避开）",
        "立即行动建议2（具体）",
        "关注重点（如果适用）"
    ],
    "key_evidence": [
        {{
            "fact": "关键事实（公司、金额、轮次、投资人、产品数据）",
            "impact": "对市场/竞争格局的影响"
        }},
        {{
            "fact": "关键事实2",
            "impact": "影响"
        }}
    ],
    "deal_data": {{
        "company": "公司名称",
        "funding_amount": "融资金额（如果有）",
        "valuation": "估值（如果有）",
        "investors": "投资方（如果有）"
    }},
    "overall_sentiment": "positive/neutral/negative",
    "tags": ["创业", "融资", "AI", "产品", "..."]
}}

核心要求：
1. **core_conclusion直接明确**：这个项目/投资是否值得关注？为什么？
2. **priority_actions必须具体**：投资人/创业者现在应该做什么？联系投资？跟进项目？学习借鉴？
3. **key_evidence要有具体数据**：公司名、金额、轮次、投资人、用户数据
4. 先给结论，再给行动建议，最后是事实数据

只返回JSON，不要其他内容。"""

    def _build_general_prompt(self, content: str, item: IntelligenceItem) -> str:
        """构建通用分析prompt"""
        return f"""你是一个专业的情报分析师。请分析以下情报，提供决策参考。

{content}

请按以下JSON格式返回分析结果：
{{
    "core_conclusion": "一句话核心结论（这个情报意味着什么，为什么重要）",
    "priority_actions": [
        "立即行动建议1（具体、可执行）",
        "立即行动建议2（具体）",
        "关注重点（如果适用）"
    ],
    "key_evidence": [
        {{
            "fact": "关键事实1（具体信息、数据、事件）",
            "impact": "影响或意义"
        }},
        {{
            "fact": "关键事实2",
            "impact": "影响"
        }}
    ],
    "overall_sentiment": "positive/neutral/negative",
    "tags": ["标签1", "标签2", "标签3", "标签4", "标签5"]
}}

核心要求：
1. **core_conclusion直接明确**：这个情报的核心价值是什么？
2. **priority_actions必须具体**：读者现在应该做什么？
3. **key_evidence要有具体信息**：支撑结论的关键事实
4. 先给结论，再给行动建议，最后是证据

只返回JSON，不要其他内容。"""

    def _get_enhanced_default(self, strategy: Dict, item: IntelligenceItem) -> Dict[str, Any]:
        """获取增强版默认分析"""
        return {
            "core_conclusion": item.content[:200] + "..." if len(item.content) > 200 else item.content,
            "priority_actions": [
                f"查看 {item.source} 的完整报道"
            ],
            "key_evidence": [
                {
                    "fact": f"来自 {item.source} 的情报",
                    "impact": f"发布于 {item.published_at.strftime('%Y-%m-%d')}"
                }
            ],
            "overall_sentiment": "neutral",
            "tags": [item.source] if item.source else [],
            "analysis_strategy": strategy["name"],
            "analyzed_at": datetime.utcnow().isoformat()
        }


# 全局实例
_enhanced_analyzer = None

def get_enhanced_analyzer() -> EnhancedAIAnalyzer:
    """获取增强版分析器实例（单例）"""
    global _enhanced_analyzer
    if _enhanced_analyzer is None:
        _enhanced_analyzer = EnhancedAIAnalyzer()
    return _enhanced_analyzer
