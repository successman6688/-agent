"""AI-powered intelligence analyzer."""

import json
from typing import List, Dict, Any, Optional
from datetime import datetime

from app.models.intelligence import IntelligenceItem, TopicConfig
from app.integrations.llm.base import create_llm
from app.core.logging import get_logger
from app.services.intelligence.enhanced_analyzer import get_enhanced_analyzer

logger = get_logger(__name__)


class AIAnalyzer:
    """
    AI情报分析器

    使用增强版分析器：
    - 深度内容分析（财经/技术/创业）
    - 提取量化数据
    - 提供可行动建议
    """

    def __init__(self):
        """初始化AI分析器"""
        self.llm = create_llm(temperature=0.3, max_tokens=2000)
        self.enhanced_analyzer = get_enhanced_analyzer()
        logger.info("AI Analyzer initialized (enhanced version)")

    async def analyze_items(
        self,
        items: List[IntelligenceItem],
        config: Optional[TopicConfig] = None,
        topic_name: str = "",
        topic_keywords: List[str] = None,
        batch_size: int = 5
    ) -> List[IntelligenceItem]:
        """
        批量分析情报（使用增强版分析器）

        Args:
            items: 情报列表
            config: 主题配置
            topic_name: 主题名称
            topic_keywords: 主题关键词
            batch_size: 批处理大小（已废弃，保留用于兼容）

        Returns:
            分析后的情报列表
        """
        config = config or TopicConfig()
        topic_keywords = topic_keywords or []

        if not config.enable_ai_summary:
            logger.info("AI analysis is disabled in config")
            return items

        # 使用增强版分析器
        logger.info(f"Using enhanced AI analyzer for topic: {topic_name}")
        return await self.enhanced_analyzer.analyze_items(
            items=items,
            topic_name=topic_name,
            topic_keywords=topic_keywords,
            config=config
        )

    async def _analyze_batch(self, items: List[IntelligenceItem]):
        """
        分析一批情报

        Args:
            items: 情报列表
        """
        for item in items:
            try:
                # 准备分析内容
                content = self._prepare_content(item)

                # 生成AI分析
                analysis = await self._generate_analysis(content)

                # 更新情报项
                item.ai_summary = analysis.get("summary")
                item.key_insights = analysis.get("insights", [])
                item.sentiment = analysis.get("sentiment")
                item.tags = analysis.get("tags", [])

                logger.debug(f"Analyzed item: {item.title[:50]}...")

            except Exception as e:
                logger.error(f"Error analyzing item '{item.title[:50]}': {e}")
                # 设置默认值，防止后续流程出错
                item.ai_summary = item.content[:200] + "..." if len(item.content) > 200 else item.content
                item.key_insights = []
                item.sentiment = "neutral"
                item.tags = []

    def _prepare_content(self, item: IntelligenceItem) -> str:
        """
        准备用于分析的内容

        Args:
            item: 情报项

        Returns:
            格式化的内容字符串
        """
        return f"""标题: {item.title}
来源: {item.source}
作者: {item.author or '未知'}
发布时间: {item.published_at.strftime('%Y-%m-%d %H:%M')}
链接: {item.url}

内容摘要:
{item.content}
"""

    async def _generate_analysis(self, content: str) -> Dict[str, Any]:
        """
        使用LLM生成分析

        Args:
            content: 情报内容

        Returns:
            分析结果字典
        """
        prompt = f"""请分析以下情报，并以JSON格式返回结果。

情报内容：
{content}

请按以下JSON格式返回分析结果：
{{
    "summary": "用一句话总结这条情报的核心内容（不超过50字）",
    "insights": [
        "关键洞察1",
        "关键洞察2",
        "关键洞察3"
    ],
    "sentiment": "情感倾向（positive/negative/neutral）",
    "tags": ["标签1", "标签2", "标签3"]
}}

要求：
1. summary要简洁准确，突出核心价值
2. insights要提炼3个最重要的观点或启示
3. sentiment判断整体情感倾向
4. tags提供3-5个关键词标签

只返回JSON，不要其他内容。"""

        try:
            # 调用LLM
            response = await self.llm.ainvoke(prompt)
            response_text = response.content.strip()

            # 解析JSON响应
            # 清理可能的markdown代码块标记
            if response_text.startswith("```"):
                response_text = response_text.split("```")[1]
                if response_text.startswith("json"):
                    response_text = response_text[4:]

            analysis = json.loads(response_text.strip())

            # 验证必需字段
            if "summary" not in analysis:
                analysis["summary"] = "AI总结生成失败"
            if "insights" not in analysis:
                analysis["insights"] = []
            if "sentiment" not in analysis:
                analysis["sentiment"] = "neutral"
            if "tags" not in analysis:
                analysis["tags"] = []

            return analysis

        except json.JSONDecodeError as e:
            logger.error(f"Failed to parse AI response as JSON: {e}")
            logger.debug(f"Response text: {response_text}")
            return self._get_default_analysis()
        except Exception as e:
            logger.error(f"Error generating AI analysis: {e}")
            return self._get_default_analysis()

    def _get_default_analysis(self) -> Dict[str, Any]:
        """
        获取默认分析结果

        Returns:
            默认分析字典
        """
        return {
            "summary": "AI分析暂时不可用",
            "insights": [],
            "sentiment": "neutral",
            "tags": []
        }

    async def analyze_trend(
        self,
        items: List[IntelligenceItem],
        topic_keywords: List[str]
    ) -> Dict[str, Any]:
        """
        分析整体趋势

        Args:
            items: 情报列表
            topic_keywords: 主题关键词

        Returns:
            趋势分析结果
        """
        if not items:
            return {
                "summary": "暂无情报数据",
                "key_trends": [],
                "hot_topics": [],
                "sentiment": "neutral"
            }

        # 选择Top 10的高分情报进行分析
        top_items = sorted(items, key=lambda x: x.overall_score, reverse=True)[:10]

        # 准备摘要内容
        items_summary = "\n".join([
            f"{i+1}. {item.title} (评分: {item.overall_score:.2f})"
            for i, item in enumerate(top_items)
        ])

        prompt = f"""基于以下情报列表，分析整体趋势和热点。

主题关键词: {', '.join(topic_keywords)}

高分情报列表：
{items_summary}

请以JSON格式返回：
{{
    "summary": "整体趋势总结（不超过100字）",
    "key_trends": [
        "趋势1",
        "趋势2",
        "趋势3"
    ],
    "hot_topics": [
        "热点1",
        "热点2",
        "热点3"
    ],
    "sentiment": "整体情感倾向（positive/negative/neutral）"
}}

只返回JSON，不要其他内容。"""

        try:
            response = await self.llm.ainvoke(prompt)
            response_text = response.content.strip()

            # 清理响应
            if response_text.startswith("```"):
                response_text = response_text.split("```")[1]
                if response_text.startswith("json"):
                    response_text = response_text[4:]

            trend_analysis = json.loads(response_text.strip())

            # 验证字段
            if "summary" not in trend_analysis:
                trend_analysis["summary"] = f"收集到{len(items)}条情报"
            if "key_trends" not in trend_analysis:
                trend_analysis["key_trends"] = []
            if "hot_topics" not in trend_analysis:
                trend_analysis["hot_topics"] = []
            if "sentiment" not in trend_analysis:
                trend_analysis["sentiment"] = "neutral"

            return trend_analysis

        except Exception as e:
            logger.error(f"Error analyzing trend: {e}")
            return {
                "summary": f"收集到{len(items)}条情报",
                "key_trends": [],
                "hot_topics": [kw for kw in topic_keywords[:3]],
                "sentiment": "neutral"
            }


# 全局分析器实例
_analyzer: Optional[AIAnalyzer] = None


def get_ai_analyzer() -> AIAnalyzer:
    """获取AI分析器实例（单例）"""
    global _analyzer
    if _analyzer is None:
        _analyzer = AIAnalyzer()
    return _analyzer
