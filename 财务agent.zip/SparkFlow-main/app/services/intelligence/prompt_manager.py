"""AI提示词管理服务"""

import json
from typing import List, Dict, Any, Optional
from datetime import datetime

from app.models.intelligence import (
    PromptTemplate,
    PromptVariable,
    PromptExecutionLog,
    IntelligenceItem
)
from app.core.logging import get_logger

logger = get_logger(__name__)


class PromptManager:
    """
    AI提示词管理器

    功能：
    1. 管理提示词模板（CRUD）
    2. 根据策略类型选择最佳模板
    3. 记录执行日志和性能指标
    4. 支持A/B测试和优化
    """

    # 默认提示词模板（初始化时使用）
    DEFAULT_TEMPLATES = {
        "finance": {
            "name": "财经投资分析模板v2",
            "description": "专为财经类情报设计的分析模板，突出投资决策和可操作性",
            "system_prompt": "你是一个专业的金融情报分析师。",
            "user_prompt_template": """请分析以下情报，提供投资决策支持。

情报内容：
{content}

请按以下JSON格式返回分析结果：
{{
    "core_conclusion": "一句话核心结论（直接说清楚这意味着什么，该买入/卖出/观望）",
    "priority_actions": [
        "立即行动建议1（具体、可执行，如：现在可以买入，目标价2050美元）",
        "立即行动建议2（具体、可执行）",
        "风险提示（如果适用）"
    ],
    "key_evidence": [
        {{
            "fact": "关键事实1（具体数字、事件、数据）",
            "impact": "对价格/投资的影响"
        }},
        {{
            "fact": "关键事实2",
            "impact": "影响"
        }}
    ],
    "data_points": {{
        "price_target": "价格目标（如果有）",
        "change_percent": "涨跌幅（如果有）",
        "related_symbols": "相关标的（如果有）"
    }},
    "overall_sentiment": "bullish/bearish/neutral",
    "tags": ["金融", "投资", "黄金", ...]
}}

核心要求：
1. **core_conclusion必须直接明确**：告诉用户该买入、卖出还是观望，不要模糊
2. **priority_actions必须具体可执行**：现在应该做什么？目标价多少？止损位在哪？
3. **key_evidence要有具体数字**：用数据支撑你的结论
4. 先给结论，再给行动建议，最后是证据

只返回JSON，不要其他内容。""",
            "output_schema": {
                "type": "object",
                "properties": {
                    "core_conclusion": {"type": "string"},
                    "priority_actions": {"type": "array"},
                    "key_evidence": {"type": "array"},
                    "overall_sentiment": {"type": "string"}
                }
            },
            "variables": [
                {"name": "content", "description": "情报内容", "required": True}
            ]
        },

        "technology": {
            "name": "技术趋势分析模板v2",
            "description": "专为技术类情报设计的分析模板，突出技术机会和行动建议",
            "system_prompt": "你是一个技术趋势分析师。",
            "user_prompt_template": """请分析以下情报，提供技术决策参考。

情报内容：
{content}

请按以下JSON格式返回分析结果：
{{
    "core_conclusion": "一句话核心结论（这个技术/产品意味着什么机会或威胁）",
    "priority_actions": [
        "立即行动建议1（具体：学习/采用/投资/观望/避开）",
        "立即行动建议2（具体）",
        "关注重点（如果适用）"
    ],
    "key_evidence": [
        {{
            "fact": "关键技术事实（版本号、性能指标、功能特性）",
            "impact": "对业务/市场/技术选型的影响"
        }},
        {{
            "fact": "关键技术事实2",
            "impact": "影响"
        }}
    ],
    "technical_data": {{
        "version": "版本信息（如果有）",
        "metrics": "关键指标（如果有）",
        "growth_rate": "增长率（如果有）"
    }},
    "overall_sentiment": "positive/neutral/negative",
    "tags": ["技术", "AI", "产品", "..."]
}}

核心要求：
1. **core_conclusion直接明确**：这个技术/产品意味着什么机会？需要立即行动吗？
2. **priority_actions必须具体**：开发者/创业者现在应该做什么？学习、采用、投资还是观望？
3. **key_evidence要有具体数据**：版本号、性能指标、用户数等
4. 先给结论，再给行动建议，最后是技术事实

只返回JSON，不要其他内容。""",
            "output_schema": {
                "type": "object",
                "properties": {
                    "core_conclusion": {"type": "string"},
                    "priority_actions": {"type": "array"},
                    "key_evidence": {"type": "array"},
                    "overall_sentiment": {"type": "string"}
                }
            },
            "variables": [
                {"name": "content", "description": "情报内容", "required": True}
            ]
        },

        "startup": {
            "name": "创业投资分析模板v2",
            "description": "专为创业投资类情报设计的分析模板，突出投资价值和跟进建议",
            "system_prompt": "你是一个风险投资和创业分析专家。",
            "user_prompt_template": """请分析以下情报，提供投资决策参考。

情报内容：
{content}

请按以下JSON格式返回分析结果：
{{
    "core_conclusion": "一句话核心结论（这个项目/融资是否值得关注，为什么）",
    "priority_actions": [
        "立即行动建议1（具体：联系投资/跟进项目/学习借鉴/避开）",
        "立即行动建议2（具体）",
        "关注重点（如果适用）"
    ],
    "key_evidence": [
        {{
            "fact": "关键事实（公司、金额、轮次、投资人、产品数据）",
            "impact": "对市场/竞争格局的影响"
        }},
        {{
            "fact": "关键事实2",
            "impact": "影响"
        }}
    ],
    "deal_data": {{
        "company": "公司名称",
        "funding_amount": "融资金额（如果有）",
        "valuation": "估值（如果有）",
        "investors": "投资方（如果有）"
    }},
    "overall_sentiment": "positive/neutral/negative",
    "tags": ["创业", "融资", "AI", "产品", "..."]
}}

核心要求：
1. **core_conclusion直接明确**：这个项目/投资是否值得关注？为什么？
2. **priority_actions必须具体**：投资人/创业者现在应该做什么？联系投资？跟进项目？学习借鉴？
3. **key_evidence要有具体数据**：公司名、金额、轮次、投资人、用户数据
4. 先给结论，再给行动建议，最后是事实数据

只返回JSON，不要其他内容。""",
            "output_schema": {
                "type": "object",
                "properties": {
                    "core_conclusion": {"type": "string"},
                    "priority_actions": {"type": "array"},
                    "key_evidence": {"type": "array"},
                    "overall_sentiment": {"type": "string"}
                }
            },
            "variables": [
                {"name": "content", "description": "情报内容", "required": True}
            ]
        },

        "general": {
            "name": "通用情报分析模板v2",
            "description": "通用情报分析模板，适用于各类情报",
            "system_prompt": "你是一个专业的情报分析师。",
            "user_prompt_template": """请分析以下情报，提供决策参考。

情报内容：
{content}

请按以下JSON格式返回分析结果：
{{
    "core_conclusion": "一句话核心结论（这个情报意味着什么，为什么重要）",
    "priority_actions": [
        "立即行动建议1（具体、可执行）",
        "立即行动建议2（具体）",
        "关注重点（如果适用）"
    ],
    "key_evidence": [
        {{
            "fact": "关键事实1（具体信息、数据、事件）",
            "impact": "影响或意义"
        }},
        {{
            "fact": "关键事实2",
            "impact": "影响"
        }}
    ],
    "overall_sentiment": "positive/neutral/negative",
    "tags": ["标签1", "标签2", "标签3", "标签4", "标签5"]
}}

核心要求：
1. **core_conclusion直接明确**：这个情报的核心价值是什么？
2. **priority_actions必须具体**：读者现在应该做什么？
3. **key_evidence要有具体信息**：支撑结论的关键事实
4. 先给结论，再给行动建议，最后是证据

只返回JSON，不要其他内容。""",
            "output_schema": {
                "type": "object",
                "properties": {
                    "core_conclusion": {"type": "string"},
                    "priority_actions": {"type": "array"},
                    "key_evidence": {"type": "array"},
                    "overall_sentiment": {"type": "string"}
                }
            },
            "variables": [
                {"name": "content", "description": "情报内容", "required": True}
            ]
        }
    }

    def __init__(self):
        """初始化提示词管理器"""
        # TODO: 从数据库加载模板
        self.templates: Dict[str, PromptTemplate] = {}
        self._init_default_templates()
        logger.info("Prompt Manager initialized")

    def _init_default_templates(self):
        """初始化默认模板"""
        for strategy_type, template_data in self.DEFAULT_TEMPLATES.items():
            template = PromptTemplate(
                **template_data,
                strategy_type=strategy_type,
                is_default=True
            )
            self.templates[strategy_type] = template
            logger.info(f"Loaded default template: {template.name} ({strategy_type})")

    def get_template(
        self,
        strategy_type: str,
        category: str = "default"
    ) -> Optional[PromptTemplate]:
        """
        获取指定类型的最佳模板

        Args:
            strategy_type: 策略类型
            category: 细分类别

        Returns:
            提示词模板
        """
        # 优先获取匹配 category 的模板
        key = f"{strategy_type}_{category}"
        if key in self.templates:
            return self.templates[key]

        # 回退到默认模板
        if strategy_type in self.templates:
            return self.templates[strategy_type]

        # 最后回退到通用模板
        return self.templates.get("general")

    def render_prompt(
        self,
        template: PromptTemplate,
        variables: Dict[str, Any]
    ) -> str:
        """
        渲染提示词模板

        Args:
            template: 提示词模板
            variables: 变量值

        Returns:
            渲染后的完整提示词
        """
        # 合并系统提示词和用户提示词
        full_prompt = template.system_prompt + "\n\n" + template.user_prompt_template

        # 替换变量
        try:
            rendered = full_prompt.format(**variables)
            return rendered
        except KeyError as e:
            logger.error(f"Missing required variable: {e}")
            raise ValueError(f"缺少必需的变量: {e}")

    async def log_execution(
        self,
        template_id: str,
        template_version: str,
        topic_id: str,
        topic_name: str,
        strategy_type: str,
        variables_used: Dict[str, Any],
        llm_response: str,
        parsed_result: Optional[Dict[str, Any]],
        parse_success: bool,
        response_time_ms: float,
        token_count: Optional[int] = None
    ) -> PromptExecutionLog:
        """
        记录提示词执行日志

        Args:
            template_id: 模板ID
            template_version: 模板版本
            topic_id: 主题ID
            topic_name: 主题名称
            strategy_type: 策略类型
            variables_used: 使用的变量
            llm_response: LLM原始响应
            parsed_result: 解析后的结果
            parse_success: 是否解析成功
            response_time_ms: 响应时间
            token_count: Token数量

        Returns:
            执行日志
        """
        log = PromptExecutionLog(
            template_id=template_id,
            template_version=template_version,
            topic_id=topic_id,
            topic_name=topic_name,
            strategy_type=strategy_type,
            variables_used=variables_used,
            llm_response=llm_response,
            parsed_result=parsed_result,
            parse_success=parse_success,
            response_time_ms=response_time_ms,
            token_count=token_count
        )

        # TODO: 保存到数据库
        logger.debug(f"Logged prompt execution: {log.template_id} - success={parse_success}")

        # 更新模板性能指标
        if template_id in self.templates:
            template = self.templates[template_id]
            template.usage_count += 1

            # 更新成功率
            if parse_success:
                # 简单的移动平均
                template.success_rate = (
                    (template.success_rate * (template.usage_count - 1) + 1.0) /
                    template.usage_count
                )
            else:
                template.success_rate = (
                    (template.success_rate * (template.usage_count - 1)) /
                    template.usage_count
                )

        return log

    def add_template(self, template: PromptTemplate):
        """添加新模板"""
        self.templates[f"{template.strategy_type}_{template.category}"] = template
        logger.info(f"Added new template: {template.name}")

    def list_templates(self, strategy_type: Optional[str] = None) -> List[PromptTemplate]:
        """列出所有模板（可选按策略类型过滤）"""
        if strategy_type:
            return [
                t for t in self.templates.values()
                if t.strategy_type == strategy_type
            ]
        return list(self.templates.values())

    def get_template_stats(self, template_id: str) -> Optional[Dict[str, Any]]:
        """获取模板统计信息"""
        # TODO: 从数据库查询详细统计
        return None


# 全局实例
_prompt_manager: Optional[PromptManager] = None


def get_prompt_manager() -> PromptManager:
    """获取提示词管理器实例（单例）"""
    global _prompt_manager
    if _prompt_manager is None:
        _prompt_manager = PromptManager()
    return _prompt_manager
