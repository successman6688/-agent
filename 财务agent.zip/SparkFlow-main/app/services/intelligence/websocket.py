"""WebSocket 连接管理器"""

from typing import Dict, Set
from fastapi import WebSocket
from app.core.logging import get_logger

logger = get_logger(__name__)


class WebSocketManager:
    """
    WebSocket 连接管理器

    管理 WebSocket 连接，支持：
    - 连接管理
    - 按主题ID分组推送消息
    - 广播消息
    """

    def __init__(self):
        """初始化管理器"""
        # 主题ID -> WebSocket连接集合
        self.topic_connections: Dict[str, Set[WebSocket]] = {}
        # 所有连接
        self.all_connections: Set[WebSocket] = set()

    async def connect(self, websocket: WebSocket, topic_id: str):
        """
        接受新的 WebSocket 连接

        Args:
            websocket: WebSocket 连接对象
            topic_id: 主题ID
        """
        await websocket.accept()

        # 添加到对应主题的连接集合
        if topic_id not in self.topic_connections:
            self.topic_connections[topic_id] = set()

        self.topic_connections[topic_id].add(websocket)
        self.all_connections.add(websocket)

        logger.info(f"WebSocket connected for topic {topic_id}")

    def disconnect(self, websocket: WebSocket, topic_id: str):
        """
        断开 WebSocket 连接

        Args:
            websocket: WebSocket 连接对象
            topic_id: 主题ID
        """
        # 从对应主题移除
        if topic_id in self.topic_connections:
            self.topic_connections[topic_id].discard(websocket)

        # 从所有连接中移除
        self.all_connections.discard(websocket)

        logger.info(f"WebSocket disconnected for topic {topic_id}")

    async def send_to_topic(self, topic_id: str, message: dict):
        """
        向特定主题的所有连接发送消息

        Args:
            topic_id: 主题ID
            message: 消息内容
        """
        if topic_id not in self.topic_connections:
            logger.warning(f"No connections for topic {topic_id}")
            return

        # 详细日志
        logger.info(f"[WebSocket] Sending message to topic {topic_id}:")
        logger.info(f"  Type: {message.get('type')}")
        logger.info(f"  Status: {message.get('status')}")
        logger.info(f"  Result: {message.get('result')}")
        if message.get('result'):
            logger.info(f"  Result type: {type(message.get('result'))}")
            if isinstance(message.get('result'), dict):
                logger.info(f"  Result keys: {list(message.get('result').keys())}")
                logger.info(f"  new_items: {message.get('result', {}).get('new_items')}")

        # 获取该主题的所有连接
        connections = self.topic_connections[topic_id].copy()

        disconnected = []

        for connection in connections:
            try:
                await connection.send_json(message)
                logger.info(f"[WebSocket] Sent to {id(connection)} successfully")
            except Exception as e:
                logger.error(f"Error sending message: {e}")
                disconnected.append(connection)

        # 清理断开的连接
        for connection in disconnected:
            self.disconnect(connection, topic_id)

    async def broadcast(self, message: dict):
        """
        向所有连接广播消息

        Args:
            message: 消息内容
        """
        if not self.all_connections:
            return

        connections = self.all_connections.copy()
        disconnected = []

        for connection in connections:
            try:
                await connection.send_json(message)
            except Exception as e:
                logger.error(f"Error broadcasting message: {e}")
                disconnected.append(connection)

        # 清理断开的连接
        for connection in disconnected:
            # 从所有主题中移除断开的连接
            for topic_id, conns in self.topic_connections.items():
                if connection in conns:
                    self.disconnect(connection, topic_id)

    async def send_task_update(
        self,
        topic_id: str,
        task_id: str,
        status: str,
        result: dict = None,
        error: str = None
    ):
        """
        发送任务更新消息

        Args:
            topic_id: 主题ID
            task_id: 任务ID
            status: 任务状态
            result: 任务结果
            error: 错误信息
        """
        message = {
            "type": "task_update",
            "topic_id": topic_id,
            "task_id": task_id,
            "status": status,
            "result": result,
            "error": error,
            "timestamp": None  # 会在发送时添加
        }

        # 添加详细日志
        logger.info(f"[WS] Preparing to send task update message:")
        logger.info(f"  - topic_id: {topic_id}")
        logger.info(f"  - task_id: {task_id}")
        logger.info(f"  - status: {status}")
        logger.info(f"  - result type: {type(result)}")
        logger.info(f"  - result value: {result}")
        if result:
            if isinstance(result, dict):
                logger.info(f"  - result.keys(): {list(result.keys())}")
                logger.info(f"  - new_items: {result.get('new_items', 'KEY NOT FOUND')}")

        await self.send_to_topic(topic_id, message)


# 全局 WebSocket 管理器实例
_manager = None


def get_websocket_manager() -> WebSocketManager:
    """获取 WebSocket 管理器实例（单例）"""
    global _manager
    if _manager is None:
        _manager = WebSocketManager()
    return _manager
