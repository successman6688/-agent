"""Intelligence collection coordinator - Database Version."""

import asyncio
import time
from typing import List, Optional
from datetime import datetime
from uuid import UUID

from sqlalchemy.ext.asyncio import AsyncSession

from app.models.intelligence import (
    IntelligenceItem,
    IntelligenceTopic,
    IntelligenceReport,
    CollectionResponse,
    SourceConfig,
)
from app.services.intelligence.fetchers import FetcherFactory
from app.services.intelligence.deduplicator import Deduplicator
from app.services.intelligence.scorer import RelevanceScorer
from app.services.intelligence.analyzer import get_ai_analyzer
from app.db.intelligence_repository import IntelligenceRepository
from app.db import IntelligenceTopicDB, IntelligenceItemDB, IntelligenceReportDB
from app.core.logging import get_logger

logger = get_logger(__name__)


class IntelligenceCoordinator:
    """
    情报收集协调器（数据库版本）

    负责协调整个情报收集流程：
    1. 并行采集多源数据
    2. 去重（基于数据库）
    3. 评分
    4. 存储到数据库
    5. 生成报告
    """

    def __init__(self, session: AsyncSession):
        """
        初始化协调器

        Args:
            session: 数据库会话
        """
        self.session = session
        self.repository = IntelligenceRepository(session)
        self.deduplicator = Deduplicator()
        self.scorer = RelevanceScorer()
        self.ai_analyzer = get_ai_analyzer()

    async def collect_intelligence(
        self,
        topic: IntelligenceTopic,
        force_refresh: bool = False
    ) -> CollectionResponse:
        """
        执行情报收集流程

        Args:
            topic: 情报主题
            force_refresh: 是否强制刷新（忽略缓存）

        Returns:
            收集响应
        """
        start_time = time.time()
        logger.info(f"Starting intelligence collection for topic: {topic.name}")

        try:
            # 1. 并行采集所有数据源
            raw_items = await self._fetch_all_sources(topic)

            if not raw_items:
                logger.warning("No items collected from sources")
                # 更新统计
                await self.repository.update_topic_stats(
                    topic.id,
                    topic.total_items,
                    0,
                    datetime.utcnow(),
                    "No items found"
                )

                return CollectionResponse(
                    topic_id=topic.id,
                    status="completed",
                    total_collected=0,
                    new_items=0,
                    duration_seconds=time.time() - start_time,
                    message="No items collected from sources"
                )

            # 2. 数据库去重（检查已存在的URL和GUID）
            unique_items = await self._deduplicate_with_db(topic.id, raw_items)
            logger.info(f"After deduplication: {len(unique_items)} unique items")

            if not unique_items:
                logger.info("All items are duplicates, no new items to save")
                # 更新统计
                await self.repository.update_topic_stats(
                    topic.id,
                    topic.total_items,
                    0,
                    datetime.utcnow(),
                    "No new items"
                )

                return CollectionResponse(
                    topic_id=topic.id,
                    status="completed",
                    total_collected=len(raw_items),
                    new_items=0,
                    duration_seconds=time.time() - start_time,
                    message="All items are duplicates"
                )

            # 3. 相关性评分
            scored_items = await self.scorer.score(
                unique_items,
                topic.keywords,
                topic.config
            )

            # 4. 过滤低分项
            filtered_items = [
                item for item in scored_items
                if item.overall_score >= topic.config.min_relevance
            ]
            logger.info(f"After filtering (min_relevance={topic.config.min_relevance}): {len(filtered_items)} items")

            # 5. AI分析（如果启用）
            if topic.config.enable_ai_summary:
                logger.info("Starting AI analysis...")
                analyzed_items = await self.ai_analyzer.analyze_items(
                    filtered_items,
                    topic.config,
                    topic_name=topic.name,
                    topic_keywords=topic.keywords
                )
                logger.info(f"AI analysis completed for {len(analyzed_items)} items")
            else:
                analyzed_items = filtered_items

            # 6. 存储到数据库
            items_data = [item.model_dump() for item in analyzed_items]
            await self.repository.create_items(items_data)

            # 7. 更新主题统计
            stats = await self.repository.get_topic_statistics(topic.id)
            await self.repository.update_topic_stats(
                topic.id,
                stats['total_items'],
                stats['today_items'],
                datetime.utcnow(),
                "success"
            )

            # 8. 生成报告（包含AI趋势分析）
            report = await self._generate_report(topic, analyzed_items)

            duration = time.time() - start_time

            logger.info(
                f"Intelligence collection completed: "
                f"{len(filtered_items)} items in {duration:.2f}s"
            )

            return CollectionResponse(
                topic_id=topic.id,
                status="completed",
                total_collected=len(raw_items),
                new_items=len(filtered_items),
                duration_seconds=duration,
                report_id=report.id if report else None,
                message=f"Successfully collected {len(filtered_items)} items"
            )

        except Exception as e:
            logger.error(f"Intelligence collection failed: {e}", exc_info=True)

            # 更新主题失败状态
            await self.repository.update_topic_stats(
                topic.id,
                topic.total_items,
                0,
                datetime.utcnow(),
                f"failed: {str(e)}"
            )

            return CollectionResponse(
                topic_id=topic.id,
                status="failed",
                total_collected=0,
                new_items=0,
                duration_seconds=time.time() - start_time,
                message=f"Collection failed: {str(e)}"
            )

    async def _fetch_all_sources(
        self,
        topic: IntelligenceTopic
    ) -> List[IntelligenceItem]:
        """
        并行抓取所有数据源

        Args:
            topic: 情报主题

        Returns:
            情报项列表
        """
        # 准备采集任务
        tasks = []

        for source_config in topic.sources:
            if not source_config.enabled:
                continue

            try:
                # 使用工厂创建采集器
                fetcher = FetcherFactory.create(source_config, topic)
                tasks.append(fetcher.fetch())
            except Exception as e:
                logger.error(
                    f"Error creating fetcher for {source_config.name}: {e}"
                )

        if not tasks:
            logger.warning("No valid fetchers found for topic")
            return []

        # 并发执行所有采集任务
        results = await asyncio.gather(*tasks, return_exceptions=True)

        # 合并结果
        all_items = []
        for result in results:
            if isinstance(result, Exception):
                logger.error(f"Fetcher error: {result}")
            elif isinstance(result, list):
                all_items.extend(result)
            else:
                logger.warning(f"Unexpected fetcher result type: {type(result)}")

        logger.info(f"Fetched {len(all_items)} items from all sources")
        return all_items

    async def _deduplicate_with_db(
        self,
        topic_id: str,
        items: List[IntelligenceItem]
    ) -> List[IntelligenceItem]:
        """
        基于数据库去重（检查URL和GUID是否已存在）

        Args:
            topic_id: 主题ID
            items: 情报项列表

        Returns:
            去重后的情报项列表
        """
        unique_items = []

        for item in items:
            # 检查GUID是否已存在
            guid_exists = await self.repository.check_guid_exists(
                topic_id,
                item.guid
            )
            if guid_exists:
                logger.debug(f"Duplicate by GUID: {item.guid}")
                continue

            # 检查URL是否已存在
            url_exists = await self.repository.check_url_exists(
                topic_id,
                item.url_hash
            )
            if url_exists:
                logger.debug(f"Duplicate by URL: {item.url}")
                continue

            # 通过所有去重检查
            unique_items.append(item)

        logger.info(
            f"Database deduplication: {len(items)} -> {len(unique_items)} "
            f"(removed {len(items) - len(unique_items)} duplicates)"
        )

        return unique_items

    async def _generate_report(
        self,
        topic: IntelligenceTopic,
        items: List[IntelligenceItem]
    ) -> Optional[IntelligenceReport]:
        """
        生成情报报告

        Args:
            topic: 情报主题
            items: 情报项列表

        Returns:
            情报报告
        """
        try:
            # 统计信息
            sources_count = {}
            for item in items:
                source = item.source
                sources_count[source] = sources_count.get(source, 0) + 1

            # 提取关键趋势（基于评分）
            top_items = sorted(items, key=lambda x: x.overall_score, reverse=True)[:10]
            hot_topics = [item.title for item in top_items[:5]]

            # 创建报告
            report = IntelligenceReport(
                topic_id=topic.id,
                period_start=datetime.utcnow().replace(hour=0, minute=0, second=0),
                period_end=datetime.utcnow(),
                total_items=len(items),
                new_items=len(items),
                sources_breakdown=sources_count,
                summary=f"收集到 {len(items)} 条相关情报",
                key_trends=[],
                hot_topics=hot_topics,
                top_items=[item.id for item in top_items]
            )

            # 保存到数据库
            report_data = report.model_dump()
            db_report = await self.repository.create_report(report_data)

            return report

        except Exception as e:
            logger.error(f"Error generating report: {e}", exc_info=True)
            return None
