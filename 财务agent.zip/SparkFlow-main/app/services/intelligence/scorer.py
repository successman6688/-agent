"""Intelligence relevance scorer."""

from typing import List, Optional
from datetime import datetime, timedelta

from app.models.intelligence import IntelligenceItem, TopicConfig
from app.core.logging import get_logger

logger = get_logger(__name__)


class RelevanceScorer:
    """
    相关性评分器

    为每条情报计算多维评分：
    1. 关键词匹配度
    2. 时间新鲜度
    3. 来源权威性
    """

    # 权威性评分（数据源 → 权威度）
    AUTHORITY_SCORES = {
        "google_news": 0.8,
        "hacker_news": 0.9,
        "reddit": 0.7,
        "36kr": 0.7,
        "techcrunch": 0.8,
        "nytimes": 0.9,
        "bbc": 0.9,
        "cnn": 0.8,
        "reuters": 0.9,
    }

    def __init__(self):
        """初始化评分器"""
        pass

    async def score(
        self,
        items: List[IntelligenceItem],
        keywords: List[str],
        config: Optional[TopicConfig] = None
    ) -> List[IntelligenceItem]:
        """
        为情报列表评分

        Args:
            items: 情报列表
            keywords: 关键词列表
            config: 主题配置

        Returns:
            评分后的情报列表（已排序）
        """
        config = config or TopicConfig()

        for item in items:
            # 计算各项评分
            keyword_score = self._score_keywords(item, keywords)
            time_score = self._score_timeliness(item.published_at)
            authority_score = self._score_authority(item.source)

            # 计算综合评分
            item.overall_score = (
                keyword_score * config.keyword_weight +
                time_score * config.timeliness_weight +
                authority_score * config.authority_weight
            )

            # 保存单项评分
            item.relevance_score = keyword_score
            item.timeliness_score = time_score
            item.authority_score = authority_score

        # 按综合评分降序排序
        items.sort(key=lambda x: x.overall_score, reverse=True)

        logger.info(f"Scored {len(items)} items")

        return items

    def _score_keywords(
        self,
        item: IntelligenceItem,
        keywords: List[str]
    ) -> float:
        """
        计算关键词匹配度

        Args:
            item: 情报项
            keywords: 关键词列表

        Returns:
            评分 (0-1)
        """
        if not keywords:
            return 0.5

        # 合并标题和内容
        text = f"{item.title} {item.content}".lower()

        # 计算匹配的关键词数量
        matches = 0
        for keyword in keywords:
            if keyword.lower() in text:
                matches += 1

        # 计算匹配比例
        score = matches / len(keywords)

        # 标题匹配给予额外权重
        title_matches = sum(
            1 for kw in keywords
            if kw.lower() in item.title.lower()
        )
        if title_matches > 0:
            score = min(score * 1.2, 1.0)

        return min(score, 1.0)

    def _score_timeliness(self, published_at: datetime) -> float:
        """
        计算时间新鲜度

        Args:
            published_at: 发布时间

        Returns:
            评分 (0-1)
        """
        # 处理时区问题：移除时区信息或使用aware datetime
        if published_at.tzinfo is not None:
            # 如果published_at有tzinfo，转换为naive datetime
            published_at = published_at.replace(tzinfo=None)

        now = datetime.utcnow()
        age = now - published_at
        age_hours = age.total_seconds() / 3600

        # 时间衰减曲线
        if age_hours < 6:
            return 1.0
        elif age_hours < 24:
            return 0.8
        elif age_hours < 48:
            return 0.6
        elif age_hours < 72:
            return 0.4
        elif age_hours < 168:  # 1周
            return 0.2
        else:
            return 0.1

    def _score_authority(self, source: str) -> float:
        """
        计算来源权威性

        Args:
            source: 来源名称

        Returns:
            评分 (0-1)
        """
        # 标准化来源名称
        source_normalized = source.lower().replace(" ", "_")

        # 查找权威性评分
        for key, score in self.AUTHORITY_SCORES.items():
            if key in source_normalized:
                return score

        # 未知来源给予中等评分
        return 0.5
