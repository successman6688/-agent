"""AI系统自我进化引擎

这个模块实现了智能系统的自我优化能力：
1. 多层反馈收集
2. 自动化评估
3. 多臂老虎机A/B测试
4. 提示词自动演化
5. 异常检测和自动回滚
"""

import asyncio
import random
from typing import List, Dict, Any, Optional, Tuple
from datetime import datetime, timedelta
from enum import Enum

from app.core.logging import get_logger
from app.models.intelligence import (
    PromptTemplate,
    PromptExecutionLog,
    IntelligenceItem
)

logger = get_logger(__name__)


class FeedbackType(Enum):
    """反馈类型"""
    EXPLICIT_RATING = "explicit_rating"  # 明确评分
    EXPLICIT_THUMBS = "explicit_thumbs"  # 点赞点踩
    IMPLICIT_CLICK = "implicit_click"  # 点击
    IMPLICIT_READ_TIME = "implicit_read_time"  # 阅读时长
    IMPLICIT_ACTION = "implicit_action"  # 是否采纳行动
    AUTO_EVALUATION = "auto_evaluation"  # 自动评估


class EvolutionEngine:
    """
    AI系统进化引擎

    核心能力：
    1. 收集多层反馈
    2. 自动评估输出质量
    3. 智能A/B测试
    4. 提示词自动优化
    5. 异常检测和恢复
    """

    def __init__(self):
        """初始化进化引擎"""
        self.feedback_buffer: List[Dict] = []
        self.prompt_stats: Dict[str, Dict] = {}  # prompt_id -> 统计数据
        self.ab_tests: Dict[str, Dict] = {}  # test_id -> A/B测试数据

        # 评估权重配置
        self.feedback_weights = {
            FeedbackType.EXPLICIT_RATING: 5.0,  # 明确评分权重最高
            FeedbackType.EXPLICIT_THUMBS: 3.0,
            FeedbackType.IMPLICIT_ACTION: 2.0,  # 采纳行动建议
            FeedbackType.IMPLICIT_CLICK: 1.0,
            FeedbackType.IMPLICIT_READ_TIME: 0.5,
            FeedbackType.AUTO_EVALUATION: 1.5  # 自动评估
        }

        # Thompson Sampling 参数
        self.alpha_prior = 1  # Beta分布先验参数
        self.beta_prior = 1

        logger.info("Evolution Engine initialized")

    # ==================== 反馈收集 ====================

    async def collect_feedback(
        self,
        item_id: str,
        prompt_id: str,
        feedback_type: FeedbackType,
        value: Any,
        user_id: Optional[str] = None
    ):
        """
        收集用户反馈

        Args:
            item_id: 情报项ID
            prompt_id: 使用的提示词ID
            feedback_type: 反馈类型
            value: 反馈值（评分、True/False、时长等）
            user_id: 用户ID
        """
        feedback = {
            "item_id": item_id,
            "prompt_id": prompt_id,
            "feedback_type": feedback_type,
            "value": value,
            "user_id": user_id,
            "timestamp": datetime.utcnow()
        }

        self.feedback_buffer.append(feedback)
        logger.debug(f"Collected feedback: {feedback_type.value} = {value}")

        # 定期批量处理
        if len(self.feedback_buffer) >= 100:
            await self._process_feedback_batch()

    async def _process_feedback_batch(self):
        """批量处理反馈"""
        if not self.feedback_buffer:
            return

        logger.info(f"Processing {len(self.feedback_buffer)} feedback items...")

        # 按prompt_id分组统计
        for feedback in self.feedback_buffer:
            prompt_id = feedback["prompt_id"]
            feedback_type = feedback["feedback_type"]
            value = feedback["value"]
            weight = self.feedback_weights.get(feedback_type, 1.0)

            if prompt_id not in self.prompt_stats:
                self.prompt_stats[prompt_id] = {
                    "total_score": 0.0,
                    "count": 0,
                    "success_count": 0,
                    "failure_count": 0,
                    "last_updated": datetime.utcnow()
                }

            # 计算加权得分
            if feedback_type == FeedbackType.EXPLICIT_RATING:
                score = (value / 5.0) * weight  # 归一化到0-1
            elif feedback_type in [FeedbackType.EXPLICIT_THUMBS,
                                   FeedbackType.IMPLICIT_ACTION]:
                score = 1.0 * weight if value else 0.0
            elif feedback_type == FeedbackType.IMPLICIT_CLICK:
                score = 1.0 * weight  # 点击就是正反馈
            elif feedback_type == FeedbackType.IMPLICIT_READ_TIME:
                # 阅读时长：假设30秒为满分
                score = min(value / 30.0, 1.0) * weight
            elif feedback_type == FeedbackType.AUTO_EVALUATION:
                score = (value / 5.0) * weight
            else:
                score = 0.0

            stats = self.prompt_stats[prompt_id]
            stats["total_score"] += score
            stats["count"] += 1

            # 更新成功/失败计数（用于Thompson Sampling）
            if score >= 0.6:  # 阈值可调
                stats["success_count"] += 1
            else:
                stats["failure_count"] += 1

            stats["last_updated"] = datetime.utcnow()

        # 清空缓冲区
        self.feedback_buffer = []
        logger.info("Feedback batch processed")

    # ==================== 自动评估 ====================

    async def auto_evaluate(
        self,
        item: IntelligenceItem,
        analysis_result: Dict[str, Any]
    ) -> float:
        """
        使用LLM自动评估分析质量

        Args:
            item: 情报项
            analysis_result: AI分析结果

        Returns:
            评分（0-5）
        """
        # TODO: 实现自动评估
        # 1. 使用更强的模型（如GPT-4）评估
        # 2. 评估维度：相关性、可操作性、准确性、完整性
        # 3. 返回综合评分

        # 简化版：基于规则快速评估
        score = 3.0  # 基础分

        # 检查是否有核心结论
        if analysis_result.get("core_conclusion"):
            score += 0.5

        # 检查是否有可操作建议
        priority_actions = analysis_result.get("priority_actions", [])
        if len(priority_actions) >= 2:
            score += 0.5

        # 检查是否有证据支撑
        key_evidence = analysis_result.get("key_evidence", [])
        if len(key_evidence) >= 2:
            score += 0.5

        # 检查是否有具体数据
        if any(evidence.get("fact") and evidence.get("fact") != "N/A"
               for evidence in key_evidence):
            score += 0.5

        # 检查情感倾向是否明确
        if analysis_result.get("overall_sentiment") in ["bullish", "bearish",
                                                        "positive", "negative"]:
            score += 0.5

        return min(score, 5.0)

    # ==================== 多臂老虎机A/B测试 ====================

    def select_prompt_thompson_sampling(
        self,
        prompt_candidates: List[PromptTemplate]
    ) -> PromptTemplate:
        """
        使用Thompson Sampling算法选择提示词

        平衡探索（尝试新版本）和利用（使用已知好版本）

        Args:
            prompt_candidates: 候选提示词列表

        Returns:
            选中的提示词
        """
        if not prompt_candidates:
            raise ValueError("No prompt candidates")

        # 如果只有一个候选，直接返回
        if len(prompt_candidates) == 1:
            return prompt_candidates[0]

        # 为每个候选采样beta分布
        samples = []
        for prompt in prompt_candidates:
            stats = self.prompt_stats.get(prompt.id, {
                "success_count": self.alpha_prior,
                "failure_count": self.beta_prior
            })

            # Beta分布采样
            alpha = stats["success_count"] + self.alpha_prior
            beta = stats["failure_count"] + self.beta_prior

            sample = random.betavariate(alpha, beta)
            samples.append((sample, prompt))

        # 选择采样值最高的
        samples.sort(key=lambda x: x[0], reverse=True)
        selected = samples[0][1]

        logger.debug(f"Thompson Sampling selected: {selected.name} "
                    f"(sample={samples[0][0]:.3f})")

        return selected

    # ==================== 提示词自动演化 ====================

    async def evolve_prompt(
        self,
        current_prompt: PromptTemplate,
        performance_report: Dict[str, Any]
    ) -> List[PromptTemplate]:
        """
        基于性能数据自动生成改进的提示词

        Args:
            current_prompt: 当前提示词
            performance_report: 性能报告

        Returns:
            改进版本的提示词列表
        """
        # TODO: 实现提示词自动演化
        # 1. 分析性能问题
        # 2. 使用LLM生成改进版本
        # 3. 验证新版本
        # 4. 返回候选列表

        logger.info(f"Auto-evolving prompt: {current_prompt.name}")
        return []

    # ==================== 异常检测和恢复 ====================

    async def detect_anomaly(
        self,
        prompt_id: str,
        recent_performance: List[float]
    ) -> bool:
        """
        检测性能异常

        Args:
            prompt_id: 提示词ID
            recent_performance: 最近N次的性能数据

        Returns:
            是否异常
        """
        if len(recent_performance) < 10:
            return False

        # 计算移动平均
        recent_avg = sum(recent_performance[-10:]) / 10

        # 获取历史平均
        if prompt_id in self.prompt_stats:
            stats = self.prompt_stats[prompt_id]
            historical_avg = stats["total_score"] / max(stats["count"], 1)

            # 如果最近平均比历史平均低30%，认为异常
            if recent_avg < historical_avg * 0.7:
                logger.warning(
                    f"Anomaly detected for prompt {prompt_id}: "
                    f"recent={recent_avg:.2f}, historical={historical_avg:.2f}"
                )
                return True

        return False

    async def auto_rollback(
        self,
        prompt_id: str
    ) -> Optional[PromptTemplate]:
        """
        自动回滚到上一个稳定版本

        Args:
            prompt_id: 当前提示词ID

        Returns:
            回滚后的提示词（如果有的话）
        """
        # TODO: 实现自动回滚
        # 1. 查找该提示词的上一版本
        # 2. 验证上一版本的稳定性
        # 3. 执行回滚
        logger.warning(f"Auto-rollback triggered for prompt: {prompt_id}")
        return None

    # ==================== 性能报告 ====================

    def get_performance_report(
        self,
        prompt_id: str
    ) -> Optional[Dict[str, Any]]:
        """
        获取提示词性能报告

        Args:
            prompt_id: 提示词ID

        Returns:
            性能报告
        """
        if prompt_id not in self.prompt_stats:
            return None

        stats = self.prompt_stats[prompt_id]

        return {
            "prompt_id": prompt_id,
            "avg_score": stats["total_score"] / max(stats["count"], 1),
            "total_count": stats["count"],
            "success_rate": stats["success_count"] / max(stats["count"], 1),
            "last_updated": stats["last_updated"]
        }

    def get_top_prompts(
        self,
        top_n: int = 5
    ) -> List[Tuple[str, float]]:
        """
        获取表现最好的N个提示词

        Args:
            top_n: 返回前N个

        Returns:
            [(prompt_id, avg_score), ...]
        """
        scores = []
        for prompt_id, stats in self.prompt_stats.items():
            if stats["count"] > 0:
                avg_score = stats["total_score"] / stats["count"]
                scores.append((prompt_id, avg_score))

        scores.sort(key=lambda x: x[1], reverse=True)
        return scores[:top_n]


# 全局实例
_evolution_engine: Optional[EvolutionEngine] = None


def get_evolution_engine() -> EvolutionEngine:
    """获取进化引擎实例（单例）"""
    global _evolution_engine
    if _evolution_engine is None:
        _evolution_engine = EvolutionEngine()
    return _evolution_engine
