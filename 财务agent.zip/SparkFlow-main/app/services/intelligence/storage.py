"""Intelligence storage manager."""

import json
from pathlib import Path
from typing import List, Optional
from datetime import datetime

from app.models.intelligence import IntelligenceItem, IntelligenceTopic, IntelligenceReport
from app.core.logging import get_logger

logger = get_logger(__name__)


class IntelligenceStorage:
    """情报存储管理器"""

    def __init__(self, storage_path: str = "data/intelligence"):
        """
        初始化存储管理器

        Args:
            storage_path: 存储路径
        """
        self.storage_path = Path(storage_path)
        self.storage_path.mkdir(parents=True, exist_ok=True)

        # 子目录
        self.topics_dir = self.storage_path / "topics"
        self.items_dir = self.storage_path / "items"
        self.reports_dir = self.storage_path / "reports"

        for dir_path in [self.topics_dir, self.items_dir, self.reports_dir]:
            dir_path.mkdir(exist_ok=True)

    async def save_topic(self, topic: IntelligenceTopic) -> None:
        """
        保存主题

        Args:
            topic: 情报主题
        """
        file_path = self.topics_dir / f"{topic.id}.json"

        # 使用自定义编码器处理datetime
        def json_serial(obj):
            """JSON serializer for objects not serializable by default json code"""
            if isinstance(obj, datetime):
                return obj.isoformat()
            raise TypeError(f"Type {type(obj)} not serializable")

        with open(file_path, 'w', encoding='utf-8') as f:
            json.dump(topic.model_dump(), f, ensure_ascii=False, indent=2, default=json_serial)

        logger.info(f"Saved topic: {topic.name} ({topic.id})")

    async def load_topic(self, topic_id: str) -> Optional[IntelligenceTopic]:
        """
        加载主题

        Args:
            topic_id: 主题ID

        Returns:
            情报主题，不存在返回None
        """
        file_path = self.topics_dir / f"{topic_id}.json"

        if not file_path.exists():
            return None

        with open(file_path, 'r', encoding='utf-8') as f:
            data = json.load(f)

        return IntelligenceTopic(**data)

    async def list_topics(self) -> List[IntelligenceTopic]:
        """
        列出所有主题

        Returns:
            主题列表
        """
        topics = []

        for file_path in self.topics_dir.glob("*.json"):
            try:
                with open(file_path, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                    topics.append(IntelligenceTopic(**data))
            except Exception as e:
                logger.error(f"Error loading topic {file_path}: {e}")

        return topics

    async def save_items(self, items: List[IntelligenceItem]) -> None:
        """
        保存情报项

        Args:
            items: 情报项列表
        """
        if not items:
            return

        # 按日期和主题组织
        today = datetime.utcnow().strftime("%Y-%m-%d")
        topic_id = items[0].topic_id

        file_path = self.items_dir / topic_id / f"{today}.jsonl"
        file_path.parent.mkdir(parents=True, exist_ok=True)

        # 自定义JSON序列化器
        def json_serial(obj):
            """JSON serializer for objects not serializable by default json code"""
            if isinstance(obj, datetime):
                return obj.isoformat()
            raise TypeError(f"Type {type(obj)} not serializable")

        # 追加写入
        with open(file_path, 'a', encoding='utf-8') as f:
            for item in items:
                json.dump(item.model_dump(), f, ensure_ascii=False, default=json_serial)
                f.write('\n')

        logger.info(f"Saved {len(items)} items to {file_path}")

    async def load_items(
        self,
        topic_id: str,
        date: Optional[str] = None,
        limit: int = 100
    ) -> List[IntelligenceItem]:
        """
        加载情报项（按时间倒序，最新的在前）

        Args:
            topic_id: 主题ID
            date: 日期（YYYY-MM-DD），默认今天
            limit: 最大数量

        Returns:
            情报项列表
        """
        if date is None:
            date = datetime.utcnow().strftime("%Y-%m-%d")

        file_path = self.items_dir / topic_id / f"{date}.jsonl"

        if not file_path.exists():
            return []

        items = []
        with open(file_path, 'r', encoding='utf-8') as f:
            for line in f:
                try:
                    data = json.loads(line)
                    items.append(IntelligenceItem(**data))
                except Exception as e:
                    logger.error(f"Error loading item: {e}")

        # 按 published_at 倒序排序（最新的在前）
        items.sort(key=lambda x: x.published_at, reverse=True)

        # 返回前 N 条
        return items[:limit]

    async def save_report(self, report: IntelligenceReport) -> None:
        """
        保存情报报告

        Args:
            report: 情报报告
        """
        today = datetime.utcnow().strftime("%Y-%m-%d")
        file_path = self.reports_dir / f"{report.topic_id}" / f"{today}_{report.id}.json"

        file_path.parent.mkdir(parents=True, exist_ok=True)

        # 自定义JSON序列化器处理datetime
        def json_serial(obj):
            """JSON serializer for objects not serializable by default json code"""
            if isinstance(obj, datetime):
                return obj.isoformat()
            raise TypeError(f"Type {type(obj)} not serializable")

        with open(file_path, 'w', encoding='utf-8') as f:
            json.dump(report.model_dump(), f, ensure_ascii=False, indent=2, default=json_serial)

        logger.info(f"Saved report: {report.id}")

    async def load_latest_report(
        self,
        topic_id: str
    ) -> Optional[IntelligenceReport]:
        """
        加载最新报告

        Args:
            topic_id: 主题ID

        Returns:
            情报报告，不存在返回None
        """
        report_dir = self.reports_dir / topic_id

        if not report_dir.exists():
            return None

        # 获取最新的报告文件
        report_files = sorted(
            report_dir.glob("*.json"),
            key=lambda x: x.stat().st_mtime,
            reverse=True
        )

        if not report_files:
            return None

        with open(report_files[0], 'r', encoding='utf-8') as f:
            data = json.load(f)

        return IntelligenceReport(**data)

    async def delete_topic(self, topic_id: str) -> bool:
        """
        删除主题及其所有相关数据

        Args:
            topic_id: 主题ID

        Returns:
            是否成功删除
        """
        try:
            logger.info(f"Deleting topic: {topic_id}")

            deleted_files = []

            # 1. 删除主题文件
            topic_file = self.topics_dir / f"{topic_id}.json"
            if topic_file.exists():
                topic_file.unlink()
                deleted_files.append(str(topic_file))
                logger.info(f"Deleted topic file: {topic_file}")

            # 2. 删除所有情报数据
            items_dir = self.items_dir / topic_id
            if items_dir.exists():
                import shutil
                shutil.rmtree(items_dir)
                deleted_files.append(str(items_dir))
                logger.info(f"Deleted items directory: {items_dir}")

            # 3. 删除所有报告
            reports_dir = self.reports_dir / topic_id
            if reports_dir.exists():
                import shutil
                shutil.rmtree(reports_dir)
                deleted_files.append(str(reports_dir))
                logger.info(f"Deleted reports directory: {reports_dir}")

            logger.info(f"Successfully deleted topic {topic_id} ({len(deleted_files)} files/dirs)")
            return True

        except Exception as e:
            logger.error(f"Error deleting topic {topic_id}: {e}")
            return False

    async def delete_all_topics(self) -> int:
        """
        删除所有主题和数据

        Returns:
            删除的主题数量
        """
        try:
            topics = await self.list_topics()
            count = 0

            for topic in topics:
                success = await self.delete_topic(topic.id)
                if success:
                    count += 1

            logger.info(f"Deleted {count}/{len(topics)} topics")
            return count

        except Exception as e:
            logger.error(f"Error deleting all topics: {e}")
            return 0
