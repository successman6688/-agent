"""Product management service (Database Version)."""

from typing import List, Optional
from datetime import datetime

from sqlalchemy.ext.asyncio import AsyncSession

from app.models.product import (
    Product,
    ProductCreate,
    ProductUpdate,
    ProductFilters,
    ProductType,
    ProductStatus,
    ProductExamples,
)
from app.db.product_repository import ProductRepository
from app.db import ProductDB
from app.core.logging import get_logger

logger = get_logger(__name__)


class ProductService:
    """产品管理服务（数据库版本）"""

    def __init__(self, session: AsyncSession):
        """
        初始化产品服务

        Args:
            session: 数据库会话
        """
        self.session = session
        self.repository = ProductRepository(session)

    # ============== CRUD Operations ==============

    async def create_product(self, data: ProductCreate) -> Product:
        """
        创建产品

        Args:
            data: 产品创建数据

        Returns:
            创建的产品
        """
        product_data = data.model_dump()
        product_data['status'] = ProductStatus.INACTIVE
        product_data['is_active'] = False

        db_product = await self.repository.create_product(product_data)
        return self._db_to_model(db_product)

    async def list_products(
        self,
        filters: Optional[ProductFilters] = None,
        limit: int = 100,
        offset: int = 0
    ) -> List[Product]:
        """
        获取产品列表

        Args:
            filters: 筛选条件
            limit: 返回数量限制
            offset: 偏移量

        Returns:
            产品列表
        """
        db_products = await self.repository.list_products(filters, limit, offset)
        return [self._db_to_model(p) for p in db_products]

    async def get_product(self, product_id: str) -> Optional[Product]:
        """
        获取产品详情

        Args:
            product_id: 产品 ID

        Returns:
            产品对象，如果不存在返回 None
        """
        db_product = await self.repository.get_product(product_id)
        if not db_product:
            return None
        return self._db_to_model(db_product)

    async def update_product(self, product_id: str, data: ProductUpdate) -> Optional[Product]:
        """
        更新产品

        Args:
            product_id: 产品 ID
            data: 更新数据

        Returns:
            更新后的产品，如果不存在返回 None
        """
        update_data = data.model_dump(exclude_unset=True)

        db_product = await self.repository.update_product(product_id, update_data)
        if not db_product:
            return None

        logger.info(f"Updated product: {db_product.name} ({product_id})")
        return self._db_to_model(db_product)

    async def delete_product(self, product_id: str) -> bool:
        """
        删除产品

        Args:
            product_id: 产品 ID

        Returns:
            是否删除成功
        """
        success = await self.repository.delete_product(product_id)
        if success:
            logger.info(f"Deleted product: {product_id}")
        return success

    # ============== Active Product Management ==============

    async def set_active_product(self, product_id: str) -> Optional[Product]:
        """
        设置当前激活产品

        Args:
            product_id: 产品 ID

        Returns:
            激活的产品，如果不存在返回 None
        """
        db_product = await self.repository.set_active_product(product_id)
        if not db_product:
            return None
        return self._db_to_model(db_product)

    async def get_active_product(self) -> Optional[Product]:
        """
        获取当前激活产品

        Returns:
            激活的产品，如果没有返回 None
        """
        db_product = await self.repository.get_active_product()
        if not db_product:
            return None
        return self._db_to_model(db_product)

    async def clear_active_product(self) -> None:
        """清除激活产品"""
        count = await self.repository.clear_active_products()
        logger.info(f"Cleared {count} active products")

    # ============== Statistics ==============

    async def get_product_count(self) -> int:
        """获取产品总数"""
        return await self.repository.get_product_count()

    async def get_active_product_count(self) -> int:
        """获取激活产品数量"""
        return await self.repository.get_active_product_count()

    async def get_products_by_type(self, product_type: ProductType) -> List[Product]:
        """
        按类型获取产品

        Args:
            product_type: 产品类型

        Returns:
            产品列表
        """
        db_products = await self.repository.get_products_by_type(product_type)
        return [self._db_to_model(p) for p in db_products]

    # ============== Content Management ==============

    async def increment_content_count(self, product_id: str) -> None:
        """增加产品的内容计数"""
        await self.repository.increment_content_count(product_id)

    async def increment_publish_count(self, product_id: str) -> None:
        """增加产品的发布计数"""
        await self.repository.increment_publish_count(product_id)

    # ============== Private Methods ==============

    def _db_to_model(self, db_product: ProductDB) -> Product:
        """将数据库模型转换为业务模型"""
        return Product(
            id=str(db_product.id),
            name=db_product.name,
            type=db_product.type,
            description=db_product.description,
            target_audience=db_product.target_audience,
            selling_points=db_product.selling_points,
            website_url=db_product.website_url,
            cta_text=db_product.cta_text,
            cta_link=db_product.cta_link,
            wechat_appid=db_product.wechat_appid,
            wechat_path=db_product.wechat_path,
            app_store_url=db_product.app_store_url,
            google_play_url=db_product.google_play_url,
            yingyongbao_url=db_product.yingyongbao_url,
            download_links=db_product.download_links,
            price=db_product.price,
            pricing_model=db_product.pricing_model,
            category=db_product.category,
            tags=db_product.tags,
            status=db_product.status,
            is_active=db_product.is_active,
            content_count=db_product.content_count,
            publish_count=db_product.publish_count,
            created_at=db_product.created_at,
            updated_at=db_product.updated_at,
        )


# ============== Helper Functions for Streamlit/External Usage ==============

async def get_products_for_streamlit() -> List[Product]:
    """
    辅助函数：为Streamlit应用获取产品列表

    Returns:
        产品列表
    """
    from app.db.connection import get_db_session
    from app.core.config import settings
    from sqlalchemy.ext.asyncio import create_async_engine, AsyncSession
    from sqlalchemy.orm import sessionmaker

    # 创建临时数据库连接
    engine = create_async_engine(settings.DATABASE_URL, echo=False)
    async_session_maker = sessionmaker(
        engine,
        class_=AsyncSession,
        expire_on_commit=False,
        autocommit=False,
        autoflush=False,
    )

    async with async_session_maker() as session:
        service = ProductService(session)
        products = await service.list_products()

    await engine.dispose()
    return products


async def get_active_product_for_streamlit() -> Optional[Product]:
    """
    辅助函数：为Streamlit应用获取激活产品

    Returns:
        激活的产品，如果没有则返回None
    """
    from app.db.connection import get_db_session
    from app.core.config import settings
    from sqlalchemy.ext.asyncio import create_async_engine, AsyncSession
    from sqlalchemy.orm import sessionmaker

    # 创建临时数据库连接
    engine = create_async_engine(settings.DATABASE_URL, echo=False)
    async_session_maker = sessionmaker(
        engine,
        class_=AsyncSession,
        expire_on_commit=False,
        autocommit=False,
        autoflush=False,
    )

    async with async_session_maker() as session:
        service = ProductService(session)
        product = await service.get_active_product()

    await engine.dispose()
    return product
