"""Product information scraper service (simplified version)."""

import re
import json
from typing import Optional, Dict, Any
from urllib.parse import urlparse, parse_qs

import requests
from bs4 import BeautifulSoup

from app.core.logging import get_logger
from app.models.product import ProductType, PricingModel

logger = get_logger(__name__)


class ProductScraper:
    """产品信息抓取服务（简化版）"""

    def __init__(self, timeout: int = 10):
        """
        初始化抓取服务。

        Args:
            timeout: 请求超时时间（秒）
        """
        self.timeout = timeout
        self.session = requests.Session()
        self.session.headers.update({
            'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
        })

    def fetch_from_url_sync(self, url: str) -> Optional[Dict[str, Any]]:
        """
        根据 URL 自动识别并抓取产品信息。

        Args:
            url: 产品链接

        Returns:
            产品信息字典，如果失败返回 None
        """
        try:
            logger.info(f"Fetching product info from: {url}")

            # 识别来源
            source = self._identify_source(url)
            logger.info(f"Identified source: {source}")

            if source == "app_store":
                return self._fetch_app_store(url)
            elif source == "google_play":
                return self._fetch_google_play(url)
            elif source == "website":
                return self._fetch_website(url)
            elif source == "wechat":
                return self._fetch_wechat_mini_program(url)
            else:
                logger.warning(f"Unsupported URL source: {source}")
                return None

        except Exception as e:
            logger.error(f"Failed to fetch product info from {url}: {e}", exc_info=True)
            return None

    def _identify_source(self, url: str) -> str:
        """识别 URL 来源。"""
        parsed = urlparse(url)
        domain = parsed.netloc.lower()

        if "apps.apple.com" in domain:
            return "app_store"
        elif "play.google.com" in domain:
            return "google_play"
        elif any(x in domain for x in ["mp.weixin.qq.com", "weixin.qq.com"]):
            return "wechat"
        else:
            return "website"

    def _fetch_app_store(self, url: str) -> Optional[Dict[str, Any]]:
        """抓取 iOS App Store 应用信息。"""
        try:
            # 从 URL 提取 App ID
            match = re.search(r'/id(\d+)', url)
            if not match:
                logger.error(f"Cannot extract App ID from URL: {url}")
                return None

            app_id = match.group(1)
            logger.info(f"Extracted App ID: {app_id}")

            # 使用 iTunes Search API
            # 添加 country=CN 参数获取中国区的内容（中文）
            api_url = f"https://itunes.apple.com/lookup?id={app_id}&country=CN"

            response = self.session.get(api_url, timeout=self.timeout)
            response.raise_for_status()

            data = response.json()

            if data.get("resultCount", 0) == 0:
                logger.error(f"App not found in App Store: {app_id}")
                return None

            app_data = data["results"][0]

            # 提取信息
            product_info = {
                "name": app_data.get("trackName"),
                "type": ProductType.APP,
                "description": self._clean_description(app_data.get("description", "")),
                "target_audience": self._extract_target_audience(app_data.get("description", "")),
                "selling_points": self._extract_selling_points(app_data.get("description", "")),
                "website_url": app_data.get("sellerUrl"),
                "cta_text": "立即下载",
                "cta_link": url,
                "app_store_url": url,
                "price": app_data.get("formattedPrice", "免费"),
                "pricing_model": PricingModel.FREE if app_data.get("price", 0) == 0 else PricingModel.ONE_TIME,
                "category": app_data.get("primaryGenreName"),
                "tags": self._extract_keywords(app_data.get("description", "")),
                "metadata": {
                    "bundle_id": app_data.get("bundleId"),
                    "version": app_data.get("version"),
                    "size": app_data.get("fileSizeBytes"),
                    "rating": app_data.get("averageUserRating"),
                    "rating_count": app_data.get("userRatingCount"),
                    "seller": app_data.get("sellerName"),
                    "release_date": app_data.get("currentVersionReleaseDate"),
                    "icon": app_data.get("artworkUrl512") or app_data.get("artworkUrl100"),
                    "screenshots": app_data.get("screenshotUrls", [])
                }
            }

            logger.info(f"Successfully fetched App Store app: {product_info['name']}")
            return product_info

        except Exception as e:
            logger.error(f"Error fetching from App Store: {e}", exc_info=True)
            return None

    def _fetch_google_play(self, url: str) -> Optional[Dict[str, Any]]:
        """抓取 Google Play 应用信息。"""
        try:
            # 从 URL 提取包名
            parsed = urlparse(url)
            query_params = parse_qs(parsed.query)
            package_id = query_params.get("id", [None])[0]

            if not package_id:
                logger.error(f"Cannot extract package ID from URL: {url}")
                return None

            logger.info(f"Extracted package ID: {package_id}")

            # 抓取页面
            response = self.session.get(url, timeout=self.timeout)
            response.raise_for_status()

            html = response.text
            soup = BeautifulSoup(html, 'html.parser')

            # 尝试从 script 标签提取
            script_tags = soup.find_all('script', type='application/ld+json')

            app_data = None
            for script in script_tags:
                try:
                    data = json.loads(script.string)
                    if data.get("@type") == "SoftwareApplication":
                        app_data = data
                        break
                except:
                    continue

            if not app_data:
                # 使用备用方案：从 meta 标签提取
                return self._parse_google_play_from_meta(soup, url, package_id)

            # 提取信息
            product_info = {
                "name": app_data.get("name"),
                "type": ProductType.APP,
                "description": self._clean_description(app_data.get("description", "")),
                "target_audience": self._extract_target_audience(app_data.get("description", "")),
                "selling_points": self._extract_selling_points(app_data.get("description", "")),
                "website_url": app_data.get("url"),
                "cta_text": "立即下载",
                "cta_link": url,
                "google_play_url": url,
                "price": app_data.get("offers", {}).get("price", "免费"),
                "pricing_model": PricingModel.FREE,
                "category": app_data.get("applicationCategory"),
                "tags": app_data.get("keywords", "").split(",") if app_data.get("keywords") else [],
                "metadata": {
                    "package_id": package_id,
                    "rating": app_data.get("aggregateRating", {}).get("ratingValue"),
                    "rating_count": app_data.get("aggregateRating", {}).get("ratingCount"),
                    "developer": app_data.get("author", {}).get("name"),
                    "icon": app_data.get("image")
                }
            }

            logger.info(f"Successfully fetched Google Play app: {product_info['name']}")
            return product_info

        except Exception as e:
            logger.error(f"Error fetching from Google Play: {e}", exc_info=True)
            return None

    def _parse_google_play_from_meta(self, soup: BeautifulSoup, url: str, package_id: str) -> Optional[Dict[str, Any]]:
        """从 meta 标签解析 Google Play 信息（备用方案）。"""
        try:
            name = soup.find('meta', property='og:title')
            description = soup.find('meta', property='og:description')
            image = soup.find('meta', property='og:image')

            if not name:
                return None

            product_info = {
                "name": name.get('content'),
                "type": ProductType.APP,
                "description": description.get('content', '') if description else '',
                "selling_points": [],
                "google_play_url": url,
                "metadata": {
                    "package_id": package_id,
                    "icon": image.get('content') if image else None
                }
            }

            return product_info

        except Exception as e:
            logger.error(f"Error parsing Google Play from meta: {e}", exc_info=True)
            return None

    def _fetch_website(self, url: str) -> Optional[Dict[str, Any]]:
        """抓取网站信息。"""
        try:
            response = self.session.get(url, timeout=self.timeout)
            response.raise_for_status()

            html = response.text
            soup = BeautifulSoup(html, 'html.parser')

            # 提取基本信息
            title = (
                soup.find('meta', property='og:title') or
                soup.find('meta', name='twitter:title') or
                soup.find('title')
            )

            description = (
                soup.find('meta', property='og:description') or
                soup.find('meta', name='twitter:description') or
                soup.find('meta', name='description')
            )

            image = (
                soup.find('meta', property='og:image') or
                soup.find('meta', name='twitter:image')
            )

            product_info = {
                "name": title.get('content') if title else soup.title.string if soup.title else url,
                "type": ProductType.WEBSITE,
                "description": description.get('content', '') if description else '',
                "selling_points": [],
                "website_url": url,
                "cta_text": "了解更多",
                "cta_link": url,
                "pricing_model": PricingModel.FREE,
                "tags": self._extract_meta_keywords(soup),
                "metadata": {
                    "icon": image.get('content') if image else None,
                    "favicon": self._get_favicon(soup, url)
                }
            }

            logger.info(f"Successfully fetched website info: {product_info['name']}")
            return product_info

        except Exception as e:
            logger.error(f"Error fetching website: {e}", exc_info=True)
            return None

    def _fetch_wechat_mini_program(self, url: str) -> Optional[Dict[str, Any]]:
        """抓取微信小程序信息（仅提供模板）。"""
        return {
            "name": "",
            "type": ProductType.MINI_PROGRAM,
            "description": "",
            "selling_points": [],
            "metadata": {
                "note": "请手动填写微信小程序的 AppID 和相关信息"
            }
        }

    # ============== 辅助方法 ==============

    def _clean_description(self, description: str, max_length: int = 500) -> str:
        """清理描述文本。"""
        if not description:
            return ""
        text = re.sub(r'\s+', ' ', description)
        if len(text) > max_length:
            text = text[:max_length] + "..."
        return text.strip()

    def _extract_target_audience(self, description: str) -> str:
        """从描述中提取目标用户（简单实现）。"""
        keywords_audience = {
            "儿童": ["儿童", "孩子", "小学", "幼儿园"],
            "开发者": ["开发者", "程序员", "编程", "API"],
            "学生": ["学生", "学习", "课程", "教育"],
            "家长": ["家长", "父母", "育儿"],
            "企业": ["企业", "公司", "团队", "协作"],
        }

        for audience, keywords in keywords_audience.items():
            if any(keyword in description for keyword in keywords):
                return audience

        return "普通用户"

    def _extract_selling_points(self, description: str) -> list:
        """从描述中提取卖点。"""
        patterns = [
            r'[●\-\*]\s*([^\n]+)',
            r'✓\s*([^\n]+)',
            r'✅\s*([^\n]+)',
            r'\d+\.\s*([^\n]+)',
        ]

        selling_points = []

        for pattern in patterns:
            matches = re.findall(pattern, description)
            selling_points.extend([m.strip() for m in matches if len(m.strip()) > 5])
            if selling_points:
                break

        return selling_points[:5] if selling_points else []

    def _extract_keywords(self, text: str) -> list:
        """提取关键词。"""
        if not text:
            return []
        stopwords = {'的', '了', '是', '在', '我', '有', '和', '就', '不', '人', '都', '一', '一个', '上', '也', '很', '到', '说', '要', '去', '你', '会', '着', '没有', '看', '好', '自己', '这'}
        words = re.findall(r'[\u4e00-\u9fa5]{2,4}', text)
        word_count = {}
        for word in words:
            if word not in stopwords:
                word_count[word] = word_count.get(word, 0) + 1
        sorted_words = sorted(word_count.items(), key=lambda x: x[1], reverse=True)
        keywords = [word for word, count in sorted_words[:10]]
        return keywords

    def _extract_meta_keywords(self, soup: BeautifulSoup) -> list:
        """从 meta 标签提取关键词。"""
        keywords_meta = soup.find('meta', name='keywords')
        if keywords_meta:
            keywords = keywords_meta.get('content', '')
            return [k.strip() for k in keywords.split(',') if k.strip()]
        return []

    def _get_favicon(self, soup: BeautifulSoup, base_url: str) -> Optional[str]:
        """获取网站图标。"""
        icon_link = (
            soup.find('link', rel='icon') or
            soup.find('link', rel='shortcut icon')
        )

        if icon_link:
            href = icon_link.get('href')
            if href:
                if href.startswith('//'):
                    return 'https:' + href
                elif href.startswith('/'):
                    parsed = urlparse(base_url)
                    return f"{parsed.scheme}://{parsed.netloc}{href}"
                elif not href.startswith('http'):
                    return base_url.rstrip('/') + '/' + href
                else:
                    return href
        return None

    def close(self):
        """关闭客户端。"""
        self.session.close()


# ============== 全局服务实例 ==============

_scraper: Optional[ProductScraper] = None


def get_product_scraper() -> ProductScraper:
    """获取产品抓取服务实例（单例）。"""
    global _scraper
    if _scraper is None:
        _scraper = ProductScraper()
    return _scraper
