"""Product data models."""

from datetime import datetime
from enum import Enum
from typing import List, Optional, Dict, Any
from uuid import uuid4

from pydantic import BaseModel, Field, ConfigDict


# ============== Enumerations ==============

class ProductType(str, Enum):
    """产品类型枚举"""
    MINI_PROGRAM = "mini_program"      # 小程序
    APP = "app"                        # APP
    WEBSITE = "website"                # 网站
    SAAS = "saas"                      # SaaS
    COURSE = "course"                  # 课程
    PHYSICAL = "physical"              # 实体商品
    SERVICE = "service"                # 服务
    OTHER = "other"                    # 其他

    @classmethod
    def get_label(cls, value: str) -> str:
        """获取中文标签"""
        labels = {
            "mini_program": "小程序",
            "app": "APP",
            "website": "网站",
            "saas": "SaaS",
            "course": "课程",
            "physical": "实体商品",
            "service": "服务",
            "other": "其他"
        }
        return labels.get(value, value)

    @classmethod
    def get_all_choices(cls) -> List[tuple]:
        """获取所有选项（用于表单）"""
        return [
            ("mini_program", "小程序"),
            ("app", "APP"),
            ("website", "网站"),
            ("saas", "SaaS"),
            ("course", "课程"),
            ("physical", "实体商品"),
            ("service", "服务"),
            ("other", "其他")
        ]


class ProductStatus(str, Enum):
    """产品状态"""
    ACTIVE = "active"                  # 激活（用于营销）
    INACTIVE = "inactive"              # 未激活
    ARCHIVED = "archived"              # 已归档


class PricingModel(str, Enum):
    """定价模式"""
    FREE = "free"                      # 免费
    ONE_TIME = "one_time"              # 一次性付费
    SUBSCRIPTION = "subscription"      # 订阅制
    FREEMIUM = "freemium"              # 免费增值


# ============== Product Models ==============

class ProductBase(BaseModel):
    """产品基础模型"""
    name: str = Field(..., description="产品名称")
    type: ProductType = Field(..., description="产品类型")
    description: str = Field(..., description="产品描述")
    target_audience: str = Field(..., description="目标用户")


class ProductMarketingInfo(BaseModel):
    """产品营销信息"""
    selling_points: List[str] = Field(default_factory=list, description="产品卖点")
    website_url: Optional[str] = Field(None, description="官网/网站链接")
    cta_text: Optional[str] = Field(None, description="CTA 文本")
    cta_link: Optional[str] = Field(None, description="CTA 链接")


class ProductPlatformInfo(BaseModel):
    """平台信息"""
    # 小程序
    wechat_appid: Optional[str] = Field(None, description="微信小程序 AppID")
    wechat_path: Optional[str] = Field(None, description="小程序路径")

    # APP
    app_store_url: Optional[str] = Field(None, description="App Store 链接")
    google_play_url: Optional[str] = Field(None, description="Google Play 链接")
    yingyongbao_url: Optional[str] = Field(None, description="应用宝链接")

    # 下载链接
    download_links: Dict[str, str] = Field(default_factory=dict, description="各平台下载链接")


class ProductPricingInfo(BaseModel):
    """价格信息"""
    price: Optional[str] = Field(None, description="价格")
    pricing_model: Optional[PricingModel] = Field(None, description="定价模式")


class ProductTags(BaseModel):
    """产品标签"""
    category: Optional[str] = Field(None, description="产品分类")
    tags: List[str] = Field(default_factory=list, description="产品标签")


class ProductCreate(BaseModel):
    """创建产品"""
    # 基础信息
    name: str
    type: ProductType
    description: str
    target_audience: str

    # 营销信息
    selling_points: List[str] = []
    website_url: Optional[str] = None
    cta_text: Optional[str] = None
    cta_link: Optional[str] = None

    # 平台信息
    wechat_appid: Optional[str] = None
    wechat_path: Optional[str] = None
    app_store_url: Optional[str] = None
    google_play_url: Optional[str] = None
    yingyongbao_url: Optional[str] = None
    download_links: Dict[str, str] = {}

    # 价格信息
    price: Optional[str] = None
    pricing_model: Optional[PricingModel] = None

    # 标签
    category: Optional[str] = None
    tags: List[str] = []


class ProductUpdate(BaseModel):
    """更新产品"""
    name: Optional[str] = None
    type: Optional[ProductType] = None
    description: Optional[str] = None
    target_audience: Optional[str] = None

    selling_points: Optional[List[str]] = None
    website_url: Optional[str] = None
    cta_text: Optional[str] = None
    cta_link: Optional[str] = None

    wechat_appid: Optional[str] = None
    wechat_path: Optional[str] = None
    app_store_url: Optional[str] = None
    google_play_url: Optional[str] = None
    yingyongbao_url: Optional[str] = None
    download_links: Optional[Dict[str, str]] = None

    price: Optional[str] = None
    pricing_model: Optional[PricingModel] = None

    category: Optional[str] = None
    tags: Optional[List[str]] = None

    status: Optional[ProductStatus] = None


class Product(ProductBase):
    """完整产品模型"""
    model_config = ConfigDict(use_enum_values=True)

    id: str = Field(default_factory=lambda: str(uuid4()))

    # 营销信息
    selling_points: List[str] = Field(default_factory=list)
    website_url: Optional[str] = None
    cta_text: Optional[str] = None
    cta_link: Optional[str] = None

    # 平台信息
    wechat_appid: Optional[str] = None
    wechat_path: Optional[str] = None
    app_store_url: Optional[str] = None
    google_play_url: Optional[str] = None
    yingyongbao_url: Optional[str] = None
    download_links: Dict[str, str] = Field(default_factory=dict)

    # 价格信息
    price: Optional[str] = None
    pricing_model: Optional[PricingModel] = None

    # 标签
    category: Optional[str] = None
    tags: List[str] = Field(default_factory=list)

    # 状态
    status: ProductStatus = Field(default=ProductStatus.INACTIVE)
    is_active: bool = Field(default=False, description="是否为当前激活产品")

    # 统计信息
    content_count: int = Field(default=0, description="已生成内容数")
    publish_count: int = Field(default=0, description="已发布内容数")

    # 时间戳
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)

    @property
    def type_label(self) -> str:
        """获取产品类型中文标签"""
        return ProductType.get_label(self.type.value if isinstance(self.type, ProductType) else self.type)

    @property
    def display_name(self) -> str:
        """显示名称（带类型）"""
        return f"{self.name} ({self.type_label})"


# ============== Product Filters ==============

class ProductFilters(BaseModel):
    """产品筛选条件"""
    type: Optional[ProductType] = None
    status: Optional[ProductStatus] = None
    is_active: Optional[bool] = None
    category: Optional[str] = None
    tags: Optional[List[str]] = None
    search: Optional[str] = None  # 搜索产品名称


# ============== Example Data ==============

class ProductExamples:
    """产品示例数据"""

    @staticmethod
    def get_examples() -> List[Dict[str, Any]]:
        """获取示例产品"""
        return [
            {
                "name": "SparkFlow",
                "type": ProductType.SAAS,
                "description": "AI 驱动的营销自动化平台，帮助个人开发者和小团队自动化内容生产和多平台发布",
                "target_audience": "独立开发者、创业团队",
                "selling_points": [
                    "自动内容生成",
                    "多平台一键发布",
                    "AI 智能优化"
                ],
                "website_url": "https://sparkflow.example.com",
                "cta_text": "免费试用",
                "cta_link": "https://sparkflow.example.com/signup",
                "price": "￥99/月起",
                "pricing_model": PricingModel.SUBSCRIPTION,
                "category": "营销工具",
                "tags": ["AI", "营销", "自动化"],
                "status": ProductStatus.ACTIVE,
                "is_active": True
            },
            {
                "name": "儿童数学学习",
                "type": ProductType.APP,
                "description": "专为 3-12 岁儿童设计的数学启蒙 APP，通过游戏化学习让孩子爱上数学",
                "target_audience": "家长、小学生",
                "selling_points": [
                    "游戏化学习体验",
                    "符合小学数学大纲",
                    "实时学习报告"
                ],
                "app_store_url": "https://apps.apple.com/app/123456",
                "google_play_url": "https://play.google.com/store/apps/details?id=com.example.math",
                "cta_text": "立即下载",
                "cta_link": "https://math.example.com/download",
                "price": "免费（含内购）",
                "pricing_model": PricingModel.FREEMIUM,
                "category": "教育",
                "tags": ["儿童教育", "数学", "学习"],
                "status": ProductStatus.INACTIVE,
                "is_active": False
            },
            {
                "name": "Python 全栈开发课程",
                "type": ProductType.COURSE,
                "description": "从零基础到全栈工程师，系统学习 Python Web 开发",
                "target_audience": "编程初学者、转行人员",
                "selling_points": [
                    "实战项目驱动",
                    "1对1 代码辅导",
                    "就业推荐服务"
                ],
                "website_url": "https://python-course.example.com",
                "cta_text": "开始学习",
                "cta_link": "https://python-course.example.com/enroll",
                "price": "￥2990",
                "pricing_model": PricingModel.ONE_TIME,
                "category": "编程教育",
                "tags": ["Python", "Web开发", "编程"],
                "status": ProductStatus.INACTIVE,
                "is_active": False
            }
        ]
