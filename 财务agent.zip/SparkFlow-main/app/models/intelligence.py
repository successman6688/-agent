"""Intelligence data models."""

from datetime import datetime
from enum import Enum
from typing import List, Optional, Dict, Any
from uuid import uuid4

from pydantic import BaseModel, Field, ConfigDict


# ============== Enumerations ==============

class SourceType(str, Enum):
    """数据源类型"""
    RSS = "rss"
    API = "api"
    WEB = "web"
    CUSTOM = "custom"
    GITHUB_TRENDING = "github_trending"
    PRODUCT_HUNT = "product_hunt"
    GOOGLE_NEWS = "google_news"


class ScheduleType(str, Enum):
    """更新频率"""
    MANUAL = "manual"       # 手动触发
    HOURLY = "hourly"       # 每小时
    DAILY = "daily"         # 每天
    WEEKLY = "weekly"       # 每周


# ============== Configuration Models ==============

class TopicConfig(BaseModel):
    """主题配置"""
    max_items: int = Field(default=50, description="最大情报条数")
    min_relevance: float = Field(default=0.5, description="最小相关性评分")
    enable_ai_summary: bool = Field(default=True, description="启用AI总结")
    languages: List[str] = Field(default=["zh", "en"], description="语言偏好")
    ai_summary_threshold: float = Field(default=0.7, description="AI总结阈值")

    # 评分权重配置
    keyword_weight: float = Field(default=0.4, description="关键词权重")
    timeliness_weight: float = Field(default=0.3, description="时效性权重")
    authority_weight: float = Field(default=0.3, description="权威性权重")


class SourceConfig(BaseModel):
    """数据源配置"""
    type: SourceType
    name: str
    enabled: bool = True

    # RSS特有
    url: Optional[str] = None
    query: Optional[str] = None

    # API特有
    base_url: Optional[str] = None
    endpoints: Optional[Dict[str, str]] = None

    # 通用配置
    params: Optional[Dict[str, Any]] = None
    headers: Optional[Dict[str, str]] = None
    update_interval: Optional[int] = None  # 更新间隔（秒）


# ============== Intelligence Topic Models ==============

class IntelligenceTopicBase(BaseModel):
    """情报主题基础模型"""
    name: str = Field(..., description="主题名称")
    keywords: List[str] = Field(..., description="关键词列表")
    sources: List[SourceConfig] = Field(..., description="数据源配置")
    schedule: ScheduleType = Field(default=ScheduleType.DAILY, description="更新频率")
    description: Optional[str] = Field(None, description="主题描述")


class IntelligenceTopicCreate(IntelligenceTopicBase):
    """创建情报主题"""
    config: TopicConfig = Field(default_factory=TopicConfig)


class IntelligenceTopicUpdate(BaseModel):
    """更新情报主题"""
    name: Optional[str] = None
    keywords: Optional[List[str]] = None
    sources: Optional[List[SourceConfig]] = None
    schedule: Optional[ScheduleType] = None
    description: Optional[str] = None
    config: Optional[TopicConfig] = None
    is_active: Optional[bool] = None


class IntelligenceTopic(IntelligenceTopicBase):
    """完整情报主题模型"""
    model_config = ConfigDict(use_enum_values=True)

    id: str = Field(default_factory=lambda: str(uuid4()))
    is_active: bool = Field(default=True, description="是否激活")
    last_run_time: Optional[datetime] = Field(None, description="最后运行时间")
    last_status: Optional[str] = Field(None, description="最后运行状态")
    total_items: int = Field(default=0, description="总情报数")
    config: TopicConfig = Field(default_factory=TopicConfig)

    # 统计信息
    today_items: int = Field(default=0, description="今日新增")
    weekly_items: int = Field(default=0, description="本周新增")

    # 时间戳
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)


# ============== Intelligence Item Models ==============

class IntelligenceItemBase(BaseModel):
    """情报项基础模型"""
    topic_id: str = Field(..., description="所属主题ID")

    # 原始内容
    title: str = Field(..., description="标题")
    content: str = Field(..., description="内容摘要")
    url: str = Field(..., description="来源链接")
    source: str = Field(..., description="来源平台")
    author: Optional[str] = Field(None, description="作者")

    # 元数据
    published_at: datetime = Field(..., description="发布时间")
    collected_at: datetime = Field(default_factory=datetime.utcnow, description="采集时间")


class IntelligenceItemCreate(IntelligenceItemBase):
    """创建情报项"""
    # 去重标识
    guid: Optional[str] = None
    url_hash: Optional[str] = None
    content_hash: Optional[str] = None


class IntelligenceItem(IntelligenceItemBase):
    """完整情报项模型"""
    id: str = Field(default_factory=lambda: str(uuid4()))

    # 评分
    relevance_score: float = Field(default=0.0, description="相关性评分 (0-1)")
    timeliness_score: float = Field(default=0.0, description="时效性评分 (0-1)")
    authority_score: float = Field(default=0.0, description="权威性评分 (0-1)")
    overall_score: float = Field(default=0.0, description="综合评分 (0-1)")

    # AI处理结果
    ai_summary: Optional[str] = Field(None, description="AI总结")
    key_insights: List[str] = Field(default_factory=list, description="关键洞察")
    sentiment: Optional[str] = Field(None, description="情感倾向 (positive/negative/neutral)")
    tags: List[str] = Field(default_factory=list, description="自动标签")

    # 去重标识
    guid: Optional[str] = Field(None, description="RSS GUID")
    url_hash: str = Field(..., description="URL哈希")
    content_hash: Optional[str] = Field(None, description="内容哈希")

    # 向量检索
    embedding_id: Optional[str] = Field(None, description="向量ID")

    # 扩展元数据
    metadata: Dict[str, Any] = Field(default_factory=dict, description="扩展元数据")


# ============== Intelligence Report Models ==============

class IntelligenceReport(BaseModel):
    """情报分析报告"""
    id: str = Field(default_factory=lambda: str(uuid4()))
    topic_id: str = Field(..., description="所属主题")

    # 统计周期
    period_start: datetime = Field(..., description="统计周期开始")
    period_end: datetime = Field(..., description="统计周期结束")

    # 统计信息
    total_items: int = Field(default=0, description="总情报数")
    new_items: int = Field(default=0, description="新增情报数")
    sources_breakdown: Dict[str, int] = Field(default_factory=dict, description="来源分布")

    # AI分析
    summary: Optional[str] = Field(None, description="整体总结")
    key_trends: List[str] = Field(default_factory=list, description="关键趋势")
    hot_topics: List[str] = Field(default_factory=list, description="热点话题")
    sentiment: Optional[str] = Field(None, description="情感倾向")

    # 重要情报
    top_items: List[str] = Field(default_factory=list, description="Top情报ID列表")

    created_at: datetime = Field(default_factory=datetime.utcnow, description="报告生成时间")


# ============== Collection Request/Response ==============

class CollectionRequest(BaseModel):
    """情报收集请求"""
    topic_id: str
    force_refresh: bool = Field(default=False, description="强制刷新")


class CollectionResponse(BaseModel):
    """情报收集响应"""
    topic_id: str
    status: str  # running, completed, failed
    total_collected: int
    new_items: int
    duration_seconds: float
    report_id: Optional[str] = None
    message: Optional[str] = None


# ============== Prompt Template Models ==============

class PromptVariable(BaseModel):
    """提示词变量"""
    name: str = Field(..., description="变量名")
    description: str = Field(..., description="变量描述")
    default_value: Any = Field(None, description="默认值")
    required: bool = Field(True, description="是否必需")


class PromptTemplate(BaseModel):
    """AI分析提示词模板"""
    id: str = Field(default_factory=lambda: str(uuid4()))
    name: str = Field(..., description="模板名称")
    description: str = Field(..., description="模板描述")

    # 分类
    strategy_type: str = Field(..., description="策略类型: finance/technology/startup/general")
    category: str = Field(default="default", description="细分类别")

    # 模板内容
    system_prompt: str = Field(..., description="系统提示词（角色设定）")
    user_prompt_template: str = Field(..., description="用户提示词模板（包含变量占位符）")

    # 输出格式
    output_schema: Dict[str, Any] = Field(..., description="输出JSON Schema")

    # 变量定义
    variables: list[PromptVariable] = Field(default_factory=list, description="模板变量列表")

    # 版本管理
    version: str = Field(default="1.0", description="版本号")
    is_active: bool = Field(True, description="是否启用")
    is_default: bool = Field(False, description="是否为默认模板")

    # 性能指标
    usage_count: int = Field(default=0, description="使用次数")
    success_rate: float = Field(default=0.0, description="成功率（AI成功解析的比例）")
    avg_quality_score: float = Field(default=0.0, description="平均质量评分（用户反馈）")

    # 元数据
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)
    created_by: str = Field(default="system", description="创建者")


class PromptExecutionLog(BaseModel):
    """提示词执行日志"""
    id: str = Field(default_factory=lambda: str(uuid4()))
    template_id: str = Field(..., description="使用的模板ID")
    template_version: str = Field(..., description="模板版本")

    # 执行上下文
    topic_id: str = Field(..., description="情报主题ID")
    topic_name: str = Field(..., description="主题名称")
    strategy_type: str = Field(..., description="策略类型")

    # 输入输出
    variables_used: Dict[str, Any] = Field(..., description="使用的变量值")
    llm_response: str = Field(..., description="LLM原始响应")
    parsed_result: Optional[Dict[str, Any]] = Field(None, description="解析后的结果")
    parse_success: bool = Field(..., description="是否成功解析")

    # 性能指标
    response_time_ms: float = Field(..., description="响应时间（毫秒）")
    token_count: Optional[int] = Field(None, description="Token数量")

    # 反馈
    user_rating: Optional[int] = Field(None, description="用户评分（1-5）")
    user_feedback: Optional[str] = Field(None, description="用户反馈")

    # 时间戳
    created_at: datetime = Field(default_factory=datetime.utcnow)
