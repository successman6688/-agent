"""Content and marketing data models."""

from datetime import datetime
from enum import Enum
from typing import List, Optional, Dict, Any
from uuid import uuid4

from pydantic import BaseModel, Field, ConfigDict


class Platform(str, Enum):
    """Supported platforms."""
    TWITTER = "twitter"
    REDDIT = "reddit"
    BLOG = "blog"
    LINKEDIN = "linkedin"


class ContentStatus(str, Enum):
    """Content status."""
    DRAFT = "draft"
    PENDING_REVIEW = "pending_review"
    APPROVED = "approved"
    REJECTED = "rejected"
    PUBLISHED = "published"
    SCHEDULED = "scheduled"


class TopicSource(str, Enum):
    """Topic source."""
    TWITTER = "twitter"
    HACKERNEWS = "hackernews"
    REDDIT = "reddit"
    CUSTOM = "custom"


# ============== Product Configuration ==============

class ProductConfig(BaseModel):
    """Product configuration for marketing."""
    model_config = ConfigDict(use_enum_values=True)

    id: str = Field(default_factory=lambda: str(uuid4()))
    name: str = Field(..., description="Product name")
    description: str = Field(..., description="Product description")
    target_audience: str = Field(..., description="Target audience")
    selling_points: List[str] = Field(default_factory=list, description="Key selling points")
    website_url: Optional[str] = Field(None, description="Product website")
    cta_text: Optional[str] = Field(None, description="Call to action text")
    cta_link: Optional[str] = Field(None, description="Call to action link")

    # Additional metadata
    tags: List[str] = Field(default_factory=list, description="Product tags")
    category: Optional[str] = Field(None, description="Product category")
    created_at: datetime = Field(default_factory=datetime.utcnow)

    class Example:
        """Example product config."""
        name = "SparkFlow"
        description = "AI-powered marketing automation platform"
        target_audience = "Indie developers and startups"
        selling_points = [
            "Automated content generation",
            "Multi-platform publishing",
            "AI-driven optimization"
        ]
        website_url = "https://sparkflow.example.com"
        cta_text = "Try for free"
        cta_link = "https://sparkflow.example.com/signup"


# ============== Topics ==============

class Topic(BaseModel):
    """Hot topic for content generation."""
    model_config = ConfigDict(use_enum_values=True)

    id: str = Field(default_factory=lambda: str(uuid4()))
    title: str = Field(..., description="Topic title")
    source: TopicSource = Field(..., description="Where the topic came from")
    source_url: Optional[str] = Field(None, description="Original URL")
    description: Optional[str] = Field(None, description="Topic description")

    # Metrics
    viral_score: int = Field(default=0, ge=0, le=100, description="Viral potential score")
    relevance_score: int = Field(default=0, ge=0, le=100, description="Relevance to product")
    engagement_score: int = Field(default=0, ge=0, le=100, description="Engagement potential")

    # Keywords and sentiment
    keywords: List[str] = Field(default_factory=list, description="Related keywords")
    sentiment: Optional[str] = Field(None, description="Sentiment analysis result")

    # Metadata
    discovered_at: datetime = Field(default_factory=datetime.utcnow)
    status: str = Field(default="pending", description="Topic status")
    metadata: Dict[str, Any] = Field(default_factory=dict, description="Additional metadata")


# ============== Content ==============

class Content(BaseModel):
    """Generated marketing content."""
    model_config = ConfigDict(use_enum_values=True)

    id: str = Field(default_factory=lambda: str(uuid4()))
    topic_id: str = Field(..., description="Related topic ID")
    platform: Platform = Field(..., description="Target platform")

    # Content
    title: Optional[str] = Field(None, description="Content title (for blog/reddit)")
    body: str = Field(..., description="Content body/text")

    # Metadata
    version: int = Field(default=1, description="Content version")
    status: ContentStatus = Field(default=ContentStatus.DRAFT, description="Content status")

    # AI metadata
    model_used: Optional[str] = Field(None, description="LLM model used")
    prompt_used: Optional[str] = Field(None, description="Prompt used for generation")
    angle: Optional[str] = Field(None, description="Content angle/approach")

    # Timestamps
    created_at: datetime = Field(default_factory=datetime.utcnow)
    reviewed_at: Optional[datetime] = Field(None, description="When content was reviewed")
    published_at: Optional[datetime] = Field(None, description="When content was published")

    # Review
    reviewed_by: Optional[str] = Field(None, description="Who reviewed the content")
    feedback: Optional[str] = Field(None, description="Review feedback")


class ContentVariant(BaseModel):
    """Content variant for A/B testing."""
    content_id: str
    variant: str
    platform: Platform
    angle: str
    content: str


# ============== Publication ==============

class Publication(BaseModel):
    """Published content record."""
    model_config = ConfigDict(use_enum_values=True)

    id: str = Field(default_factory=lambda: str(uuid4()))
    content_id: str = Field(..., description="Related content ID")
    platform: Platform = Field(..., description="Platform where published")

    # Platform specific
    platform_post_id: Optional[str] = Field(None, description="Platform post ID")
    platform_post_url: Optional[str] = Field(None, description="Platform post URL")

    # Status
    status: str = Field(default="published", description="Publication status")
    error_message: Optional[str] = Field(None, description="Error message if failed")

    # Timestamps
    published_at: datetime = Field(default_factory=datetime.utcnow)

    # Metadata
    metadata: Dict[str, Any] = Field(default_factory=dict)


# ============== Analytics ==============

class PlatformMetrics(BaseModel):
    """Platform-specific metrics."""
    impressions: int = Field(default=0, description="Number of impressions")
    likes: int = Field(default=0, description="Number of likes")
    comments: int = Field(default=0, description="Number of comments")
    shares: int = Field(default=0, description="Number of shares/retweets")
    clicks: int = Field(default=0, description="Number of clicks")
    conversions: int = Field(default=0, description="Number of conversions")

    @property
    def engagement_rate(self) -> float:
        """Calculate engagement rate."""
        if self.impressions == 0:
            return 0.0
        return round((self.likes + self.comments + self.shares) / self.impressions * 100, 2)

    @property
    def ctr(self) -> float:
        """Calculate click-through rate."""
        if self.impressions == 0:
            return 0.0
        return round(self.clicks / self.impressions * 100, 2)

    @property
    def conversion_rate(self) -> float:
        """Calculate conversion rate."""
        if self.clicks == 0:
            return 0.0
        return round(self.conversions / self.clicks * 100, 2)


class Analytics(BaseModel):
    """Analytics data for content/campaign."""
    publication_id: str
    metrics: PlatformMetrics
    recorded_at: datetime = Field(default_factory=datetime.utcnow)
    metadata: Dict[str, Any] = Field(default_factory=dict)


# ============== Campaign ==============

class Campaign(BaseModel):
    """Marketing campaign."""
    model_config = ConfigDict(use_enum_values=True)

    id: str = Field(default_factory=lambda: str(uuid4()))
    name: str = Field(..., description="Campaign name")
    description: Optional[str] = Field(None, description="Campaign description")

    # Target
    target_platforms: List[Platform] = Field(default_factory=list)
    goals: List[str] = Field(default_factory=list, description="Campaign goals")
    duration_days: int = Field(default=30, description="Campaign duration in days")

    # Status
    status: str = Field(default="active", description="Campaign status")

    # Timestamps
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)
    end_date: Optional[datetime] = Field(None, description="Campaign end date")
