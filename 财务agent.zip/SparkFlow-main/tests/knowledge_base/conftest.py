"""Pytest 配置和 Fixtures"""
import pytest
import asyncio
from pathlib import Path
import tempfile
import shutil

@pytest.fixture(scope="session")
def event_loop():
    """创建事件循环"""
    loop = asyncio.get_event_loop_policy().new_event_loop()
    yield loop
    loop.close()

@pytest.fixture(scope="session")
def fixtures_dir():
    """测试数据目录"""
    return Path(__file__).parent / "fixtures"

@pytest.fixture(scope="session")
def sample_pdf(fixtures_dir):
    """示例 PDF 文件路径"""
    return fixtures_dir / "sample.pdf"

@pytest.fixture(scope="session")
def sample_docx(fixtures_dir):
    """示例 DOCX 文件路径"""
    return fixtures_dir / "sample.docx"

@pytest.fixture(scope="session")
def sample_txt(fixtures_dir):
    """示例 TXT 文件路径"""
    return fixtures_dir / "sample.txt"

@pytest.fixture
def temp_dir():
    """临时目录"""
    temp = tempfile.mkdtemp()
    yield Path(temp)
    shutil.rmtree(temp)

@pytest.fixture
def mock_brand_id():
    """模拟品牌 ID"""
    return "test_brand_001"

@pytest.fixture
def sample_text():
    """示例文本"""
    return """
    这是一个测试品牌的介绍文档。
    
    品牌定位：高端科技产品
    目标人群：25-40岁的都市白领
    核心卖点：创新、品质、服务
    
    产品特点：
    1. 采用最新技术
    2. 精致的设计
    3. 优质的用户体验
    
    品牌故事：
    我们致力于为用户提供最好的产品和服务...
    """ * 10  # 重复以生成足够长的文本

@pytest.fixture
def sample_chunks():
    """示例 chunks"""
    return [
        {
            "chunk_id": "chunk_001",
            "text": "这是第一个文本块",
            "start_pos": 0,
            "end_pos": 10,
            "metadata": {
                "file_name": "test.pdf",
                "page": 1
            }
        },
        {
            "chunk_id": "chunk_002",
            "text": "这是第二个文本块",
            "start_pos": 10,
            "end_pos": 20,
            "metadata": {
                "file_name": "test.pdf",
                "page": 1
            }
        }
    ]

@pytest.fixture
async def mock_db_session():
    """模拟数据库会话"""
    # 这里可以创建一个测试数据库会话
    # 或者使用 SQLite 内存数据库
    class MockSession:
        async def commit(self):
            pass
        
        async def rollback(self):
            pass
        
        async def close(self):
            pass
    
    session = MockSession()
    yield session
    await session.close()

@pytest.fixture
def mock_openai_response():
    """模拟 OpenAI API 响应"""
    return {
        "brand_tone": "专业、创新、可靠",
        "target_audience": "25-40岁都市白领",
        "key_features": ["创新技术", "精致设计", "优质服务"],
        "brand_story": "致力于为用户提供最好的产品"
    }

@pytest.fixture
def mock_embedding():
    """模拟 Embedding 向量"""
    import random
    return [random.random() for _ in range(1536)]

# 测试标记
def pytest_configure(config):
    """配置 pytest 标记"""
    config.addinivalue_line(
        "markers", "unit: 单元测试"
    )
    config.addinivalue_line(
        "markers", "integration: 集成测试"
    )
    config.addinivalue_line(
        "markers", "slow: 慢速测试"
    )
    config.addinivalue_line(
        "markers", "requires_services: 需要外部服务的测试"
    )
