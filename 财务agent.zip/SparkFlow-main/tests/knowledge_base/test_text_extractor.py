"""测试文本提取器"""
import pytest
from pathlib import Path
from pipline.services.knowledge_base.text_extractor import TextExtractor

class TestTextExtractor:
    """文本提取器测试"""
    
    def setup_method(self):
        """每个测试前执行"""
        self.extractor = TextExtractor()
    
    def test_extract_from_pdf(self):
        """测试从 PDF 提取文本"""
        file_path = Path("tests/knowledge_base/fixtures/sample.pdf")
        result = self.extractor.extract(file_path, file_type="pdf")
        
        assert result["success"] is True
        assert len(result["text"]) > 0
        assert result["page_count"] > 0
        assert "metadata" in result
    
    def test_extract_from_docx(self):
        """测试从 DOCX 提取文本"""
        file_path = Path("tests/knowledge_base/fixtures/sample.docx")
        result = self.extractor.extract(file_path, file_type="docx")
        
        assert result["success"] is True
        assert len(result["text"]) > 0
    
    def test_extract_from_txt(self):
        """测试从 TXT 提取文本"""
        file_path = Path("tests/knowledge_base/fixtures/sample.txt")
        result = self.extractor.extract(file_path, file_type="txt")
        
        assert result["success"] is True
        assert len(result["text"]) > 0
    
    def test_extract_corrupted_file(self):
        """测试损坏的文件"""
        file_path = Path("tests/knowledge_base/fixtures/corrupted.pdf")
        result = self.extractor.extract(file_path, file_type="pdf")
        
        assert result["success"] is False
        assert "error" in result
    
    def test_extract_empty_file(self):
        """测试空文件"""
        file_path = Path("tests/knowledge_base/fixtures/empty.txt")
        result = self.extractor.extract(file_path, file_type="txt")
        
        assert result["success"] is True
        assert len(result["text"]) == 0

if __name__ == "__main__":
    pytest.main([__file__, "-v"])
