"""测试完整 Pipeline 流程"""
import asyncio
import pytest
from pathlib import Path
from pipline.services.knowledge_base.pipline import KnowledgeBasePipeline
from pipline.models.knowledge_base import BrandKnowledgeBase

class TestKnowledgeBasePipeline:
    """Pipeline 集成测试"""
    
    def setup_method(self):
        """每个测试前执行"""
        self.pipeline = KnowledgeBasePipeline()
    
    @pytest.mark.asyncio
    async def test_full_pipeline_pdf(self):
        """测试完整 Pipeline - PDF 文件"""
        file_path = Path("tests/knowledge_base/fixtures/sample.pdf")
        brand_id = "test_brand_001"
        
        # 执行 Pipeline
        result = await self.pipeline.process_file(
            file_path=file_path,
            brand_id=brand_id
        )
        
        # 验证结果
        assert result["status"] == "success"
        assert result["kb_id"] is not None
        assert result["chunks_count"] > 0
        assert result["vectors_count"] > 0
        assert "ai_insights" in result
        
        print(f"\n✅ Pipeline 执行成功！")
        print(f"知识库 ID: {result['kb_id']}")
        print(f"Chunks 数量: {result['chunks_count']}")
        print(f"向量数量: {result['vectors_count']}")
    
    @pytest.mark.asyncio
    async def test_pipeline_with_multiple_files(self):
        """测试批量文件处理"""
        files = [
            Path("tests/knowledge_base/fixtures/sample.pdf"),
            Path("tests/knowledge_base/fixtures/sample.docx"),
            Path("tests/knowledge_base/fixtures/sample.txt")
        ]
        brand_id = "test_brand_002"
        
        results = []
        for file_path in files:
            result = await self.pipeline.process_file(
                file_path=file_path,
                brand_id=brand_id
            )
            results.append(result)
        
        # 验证所有文件都处理成功
        assert all(r["status"] == "success" for r in results)
        assert len(results) == 3
        
        print(f"\n✅ 批量处理完成！")
        print(f"成功处理 {len(results)} 个文件")
    
    @pytest.mark.asyncio
    async def test_pipeline_error_handling(self):
        """测试错误处理"""
        file_path = Path("tests/knowledge_base/fixtures/corrupted.pdf")
        brand_id = "test_brand_003"
        
        result = await self.pipeline.process_file(
            file_path=file_path,
            brand_id=brand_id
        )
        
        # 应该返回错误状态
        assert result["status"] == "failed"
        assert "error" in result
        
        print(f"\n✅ 错误处理正常！")
        print(f"错误信息: {result['error']}")
    
    @pytest.mark.asyncio
    async def test_pipeline_status_tracking(self):
        """测试状态跟踪"""
        file_path = Path("tests/knowledge_base/fixtures/sample.pdf")
        brand_id = "test_brand_004"
        
        # 启动 Pipeline
        task_id = await self.pipeline.start_async(
            file_path=file_path,
            brand_id=brand_id
        )
        
        # 等待一段时间
        await asyncio.sleep(2)
        
        # 查询状态
        status = await self.pipeline.get_status(task_id)
        
        assert status["task_id"] == task_id
        assert status["status"] in ["processing", "completed", "failed"]
        
        print(f"\n✅ 状态跟踪正常！")
        print(f"任务 ID: {task_id}")
        print(f"当前状态: {status['status']}")

if __name__ == "__main__":
    pytest.main([__file__, "-v", "-s"])
