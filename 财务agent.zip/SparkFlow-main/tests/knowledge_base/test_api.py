"""测试知识库 API 端点"""
import asyncio
import pytest
from httpx import AsyncClient
from pathlib import Path

# 假设你的 FastAPI app 在这里
# from main import app

class TestKnowledgeBaseAPI:
    """API 端点测试"""
    
    @pytest.mark.asyncio
    async def test_create_knowledge_base(self):
        """测试创建知识库"""
        async with AsyncClient(base_url="http://localhost:8000") as client:
            # 准备测试数据
            files = {
                "file": open("tests/knowledge_base/fixtures/sample.pdf", "rb")
            }
            data = {
                "brand_id": "test_brand_001",
                "name": "测试品牌知识库"
            }
            
            # 发送请求
            response = await client.post(
                "/api/v1/knowledge-base/",
                files=files,
                data=data
            )
            
            # 验证响应
            assert response.status_code == 200
            result = response.json()
            assert result["kb_id"] is not None
            assert result["status"] == "processing"
            
            print(f"\n✅ 创建知识库成功！")
            print(f"知识库 ID: {result['kb_id']}")
    
    @pytest.mark.asyncio
    async def test_get_knowledge_base_status(self):
        """测试查询知识库状态"""
        async with AsyncClient(base_url="http://localhost:8000") as client:
            kb_id = "test_kb_001"
            
            response = await client.get(f"/api/v1/knowledge-base/{kb_id}/status")
            
            assert response.status_code == 200
            result = response.json()
            assert "status" in result
            assert result["status"] in ["processing", "ready", "failed"]
            
            print(f"\n✅ 查询状态成功！")
            print(f"状态: {result['status']}")
    
    @pytest.mark.asyncio
    async def test_search_knowledge_base(self):
        """测试知识库搜索"""
        async with AsyncClient(base_url="http://localhost:8000") as client:
            kb_id = "test_kb_001"
            query = "品牌定位"
            
            response = await client.post(
                f"/api/v1/knowledge-base/{kb_id}/search",
                json={"query": query, "top_k": 5}
            )
            
            assert response.status_code == 200
            result = response.json()
            assert "results" in result
            assert len(result["results"]) <= 5
            
            print(f"\n✅ 搜索成功！")
            print(f"返回结果数: {len(result['results'])}")
    
    @pytest.mark.asyncio
    async def test_delete_knowledge_base(self):
        """测试删除知识库"""
        async with AsyncClient(base_url="http://localhost:8000") as client:
            kb_id = "test_kb_001"
            
            response = await client.delete(f"/api/v1/knowledge-base/{kb_id}")
            
            assert response.status_code == 200
            result = response.json()
            assert result["success"] is True
            
            print(f"\n✅ 删除成功！")
    
    @pytest.mark.asyncio
    async def test_upload_invalid_file(self):
        """测试上传不支持的文件类型"""
        async with AsyncClient(base_url="http://localhost:8000") as client:
            files = {
                "file": ("test.mp4", b"fake video content", "video/mp4")
            }
            data = {
                "brand_id": "test_brand_001",
                "name": "测试"
            }
            
            response = await client.post(
                "/api/v1/knowledge-base/",
                files=files,
                data=data
            )
            
            # 应该返回 400 错误
            assert response.status_code == 400
            result = response.json()
            assert "error" in result
            
            print(f"\n✅ 错误处理正常！")
            print(f"错误信息: {result['error']}")

if __name__ == "__main__":
    pytest.main([__file__, "-v", "-s"])
