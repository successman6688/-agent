"""快速测试脚本 - 不依赖外部服务"""
import sys
from pathlib import Path

# 添加项目路径
sys.path.insert(0, str(Path(__file__).parent.parent.parent))

def test_imports():
    """测试模块导入"""
    print("\n=== 测试模块导入 ===")
    
    try:
        from pipline.models.knowledge_base import BrandKnowledgeBase
        print("✅ models.knowledge_base")
    except Exception as e:
        print(f"❌ models.knowledge_base: {e}")
    
    try:
        from pipline.services.knowledge_base.file_detector import FileDetector
        print("✅ services.file_detector")
    except Exception as e:
        print(f"❌ services.file_detector: {e}")
    
    try:
        from pipline.services.knowledge_base.text_extractor import TextExtractor
        print("✅ services.text_extractor")
    except Exception as e:
        print(f"❌ services.text_extractor: {e}")
    
    try:
        from pipline.services.knowledge_base.chunker import SemanticChunker
        print("✅ services.chunker")
    except Exception as e:
        print(f"❌ services.chunker: {e}")
    
    try:
        from pipline.services.knowledge_base.embedder import Embedder
        print("✅ services.embedder")
    except Exception as e:
        print(f"❌ services.embedder: {e}")
    
    try:
        from pipline.services.knowledge_base.vector_store import VectorStore
        print("✅ services.vector_store")
    except Exception as e:
        print(f"❌ services.vector_store: {e}")
    
    try:
        from pipline.services.knowledge_base.ai_parser import AIParser
        print("✅ services.ai_parser")
    except Exception as e:
        print(f"❌ services.ai_parser: {e}")
    
    try:
        from pipline.services.knowledge_base.pipline import KnowledgeBasePipeline
        print("✅ services.pipeline")
    except Exception as e:
        print(f"❌ services.pipeline: {e}")
    
    try:
        from pipline.tasks.knowledge_base_tasks import process_knowledge_base_task
        print("✅ tasks.knowledge_base_tasks")
    except Exception as e:
        print(f"❌ tasks.knowledge_base_tasks: {e}")
    
    try:
        from pipline.db.knowledge_base_repository import KnowledgeBaseRepository
        print("✅ db.knowledge_base_repository")
    except Exception as e:
        print(f"❌ db.knowledge_base_repository: {e}")

def test_basic_functionality():
    """测试基本功能（不需要外部服务）"""
    print("\n=== 测试基本功能 ===")
    
    # 测试 Chunker
    try:
        from pipline.services.knowledge_base.chunker import SemanticChunker
        chunker = SemanticChunker(chunk_size=100, chunk_overlap=20)
        text = "这是测试文本。" * 50
        chunks = chunker.chunk(text)
        print(f"✅ Chunker: 生成 {len(chunks)} 个 chunks")
    except Exception as e:
        print(f"❌ Chunker: {e}")
    
    # 测试 FileDetector
    try:
        from pipline.services.knowledge_base.file_detector import FileDetector
        detector = FileDetector()
        # 测试支持的文件类型列表
        supported = detector.get_supported_types()
        print(f"✅ FileDetector: 支持 {len(supported)} 种文件类型")
    except Exception as e:
        print(f"❌ FileDetector: {e}")
    
    # 测试 Model
    try:
        from pipline.models.knowledge_base import BrandKnowledgeBase
        kb = BrandKnowledgeBase(
            brand_id="test_001",
            name="测试知识库",
            kb_status="processing"
        )
        print(f"✅ Model: 创建知识库对象 {kb.name}")
    except Exception as e:
        print(f"❌ Model: {e}")

def main():
    """主函数"""
    print("=" * 60)
    print("品牌知识库模块 - 快速测试")
    print("=" * 60)
    
    test_imports()
    test_basic_functionality()
    
    print("\n" + "=" * 60)
    print("快速测试完成！")
    print("=" * 60)
    print("\n提示：")
    print("1. 如果导入失败，说明模块代码还未实现")
    print("2. 完整测试需要运行: python tests/knowledge_base/run_tests.py")
    print("3. 单元测试需要运行: pytest tests/knowledge_base/ -v")

if __name__ == "__main__":
    main()
