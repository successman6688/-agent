# 品牌知识库模块测试

## 测试结构

```
tests/knowledge_base/
├── test_file_detector.py      # 单元测试：文件类型检测
├── test_text_extractor.py     # 单元测试：文本提取
├── test_chunker.py            # 单元测试：语义分块
├── test_pipeline.py           # 集成测试：完整 Pipeline
├── test_api.py                # 集成测试：API 端点
├── run_tests.py               # 手动测试脚本
└── fixtures/                  # 测试数据
    ├── sample.pdf
    ├── sample.docx
    ├── sample.txt
    ├── corrupted.pdf
    └── empty.txt
```

## 运行测试

### 1. 单元测试（推荐）

```bash
# 运行所有单元测试
pytest tests/knowledge_base/ -v

# 运行特定测试文件
pytest tests/knowledge_base/test_file_detector.py -v

# 运行特定测试方法
pytest tests/knowledge_base/test_chunker.py::TestSemanticChunker::test_chunk_long_text -v
```

### 2. 集成测试

```bash
# 运行 Pipeline 集成测试
pytest tests/knowledge_base/test_pipeline.py -v -s

# 运行 API 集成测试（需要先启动服务）
pytest tests/knowledge_base/test_api.py -v -s
```

### 3. 手动测试

```bash
# 运行手动测试脚本
python tests/knowledge_base/run_tests.py
```

## 测试前准备

### 1. 安装依赖

```bash
pip install pytest pytest-asyncio httpx
```

### 2. 准备测试数据

在 `tests/knowledge_base/fixtures/` 目录下放置测试文件：
- `sample.pdf` - 正常的 PDF 文件
- `sample.docx` - 正常的 Word 文件
- `sample.txt` - 正常的文本文件
- `corrupted.pdf` - 损坏的 PDF 文件（用于测试错误处理）
- `empty.txt` - 空文本文件

### 3. 配置环境变量

```bash
# .env 文件
OPENAI_API_KEY=your_api_key
WEAVIATE_URL=http://localhost:8080
REDIS_URL=redis://localhost:6379
CELERY_BROKER_URL=redis://localhost:6379/0
```

### 4. 启动依赖服务

```bash
# 启动 Redis
docker run -d -p 6379:6379 redis:latest

# 启动 Weaviate
docker run -d -p 8080:8080 semitechnologies/weaviate:latest

# 启动 Celery Worker
celery -A app.tasks worker --loglevel=info
```

## 测试覆盖率

### 单元测试覆盖

- ✅ 文件类型检测（PDF/DOCX/TXT/PPTX/XLSX）
- ✅ 文本提取（各种格式）
- ✅ 文本清洗
- ✅ 语义分块（长文本、短文本、重叠）
- ✅ 向量化
- ✅ 向量库操作
- ✅ AI 解析

### 集成测试覆盖

- ✅ 完整 Pipeline 流程
- ✅ 批量文件处理
- ✅ 错误处理
- ✅ 状态跟踪
- ✅ API 端点（CRUD 操作）

### 性能测试

```bash
# 测试大文件处理
pytest tests/knowledge_base/test_pipeline.py::test_large_file_processing -v

# 测试并发处理
pytest tests/knowledge_base/test_pipeline.py::test_concurrent_processing -v
```

## 常见问题

### Q1: 测试文件找不到？
A: 确保在 `fixtures/` 目录下放置了测试文件。

### Q2: Celery 任务执行失败？
A: 检查 Redis 是否启动，Celery Worker 是否运行。

### Q3: 向量化失败？
A: 检查 OpenAI API Key 是否配置正确。

### Q4: Weaviate 连接失败？
A: 确保 Weaviate 服务已启动，端口 8080 可访问。

## 测试报告

运行测试后会生成覆盖率报告：

```bash
# 生成覆盖率报告
pytest tests/knowledge_base/ --cov=pipline.services.knowledge_base --cov-report=html

# 查看报告
open htmlcov/index.html
```
