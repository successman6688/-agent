"""测试语义分块器"""
import pytest
from pipline.services.knowledge_base.chunker import SemanticChunker

class TestSemanticChunker:
    """语义分块器测试"""
    
    def setup_method(self):
        """每个测试前执行"""
        self.chunker = SemanticChunker(
            chunk_size=512,
            chunk_overlap=64
        )
    
    def test_chunk_long_text(self):
        """测试长文本分块"""
        text = "这是一段测试文本。" * 200  # 生成长文本
        
        chunks = self.chunker.chunk(text)
        
        assert len(chunks) > 1
        assert all(len(chunk["text"]) <= 512 for chunk in chunks)
        assert all("chunk_id" in chunk for chunk in chunks)
        assert all("start_pos" in chunk for chunk in chunks)
    
    def test_chunk_short_text(self):
        """测试短文本（不需要分块）"""
        text = "这是一段很短的文本。"
        
        chunks = self.chunker.chunk(text)
        
        assert len(chunks) == 1
        assert chunks[0]["text"] == text
    
    def test_chunk_with_metadata(self):
        """测试带元数据的分块"""
        text = "测试文本" * 100
        metadata = {
            "file_name": "test.pdf",
            "brand_id": "brand_123",
            "page": 1
        }
        
        chunks = self.chunker.chunk(text, metadata=metadata)
        
        assert all(chunk["metadata"]["file_name"] == "test.pdf" for chunk in chunks)
        assert all(chunk["metadata"]["brand_id"] == "brand_123" for chunk in chunks)
    
    def test_merge_short_chunks(self):
        """测试合并过短的 chunk"""
        text = "短句1。\n短句2。\n短句3。"
        
        chunks = self.chunker.chunk(text, min_chunk_size=50)
        
        # 应该合并成一个 chunk
        assert len(chunks) == 1
    
    def test_chunk_overlap(self):
        """测试 chunk 重叠"""
        text = "ABCDEFGHIJKLMNOPQRSTUVWXYZ" * 50
        
        chunks = self.chunker.chunk(text)
        
        # 检查相邻 chunk 是否有重叠
        if len(chunks) > 1:
            overlap = chunks[0]["text"][-64:] == chunks[1]["text"][:64]
            assert overlap or len(chunks[0]["text"]) < 64

if __name__ == "__main__":
    pytest.main([__file__, "-v"])
