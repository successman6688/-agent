"""运行知识库模块测试"""
import asyncio
import sys
from pathlib import Path

# 添加项目路径
sys.path.insert(0, str(Path(__file__).parent.parent.parent))

async def run_manual_test():
    """手动测试完整流程"""
    print("=" * 60)
    print("品牌知识库 Pipeline 手动测试")
    print("=" * 60)
    
    from pipline.services.knowledge_base.pipline import KnowledgeBasePipeline
    
    # 1. 初始化 Pipeline
    print("\n[1/5] 初始化 Pipeline...")
    pipeline = KnowledgeBasePipeline()
    print("✅ Pipeline 初始化完成")
    
    # 2. 测试文件检测
    print("\n[2/5] 测试文件类型检测...")
    test_file = Path("tests/knowledge_base/fixtures/sample.pdf")
    if test_file.exists():
        from pipline.services.knowledge_base.file_detector import FileDetector
        detector = FileDetector()
        result = detector.detect(test_file)
        print(f"✅ 文件类型: {result.get('file_type')}")
        print(f"   MIME 类型: {result.get('mime_type')}")
    else:
        print("⚠️  测试文件不存在，跳过")
    
    # 3. 测试文本提取
    print("\n[3/5] 测试文本提取...")
    if test_file.exists():
        from pipline.services.knowledge_base.text_extractor import TextExtractor
        extractor = TextExtractor()
        result = extractor.extract(test_file, file_type="pdf")
        if result.get("success"):
            text_preview = result["text"][:200]
            print(f"✅ 提取成功，文本长度: {len(result['text'])}")
            print(f"   预览: {text_preview}...")
        else:
            print(f"❌ 提取失败: {result.get('error')}")
    
    # 4. 测试语义分块
    print("\n[4/5] 测试语义分块...")
    from pipline.services.knowledge_base.chunker import SemanticChunker
    chunker = SemanticChunker(chunk_size=512, chunk_overlap=64)
    test_text = "这是一段测试文本。" * 100
    chunks = chunker.chunk(test_text)
    print(f"✅ 分块完成，生成 {len(chunks)} 个 chunks")
    
    # 5. 测试完整 Pipeline（如果文件存在）
    print("\n[5/5] 测试完整 Pipeline...")
    if test_file.exists():
        try:
            result = await pipeline.process_file(
                file_path=test_file,
                brand_id="test_brand_manual"
            )
            print(f"✅ Pipeline 执行完成")
            print(f"   状态: {result.get('status')}")
            print(f"   知识库 ID: {result.get('kb_id')}")
            print(f"   Chunks 数量: {result.get('chunks_count')}")
        except Exception as e:
            print(f"❌ Pipeline 执行失败: {e}")
            import traceback
            traceback.print_exc()
    else:
        print("⚠️  测试文件不存在，跳过完整 Pipeline 测试")
    
    print("\n" + "=" * 60)
    print("测试完成！")
    print("=" * 60)

if __name__ == "__main__":
    asyncio.run(run_manual_test())
