"""生成测试文件"""
from pathlib import Path
from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import letter
from docx import Document

def generate_sample_pdf():
    """生成示例 PDF"""
    output_path = Path(__file__).parent / "sample.pdf"
    
    c = canvas.Canvas(str(output_path), pagesize=letter)
    
    # 第一页
    c.setFont("Helvetica", 16)
    c.drawString(100, 750, "Brand Knowledge Base - Test Document")
    
    c.setFont("Helvetica", 12)
    y = 700
    content = [
        "Brand Positioning: Premium Technology Products",
        "",
        "Target Audience: Urban professionals aged 25-40",
        "",
        "Core Values:",
        "- Innovation",
        "- Quality",
        "- Service Excellence",
        "",
        "Product Features:",
        "1. Latest technology integration",
        "2. Refined design aesthetics",
        "3. Superior user experience",
        "",
        "Brand Story:",
        "We are committed to providing the best products and services",
        "to our customers. Our journey began with a simple idea:",
        "make technology accessible and delightful for everyone.",
    ]
    
    for line in content:
        c.drawString(100, y, line)
        y -= 20
    
    c.showPage()
    c.save()
    
    print(f"✅ 生成 PDF: {output_path}")

def generate_sample_docx():
    """生成示例 DOCX"""
    output_path = Path(__file__).parent / "sample.docx"
    
    doc = Document()
    doc.add_heading('Brand Knowledge Base - Test Document', 0)
    
    doc.add_heading('Brand Positioning', level=1)
    doc.add_paragraph('Premium Technology Products')
    
    doc.add_heading('Target Audience', level=1)
    doc.add_paragraph('Urban professionals aged 25-40')
    
    doc.add_heading('Core Values', level=1)
    doc.add_paragraph('Innovation', style='List Bullet')
    doc.add_paragraph('Quality', style='List Bullet')
    doc.add_paragraph('Service Excellence', style='List Bullet')
    
    doc.add_heading('Product Features', level=1)
    doc.add_paragraph('Latest technology integration', style='List Number')
    doc.add_paragraph('Refined design aesthetics', style='List Number')
    doc.add_paragraph('Superior user experience', style='List Number')
    
    doc.add_heading('Brand Story', level=1)
    doc.add_paragraph(
        'We are committed to providing the best products and services '
        'to our customers. Our journey began with a simple idea: '
        'make technology accessible and delightful for everyone.'
    )
    
    doc.save(str(output_path))
    
    print(f"✅ 生成 DOCX: {output_path}")

def generate_sample_txt():
    """生成示例 TXT"""
    output_path = Path(__file__).parent / "sample.txt"
    
    content = """Brand Knowledge Base - Test Document

Brand Positioning: Premium Technology Products

Target Audience: Urban professionals aged 25-40

Core Values:
- Innovation
- Quality
- Service Excellence

Product Features:
1. Latest technology integration
2. Refined design aesthetics
3. Superior user experience

Brand Story:
We are committed to providing the best products and services to our customers.
Our journey began with a simple idea: make technology accessible and delightful
for everyone.

Additional Information:
This is a test document used for validating the knowledge base pipeline.
It contains typical brand information that would be processed by the system.
"""
    
    output_path.write_text(content, encoding='utf-8')
    
    print(f"✅ 生成 TXT: {output_path}")

def generate_empty_txt():
    """生成空 TXT"""
    output_path = Path(__file__).parent / "empty.txt"
    output_path.write_text("", encoding='utf-8')
    print(f"✅ 生成空文件: {output_path}")

def generate_corrupted_pdf():
    """生成损坏的 PDF"""
    output_path = Path(__file__).parent / "corrupted.pdf"
    output_path.write_text("This is not a valid PDF file", encoding='utf-8')
    print(f"✅ 生成损坏的 PDF: {output_path}")

def main():
    """主函数"""
    print("=" * 60)
    print("生成测试文件")
    print("=" * 60)
    
    try:
        generate_sample_pdf()
    except Exception as e:
        print(f"❌ 生成 PDF 失败: {e}")
        print("   提示: 需要安装 reportlab: pip install reportlab")
    
    try:
        generate_sample_docx()
    except Exception as e:
        print(f"❌ 生成 DOCX 失败: {e}")
        print("   提示: 需要安装 python-docx: pip install python-docx")
    
    try:
        generate_sample_txt()
        generate_empty_txt()
        generate_corrupted_pdf()
    except Exception as e:
        print(f"❌ 生成文本文件失败: {e}")
    
    print("\n" + "=" * 60)
    print("完成！")
    print("=" * 60)

if __name__ == "__main__":
    main()
