"""测试文件类型检测器"""
import pytest
from pathlib import Path
from pipline.services.knowledge_base.file_detector import FileDetector

class TestFileDetector:
    """文件检测器测试"""
    
    def setup_method(self):
        """每个测试前执行"""
        self.detector = FileDetector()
    
    def test_detect_pdf(self):
        """测试 PDF 检测"""
        file_path = Path("tests/knowledge_base/fixtures/sample.pdf")
        result = self.detector.detect(file_path)
        
        assert result["file_type"] == "pdf"
        assert result["mime_type"] == "application/pdf"
        assert result["is_supported"] is True
    
    def test_detect_docx(self):
        """测试 DOCX 检测"""
        file_path = Path("tests/knowledge_base/fixtures/sample.docx")
        result = self.detector.detect(file_path)
        
        assert result["file_type"] == "docx"
        assert result["is_supported"] is True
    
    def test_detect_txt(self):
        """测试 TXT 检测"""
        file_path = Path("tests/knowledge_base/fixtures/sample.txt")
        result = self.detector.detect(file_path)
        
        assert result["file_type"] == "txt"
        assert result["is_supported"] is True
    
    def test_unsupported_file(self):
        """测试不支持的文件类型"""
        file_path = Path("tests/knowledge_base/fixtures/sample.mp4")
        result = self.detector.detect(file_path)
        
        assert result["is_supported"] is False
        assert "error" in result
    
    def test_file_not_exist(self):
        """测试文件不存在"""
        file_path = Path("tests/knowledge_base/fixtures/not_exist.pdf")
        
        with pytest.raises(FileNotFoundError):
            self.detector.detect(file_path)

if __name__ == "__main__":
    pytest.main([__file__, "-v"])
