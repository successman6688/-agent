"""演示AI系统自我进化"""

import asyncio
from app.services.intelligence.evolution_engine import (
    get_evolution_engine,
    FeedbackType
)
from app.models.intelligence import PromptTemplate


async def demo_evolution_system():
    """演示进化系统的工作流程"""

    print("=" * 60)
    print("🧠 AI系统自我进化演示")
    print("=" * 60)
    print()

    engine = get_evolution_engine()

    # ==================== 第1步：模拟多个提示词版本 ====================
    print("📝 步骤1：创建多个提示词版本（A/B测试）")
    print("-" * 60)

    prompt_v1 = PromptTemplate(
        id="prompt_v1",
        name="财经分析v1.0（旧版）",
        description="第一版财经分析提示词",
        strategy_type="finance",
        system_prompt="你是一个金融分析师",
        user_prompt_template="分析这个：{content}",
        output_schema={},
        variables=[],
        version="1.0"
    )

    prompt_v2 = PromptTemplate(
        id="prompt_v2",
        name="财经分析v2.0（改进版）",
        description="第二版财经分析提示词，增加了专业性",
        strategy_type="finance",
        system_prompt="你是一个专业的金融情报分析师",
        user_prompt_template="请提供投资建议：{content}",
        output_schema={},
        variables=[],
        version="2.0"
    )

    prompt_v3 = PromptTemplate(
        id="prompt_v3",
        name="财经分析v3.0（实验版）",
        description="第三版财经分析提示词，强调可操作性",
        strategy_type="finance",
        system_prompt="你是一个专业的金融情报分析师，专注于可操作建议",
        user_prompt_template="请提供具体可执行的投资建议：{content}",
        output_schema={},
        variables=[],
        version="3.0"
    )

    candidates = [prompt_v1, prompt_v2, prompt_v3]
    print(f"创建了 {len(candidates)} 个提示词版本:")
    for p in candidates:
        print(f"  - {p.name} (v{p.version})")
    print()

    # ==================== 第2步：Thompson Sampling选择 ====================
    print("🎲 步骤2：使用Thompson Sampling算法选择提示词")
    print("-" * 60)

    # 模拟初始数据
    engine.prompt_stats["prompt_v1"] = {
        "success_count": 80,
        "failure_count": 20,
        "total_score": 350,
        "count": 100,
        "last_updated": None
    }
    engine.prompt_stats["prompt_v2"] = {
        "success_count": 90,
        "failure_count": 10,
        "total_score": 420,
        "count": 100,
        "last_updated": None
    }
    engine.prompt_stats["prompt_v3"] = {
        "success_count": 5,
        "failure_count": 0,
        "total_score": 25,
        "count": 5,
        "last_updated": None
    }

    print("当前性能数据:")
    for pid, stats in engine.prompt_stats.items():
        if stats["count"] > 0:
            avg = stats["total_score"] / stats["count"]
            success_rate = stats["success_count"] / stats["count"]
            print(f"  {pid}: 平均分={avg:.2f}, 成功率={success_rate:.2%}, "
                  f"样本数={stats['count']}")
    print()

    # 执行10次选择，看分布
    print("执行10次Thompson Sampling:")
    selections = {}
    for i in range(10):
        selected = engine.select_prompt_thompson_sampling(candidates)
        selections[selected.id] = selections.get(selected.id, 0) + 1
        print(f"  第{i+1}次: {selected.name}")

    print("\n选择分布:")
    for pid, count in selections.items():
        print(f"  {pid}: {count} 次 ({count/10:.0%})")
    print()

    # ==================== 第3步：收集反馈 ====================
    print("📊 步骤3：收集用户反馈（多层反馈循环）")
    print("-" * 60)

    # 模拟用户行为
    await engine.collect_feedback(
        item_id="item_001",
        prompt_id="prompt_v2",
        feedback_type=FeedbackType.EXPLICIT_RATING,
        value=5,  # 5星好评
        user_id="user_123"
    )
    print("✅ 收集反馈: 用户user_123 给 prompt_v2 评分 ⭐⭐⭐⭐⭐")

    await engine.collect_feedback(
        item_id="item_002",
        prompt_id="prompt_v2",
        feedback_type=FeedbackType.IMPLICIT_ACTION,
        value=True,  # 用户采纳了行动建议
        user_id="user_456"
    )
    print("✅ 收集反馈: 用户user_456 采纳了 prompt_v2 的行动建议")

    await engine.collect_feedback(
        item_id="item_003",
        prompt_id="prompt_v2",
        feedback_type=FeedbackType.IMPLICIT_CLICK,
        value=True,
        user_id="user_789"
    )
    print("✅ 收集反馈: 用户user_789 点击查看详情")

    await engine.collect_feedback(
        item_id="item_004",
        prompt_id="prompt_v1",
        feedback_type=FeedbackType.EXPLICIT_RATING,
        value=2,  # 2星差评
        user_id="user_abc"
    )
    print("❌ 收集反馈: 用户user_abc 给 prompt_v1 评分 ⭐⭐")

    # 处理反馈
    await engine._process_feedback_batch()
    print()

    # ==================== 第4步：更新后的性能 ====================
    print("📈 步骤4：更新后的性能数据")
    print("-" * 60)

    for pid, stats in engine.prompt_stats.items():
        if stats["count"] > 0:
            avg = stats["total_score"] / stats["count"]
            success_rate = stats["success_count"] / stats["count"]
            print(f"  {pid}:")
            print(f"    平均分: {avg:.2f}/5.0")
            print(f"    成功率: {success_rate:.2%}")
            print(f"    总样本: {stats['count']}")
    print()

    # ==================== 第5步：Top提示词 ====================
    print("🏆 步骤5：表现最好的提示词")
    print("-" * 60)

    top_prompts = engine.get_top_prompts(top_n=3)
    for i, (pid, score) in enumerate(top_prompts, 1):
        print(f"  #{i} {pid}: {score:.2f} 分")
    print()

    # ==================== 第6步：自动评估 ====================
    print("🤖 步骤6：自动评估输出质量")
    print("-" * 60)

    analysis_result_good = {
        "core_conclusion": "建议买入黄金，目标价2050美元",
        "priority_actions": [
            "在2000美元附近买入",
            "止损设在1980美元"
        ],
        "key_evidence": [
            {"fact": "突破2000美元阻力位", "impact": "确立上涨趋势"}
        ],
        "overall_sentiment": "bullish"
    }

    analysis_result_bad = {
        "core_conclusion": "黄金价格有所波动",
        "priority_actions": [],
        "key_evidence": [],
        "overall_sentiment": "neutral"
    }

    score_good = await engine.auto_evaluate(None, analysis_result_good)
    score_bad = await engine.auto_evaluate(None, analysis_result_bad)

    print(f"优秀分析: {score_good:.1f}/5.0 分")
    print(f"  - ✅ 有核心结论")
    print(f"  - ✅ 有可操作建议")
    print(f"  - ✅ 有证据支撑")
    print(f"  - ✅ 情感倾向明确")
    print()

    print(f"较差分析: {score_bad:.1f}/5.0 分")
    print(f"  - ❌ 缺乏可操作建议")
    print(f"  - ❌ 缺乏证据支撑")
    print()

    # ==================== 总结 ====================
    print("=" * 60)
    print("🎯 总结：AI系统如何自我进化")
    print("=" * 60)
    print("""
1. 🔄 **反馈循环**:
   - 收集用户反馈（评分、点击、采纳行动等）
   - 自动评估输出质量
   - 定期批量处理

2. 🎲 **智能A/B测试**:
   - Thompson Sampling算法自动选择最佳版本
   - 平衡探索（尝试新版本）和利用（使用好版本）
   - 随着数据积累，自动收敛到最优版本

3. 📊 **性能追踪**:
   - 加权评分（不同反馈类型有不同权重）
   - 成功率统计
   - 实时性能报告

4. 🚨 **异常检测**:
   - 监控性能下降
   - 自动回滚到稳定版本
   - 保障系统稳定性

5. 🧬 **自动演化**:
   - 基于性能数据生成改进版本
   - 自动测试新版本
   - 持续迭代优化

这样的系统可以：
✅ 自动发现最好的提示词
✅ 持续优化输出质量
✅ 适应不同的用户偏好
✅ 在遇到问题时自动恢复
    """)


if __name__ == "__main__":
    asyncio.run(demo_evolution_system())
