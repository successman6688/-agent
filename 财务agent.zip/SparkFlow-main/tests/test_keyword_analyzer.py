"""测试关键词分析器"""
import asyncio
from app.services.intelligence.keyword_analyzer import get_keyword_analyzer

async def test_keyword_analyzer():
    """测试关键词分析"""
    analyzer = get_keyword_analyzer()

    print("=== 测试 AI 关键词分析 ===\n")
    print("输入: 黄金投资，黄金价格\n")

    result = await analyzer.analyze_keywords(
        user_input="黄金投资，黄金价格",
        language="zh"
    )

    print("\n=== 分析结果 ===\n")
    print(f"🎯 核心关键词: {result.get('primary_keywords', [])}")
    print(f"🔍 扩展关键词: {result.get('expanded_keywords', [])}")
    print(f"📌 主题名称: {result.get('topic_name', '')}")
    print(f"📝 主题描述: {result.get('topic_description', '')}")
    print(f"⏰ 更新频率: {result.get('schedule', '')}")
    print(f"📂 分类: {result.get('category', '')}")
    print(f"\n💡 AI洞察:")
    for i, insight in enumerate(result.get('insights', []), 1):
        print(f"   {i}. {insight}")
    print(f"\n🔍 搜索查询:")
    for query in result.get('search_queries', []):
        print(f"   - {query}")
    print(f"\n📡 推荐数据源:")
    for source in result.get('recommended_sources', []):
        print(f"   - {source}")
    print(f"\n📊 数据源建议: {result.get('data_sources_tips', '')}")
    print(f"\n⚠️  是否使用fallback: {result.get('fallback', False)}")

if __name__ == "__main__":
    asyncio.run(test_keyword_analyzer())
