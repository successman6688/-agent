// 测试前端解析WebSocket消息

const message = {
  "type": "task_update",
  "topic_id": "ea749704-8b9d-4418-a867-dc3d9b0d0a76",
  "task_id": "test-123",
  "status": "completed",
  "result": {
    "topic_id": "ea749704-8b9d-4418-a867-dc3d9b0d0a76",
    "status": "completed",
    "total_collected": 239,
    "new_items": 100,
    "duration_seconds": 45.6,
    "message": "Successfully collected 100 items"
  },
  "error": null
};

console.log("=== 测试消息解析 ===\n");
console.log("1. 完整消息:");
console.log(JSON.stringify(message, null, 2));

console.log("\n2. 访问 new_items:");
console.log("  message.result:", message.result);
console.log("  message.result.new_items:", message.result?.new_items);
console.log("  message.result['new_items']:", message.result['new_items']);

console.log("\n3. 前端代码逻辑:");
let newItems = 0;
if (message.result && typeof message.result === 'object') {
  newItems = message.result.new_items || message.result['new_items'] || 0;
}
console.log("  提取结果:", newItems);
