"""测试 Anthropic API 连接"""
import asyncio
import os
from dotenv import load_dotenv

# 加载环境变量
load_dotenv()

async def test_anthropic_api():
    """测试 Anthropic API 连接"""
    from langchain_anthropic import ChatAnthropic

    api_key = os.getenv("ANTHROPIC_API_KEY")
    api_base = os.getenv("ANTHROPIC_API_BASE")

    print(f"API Key: {api_key[:20]}...")
    print(f"API Base: {api_base}")

    # 测试不同的配置方式
    print("\n=== 测试 1: 使用 anthropic_api_url ===")
    try:
        llm = ChatAnthropic(
            model="claude-sonnet-4-20250514",
            anthropic_api_key=api_key,
            anthropic_api_url=api_base,
            temperature=0.3,
            max_tokens=100
        )
        response = await llm.ainvoke("Hello, please respond with 'OK'")
        print(f"✅ 成功！响应: {response.content}")
    except Exception as e:
        print(f"❌ 失败: {e}")

    print("\n=== 测试 2: 使用 base_url (如果支持) ===")
    try:
        llm = ChatAnthropic(
            model="claude-sonnet-4-20250514",
            anthropic_api_key=api_key,
            base_url=api_base,  # 尝试这个参数
            temperature=0.3,
            max_tokens=100
        )
        response = await llm.ainvoke("Hello, please respond with 'OK'")
        print(f"✅ 成功！响应: {response.content}")
    except Exception as e:
        print(f"❌ 失败: {e}")

    print("\n=== 测试 3: 直接使用 anthropic ===")
    try:
        from anthropic import AsyncAnthropic

        client = AsyncAnthropic(
            api_key=api_key,
            base_url=api_base
        )
        response = await client.messages.create(
            model="claude-sonnet-4-20250514",
            max_tokens=100,
            messages=[{"role": "user", "content": "Hello, please respond with 'OK'"}]
        )
        print(f"✅ 成功！响应: {response.content[0].text}")
    except Exception as e:
        print(f"❌ 失败: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    asyncio.run(test_anthropic_api())
