"""测试增强版AI分析器"""
import asyncio
import json
from app.services.intelligence.enhanced_analyzer import EnhancedAIAnalyzer
from app.models.intelligence import IntelligenceItem
from datetime import datetime

async def test_enhanced_analysis():
    """测试增强版分析器"""

    # 创建测试情报项
    item = IntelligenceItem(
        topic_id="test-topic-gold",
        title="现货黄金大涨！多家品牌酝酿新一轮涨价",
        source="搜狐财经",
        author="财经报道",
        published_at=datetime.now(),
        url="https://example.com/gold-surge",
        url_hash="abc123",
        content="""现货黄金价格近期突破每盎司2000美元大关，创下年内新高。
受此影响，周大福、周生生等知名金饰品牌正酝酿新一轮零售价格上调，
预计每克涨价幅度在10-20元之间。

市场分析认为，此轮金价上涨主要受以下因素推动：
1. 避险情绪升温：全球地缘政治紧张局势加剧
2. 美联储降息预期：市场预期年内降息概率上升
3. 央行购金热潮：多国央行持续增持黄金储备

技术面上，金价已突破关键阻力位，下一目标看2050美元。
投资者可关注黄金ETF、黄金股等相关投资标的。
""",
    )

    print("=== 测试增强版AI分析器 ===\n")

    analyzer = EnhancedAIAnalyzer()

    # 测试财经分析策略
    print("1. 测试财经分析策略")
    print("-" * 50)

    strategy = analyzer._detect_strategy(
        topic_name="黄金市场动态",
        keywords=["黄金", "金价", "投资"]
    )
    print(f"检测策略: {strategy['name']}")
    print(f"关注领域: {', '.join(strategy['focus_areas'])}")
    print()

    # 准备内容
    content = analyzer._prepare_content_with_context(item, strategy)
    print(f"分析内容:")
    print(content[:200] + "...")
    print()

    # 生成分析
    try:
        analysis = await analyzer._generate_enhanced_analysis(content, strategy, item)

        print("✅ 分析成功!")
        print()
        print("=== 分析结果 ===")
        print(json.dumps(analysis, ensure_ascii=False, indent=2))
        print()

        # 检查关键字段
        print("=== 字段检查 ===")
        print(f"✅ core_conclusion: {bool(analysis.get('core_conclusion'))}")
        print(f"✅ priority_actions: {len(analysis.get('priority_actions', []))} 条")
        print(f"✅ key_evidence: {len(analysis.get('key_evidence', []))} 条")
        print(f"✅ overall_sentiment: {analysis.get('overall_sentiment')}")
        print(f"✅ tags: {analysis.get('tags', [])}")
        print(f"✅ analysis_strategy: {analysis.get('analysis_strategy')}")

        # 显示核心结论
        print("\n=== 📌 核心结论 ===")
        print(analysis.get('core_conclusion', 'N/A'))

        # 显示优先行动
        if analysis.get('priority_actions'):
            print("\n=== ⚡ 立即行动 ===")
            for i, action in enumerate(analysis['priority_actions'], 1):
                print(f"{i}. {action}")

        # 显示关键证据
        if analysis.get('key_evidence'):
            print("\n=== 💡 关键证据 ===")
            for i, evidence in enumerate(analysis['key_evidence'], 1):
                print(f"\n证据 {i}:")
                print(f"  事实: {evidence.get('fact', 'N/A')}")
                print(f"  影响: {evidence.get('impact', 'N/A')}")

        # 检查数据点
        if analysis.get('data_points'):
            print("\n=== 量化数据 ===")
            for key, value in analysis['data_points'].items():
                if value:
                    print(f"  {key}: {value}")

    except Exception as e:
        print(f"❌ 分析失败: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    asyncio.run(test_enhanced_analysis())
