"""性能分析 - 找出超时原因"""
import asyncio
import time
from app.services.intelligence.storage import IntelligenceStorage

async def analyze_performance():
    """分析性能瓶颈"""

    storage = IntelligenceStorage()
    topic_id = "017d2dcb-72fd-4c60-abc2-4025dfe3f68e"

    print("=== 性能分析 ===\n")

    # 1. 测试加载主题
    print("1️⃣ 加载主题...")
    start = time.time()
    topic = await storage.load_topic(topic_id)
    elapsed = time.time() - start
    print(f"   耗时: {elapsed:.3f}秒")
    print(f"   主题: {topic.name if topic else 'None'}")

    # 2. 测试加载items（默认limit=100）
    print(f"\n2️⃣ 加载items (limit=100)...")
    start = time.time()
    items = await storage.load_items(topic_id, limit=100)
    elapsed = time.time() - start
    print(f"   耗时: {elapsed:.3f}秒")
    print(f"   返回: {len(items)} 条")

    # 3. 测试加载items（limit=50，前端默认）
    print(f"\n3️⃣ 加载items (limit=50)...")
    start = time.time()
    items = await storage.load_items(topic_id, limit=50)
    elapsed = time.time() - start
    print(f"   耗时: {elapsed:.3f}秒")
    print(f"   返回: {len(items)} 条")

    # 4. 测试文件读取
    print(f"\n4️⃣ 测试文件读取性能...")
    from pathlib import Path
    items_file = Path(f"/Users/houziqiang/workspace/marketing/SparkFlow/data/intelligence/items/{topic_id}/2026-02-27.jsonl")

    start = time.time()
    with open(items_file, 'r') as f:
        lines = f.readlines()
    elapsed = time.time() - start
    print(f"   读取文件 ({len(lines)} 行): {elapsed:.3f}秒")

    # 5. 测试JSON解析
    print(f"\n5️⃣ 测试JSON解析性能...")
    import json

    start = time.time()
    parsed_items = []
    for i, line in enumerate(lines[:50]):  # 只解析前50条
        data = json.loads(line)
        parsed_items.append(data)
    elapsed = time.time() - start
    print(f"   解析50条JSON: {elapsed:.3f}秒")

    # 6. 测试Pydantic模型创建
    print(f"\n6️⃣ 测试Pydantic模型创建...")
    from app.models.intelligence import IntelligenceItem

    start = time.time()
    model_items = []
    for data in parsed_items:
        item = IntelligenceItem(**data)
        model_items.append(item)
    elapsed = time.time() - start
    print(f"   创建50个模型: {elapsed:.3f}秒")

    # 7. 分析单条item大小
    print(f"\n7️⃣ 单条item分析...")
    if parsed_items:
        sample = parsed_items[0]
        json_str = json.dumps(sample)
        print(f"   JSON大小: {len(json_str)} bytes")
        print(f"   字段数: {len(sample.keys())}")

    # 8. 总结
    print(f"\n=== 性能总结 ===\n")
    print(f"✅ 如果单项操作 < 100ms，性能正常")
    print(f"⚠️  如果单项操作 > 500ms，需要优化")
    print(f"❌ 如果单项操作 > 1s，有严重性能问题")

if __name__ == "__main__":
    asyncio.run(analyze_performance())
