"""调试收集流程 - 找出为什么239条变成0条"""
import asyncio
from app.db.connection import get_db
from app.db.intelligence_repository import IntelligenceRepository
from app.services.intelligence.coordinator import IntelligenceCoordinator
from app.api.v1.endpoints.intelligence import db_to_pynamo_topic

async def debug_collection():
    """调试收集流程"""

    topic_id = "017d2dcb-72fd-4c60-abc2-4025dfe3f68e"

    async with get_db() as session:
        repo = IntelligenceRepository(session)

        # 加载主题
        db_topic = await repo.get_topic(topic_id)

        if not db_topic:
            print(f"❌ 主题不存在: {topic_id}")
            return

        # 转换为Pydantic模型
        topic = db_to_pynamo_topic(db_topic)

        print(f"=== 主题信息 ===\n")
        print(f"名称: {topic.name}")
        print(f"关键词: {topic.keywords}")
        print(f"min_relevance: {topic.config.min_relevance}")
        print(f"enable_ai_summary: {topic.config.enable_ai_summary}\n")

        # 获取协调器
        coordinator = IntelligenceCoordinator(session)

        print(f"=== 第1步：收集原始数据 ===\n")
        raw_items = await coordinator._fetch_all_sources(topic)
        print(f"✅ 收集到: {len(raw_items)} 条原始数据")

        if not raw_items:
            print("❌ 没有收集到任何数据")
            return

        # 显示前3条
        print(f"\n前3条原始数据:")
        for i, item in enumerate(raw_items[:3], 1):
            print(f"\n{i}. {item.title[:60]}...")
            print(f"   URL: {item.url[:60]}...")
            print(f"   来源: {item.source}")

        print(f"\n=== 第2步：去重（基于数据库） ===\n")
        unique_items = await coordinator._deduplicate_with_db(topic.id, raw_items)
        print(f"✅ 去重后: {len(unique_items)} 条")
        print(f"❌ 去重掉: {len(raw_items) - len(unique_items)} 条")

        print(f"\n=== 第3步：评分 ===\n")
        scored_items = await coordinator.scorer.score(
            unique_items,
            topic.keywords,
            topic.config
        )
        print(f"✅ 评分完成")

        # 显示分数分布
        print(f"\n分数分布:")
        high = len([i for i in scored_items if i.overall_score >= 0.7])
        medium = len([i for i in scored_items if 0.5 <= i.overall_score < 0.7])
        low = len([i for i in scored_items if i.overall_score < 0.5])
        print(f"  高分 (≥0.7): {high} 条")
        print(f"  中分 (0.5-0.7): {medium} 条")
        print(f"  低分 (<0.5): {low} 条")

        print(f"\n=== 第4步：过滤（min_relevance={topic.config.min_relevance}） ===\n")
        filtered_items = [
            item for item in scored_items
            if item.overall_score >= topic.config.min_relevance
        ]
        print(f"✅ 过滤后: {len(filtered_items)} 条")
        print(f"❌ 过滤掉: {len(scored_items) - len(filtered_items)} 条")

        # 显示前3条高分项
        if filtered_items:
            print(f"\n前3条高分情报:")
            for i, item in enumerate(sorted(filtered_items, key=lambda x: x.overall_score, reverse=True)[:3], 1):
                print(f"\n{i}. {item.title[:60]}...")
                print(f"   评分: {item.overall_score:.3f}")
                print(f"   来源: {item.source}")

if __name__ == "__main__":
    asyncio.run(debug_collection())
