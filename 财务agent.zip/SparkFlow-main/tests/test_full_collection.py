"""测试完整的情报收集流程"""
import asyncio
import json
from app.services.intelligence.coordinator import get_intelligence_coordinator
from app.services.intelligence.storage import IntelligenceStorage

async def test_full_collection():
    """测试完整收集流程"""

    topic_id = "6ea4730b-f5d8-46a1-8a24-1d4c51f77f45"

    # 加载主题
    storage = IntelligenceStorage()
    topic = await storage.load_topic(topic_id)

    if not topic:
        print(f"❌ 主题不存在: {topic_id}")
        return

    print(f"=== 主题信息 ===\n")
    print(f"名称: {topic.name}")
    print(f"关键词: {topic.keywords}")
    print(f"数据源: {len(topic.sources)} 个")
    print(f"配置: min_relevance={topic.config.min_relevance}")
    print(f"\n数据源详情:")
    for i, source in enumerate(topic.sources, 1):
        print(f"  {i}. {source.name}")
        print(f"     Query: {source.query}")
        print(f"     Enabled: {source.enabled}")

    # 执行收集
    print(f"\n=== 开始收集 ===\n")

    coordinator = get_intelligence_coordinator()
    response = await coordinator.collect_intelligence(topic, force_refresh=True)

    print(f"\n=== 收集结果 ===\n")
    print(f"状态: {response.status}")
    print(f"收集总数: {response.total_collected}")
    print(f"新增情报: {response.new_items}")
    print(f"耗时: {response.duration_seconds:.2f}s")
    print(f"消息: {response.message}")

    # 检查items文件
    print(f"\n=== 检查存储 ===\n")

    from pathlib import Path
    items_dir = Path("/Users/houziqiang/workspace/marketing/SparkFlow/data/intelligence/items")
    topic_items_dir = items_dir / topic_id

    if topic_items_dir.exists():
        files = list(topic_items_dir.glob("*.jsonl"))
        print(f"Items目录存在，包含 {len(files)} 个文件")

        # 读取今天的文件
        from datetime import datetime
        today = datetime.utcnow().strftime("%Y-%m-%d")
        today_file = topic_items_dir / f"{today}.jsonl"

        if today_file.exists():
            with open(today_file, 'r', encoding='utf-8') as f:
                items = [json.loads(line) for line in f]
            print(f"今天有 {len(items)} 条情报")

            if items:
                print(f"\n前3条情报:")
                for i, item in enumerate(items[:3], 1):
                    print(f"  {i}. {item.get('title', 'N/A')[:60]}...")
                    print(f"     评分: {item.get('overall_score', 'N/A')}")
        else:
            print(f"今天 ({today}) 的文件不存在")
    else:
        print(f"Items目录不存在: {topic_items_dir}")

    # 重新加载主题，查看更新后的统计
    print(f"\n=== 更新后的主题统计 ===\n")
    updated_topic = await storage.load_topic(topic_id)
    print(f"total_items: {updated_topic.total_items}")
    print(f"today_items: {updated_topic.today_items}")
    print(f"weekly_items: {updated_topic.weekly_items}")

if __name__ == "__main__":
    asyncio.run(test_full_collection())
