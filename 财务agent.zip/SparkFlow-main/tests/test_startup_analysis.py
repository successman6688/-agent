"""测试创业投资类AI分析"""
import asyncio
import json
from app.services.intelligence.enhanced_analyzer import EnhancedAIAnalyzer
from app.models.intelligence import IntelligenceItem
from datetime import datetime

async def test_startup_analysis():
    """测试创业投资类分析"""

    item = IntelligenceItem(
        topic_id="test-topic-startup",
        title="AI代码助手Codeflow完成A轮5000万美元融资，估值达3亿美元",
        source="36氪",
        author="创投快讯",
        published_at=datetime.now(),
        url="https://36kr.com/p/codeflow-series-a",
        url_hash="startup123",
        content="""AI代码助手Codeflow今日宣布完成5000万美元A轮融资，本轮融资由
红杉资本领投，经纬创投和天使轮投资方真格基金跟投。

Codeflow成立于2023年，主打"企业级AI编程助手"，核心产品特点：
- 支持私有化部署，保障代码安全
- 可学习企业内部代码库，提供定制化建议
- 支持主流编程语言和IDE

目前Codeflow已服务超过200家大中型企业客户，包括字节跳动、腾讯等
头部科技公司。ARR（年度经常性收入）已达2000万美元，是去年同期的10倍。

本轮融资将用于：
1. 扩大研发团队，提升模型能力
2. 拓展国际市场，特别是欧洲和东南亚
3. 构建企业级代码安全合规体系

CodeflowCEO张明表示："企业对AI编程助手的需求远超预期，我们正
在见证软件开发范式的根本变革。"
""",
    )

    print("=== 测试创业投资类AI分析 ===\n")

    analyzer = EnhancedAIAnalyzer()

    # 检测策略
    strategy = analyzer._detect_strategy(
        topic_name="AI创业投资",
        keywords=["创业", "融资", "AI", "投资"]
    )
    print(f"检测策略: {strategy['name']}\n")

    # 准备内容
    content = analyzer._prepare_content_with_context(item, strategy)

    # 生成分析
    try:
        analysis = await analyzer._generate_enhanced_analysis(content, strategy, item)

        print("✅ 分析成功!\n")

        # 核心结论
        print("=== 📌 核心结论 ===")
        print(analysis.get('core_conclusion', 'N/A'))
        print()

        # 立即行动
        if analysis.get('priority_actions'):
            print("=== ⚡ 投资人/创业者立即行动 ===")
            for i, action in enumerate(analysis['priority_actions'], 1):
                print(f"{i}. {action}")
            print()

        # 关键证据
        if analysis.get('key_evidence'):
            print("=== 💡 关键事实 ===")
            for i, evidence in enumerate(analysis['key_evidence'], 1):
                print(f"{i}. {evidence.get('fact', 'N/A')}")
                print(f"   → {evidence.get('impact', 'N/A')}")
            print()

        # 交易数据
        if analysis.get('deal_data'):
            print("=== 💰 融资详情 ===")
            deal = analysis['deal_data']
            print(f"  公司: {deal.get('company', 'N/A')}")
            print(f"  金额: {deal.get('funding_amount', 'N/A')}")
            print(f"  估值: {deal.get('valuation', 'N/A')}")
            print(f"  投资方: {deal.get('investors', 'N/A')}")
            print()

        print(f"情感倾向: {analysis.get('overall_sentiment')}")
        print(f"标签: {', '.join(analysis.get('tags', []))}")

    except Exception as e:
        print(f"❌ 分析失败: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    asyncio.run(test_startup_analysis())
