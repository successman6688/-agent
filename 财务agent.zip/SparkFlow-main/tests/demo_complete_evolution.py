"""AI系统自我进化 - 完整演示

演示整个自我进化系统的工作流程
"""

import asyncio
from app.services.intelligence.evolution_engine import (
    get_evolution_engine,
    FeedbackType
)


async def demo_complete_evolution():
    """完整演示自我进化系统"""

    print("=" * 80)
    print("🧠 AI系统自我进化 - 完整演示")
    print("=" * 80)
    print()

    engine = get_evolution_engine()

    # ==================== 场景1：多版本A/B测试 ====================
    print("📊 场景1：智能A/B测试 - 自动选择最佳版本")
    print("-" * 80)

    # 模拟3个提示词版本
    prompts = {
        "finance_v1": {"name": "财经分析v1.0", "strategy": "finance"},
        "finance_v2": {"name": "财经分析v2.0", "strategy": "finance"},
        "finance_v3": {"name": "财经分析v3.0（实验版）", "strategy": "finance"},
    }

    # 模拟性能数据
    print("\n当前各版本性能:")
    print("-" * 40)
    engine.prompt_stats["finance_v1"] = {
        "success_count": 80,
        "failure_count": 20,
        "total_score": 350,
        "count": 100,
        "last_updated": None
    }
    engine.prompt_stats["finance_v2"] = {
        "success_count": 90,
        "failure_count": 10,
        "total_score": 420,
        "count": 100,
        "last_updated": None
    }
    engine.prompt_stats["finance_v3"] = {
        "success_count": 5,
        "failure_count": 0,
        "total_score": 25,
        "count": 5,
        "last_updated": None
    }

    for pid, stats in engine.prompt_stats.items():
        avg = stats["total_score"] / stats["count"]
        success_rate = stats["success_count"] / stats["count"]
        print(f"{pid:12} | 平均分: {avg:.2f} | 成功率: {success_rate:.1%} | 样本: {stats['count']}")

    # Thompson Sampling选择
    print("\n🎲 Thompson Sampling 10次选择:")
    selections = {}
    for i in range(10):
        # 简化版选择（模拟）
        import random
        if random.random() < 0.3:
            selected = "finance_v3"  # 探索新版本
        elif random.random() < 0.7:
            selected = "finance_v2"  # 利用好版本
        else:
            selected = "finance_v1"
        selections[selected] = selections.get(selected, 0) + 1
        print(f"  第{i+1:2}次: {prompts[selected]['name']}")

    print("\n选择分布:")
    for pid, count in selections.items():
        print(f"  {prompts[pid]['name']}: {count} 次")

    # ==================== 场景2：多层反馈循环 ====================
    print("\n\n" + "=" * 80)
    print("🔄 场景2：多层反馈循环 - 收集不同类型的反馈")
    print("-" * 80)

    print("\n用户反馈收集:")
    print("-" * 40)

    # 不同类型的反馈
    feedbacks = [
        ("⭐ 明确评分", FeedbackType.EXPLICIT_RATING, 5, 5.0),
        ("👍 点赞", FeedbackType.EXPLICIT_THUMBS, True, 3.0),
        ("✓ 采纳行动", FeedbackType.IMPLICIT_ACTION, True, 2.0),
        ("👆 点击查看", FeedbackType.IMPLICIT_CLICK, True, 1.0),
        ("⏱️ 阅读时长", FeedbackType.IMPLICIT_READ_TIME, 45, 0.5),
    ]

    for name, feedback_type, value, weight in feedbacks:
        await engine.collect_feedback(
            item_id=f"item_{name}",
            prompt_id="finance_v2",
            feedback_type=feedback_type,
            value=value
        )
        print(f"  {name:15} (权重: {weight}): ✅")

    await engine._process_feedback_batch()
    print("\n✅ 反馈已处理并更新统计数据")

    # ==================== 场景3：异常检测与自动恢复 ====================
    print("\n\n" + "=" * 80)
    print("🚨 场景3：异常检测与自动恢复")
    print("-" * 80)

    print("\n检测异常性能...")

    # 模拟性能下降
    recent_performance = [
        0.85, 0.87, 0.84, 0.83, 0.50,  # 突然下降
        0.52, 0.51, 0.49, 0.48, 0.47
    ]

    is_anomaly = await engine.detect_anomaly(
        prompt_id="finance_v2",
        recent_performance=recent_performance
    )

    if is_anomaly:
        print("  ⚠️  检测到异常！成功率从85%下降到47%")
        print("  🔄 触发自动回滚...")
        print("  ✅ 已回滚到上一个稳定版本")
    else:
        print("  ✅ 性能正常")

    # ==================== 场景4：性能排行榜 ====================
    print("\n\n" + "=" * 80)
    print("🏆 场景4：性能排行榜")
    print("-" * 80)

    top_prompts = engine.get_top_prompts(top_n=5)
    print("\nTop 5 提示词:")
    print("-" * 40)

    for i, (pid, score) in enumerate(top_prompts, 1):
        stats = engine.get_performance_report(pid)
        if stats:
            status = "🥇" if i == 1 else "🥈" if i == 2 else "🥉" if i == 3 else "  "
            print(f"{status} {i}. {pid:20} | {score:.2f}分 | "
                  f"成功率: {stats['success_rate']:.1%} | "
                  f"样本: {stats['total_count']}")

    # ==================== 总结 ====================
    print("\n\n" + "=" * 80)
    print("🎯 自我进化系统核心能力总结")
    print("=" * 80)
    print("""
1. 🎲 智能A/B测试
   - Thompson Sampling自动选择最佳版本
   - 平衡探索（尝试新版本）和利用（使用好版本）
   - 随着数据积累，自动收敛到最优解

2. 🔄 多层反馈循环
   - 显式反馈：评分、点赞点踩（权重高）
   - 隐式反馈：点击、阅读时长、采纳行动（权重低）
   - 自动评估：AI自动评估输出质量
   - 批量处理：定期批量更新统计数据

3. 🚨 异常检测与恢复
   - 实时监控性能指标
   - 检测突然的性能下降
   - 自动回滚到稳定版本
   - 保障系统稳定性

4. 📊 性能追踪与排行
   - 实时统计成功率、评分
   - Top提示词排行
   - 多维度性能报告
   - 数据驱动优化

5. 🧬 自动演化
   - AI自动分析提示词问题
   - 自动生成改进版本
   - 评估新版本质量
   - 持续迭代优化

这样的系统可以：
✅ 自动发现最优策略（无需人工调参）
✅ 持续优化输出质量
✅ 适应不同的用户偏好
✅ 在遇到问题时自动恢复
✅ 随着使用越来越好

这就是真正的"自我进化"！🚀
    """)


if __name__ == "__main__":
    asyncio.run(demo_complete_evolution())
