"""测试list_topics性能"""
import asyncio
import time
from sqlalchemy.ext.asyncio import create_async_engine, AsyncSession
from sqlalchemy.orm import sessionmaker
from app.core.config import settings
from app.db.intelligence_repository import IntelligenceRepository

async def test_list_topics():
    """测试加载所有主题"""

    # 创建数据库连接（不创建表）
    database_url = settings.DATABASE_URL
    engine = create_async_engine(database_url, echo=False)
    async_session_maker = sessionmaker(
        engine,
        class_=AsyncSession,
        expire_on_commit=False,
        autocommit=False,
        autoflush=False,
    )

    print("=== 测试 list_topics() ===\n")

    async with async_session_maker() as session:
        repo = IntelligenceRepository(session)

        start = time.time()
        db_topics = await repo.list_topics()
        elapsed = time.time() - start

        print(f"✅ 加载完成")
        print(f"   主题数量: {len(db_topics)}")
        print(f"   总耗时: {elapsed:.3f}秒")
        print(f"   平均每个: {elapsed/len(db_topics)*1000:.1f}ms" if db_topics else "")

        for topic in db_topics:
            print(f"   - {topic.name}")

    await engine.dispose()

if __name__ == "__main__":
    asyncio.run(test_list_topics())
