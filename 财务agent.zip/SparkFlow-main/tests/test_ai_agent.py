"""测试 AI Agent 主题的数据收集"""
import asyncio
from app.services.intelligence.fetchers.google_news import GoogleNewsRSSFetcher
from app.models.intelligence import SourceConfig, IntelligenceTopic

async def test_ai_agent_topic():
    """测试 AI Agent 主题"""

    # 主题配置
    config = SourceConfig(
        type="rss",
        name="Google News",
        enabled=True,
        query='"AI agent" entrepreneurship market trends',
        params={
            "hl": "zh-CN",
            "gl": "CN",
            "ceid": "CN:zh"
        }
    )

    topic = IntelligenceTopic(
        name="AI Agent 创业与投资情报",
        keywords=["AI agent", "创业", "大模型应用"],
        sources=[config],
        schedule="daily"
    )

    fetcher = GoogleNewsRSSFetcher(config, topic)

    print("=== 测试 1: 英文查询 ===\n")
    print(f"Query: {config.query}")
    print(f"URL: {fetcher.url}\n")

    items1 = await fetcher.fetch()
    print(f"收集结果: {len(items1)} 条\n")

    if items1:
        print("前3条:")
        for i, item in enumerate(items1[:3], 1):
            print(f"{i}. {item.title[:80]}...")
        print()

    # 测试中文查询
    print("\n=== 测试 2: 中文查询 ===\n")

    config2 = SourceConfig(
        type="rss",
        name="Google News",
        enabled=True,
        query="AI agent 创业",
        params={
            "hl": "zh-CN",
            "gl": "CN",
            "ceid": "CN:zh"
        }
    )

    topic2 = IntelligenceTopic(
        name="AI Agent 创业与投资情报",
        keywords=["AI agent", "创业"],
        sources=[config2],
        schedule="daily"
    )

    fetcher2 = GoogleNewsRSSFetcher(config2, topic2)

    print(f"Query: {config2.query}")
    print(f"URL: {fetcher2.url}\n")

    items2 = await fetcher2.fetch()
    print(f"收集结果: {len(items2)} 条\n")

    if items2:
        print("前3条:")
        for i, item in enumerate(items2[:3], 1):
            print(f"{i}. {item.title[:80]}...")
    else:
        print("❌ 中文查询也没有结果")

    # 测试更简单的查询
    print("\n=== 测试 3: 简化查询 ===\n")

    config3 = SourceConfig(
        type="rss",
        name="Google News",
        enabled=True,
        query="AI",
        params={
            "hl": "en",
            "gl": "US",
            "ceid": "US:en"
        }
    )

    topic3 = IntelligenceTopic(
        name="Test",
        keywords=["AI"],
        sources=[config3],
        schedule="daily"
    )

    fetcher3 = GoogleNewsRSSFetcher(config3, topic3)

    print(f"Query: {config3.query}")
    print(f"URL: {fetcher3.url}\n")

    items3 = await fetcher3.fetch()
    print(f"收集结果: {len(items3)} 条\n")

    if items3:
        print("✅ Google News 工作正常")
        print("前3条:")
        for i, item in enumerate(items3[:3], 1):
            print(f"{i}. {item.title[:80]}...")

if __name__ == "__main__":
    asyncio.run(test_ai_agent_topic())
