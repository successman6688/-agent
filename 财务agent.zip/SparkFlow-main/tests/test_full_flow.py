"""测试完整收集流程（包括AI分析和保存）"""
import asyncio
from app.services.intelligence.coordinator import get_intelligence_coordinator
from app.services.intelligence.storage import IntelligenceStorage

async def test_full_flow():
    """测试完整流程"""

    topic_id = "017d2dcb-72fd-4c60-abc2-4025dfe3f68e"

    # 加载主题
    storage = IntelligenceStorage()
    topic = await storage.load_topic(topic_id)

    print(f"=== 完整收集流程测试 ===\n")
    print(f"主题: {topic.name}")
    print(f"关键词: {topic.keywords}")
    print(f"min_relevance: {topic.config.min_relevance}")
    print(f"enable_ai_summary: {topic.config.enable_ai_summary}\n")

    # 执行完整收集
    coordinator = get_intelligence_coordinator()

    print(f"开始收集...\n")
    response = await coordinator.collect_intelligence(topic, force_refresh=True)

    print(f"\n=== 收集响应 ===\n")
    print(f"状态: {response.status}")
    print(f"total_collected: {response.total_collected}")
    print(f"new_items: {response.new_items}")
    print(f"duration: {response.duration_seconds:.2f}s")
    print(f"message: {response.message}")

    # 检查文件
    print(f"\n=== 检查存储 ===\n")
    from pathlib import Path
    items_dir = Path("/Users/houziqiang/workspace/marketing/SparkFlow/data/intelligence/items")
    topic_items_dir = items_dir / topic_id

    if topic_items_dir.exists():
        files = list(topic_items_dir.glob("*.jsonl"))
        print(f"✅ Items目录存在，包含 {len(files)} 个文件")

        from datetime import datetime
        today = datetime.utcnow().strftime("%Y-%m-%d")
        today_file = topic_items_dir / f"{today}.jsonl"

        if today_file.exists():
            import json
            with open(today_file, 'r', encoding='utf-8') as f:
                items = [json.loads(line) for line in f]
            print(f"✅ 今天的文件存在，包含 {len(items)} 条情报")
        else:
            print(f"❌ 今天的文件不存在: {today_file}")
    else:
        print(f"❌ Items目录不存在: {topic_items_dir}")

    # 重新加载主题，查看统计
    print(f"\n=== 更新后的主题统计 ===\n")
    updated_topic = await storage.load_topic(topic_id)
    print(f"total_items: {updated_topic.total_items}")
    print(f"today_items: {updated_topic.today_items}")
    print(f"weekly_items: {updated_topic.weekly_items}")

if __name__ == "__main__":
    asyncio.run(test_full_flow())
