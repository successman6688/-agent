"""测试技术类AI分析"""
import asyncio
import json
from app.services.intelligence.enhanced_analyzer import EnhancedAIAnalyzer
from app.models.intelligence import IntelligenceItem
from datetime import datetime

async def test_tech_analysis():
    """测试技术类分析"""

    item = IntelligenceItem(
        topic_id="test-topic-tech",
        title="Claude 4发布：支持100万token上下文，实时语音交互",
        source="TechCrunch",
        author="AI News",
        published_at=datetime.now(),
        url="https://techcrunch.com/claude-4",
        url_hash="tech123",
        content="""Anthropic今日发布Claude 4模型，带来三大突破：

1. 超长上下文：支持100万token上下文窗口，相当于3本《哈利波特》小说
   的长度，可处理整个代码库或长篇研究报告。

2. 实时语音交互：新增流式语音模式，延迟低至300ms，支持自然对话中断
   和多轮对话。

3. 推理能力提升：在数学、编程等任务上比Claude 3提升40%，在GPQA Diamond
   基准测试中达到89.2%准确率。

API价格：输入$15/百万token，输出$75/百万token，与Claude 3持平。
现已在claude.ai和API开放使用。
""",
    )

    print("=== 测试技术类AI分析 ===\n")

    analyzer = EnhancedAIAnalyzer()

    # 检测策略
    strategy = analyzer._detect_strategy(
        topic_name="AI技术动态",
        keywords=["AI", "Claude", "大模型"]
    )
    print(f"检测策略: {strategy['name']}\n")

    # 准备内容
    content = analyzer._prepare_content_with_context(item, strategy)

    # 生成分析
    try:
        analysis = await analyzer._generate_enhanced_analysis(content, strategy, item)

        print("✅ 分析成功!\n")

        # 核心结论
        print("=== 📌 核心结论 ===")
        print(analysis.get('core_conclusion', 'N/A'))
        print()

        # 立即行动
        if analysis.get('priority_actions'):
            print("=== ⚡ 开发者/创业者立即行动 ===")
            for i, action in enumerate(analysis['priority_actions'], 1):
                print(f"{i}. {action}")
            print()

        # 关键证据
        if analysis.get('key_evidence'):
            print("=== 💡 关键技术事实 ===")
            for i, evidence in enumerate(analysis['key_evidence'], 1):
                print(f"{i}. {evidence.get('fact', 'N/A')}")
                print(f"   → {evidence.get('impact', 'N/A')}")
            print()

        # 技术数据
        if analysis.get('technical_data'):
            print("=== 📊 技术指标 ===")
            for key, value in analysis['technical_data'].items():
                if value:
                    print(f"  {key}: {value}")
            print()

        print(f"情感倾向: {analysis.get('overall_sentiment')}")
        print(f"标签: {', '.join(analysis.get('tags', []))}")

    except Exception as e:
        print(f"❌ 分析失败: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    asyncio.run(test_tech_analysis())
