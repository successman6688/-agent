"""测试 Google News fetcher"""
import asyncio
from app.services.intelligence.fetchers.google_news import GoogleNewsRSSFetcher
from app.models.intelligence import SourceConfig, IntelligenceTopic

async def test_google_news():
    """测试 Google News fetcher"""

    # 创建配置
    config = SourceConfig(
        type="rss",
        name="Google News",
        enabled=True,
        query="黄金 OR 金价",
        params={
            "hl": "zh-CN",
            "gl": "CN",
            "ceid": "CN:zh"
        }
    )

    # 创建主题
    topic = IntelligenceTopic(
        name="测试主题",
        keywords=["黄金", "金价"],
        sources=[config],
        schedule="daily"
    )

    fetcher = GoogleNewsRSSFetcher(config, topic)

    print("=== 测试 Google News Fetcher ===\n")
    print(f"Query: 黄金 OR 金价")
    print(f"URL: {fetcher.url}\n")

    items = await fetcher.fetch()

    print(f"\n收集结果: {len(items)} 条\n")

    for i, item in enumerate(items[:5], 1):
        print(f"{i}. {item.title[:60]}...")
        print(f"   URL: {item.url[:80]}...")
        print(f"   Published: {item.published_at}")
        print()

if __name__ == "__main__":
    asyncio.run(test_google_news())
