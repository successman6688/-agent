"""简单测试：模拟WebSocket消息发送"""
import asyncio
import json
from app.services.intelligence.storage import IntelligenceStorage
from app.models.intelligence import CollectionResponse

async def test_ws_message_simple():
    """简单测试WebSocket消息"""

    # 1. 创建一个 CollectionResponse 对象
    print("=== 创建 CollectionResponse ===\n")

    response = CollectionResponse(
        topic_id="test-id",
        status="completed",
        total_collected=239,
        new_items=100,
        duration_seconds=45.6,
        message="Successfully collected 100 items"
    )

    print(f"✅ 对象创建成功")
    print(f"  new_items: {response.new_items}")
    print(f"  类型: {type(response)}")

    # 2. 测试 model_dump()
    print(f"\n=== model_dump() ===\n")
    result_dict = response.model_dump()
    print(f"✅ model_dump() 成功")
    print(f"  result_dict['new_items']: {result_dict['new_items']}")
    print(f"  result_dict.get('new_items'): {result_dict.get('new_items')}")

    # 3. 模拟 WebSocket 消息
    print(f"\n=== 模拟 WebSocket 消息 ===\n")
    message = {
        "type": "task_update",
        "topic_id": "test-id",
        "task_id": "test-123",
        "status": "completed",
        "result": result_dict,
        "error": None
    }

    message_json = json.dumps(message, ensure_ascii=False)
    print(f"消息 JSON:")
    print(message_json[:500] + "..." if len(message_json) > 500 else message_json)

    # 4. 解析测试
    print(f"\n=== 前端解析测试 ===\n")
    parsed = json.loads(message_json)
    print(f"✅ JSON 解析成功")
    print(f"  parsed.result.new_items: {parsed['result']['new_items']}")
    print(f"  parsed.result?.new_items: {parsed['result'].get('new_items')}")

    # 5. 前端逻辑测试
    print(f"\n=== 前端代码逻辑 ===\n")
    message_obj = parsed  # 模拟 JSON.parse 后的对象
    newItems = 0
    if (message_obj.result and isinstance(message_obj.result, dict)):
        newItems = message_obj.result.get('new_items', 0)

    print(f"  提取的 newItems: {newItems}")

if __name__ == "__main__":
    asyncio.run(test_ws_message_simple())
