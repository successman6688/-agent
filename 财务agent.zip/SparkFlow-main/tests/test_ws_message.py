"""测试WebSocket消息格式"""
import json

# 模拟 CollectionResponse
class CollectionResponse:
    topic_id: str
    status: str
    total_collected: int
    new_items: int
    duration_seconds: float
    report_id: str = None
    message: str = None

    def __init__(self, **kwargs):
        self.topic_id = kwargs.get('topic_id')
        self.status = kwargs.get('status')
        self.total_collected = kwargs.get('total_collected', 0)
        self.new_items = kwargs.get('new_items', 0)
        self.duration_seconds = kwargs.get('duration_seconds', 0.0)
        self.report_id = kwargs.get('report_id')
        self.message = kwargs.get('message')

    def model_dump(self):
        """转换为字典"""
        return {
            'topic_id': self.topic_id,
            'status': self.status,
            'total_collected': self.total_collected,
            'new_items': self.new_items,
            'duration_seconds': self.duration_seconds,
            'report_id': self.report_id,
            'message': self.message
        }


# 测试
response = CollectionResponse(
    topic_id='test-id',
    status='completed',
    total_collected=100,
    new_items=50,
    duration_seconds=10.5,
    message='Success'
)

print("=== CollectionResponse ===")
print(f"new_items: {response.new_items}")
print(f"\n=== model_dump() ===")
result_dict = response.model_dump()
print(json.dumps(result_dict, indent=2, ensure_ascii=False))

print(f"\n=== 访问测试 ===")
print(f"result_dict['new_items']: {result_dict['new_items']}")
print(f"result_dict.get('new_items'): {result_dict.get('new_items')}")
