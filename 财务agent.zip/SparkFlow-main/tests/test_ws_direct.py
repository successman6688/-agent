"""直接测试WebSocket消息"""
import asyncio
import json
from app.services.intelligence.coordinator import get_intelligence_coordinator
from app.services.intelligence.storage import IntelligenceStorage
from app.services.intelligence.websocket import get_websocket_manager

async def test_websocket_message():
    """测试WebSocket消息内容"""

    topic_id = "ea749704-8b9d-4418-a867-dc3d9b0d0a76"

    storage = IntelligenceStorage()
    topic = await storage.load_topic(topic_id)

    if not topic:
        print("❌ 主题不存在")
        return

    print(f"=== 主题信息 ===\n")
    print(f"名称: {topic.name}")
    print(f"ID: {topic.id}")
    print(f"当前 total_items: {topic.total_items}\n")

    # 执行收集
    coordinator = get_intelligence_coordinator()

    print(f"=== 执行收集 ===\n")
    response = await coordinator.collect_intelligence(topic, force_refresh=True)

    print(f"=== 收集响应（CollectionResponse） ===\n")
    print(f"类型: {type(response)}")
    print(f"属性:")
    print(f"  - topic_id: {response.topic_id}")
    print(f"  - status: {response.status}")
    print(f"  - total_collected: {response.total_collected}")
    print(f"  - new_items: {response.new_items}")
    print(f"  - duration_seconds: {response.duration_seconds}")
    print(f"  - message: {response.message}\n")

    # 测试 model_dump
    print(f"=== model_dump() 结果 ===\n")
    if hasattr(response, 'model_dump'):
        result_dict = response.model_dump()
        print(f"✅ 有 model_dump() 方法")
        print(json.dumps(result_dict, indent=2, ensure_ascii=False))
        print(f"\n访问 new_items:")
        print(f"  result_dict['new_items'] = {result_dict['new_items']}")
        print(f"  result_dict.get('new_items') = {result_dict.get('new_items')}")
    else:
        print(f"❌ 没有 model_dump() 方法")
        print(f"   dir(response): {[x for x in dir(response) if not x.startswith('_')]}")

    # 模拟WebSocket消息
    print(f"\n=== 模拟 WebSocket 消息 ===\n")

    ws_manager = get_websocket_manager()

    # 模拟发送消息（不实际发送）
    message = {
        "type": "task_update",
        "topic_id": topic_id,
        "task_id": "test-task-id",
        "status": "completed",
        "result": response.model_dump() if hasattr(response, 'model_dump') else response,
        "error": None
    }

    print("WebSocket 消息内容:")
    print(json.dumps(message, indent=2, ensure_ascii=False))

    print(f"\n=== 验证 new_items 访问 ===\n")
    print(f"message.result: {message.result}")
    print(f"message.result['new_items']: {message.result['new_items']}")
    print(f"message.result?.new_items: {message.result.get('new_items') if isinstance(message.result, dict) else 'N/A'}")

if __name__ == "__main__":
    asyncio.run(test_websocket_message())
