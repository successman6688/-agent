"""测试主题实际使用的查询"""
import asyncio
from app.services.intelligence.fetchers.google_news import GoogleNewsRSSFetcher
from app.models.intelligence import SourceConfig, IntelligenceTopic

async def test_topic_query():
    """测试主题查询"""

    # 模拟主题配置
    config = SourceConfig(
        type="rss",
        name="Google News",
        enabled=True,
        query="(黄金 OR 金价) AND (投资 OR 走势 OR 分析)",  # 主题实际使用的查询
        params={
            "hl": "zh-CN",
            "gl": "CN",
            "ceid": "CN:zh"
        }
    )

    topic = IntelligenceTopic(
        name="测试",
        keywords=["黄金", "金价"],
        sources=[config],
        schedule="daily"
    )

    fetcher = GoogleNewsRSSFetcher(config, topic)

    print("=== 测试 1: 主题实际查询（复杂语法） ===\n")
    print(f"Query: {config.query}")
    print(f"URL: {fetcher.url}\n")

    items = await fetcher.fetch()
    print(f"收集结果: {len(items)} 条\n")

    print("\n=== 测试 2: 简化查询 ===\n")

    config2 = SourceConfig(
        type="rss",
        name="Google News",
        enabled=True,
        query="黄金 投资走势分析",  # 简化：空格分隔
        params={
            "hl": "zh-CN",
            "gl": "CN",
            "ceid": "CN:zh"
        }
    )

    topic2 = IntelligenceTopic(
        name="测试2",
        keywords=["黄金", "金价"],
        sources=[config2],
        schedule="daily"
    )

    fetcher2 = GoogleNewsRSSFetcher(config2, topic2)
    print(f"Query: {config2.query}")
    print(f"URL: {fetcher2.url}\n")

    items2 = await fetcher2.fetch()
    print(f"收集结果: {len(items2)} 条\n")

    print("\n=== 测试 3: 单个关键词 ===\n")

    config3 = SourceConfig(
        type="rss",
        name="Google News",
        enabled=True,
        query="黄金投资",  # 最简单
        params={
            "hl": "zh-CN",
            "gl": "CN",
            "ceid": "CN:zh"
        }
    )

    topic3 = IntelligenceTopic(
        name="测试3",
        keywords=["黄金"],
        sources=[config3],
        schedule="daily"
    )

    fetcher3 = GoogleNewsRSSFetcher(config3, topic3)
    print(f"Query: {config3.query}")
    print(f"URL: {fetcher3.url}\n")

    items3 = await fetcher3.fetch()
    print(f"收集结果: {len(items3)} 条\n")

if __name__ == "__main__":
    asyncio.run(test_topic_query())
