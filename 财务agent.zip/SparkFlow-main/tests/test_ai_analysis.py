"""测试 AI 分析"""
import asyncio
from app.services.intelligence.fetchers.google_news import GoogleNewsRSSFetcher
from app.services.intelligence.scorer import RelevanceScorer
from app.services.intelligence.analyzer import get_ai_analyzer
from app.models.intelligence import SourceConfig, IntelligenceTopic, TopicConfig

async def test_ai_analysis():
    """测试 AI 分析"""

    # 创建配置
    config = SourceConfig(
        type="rss",
        name="Google News",
        enabled=True,
        query="(黄金 OR 金价) AND (投资 OR 走势 OR 分析)",
        params={
            "hl": "zh-CN",
            "gl": "CN",
            "ceid": "CN:zh"
        }
    )

    topic = IntelligenceTopic(
        name="黄金市场动态与投资策略",
        keywords=["黄金", "金价", "黄金投资"],
        sources=[config],
        schedule="daily",
        config=TopicConfig(
            min_relevance=0.3,
            enable_ai_summary=True
        )
    )

    # 收集
    fetcher = GoogleNewsRSSFetcher(config, topic)
    items = await fetcher.fetch()
    print(f"=== 收集 ===\n收集到: {len(items)} 条\n")

    # 评分
    scorer = RelevanceScorer()
    scored_items = await scorer.score(items, topic.keywords, topic.config)
    print(f"=== 评分 ===\n评分后: {len(scored_items)} 条\n")

    # 过滤
    filtered_items = [
        item for item in scored_items
        if item.overall_score >= topic.config.min_relevance
    ]
    print(f"=== 过滤 ===\n过滤后: {len(filtered_items)} 条\n")

    # 只测试前5条
    test_items = filtered_items[:5]

    print("=== AI 分析 (前5条) ===\n")

    analyzer = get_ai_analyzer()

    try:
        analyzed_items = await analyzer.analyze_items(
            test_items,
            topic.config,
            topic_name=topic.name,
            topic_keywords=topic.keywords
        )
        print(f"AI分析完成: {len(analyzed_items)} 条\n")

        for i, item in enumerate(analyzed_items, 1):
            print(f"{i}. {item.title[:50]}...")
            print(f"   AI摘要: {item.ai_summary[:80] if item.ai_summary else 'N/A'}...")
            print(f"   Sentiment: {item.sentiment}")
            print(f"   Tags: {item.tags if item.tags else []}")
            print()

    except Exception as e:
        print(f"❌ AI分析失败: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    asyncio.run(test_ai_analysis())
