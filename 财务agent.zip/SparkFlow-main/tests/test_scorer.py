"""测试评分逻辑"""
import asyncio
from app.services.intelligence.fetchers.google_news import GoogleNewsRSSFetcher
from app.services.intelligence.scorer import RelevanceScorer
from app.models.intelligence import SourceConfig, IntelligenceTopic, TopicConfig

async def test_scorer():
    """测试评分和过滤"""

    # 创建配置
    config = SourceConfig(
        type="rss",
        name="Google News",
        enabled=True,
        query="(黄金 OR 金价) AND (投资 OR 走势 OR 分析)",
        params={
            "hl": "zh-CN",
            "gl": "CN",
            "ceid": "CN:zh"
        }
    )

    topic = IntelligenceTopic(
        name="黄金市场动态与投资策略",
        keywords=["黄金", "金价", "黄金投资"],
        sources=[config],
        schedule="daily",
        config=TopicConfig(
            min_relevance=0.3,
            keyword_weight=0.4,
            timeliness_weight=0.3,
            authority_weight=0.3
        )
    )

    # 收集
    fetcher = GoogleNewsRSSFetcher(config, topic)
    items = await fetcher.fetch()

    print(f"=== 收集结果 ===\n")
    print(f"收集到: {len(items)} 条情报\n")

    # 评分
    scorer = RelevanceScorer()
    scored_items = await scorer.score(items, topic.keywords, topic.config)

    print(f"=== 评分结果 ===\n")
    print(f"评分后: {len(scored_items)} 条\n")

    # 显示前10条的评分
    print("前10条情报的评分:")
    for i, item in enumerate(scored_items[:10], 1):
        print(f"\n{i}. {item.title[:50]}...")
        print(f"   评分: {item.overall_score:.4f}")
        print(f"   相关性: {item.relevance_score:.4f}")
        print(f"   时效: {item.timeliness_score:.4f}")
        print(f"   权威: {item.authority_score:.4f}")

    # 过滤
    min_relevance = topic.config.min_relevance
    filtered_items = [item for item in scored_items if item.overall_score >= min_relevance]

    print(f"\n=== 过滤结果 (min_relevance={min_relevance}) ===\n")
    print(f"过滤后: {len(filtered_items)} 条")

    if len(filtered_items) == 0:
        print("\n⚠️  所有情报都被过滤掉了！")
        print(f"最高评分: {max(item.overall_score for item in scored_items):.4f}")
        print(f"最低评分: {min(item.overall_score for item in scored_items):.4f}")

        # 显示评分最高的几条
        top_items = sorted(scored_items, key=lambda x: x.overall_score, reverse=True)[:5]
        print("\n评分最高的5条:")
        for i, item in enumerate(top_items, 1):
            print(f"\n{i}. {item.title[:60]}...")
            print(f"   总评分: {item.overall_score:.4f}")
            print(f"   相关性: {item.relevance_score:.4f}")
            print(f"   时效: {item.timeliness_score:.4f}")
            print(f"   权威: {item.authority_score:.4f}")

if __name__ == "__main__":
    asyncio.run(test_scorer())
