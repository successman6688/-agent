"""测试反馈API"""
import asyncio
from app.services.intelligence.evolution_engine import (
    get_evolution_engine,
    FeedbackType
)


async def test_feedback_api():
    """测试反馈收集"""

    print("=" * 60)
    print("📬 测试反馈API")
    print("=" * 60)
    print()

    engine = get_evolution_engine()

    # 模拟用户反馈
    print("📊 收集反馈...")
    await engine.collect_feedback(
        item_id="test_item_001",
        prompt_id="finance_v2",
        feedback_type=FeedbackType.EXPLICIT_RATING,
        value=5,  # 5星好评
        user_id="user_test_1"
    )
    print("✅ 收集评分: 5星")

    await engine.collect_feedback(
        item_id="test_item_002",
        prompt_id="finance_v2",
        feedback_type=FeedbackType.IMPLICIT_ACTION,
        value=True,  # 采纳了行动建议
        user_id="user_test_2"
    )
    print("✅ 收集反馈: 用户采纳了行动建议")

    await engine.collect_feedback(
        item_id="test_item_003",
        prompt_id="finance_v1",
        feedback_type=FeedbackType.EXPLICIT_THUMBS,
        value=False,  # 点踩
        user_id="user_test_3"
    )
    print("❌ 收集反馈: 用户点踩")

    # 处理反馈
    print("\n⏳ 处理反馈...")
    await engine._process_feedback_batch()
    print("✅ 反馈处理完成")

    # 查看统计
    print("\n📈 性能统计:")
    top_prompts = engine.get_top_prompts(top_n=5)
    for i, (pid, score) in enumerate(top_prompts, 1):
        stats = engine.get_performance_report(pid)
        if stats:
            print(f"  #{i} {pid}:")
            print(f"      平均分: {stats['avg_score']:.2f}")
            print(f"      成功率: {stats['success_rate']:.2%}")
            print(f"      总样本: {stats['total_count']}")


if __name__ == "__main__":
    asyncio.run(test_feedback_api())
