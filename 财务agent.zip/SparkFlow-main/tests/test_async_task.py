"""测试异步任务"""
import asyncio
from app.services.intelligence.coordinator import get_intelligence_coordinator
from app.services.intelligence.storage import IntelligenceStorage

async def test_async_task():
    """测试异步任务"""

    topic_id = "017d2dcb-72fd-4c60-abc2-4025dfe3f68e"

    # 加载主题
    storage = IntelligenceStorage()
    topic = await storage.load_topic(topic_id)

    if not topic:
        print(f"❌ 主题不存在: {topic_id}")
        return

    print(f"=== 测试异步收集任务 ===\n")
    print(f"主题: {topic.name}")

    # 模拟收集任务返回
    coordinator = get_intelligence_coordinator()

    # 创建一个模拟的 collection_task
    async def mock_collection_task():
        return await coordinator.collect_intelligence(topic, force_refresh=True)

    # 测试返回值类型
    result = await mock_collection_task()

    print(f"\n=== 返回值类型 ===\n")
    print(f"类型: {type(result)}")
    print(f"是否有 model_dump: {hasattr(result, 'model_dump')}")
    print(f"是否有 dict: {hasattr(result, 'dict')}")

    if hasattr(result, 'model_dump'):
        result_dict = result.model_dump()
        print(f"\n转换为字典后:")
        print(f"new_items: {result_dict.get('new_items')}")
        print(f"total_collected: {result_dict.get('total_collected')}")
        print(f"status: {result_dict.get('status')}")

    print(f"\n✅ 测试完成！")

if __name__ == "__main__":
    asyncio.run(test_async_task())
