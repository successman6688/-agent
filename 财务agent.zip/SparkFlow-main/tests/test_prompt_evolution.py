"""演示提示词自动演化"""

import asyncio
from app.services.intelligence.prompt_evolution import get_prompt_evolution_service


async def demo_prompt_evolution():
    """演示提示词自动演化"""

    print("=" * 70)
    print("🧬 提示词自动演化演示")
    print("=" * 70)
    print()

    service = get_prompt_evolution_service()

    # 模拟当前提示词
    current_prompt = {
        "id": "finance_v1",
        "name": "财经分析v1.0",
        "strategy_type": "finance",
        "system_prompt": "你是一个专业的金融情报分析师。",
        "user_prompt_template": "请分析以下情报：\n{content}\n\n请以JSON格式返回结果。",
        "version": "1.0"
    }

    # 模拟执行日志
    execution_logs = [
        {
            "parse_success": False,
            "llm_response": "根据我的分析..."
        },
        {
            "parse_success": False,
            "llm_response": "好的，让我来分析这个问题..."
        }
    ]

    # 模拟用户反馈
    user_feedbacks = [
        {"feedback_type": "thumbs_down", "feedback_value": True},
        {"feedback_type": "rating", "feedback_value": 2}
    ]

    print("📊 步骤1：分析当前提示词的问题")
    print("-" * 70)
    print(f"当前提示词: {current_prompt['name']}")
    print(f"成功率: 50% (1/2)")
    print(f"负面反馈: 2")
    print()

    try:
        # 分析问题
        print("⏳ 正在分析问题...")
        problems_analysis = await service.analyze_prompt_problems(
            current_prompt,
            execution_logs,
            user_feedbacks
        )

        print("✅ 分析完成！")
        print()

        if "problems" in problems_analysis:
            print("发现的问题:")
            for i, problem in enumerate(problems_analysis["problems"], 1):
                print(f"  {i}. {problem['type']} ({problem['severity']}):")
                print(f"     {problem['description']}")
            print()

        if "suggested_improvements" in problems_analysis:
            print("改进建议:")
            for suggestion in problems_analysis["suggested_improvements"]:
                print(f"  • {suggestion}")
            print()

        print(f"综合评分: {problems_analysis.get('overall_score', 'N/A')}/10")
        print()

        # 演示2：生成改进版本（注释掉，因为会消耗LLM调用）
        print("📝 步骤2：生成改进版本")
        print("-" * 70)
        print("（注：实际调用会消耗LLM API，这里使用模拟数据）")
        print()

        # 模拟改进版本
        improved_versions = [
            {
                "name": "财经分析v1.1（加强版）",
                "version": "1.1",
                "improvements": [
                    "添加明确的JSON格式要求",
                    "增加字段验证说明",
                    "提供输出示例"
                ]
            },
            {
                "name": "财经分析v1.2（简化版）",
                "version": "1.2",
                "improvements": [
                    "简化提示词结构",
                    "聚焦核心要求",
                    "减少歧义"
                ]
            },
            {
                "name": "财经分析v2.0（重构版）",
                "version": "2.0",
                "improvements": [
                    "完全重构提示词结构",
                    "采用链式思维（CoT）",
                    "增加自验证步骤"
                ]
            }
        ]

        print(f"生成了 {len(improved_versions)} 个改进版本:")
        for version in improved_versions:
            print(f"\n  📌 {version['name']}")
            for improvement in version["improvements"]:
                print(f"     ✓ {improvement}")
        print()

        # 演示3：评估质量（注释掉）
        print("🎯 步骤3：评估新版本质量")
        print("-" * 70)
        print("（注：实际评估会消耗LLM API）")
        print()

        # 模拟评估结果
        evaluations = [
            {"name": "财经分析v1.1", "overall_score": 7.5, "recommendation": "test"},
            {"name": "财经分析v1.2", "overall_score": 8.2, "recommendation": "test"},
            {"name": "财经分析v2.0", "overall_score": 9.1, "recommendation": "deploy"}
        ]

        print("质量评估结果:")
        for eval_result in evaluations:
            print(f"\n  {eval_result['name']}:")
            print(f"  综合评分: {eval_result['overall_score']}/10")
            print(f"  建议: {eval_result['recommendation']}")
        print()

        # 推荐最佳版本
        best = max(evaluations, key=lambda x: x["overall_score"])
        print("🏆 推荐部署:", best["name"])
        print()

    except Exception as e:
        print(f"❌ 演示失败: {e}")
        import traceback
        traceback.print_exc()

    # 总结
    print("=" * 70)
    print("🎯 提示词自动演化流程总结")
    print("=" * 70)
    print("""
1. 📊 **性能分析**
   - 收集执行日志和用户反馈
   - 计算成功率、质量评分
   - 识别失败模式

2. 🔍 **问题诊断**
   - 使用AI分析提示词问题
   - 识别JSON格式、输出质量、逻辑错误
   - 生成改进建议

3. 🧬 **版本生成**
   - 基于问题自动生成改进版本
   - 保持原有功能，优化问题点
   - 生成多个候选版本

4. 🎯 **质量评估**
   - 评估清晰度、完整性、鲁棒性
   - 评分和推荐
   - 选择最佳版本

5. 🚀 **自动部署**
   - A/B测试新版本
   - Thompson Sampling自动选择
   - 持续迭代优化

这样的系统可以：
✅ 自动发现和修复提示词问题
✅ 不断生成更好的版本
✅ 减少人工调参工作
✅ 持续提升AI分析质量
    """)


if __name__ == "__main__":
    asyncio.run(demo_prompt_evolution())
