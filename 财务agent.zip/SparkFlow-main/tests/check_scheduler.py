"""检查并配置调度器"""
import asyncio
from app.services.intelligence.scheduler import get_intelligence_scheduler
from app.db.connection import get_db
from app.db.intelligence_repository import IntelligenceRepository
from app.api.v1.endpoints.intelligence import db_to_pynamo_topic
from app.models.intelligence import ScheduleType

async def check_and_configure():
    """检查调度器状态并配置"""

    scheduler = get_intelligence_scheduler()

    print("=== 检查调度器状态 ===\n")

    # 检查是否运行
    is_running = scheduler.is_running()
    print(f"调度器运行中: {is_running}")

    if not is_running:
        print("\n启动调度器...")
        scheduler.start()
        print("✅ 调度器已启动")
    else:
        print("\n✅ 调度器已在运行")

    # 加载所有主题
    print("\n=== 配置主题收集频率 ===\n")

    async with get_db() as session:
        repo = IntelligenceRepository(session)
        db_topics = await repo.list_topics()

        print(f"找到 {len(db_topics)} 个主题\n")

        for db_topic in db_topics:
            # 转换为Pydantic模型
            topic = db_to_pynamo_topic(db_topic)

            # 根据主题名称智能判断合适的频率
            schedule = topic.schedule

            # 智能调整：实时性要求高的主题设为hourly
            if any(keyword in topic.name.lower() for keyword in ['黄金', '金价', '股票', '实时', '快讯']):
                if schedule != ScheduleType.HOURLY:
                    schedule = ScheduleType.HOURLY
                    print(f"⚡ {topic.name[:30]}")
                    print(f"   旧频率: {topic.schedule} → 新频率: {schedule} (每小时)")
            # 普通主题保持daily
            elif schedule == ScheduleType.HOURLY:
                print(f"📊 {topic.name[:30]} - {schedule} (每小时)")
            else:
                print(f"📰 {topic.name[:30]} - {schedule} (每天)")

            # 更新主题配置（如果需要）
            if topic.schedule != schedule:
                topic.schedule = schedule
                await repo.update_topic(topic.id, {"schedule": schedule})

            # 添加到调度器
            if topic.is_active:
                await scheduler.schedule_topic(topic)

    print(f"\n=== 当前调度配置 ===\n")
    jobs = scheduler.scheduler.get_jobs()

    if not jobs:
        print("⚠️  没有定时任务")
    else:
        print(f"共有 {len(jobs)} 个定时任务:\n")

        for job in jobs:
            print(f"📌 {job.name}")
            print(f"   下次执行: {job.next_run_time}")
            print()

if __name__ == "__main__":
    asyncio.run(check_and_configure())
