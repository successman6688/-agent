<template>
  <div class="analytics">
    <el-page-header title="数据分析" />

    <el-result icon="info" title="功能开发中" sub-title="数据分析功能正在开发中，敬请期待">
      <template #extra>
        <el-button type="primary" @click="$router.push('/')">返回首页</el-button>
      </template>
    </el-result>
  </div>
</template>

<script setup lang="ts">
// Analytics feature coming soon
</script>

<style scoped>
.analytics {
  padding: 24px;
}
</style>
