<template>
  <div class="publication-list">
    <el-page-header title="发布记录" />

    <el-result icon="info" title="功能开发中" sub-title="发布管理功能正在开发中，敬请期待">
      <template #extra>
        <el-button type="primary" @click="$router.push('/')">返回首页</el-button>
      </template>
    </el-result>
  </div>
</template>

<script setup lang="ts">
// Publication management feature coming soon
</script>

<style scoped>
.publication-list {
  padding: 24px;
}
</style>
