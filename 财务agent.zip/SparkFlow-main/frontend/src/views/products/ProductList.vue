<template>
  <div class="product-list">
    <!-- Page Header -->
    <div class="page-header">
      <div class="page-title">
        <h1>产品管理</h1>
        <p class="subtitle">管理您的产品信息，激活产品用于营销</p>
      </div>
      <div class="page-actions">
        <el-button type="primary" @click="handleCreate">
          <el-icon><Plus /></el-icon>
          添加产品
        </el-button>
        <el-button @click="handleRefresh">
          <el-icon><Refresh /></el-icon>
          刷新
        </el-button>
      </div>
    </div>

    <!-- Filters -->
    <el-card class="filter-card" shadow="never">
      <el-form :model="filters" inline>
        <el-form-item label="产品类型">
          <el-select v-model="filters.type" placeholder="全部" clearable @change="handleSearch">
            <el-option label="小程序" value="mini_program" />
            <el-option label="APP" value="app" />
            <el-option label="网站" value="website" />
            <el-option label="SaaS" value="saas" />
            <el-option label="课程" value="course" />
            <el-option label="实体商品" value="physical" />
            <el-option label="服务" value="service" />
            <el-option label="其他" value="other" />
          </el-select>
        </el-form-item>

        <el-form-item label="状态">
          <el-select v-model="filters.status" placeholder="全部" clearable @change="handleSearch">
            <el-option label="激活" value="active" />
            <el-option label="未激活" value="inactive" />
            <el-option label="已归档" value="archived" />
          </el-select>
        </el-form-item>

        <el-form-item label="搜索">
          <el-input
            v-model="filters.search"
            placeholder="搜索产品名称或描述"
            clearable
            @clear="handleSearch"
            @keyup.enter="handleSearch"
          >
            <template #append>
              <el-button :icon="Search" @click="handleSearch" />
            </template>
          </el-input>
        </el-form-item>
      </el-form>
    </el-card>

    <!-- Product Table -->
    <el-card class="table-card" shadow="never">
      <el-table
        v-loading="loading"
        :data="products"
        stripe
        @row-click="handleRowClick"
      >
        <el-table-column prop="name" label="产品名称" min-width="180">
          <template #default="{ row }">
            <div class="product-name">
              <span>{{ row.name }}</span>
              <el-tag v-if="row.is_active" type="success" size="small" class="active-tag">
                激活
              </el-tag>
            </div>
          </template>
        </el-table-column>

        <el-table-column prop="type" label="类型" width="100">
          <template #default="{ row }">
            {{ getTypeLabel(row.type) }}
          </template>
        </el-table-column>

        <el-table-column prop="target_audience" label="目标用户" width="120" show-overflow-tooltip />

        <el-table-column prop="category" label="分类" width="100" show-overflow-tooltip />

        <el-table-column prop="status" label="状态" width="100">
          <template #default="{ row }">
            <el-tag :type="getStatusType(row.status)">
              {{ getStatusLabel(row.status) }}
            </el-tag>
          </template>
        </el-table-column>

        <el-table-column label="统计" width="150">
          <template #default="{ row }">
            <span class="stats">
              <el-icon><Document /></el-icon>
              {{ row.content_count }}
            </span>
            <span class="stats">
              <el-icon><Promotion /></el-icon>
              {{ row.publish_count }}
            </span>
          </template>
        </el-table-column>

        <el-table-column prop="created_at" label="创建时间" width="180">
          <template #default="{ row }">
            {{ formatDate(row.created_at) }}
          </template>
        </el-table-column>

        <el-table-column label="操作" width="200" fixed="right">
          <template #default="{ row }">
            <el-button
              v-if="!row.is_active"
              type="success"
              size="small"
              text
              @click.stop="handleActivate(row)"
            >
              激活
            </el-button>
            <el-button type="primary" size="small" text @click.stop="handleEdit(row)">
              编辑
            </el-button>
            <el-button type="danger" size="small" text @click.stop="handleDelete(row)">
              删除
            </el-button>
          </template>
        </el-table-column>
      </el-table>
    </el-card>
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted, computed } from 'vue'
import { useRouter } from 'vue-router'
import { ElMessage, ElMessageBox } from 'element-plus'
import { Plus, Refresh, Search, Document, Promotion } from '@element-plus/icons-vue'
import { useProductsStore } from '@/stores/products'
import { storeToRefs } from 'pinia'
import type { Product, ProductFilters } from '@/types/product'

const router = useRouter()
const productsStore = useProductsStore()
const { products, loading } = storeToRefs(productsStore)

// Filters
const filters = ref<ProductFilters>({
  type: undefined,
  status: undefined,
  search: '',
})

// Fetch products
const fetchProducts = async () => {
  try {
    await productsStore.fetchProducts(filters.value)
  } catch (error) {
    ElMessage.error('加载产品列表失败')
  }
}

// Handle search
const handleSearch = () => {
  fetchProducts()
}

// Handle refresh
const handleRefresh = () => {
  fetchProducts()
}

// Handle create
const handleCreate = () => {
  router.push({ name: 'ProductCreate' })
}

// Handle edit
const handleEdit = (product: Product) => {
  router.push({ name: 'ProductEdit', params: { id: product.id } })
}

// Handle row click
const handleRowClick = (product: Product) => {
  router.push({ name: 'ProductDetail', params: { id: product.id } })
}

// Handle activate
const handleActivate = async (product: Product) => {
  try {
    await ElMessageBox.confirm(
      `确定要激活产品"${product.name}"吗？激活后将用于内容生成。`,
      '激活产品',
      {
        type: 'warning',
      }
    )

    await productsStore.activateProduct(product.id)
    ElMessage.success('产品激活成功')
    await fetchProducts()
  } catch (error: any) {
    if (error !== 'cancel') {
      ElMessage.error(error.message || '产品激活失败')
    }
  }
}

// Handle delete
const handleDelete = async (product: Product) => {
  try {
    await ElMessageBox.confirm(
      `确定要删除产品"${product.name}"吗？此操作不可恢复。`,
      '删除产品',
      {
        type: 'warning',
        confirmButtonText: '确定',
        cancelButtonText: '取消',
      }
    )

    await productsStore.deleteProduct(product.id)
    ElMessage.success('产品删除成功')
    await fetchProducts()
  } catch (error: any) {
    if (error !== 'cancel') {
      ElMessage.error(error.message || '产品删除失败')
    }
  }
}

// Get type label
const getTypeLabel = (type: string) => {
  const labels: Record<string, string> = {
    mini_program: '小程序',
    app: 'APP',
    website: '网站',
    saas: 'SaaS',
    course: '课程',
    physical: '实体商品',
    service: '服务',
    other: '其他',
  }
  return labels[type] || type
}

// Get status label
const getStatusLabel = (status: string) => {
  const labels: Record<string, string> = {
    active: '激活',
    inactive: '未激活',
    archived: '已归档',
  }
  return labels[status] || status
}

// Get status type for element-plus tag
const getStatusType = (status: string) => {
  const types: Record<string, any> = {
    active: 'success',
    inactive: 'info',
    archived: 'danger',
  }
  return types[status] || 'info'
}

// Format date
const formatDate = (date: string) => {
  return new Date(date).toLocaleString('zh-CN')
}

onMounted(() => {
  fetchProducts()
})
</script>

<style scoped>
.product-list {
  padding: 0;
}

.page-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 16px;
}

.page-title h1 {
  margin: 0;
  font-size: 24px;
  font-weight: 600;
}

.subtitle {
  margin: 4px 0 0;
  color: #666;
  font-size: 14px;
}

.page-actions {
  display: flex;
  gap: 8px;
}

.filter-card {
  margin-bottom: 16px;
}

.table-card {
  margin-bottom: 16px;
}

.product-name {
  display: flex;
  align-items: center;
  gap: 8px;
}

.active-tag {
  flex-shrink: 0;
}

.stats {
  display: inline-flex;
  align-items: center;
  gap: 4px;
  margin-right: 12px;
  font-size: 12px;
  color: #666;
}

.stats .el-icon {
  font-size: 14px;
}

:deep(.el-table__row) {
  cursor: pointer;
}

:deep(.el-table__row:hover) {
  background-color: #f5f7fa;
}
</style>
