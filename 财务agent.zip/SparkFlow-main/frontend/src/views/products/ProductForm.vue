<template>
  <div class="product-form">
    <el-page-header @back="handleBack" class="page-header">
      <template #content>
        {{ isEdit ? '编辑产品' : '创建产品' }}
      </template>
    </el-page-header>

    <el-form
      ref="formRef"
      :model="form"
      :rules="rules"
      label-width="120px"
      class="form"
      v-loading="loading"
    >
      <!-- 基本信息 -->
      <el-divider content-position="left">基本信息</el-divider>

      <el-form-item label="产品名称" prop="name">
        <el-input v-model="form.name" placeholder="请输入产品名称" />
      </el-form-item>

      <el-form-item label="产品类型" prop="type">
        <el-select v-model="form.type" placeholder="请选择产品类型">
          <el-option label="小程序" value="mini_program" />
          <el-option label="APP" value="app" />
          <el-option label="网站" value="website" />
          <el-option label="SaaS" value="saas" />
          <el-option label="课程" value="course" />
          <el-option label="实体商品" value="physical" />
          <el-option label="服务" value="service" />
          <el-option label="其他" value="other" />
        </el-select>
      </el-form-item>

      <el-form-item label="产品描述" prop="description">
        <el-input
          v-model="form.description"
          type="textarea"
          :rows="4"
          placeholder="请输入产品描述"
        />
      </el-form-item>

      <el-form-item label="目标用户" prop="target_audience">
        <el-input v-model="form.target_audience" placeholder="例如：独立开发者、创业团队" />
      </el-form-item>

      <!-- 营销信息 -->
      <el-divider content-position="left">营销信息</el-divider>

      <el-form-item label="产品卖点">
        <el-input
          v-model="sellingPointsText"
          type="textarea"
          :rows="3"
          placeholder="每行一个卖点，例如：&#10;自动内容生成&#10;多平台一键发布&#10;AI智能优化"
        />
      </el-form-item>

      <el-form-item label="官网链接">
        <el-input v-model="form.website_url" placeholder="https://example.com" />
      </el-form-item>

      <el-form-item label="CTA文本">
        <el-input v-model="form.cta_text" placeholder="例如：立即下载、免费试用" />
      </el-form-item>

      <el-form-item label="CTA链接">
        <el-input v-model="form.cta_link" placeholder="点击CTA后跳转的链接" />
      </el-form-item>

      <!-- 平台信息 -->
      <el-divider content-position="left">平台信息</el-divider>

      <el-form-item label="微信AppID" v-if="form.type === 'mini_program'">
        <el-input v-model="form.wechat_appid" placeholder="微信小程序AppID" />
      </el-form-item>

      <el-form-item label="小程序路径" v-if="form.type === 'mini_program'">
        <el-input v-model="form.wechat_path" placeholder="pages/index/index" />
      </el-form-item>

      <el-form-item label="App Store" v-if="form.type === 'app'">
        <el-input v-model="form.app_store_url" placeholder="https://apps.apple.com/..." />
      </el-form-item>

      <el-form-item label="Google Play" v-if="form.type === 'app'">
        <el-input v-model="form.google_play_url" placeholder="https://play.google.com/..." />
      </el-form-item>

      <!-- 价格信息 -->
      <el-divider content-position="left">价格信息</el-divider>

      <el-form-item label="价格">
        <el-input v-model="form.price" placeholder="例如：￥99/月、免费" />
      </el-form-item>

      <el-form-item label="定价模式">
        <el-select v-model="form.pricing_model" placeholder="请选择定价模式" clearable>
          <el-option label="免费" value="free" />
          <el-option label="一次性付费" value="one_time" />
          <el-option label="订阅制" value="subscription" />
          <el-option label="免费增值" value="freemium" />
        </el-select>
      </el-form-item>

      <!-- 标签 -->
      <el-divider content-position="left">标签</el-divider>

      <el-form-item label="产品分类">
        <el-input v-model="form.category" placeholder="例如：营销工具、教育" />
      </el-form-item>

      <el-form-item label="产品标签">
        <el-input
          v-model="tagsText"
          placeholder="用逗号分隔，例如：AI,营销,自动化"
        />
      </el-form-item>

      <!-- 表单操作 -->
      <el-form-item>
        <el-button type="primary" @click="handleSubmit" :loading="submitting">
          {{ isEdit ? '保存' : '创建' }}
        </el-button>
        <el-button @click="handleBack">取消</el-button>
      </el-form-item>
    </el-form>
  </div>
</template>

<script setup lang="ts">
import { ref, computed, onMounted } from 'vue'
import { useRouter, useRoute } from 'vue-router'
import { ElMessage, type FormInstance, type FormRules } from 'element-plus'
import { useProductsStore } from '@/stores/products'
import type { ProductCreate, ProductUpdate } from '@/types/product'

const router = useRouter()
const route = useRoute()
const productsStore = useProductsStore()

const formRef = ref<FormInstance>()
const loading = ref(false)
const submitting = ref(false)

// Is edit mode
const isEdit = computed(() => !!route.params.id)
const productId = computed(() => route.params.id as string)

// Form data
const form = ref<ProductCreate | ProductUpdate>({
  name: '',
  type: undefined as any,
  description: '',
  target_audience: '',
  selling_points: [],
  website_url: '',
  cta_text: '',
  cta_link: '',
  wechat_appid: '',
  wechat_path: '',
  app_store_url: '',
  google_play_url: '',
  price: '',
  pricing_model: undefined,
  category: '',
  tags: [],
})

// Computed text for selling points (one per line)
const sellingPointsText = computed({
  get: () => form.value.selling_points?.join('\n') || '',
  set: (value: string) => {
    form.value.selling_points = value.split('\n').filter(s => s.trim())
  },
})

// Computed text for tags (comma-separated)
const tagsText = computed({
  get: () => form.value.tags?.join(',') || '',
  set: (value: string) => {
    form.value.tags = value.split(',').map(s => s.trim()).filter(s => s)
  },
})

// Form rules
const rules: FormRules = {
  name: [{ required: true, message: '请输入产品名称', trigger: 'blur' }],
  type: [{ required: true, message: '请选择产品类型', trigger: 'change' }],
  description: [{ required: true, message: '请输入产品描述', trigger: 'blur' }],
  target_audience: [{ required: true, message: '请输入目标用户', trigger: 'blur' }],
}

// Load product for edit
const loadProduct = async () => {
  if (!isEdit.value) return

  loading.value = true
  try {
    const product = await productsStore.fetchProduct(productId.value)
    // Copy data to form
    const data = { ...product }
    form.value = {
      name: data.name,
      type: data.type,
      description: data.description,
      target_audience: data.target_audience,
      selling_points: data.selling_points,
      website_url: data.website_url,
      cta_text: data.cta_text,
      cta_link: data.cta_link,
      wechat_appid: data.wechat_appid,
      wechat_path: data.wechat_path,
      app_store_url: data.app_store_url,
      google_play_url: data.google_play_url,
      price: data.price,
      pricing_model: data.pricing_model,
      category: data.category,
      tags: data.tags,
    }
  } catch (error) {
    ElMessage.error('加载产品信息失败')
    router.back()
  } finally {
    loading.value = false
  }
}

// Handle submit
const handleSubmit = async () => {
  if (!formRef.value) return

  try {
    await formRef.value.validate()

    submitting.value = true

    if (isEdit.value) {
      // Update
      await productsStore.updateProduct(productId.value, form.value as ProductUpdate)
      ElMessage.success('产品更新成功')
    } else {
      // Create
      const product = await productsStore.createProduct(form.value as ProductCreate)
      ElMessage.success('产品创建成功')
      // Navigate to detail page
      router.replace({ name: 'ProductDetail', params: { id: product.id } })
      return
    }

    router.back()
  } catch (error: any) {
    if (error !== false) { // Not a validation error
      ElMessage.error(error.message || '操作失败')
    }
  } finally {
    submitting.value = false
  }
}

// Handle back
const handleBack = () => {
  router.back()
}

onMounted(() => {
  loadProduct()
})
</script>

<style scoped>
.product-form {
  max-width: 800px;
  margin: 0 auto;
}

.page-header {
  margin-bottom: 24px;
}

.form {
  background: #fff;
  padding: 24px;
  border-radius: 8px;
}

:deep(.el-divider__text) {
  font-weight: 600;
  color: #303133;
}
</style>
