<template>
  <div class="product-detail" v-loading="loading">
    <div v-if="product">
      <!-- Page Header -->
      <el-page-header @back="handleBack" class="page-header">
        <template #content>
          <div class="header-content">
            <span class="product-name">{{ product.name }}</span>
            <el-tag v-if="product.is_active" type="success" class="active-tag">激活</el-tag>
            <el-tag :type="getStatusType(product.status)">
              {{ getStatusLabel(product.status) }}
            </el-tag>
          </div>
        </template>
        <template #extra>
          <div class="header-actions">
            <el-button
              v-if="!product.is_active"
              type="success"
              @click="handleActivate"
            >
              激活产品
            </el-button>
            <el-button type="primary" @click="handleEdit">编辑</el-button>
            <el-button type="danger" @click="handleDelete">删除</el-button>
          </div>
        </template>
      </el-page-header>

      <!-- Product Info Card -->
      <el-card class="info-card" shadow="never">
        <template #header>
          <span class="card-title">基本信息</span>
        </template>

        <el-descriptions :column="2" border>
          <el-descriptions-item label="产品名称">
            {{ product.name }}
          </el-descriptions-item>

          <el-descriptions-item label="产品类型">
            {{ getTypeLabel(product.type) }}
          </el-descriptions-item>

          <el-descriptions-item label="目标用户" :span="2">
            {{ product.target_audience }}
          </el-descriptions-item>

          <el-descriptions-item label="产品描述" :span="2">
            {{ product.description }}
          </el-descriptions-item>

          <el-descriptions-item label="产品分类" :span="2">
            {{ product.category || '-' }}
          </el-descriptions-item>

          <el-descriptions-item label="产品标签" :span="2">
            <el-tag
              v-for="tag in product.tags"
              :key="tag"
              size="small"
              style="margin-right: 8px"
            >
              {{ tag }}
            </el-tag>
            <span v-if="!product.tags || product.tags.length === 0">-</span>
          </el-descriptions-item>

          <el-descriptions-item label="价格" :span="2">
            {{ product.price || '-' }}
            <el-tag v-if="product.pricing_model" size="small" style="margin-left: 8px">
              {{ getPricingModelLabel(product.pricing_model) }}
            </el-tag>
          </el-descriptions-item>

          <el-descriptions-item label="创建时间">
            {{ formatDate(product.created_at) }}
          </el-descriptions-item>

          <el-descriptions-item label="更新时间">
            {{ formatDate(product.updated_at) }}
          </el-descriptions-item>
        </el-descriptions>
      </el-card>

      <!-- Marketing Info Card -->
      <el-card class="info-card" shadow="never">
        <template #header>
          <span class="card-title">营销信息</span>
        </template>

        <el-descriptions :column="1" border>
          <el-descriptions-item label="产品卖点">
            <ul class="selling-points">
              <li v-for="(point, index) in product.selling_points" :key="index">
                {{ point }}
              </li>
            </ul>
            <span v-if="!product.selling_points || product.selling_points.length === 0">-</span>
          </el-descriptions-item>

          <el-descriptions-item label="官网链接">
            <el-link
              v-if="product.website_url"
              :href="product.website_url"
              target="_blank"
              type="primary"
            >
              {{ product.website_url }}
            </el-link>
            <span v-else>-</span>
          </el-descriptions-item>

          <el-descriptions-item label="CTA文本">
            {{ product.cta_text || '-' }}
          </el-descriptions-item>

          <el-descriptions-item label="CTA链接">
            <el-link
              v-if="product.cta_link"
              :href="product.cta_link"
              target="_blank"
              type="primary"
            >
              {{ product.cta_link }}
            </el-link>
            <span v-else>-</span>
          </el-descriptions-item>
        </el-descriptions>
      </el-card>

      <!-- Platform Info Card -->
      <el-card class="info-card" shadow="never">
        <template #header>
          <span class="card-title">平台信息</span>
        </template>

        <el-descriptions :column="1" border>
          <el-descriptions-item
            v-if="product.type === 'mini_program'"
            label="微信AppID"
          >
            {{ product.wechat_appid || '-' }}
          </el-descriptions-item>

          <el-descriptions-item
            v-if="product.type === 'mini_program'"
            label="小程序路径"
          >
            {{ product.wechat_path || '-' }}
          </el-descriptions-item>

          <el-descriptions-item
            v-if="product.type === 'app'"
            label="App Store"
          >
            <el-link
              v-if="product.app_store_url"
              :href="product.app_store_url"
              target="_blank"
              type="primary"
            >
              {{ product.app_store_url }}
            </el-link>
            <span v-else>-</span>
          </el-descriptions-item>

          <el-descriptions-item
            v-if="product.type === 'app'"
            label="Google Play"
          >
            <el-link
              v-if="product.google_play_url"
              :href="product.google_play_url"
              target="_blank"
              type="primary"
            >
              {{ product.google_play_url }}
            </el-link>
            <span v-else>-</span>
          </el-descriptions-item>
        </el-descriptions>
      </el-card>

      <!-- Statistics Card -->
      <el-card class="info-card" shadow="never">
        <template #header>
          <span class="card-title">统计信息</span>
        </template>

        <el-row :gutter="16">
          <el-col :span="8">
            <el-statistic title="已生成内容" :value="product.content_count">
              <template #prefix>
                <el-icon><Document /></el-icon>
              </template>
            </el-statistic>
          </el-col>
          <el-col :span="8">
            <el-statistic title="已发布内容" :value="product.publish_count">
              <template #prefix>
                <el-icon><Promotion /></el-icon>
              </template>
            </el-statistic>
          </el-col>
          <el-col :span="8">
            <el-statistic title="产品状态">
              <template #default>
                <el-tag :type="getStatusType(product.status)">
                  {{ getStatusLabel(product.status) }}
                </el-tag>
              </template>
            </el-statistic>
          </el-col>
        </el-row>
      </el-card>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted } from 'vue'
import { useRouter, useRoute } from 'vue-router'
import { ElMessage, ElMessageBox } from 'element-plus'
import { Document, Promotion } from '@element-plus/icons-vue'
import { useProductsStore } from '@/stores/products'
import { storeToRefs } from 'pinia'
import type { Product } from '@/types/product'

const router = useRouter()
const route = useRoute()
const productsStore = useProductsStore()

const loading = ref(false)
const product = ref<Product | null>(null)

const productId = route.params.id as string

// Load product
const loadProduct = async () => {
  loading.value = true
  try {
    product.value = await productsStore.fetchProduct(productId)
  } catch (error: any) {
    ElMessage.error(error.message || '加载产品信息失败')
    router.back()
  } finally {
    loading.value = false
  }
}

// Handle back
const handleBack = () => {
  router.back()
}

// Handle edit
const handleEdit = () => {
  router.push({ name: 'ProductEdit', params: { id: productId } })
}

// Handle activate
const handleActivate = async () => {
  if (!product.value) return

  try {
    await ElMessageBox.confirm(
      `确定要激活产品"${product.value.name}"吗？`,
      '激活产品',
      {
        type: 'warning',
      }
    )

    await productsStore.activateProduct(productId)
    product.value = productsStore.activeProduct
    ElMessage.success('产品激活成功')
  } catch (error: any) {
    if (error !== 'cancel') {
      ElMessage.error(error.message || '产品激活失败')
    }
  }
}

// Handle delete
const handleDelete = async () => {
  if (!product.value) return

  try {
    await ElMessageBox.confirm(
      `确定要删除产品"${product.value.name}"吗？此操作不可恢复。`,
      '删除产品',
      {
        type: 'warning',
        confirmButtonText: '确定',
        cancelButtonText: '取消',
      }
    )

    await productsStore.deleteProduct(productId)
    ElMessage.success('产品删除成功')
    router.push({ name: 'ProductList' })
  } catch (error: any) {
    if (error !== 'cancel') {
      ElMessage.error(error.message || '产品删除失败')
    }
  }
}

// Get type label
const getTypeLabel = (type: string) => {
  const labels: Record<string, string> = {
    mini_program: '小程序',
    app: 'APP',
    website: '网站',
    saas: 'SaaS',
    course: '课程',
    physical: '实体商品',
    service: '服务',
    other: '其他',
  }
  return labels[type] || type
}

// Get status label
const getStatusLabel = (status: string) => {
  const labels: Record<string, string> = {
    active: '激活',
    inactive: '未激活',
    archived: '已归档',
  }
  return labels[status] || status
}

// Get status type
const getStatusType = (status: string) => {
  const types: Record<string, any> = {
    active: 'success',
    inactive: 'info',
    archived: 'danger',
  }
  return types[status] || 'info'
}

// Get pricing model label
const getPricingModelLabel = (model: string) => {
  const labels: Record<string, string> = {
    free: '免费',
    one_time: '一次性',
    subscription: '订阅制',
    freemium: '免费增值',
  }
  return labels[model] || model
}

// Format date
const formatDate = (date: string) => {
  return new Date(date).toLocaleString('zh-CN')
}

onMounted(() => {
  loadProduct()
})
</script>

<style scoped>
.product-detail {
  padding: 0;
}

.page-header {
  margin-bottom: 24px;
}

.header-content {
  display: flex;
  align-items: center;
  gap: 12px;
}

.product-name {
  font-size: 20px;
  font-weight: 600;
}

.active-tag {
  flex-shrink: 0;
}

.header-actions {
  display: flex;
  gap: 8px;
}

.info-card {
  margin-bottom: 16px;
}

.card-title {
  font-weight: 600;
}

.selling-points {
  margin: 0;
  padding-left: 20px;
}

.selling-points li {
  margin-bottom: 4px;
}
</style>
