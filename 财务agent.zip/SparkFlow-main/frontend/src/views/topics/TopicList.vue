<template>
  <div class="topic-list">
    <el-page-header title="话题发现" />

    <el-result icon="info" title="功能开发中" sub-title="话题发现功能正在开发中，敬请期待">
      <template #extra>
        <el-button type="primary" @click="$router.push('/')">返回首页</el-button>
      </template>
    </el-result>
  </div>
</template>

<script setup lang="ts">
// Topic discovery feature coming soon
</script>

<style scoped>
.topic-list {
  padding: 24px;
}
</style>
