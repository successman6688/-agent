<template>
  <div class="content-generate">
    <el-page-header title="内容生成" />

    <el-result icon="info" title="功能开发中" sub-title="AI内容生成功能正在开发中，敬请期待">
      <template #extra>
        <el-button type="primary" @click="$router.push('/')">返回首页</el-button>
      </template>
    </el-result>
  </div>
</template>

<script setup lang="ts">
// Content generation feature coming soon
</script>

<style scoped>
.content-generate {
  padding: 24px;
}
</style>
