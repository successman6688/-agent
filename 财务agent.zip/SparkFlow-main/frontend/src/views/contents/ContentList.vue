<template>
  <div class="content-list">
    <el-page-header title="内容管理" />

    <el-result icon="info" title="功能开发中" sub-title="内容管理功能正在开发中，敬请期待">
      <template #extra>
        <el-button type="primary" @click="$router.push('/')">返回首页</el-button>
      </template>
    </el-result>
  </div>
</template>

<script setup lang="ts">
// Content management feature coming soon
</script>

<style scoped>
.content-list {
  padding: 24px;
}
</style>
