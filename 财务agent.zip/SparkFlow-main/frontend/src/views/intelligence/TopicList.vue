<template>
  <div class="intelligence-topics">
    <!-- Page Header -->
    <div class="page-header">
      <div class="page-title">
        <h1>情报监控</h1>
        <p class="subtitle">全网主题情报自动收集与分析</p>
      </div>
      <div class="page-actions">
        <el-button type="primary" @click="startAIAnalysis">
          <el-icon><Plus /></el-icon>
          AI智能创建
        </el-button>
        <el-button @click="showQuickStartDialog = true">
          <el-icon><Document /></el-icon>
          快速创建
        </el-button>
        <el-button @click="handleRefresh">
          <el-icon><Refresh /></el-icon>
          刷新
        </el-button>
        <el-dropdown @command="handleBatchAction" trigger="click">
          <el-button>
            更多操作
            <el-icon class="el-icon--right"><ArrowDown /></el-icon>
          </el-button>
          <template #dropdown>
            <el-dropdown-menu>
              <el-dropdown-item command="deleteAll">
                <el-icon><Delete /></el-icon>
                清空所有主题
              </el-dropdown-item>
            </el-dropdown-menu>
          </template>
        </el-dropdown>
      </div>
    </div>

    <!-- Topic Cards -->
    <el-row :gutter="16" v-loading="loading">
      <el-col
        v-for="topic in topics"
        :key="topic.id"
        :xs="24"
        :sm="12"
        :md="8"
        :lg="6"
      >
        <el-card class="topic-card" shadow="hover" @click="viewTopic(topic.id)">
          <!-- Card Actions Menu -->
          <div class="card-actions" @click.stop>
            <el-dropdown trigger="click" @command="(cmd) => handleCardAction(cmd, topic)">
              <el-button circle size="small" text>
                <el-icon><MoreFilled /></el-icon>
              </el-button>
              <template #dropdown>
                <el-dropdown-menu>
                  <el-dropdown-item command="collect">
                    <el-icon><Refresh /></el-icon>
                    立即收集
                  </el-dropdown-item>
                  <el-dropdown-item command="view">
                    <el-icon><View /></el-icon>
                    查看详情
                  </el-dropdown-item>
                  <el-dropdown-item divided command="delete" style="color: #f56c6c">
                    <el-icon><Delete /></el-icon>
                    删除主题
                  </el-dropdown-item>
                </el-dropdown-menu>
              </template>
            </el-dropdown>
          </div>

          <!-- Header -->
          <div class="topic-header">
            <h3 class="topic-name">{{ topic.name }}</h3>
            <el-tag
              :type="topic.is_active ? 'success' : 'info'"
              size="small"
            >
              {{ topic.is_active ? '激活' : '未激活' }}
            </el-tag>
          </div>

          <!-- Keywords -->
          <div class="topic-keywords">
            <el-tag
              v-for="keyword in topic.keywords.slice(0, 3)"
              :key="keyword"
              size="small"
              class="keyword-tag"
            >
              {{ keyword }}
            </el-tag>
            <span v-if="topic.keywords.length > 3" class="more-keywords">
              +{{ topic.keywords.length - 3 }}
            </span>
          </div>

          <!-- Stats -->
          <div class="topic-stats">
            <div class="stat-item">
              <el-icon><Document /></el-icon>
              <span>{{ topic.total_items }}</span>
            </div>
            <div class="stat-item">
              <el-icon><Clock /></el-icon>
              <span>{{ getScheduleLabel(topic.schedule) }}</span>
            </div>
          </div>

          <!-- Progress -->
          <el-progress
            v-if="topic.today_items > 0"
            :percentage="Math.min(topic.today_items * 10, 100)"
            :format="() => `${topic.today_items} 今日新增`"
            :stroke-width="8"
          />

          <!-- Actions -->
          <div class="topic-actions">
            <el-button
              type="primary"
              size="small"
              @click.stop="handleCollect(topic)"
              :loading="collectingTopicIds.includes(topic.id)"
            >
              立即收集
            </el-button>
            <el-button
              size="small"
              @click.stop="viewTopic(topic.id)"
            >
              查看详情
            </el-button>
          </div>

          <!-- Last Run -->
          <div v-if="topic.last_run_time" class="last-run">
            <el-text size="small" type="info">
              最后运行: {{ formatDateTime(topic.last_run_time) }}
            </el-text>
          </div>
        </el-card>
      </el-col>
    </el-row>

    <!-- Empty State -->
    <el-empty
      v-if="!loading && topics.length === 0"
      description="还没有情报主题，点击AI智能创建开始使用"
    >
      <el-button type="primary" @click="startAIAnalysis">
        创建第一个主题
      </el-button>
    </el-empty>

    <!-- AI Analysis Dialog -->
    <el-dialog
      v-model="showAIDialog"
      title="🤖 AI智能创建情报主题"
      width="700px"
      :close-on-click-modal="false"
    >
      <!-- Step 1: Input -->
      <div v-if="aiStep === 'input'" class="ai-input-step">
        <el-alert
          title="智能分析"
          type="info"
          :closable="false"
          style="margin-bottom: 20px"
        >
          <template #default>
            <p>输入关键词或描述，AI将自动分析并生成最优配置</p>
            <p style="font-size: 12px; color: #666; margin-top: 8px;">
              💡 例如："黄金 金价" 或 "我想监控AI和人工智能的新闻"
            </p>
          </template>
        </el-alert>

        <el-form :model="aiInputForm" label-width="80px">
          <el-form-item label="输入内容">
            <el-input
              v-model="aiInputForm.keywords"
              type="textarea"
              :rows="3"
              placeholder="输入关键词或描述，例如：黄金 金价 中国市场..."
              maxlength="200"
              show-word-limit
            />
          </el-form-item>
          <el-form-item label="语言">
            <el-radio-group v-model="aiInputForm.language">
              <el-radio-button label="zh">中文</el-radio-button>
              <el-radio-button label="en">English</el-radio-button>
            </el-radio-group>
          </el-form-item>
        </el-form>

        <div style="text-align: right; margin-top: 20px;">
          <el-button @click="showAIDialog = false">取消</el-button>
          <el-button
            type="primary"
            @click="analyzeKeywords"
            :loading="analyzing"
          >
            <el-icon><MagicStick /></el-icon>
            AI分析
          </el-button>
        </div>
      </div>

      <!-- Step 2: Review -->
      <div v-if="aiStep === 'review'" class="ai-review-step">
        <el-alert
          title="AI分析完成"
          type="success"
          :closable="false"
          style="margin-bottom: 20px"
        >
          <template #default>
            <p>AI已生成最优配置，请确认或调整后创建</p>
          </template>
        </el-alert>

        <el-tabs v-model="activeTab" type="border-card">
          <!-- 核心关键词 -->
          <el-tab-pane name="keywords">
            <template #label>
              <span>🎯 核心关键词</span>
            </template>
            <div class="analysis-section">
              <p class="section-desc">AI提取的核心关键词（可编辑）</p>
              <el-select
                v-model="aiAnalysisResult.primary_keywords"
                multiple
                filterable
                allow-create
                placeholder="选择或输入关键词"
                style="width: 100%"
              >
                <el-option
                  v-for="keyword in aiAnalysisResult.primary_keywords"
                  :key="keyword"
                  :label="keyword"
                  :value="keyword"
                />
              </el-select>
              <p style="margin-top: 12px; font-size: 12px; color: #999;">
                💡 提示：可以直接输入新关键词后按回车添加
              </p>
            </div>
          </el-tab-pane>

          <!-- 扩展关键词 -->
          <el-tab-pane name="expanded">
            <template #label>
              <span>🔍 扩展关键词</span>
            </template>
            <div class="analysis-section">
              <p class="section-desc">AI推荐的扩展关键词（供参考）</p>
              <el-tag
                v-for="keyword in aiAnalysisResult.expanded_keywords"
                :key="keyword"
                style="margin: 4px;"
              >
                {{ keyword }}
              </el-tag>
            </div>
          </el-tab-pane>

          <!-- 主题配置 -->
          <el-tab-pane name="config">
            <template #label>
              <span>⚙️ 主题配置</span>
            </template>
            <el-form :model="aiAnalysisResult" label-width="100px">
              <el-form-item label="主题名称">
                <el-input v-model="aiAnalysisResult.topic_name" />
              </el-form-item>
              <el-form-item label="主题描述">
                <el-input
                  v-model="aiAnalysisResult.topic_description"
                  type="textarea"
                  :rows="2"
                />
              </el-form-item>
              <el-form-item label="更新频率">
                <el-select v-model="aiAnalysisResult.schedule">
                  <el-option label="每小时" value="hourly" />
                  <el-option label="每天" value="daily" />
                  <el-option label="每周" value="weekly" />
                </el-select>
              </el-form-item>
              <el-form-item label="启用AI分析">
                <el-switch v-model="enableAISummary" />
              </el-form-item>
            </el-form>
          </el-tab-pane>

          <!-- 数据源 -->
          <el-tab-pane name="sources">
            <template #label>
              <span>📡 数据源</span>
            </template>
            <div class="analysis-section">
              <p class="section-desc">AI推荐的数据源（自动配置）</p>
              <el-table :data="aiAnalysisResult.recommended_sources" style="width: 100%">
                <el-table-column prop="type" label="类型" width="100" />
                <el-table-column prop="name" label="名称" />
                <el-table-column prop="reason" label="推荐理由" />
              </el-table>
            </div>
          </el-tab-pane>

          <!-- AI洞察 -->
          <el-tab-pane name="insights">
            <template #label>
              <span>💡 AI洞察</span>
            </template>
            <div class="analysis-section">
              <p class="section-desc">AI分析的关键洞察</p>
              <el-timeline>
                <el-timeline-item
                  v-for="(insight, index) in aiAnalysisResult.insights"
                  :key="index"
                  :timestamp="`洞察 ${index + 1}`"
                  placement="top"
                >
                  <p>{{ insight }}</p>
                </el-timeline-item>
              </el-timeline>
            </div>
          </el-tab-pane>
        </el-tabs>

        <div style="text-align: right; margin-top: 20px; border-top: 1px solid #eee; padding-top: 16px;">
          <el-button @click="aiStep = 'input'" :disabled="creating">
            <el-icon><Back /></el-icon>
            返回
          </el-button>
          <el-button
            type="primary"
            @click="createTopicFromAI"
            :loading="creating"
          >
            <el-icon><Check /></el-icon>
            确认创建
          </el-button>
        </div>
      </div>
    </el-dialog>

    <!-- Quick Start Dialog (传统方式) -->
    <el-dialog
      v-model="showQuickStartDialog"
      title="快速创建情报主题"
      width="500px"
    >
      <el-alert
        title="传统方式"
        type="warning"
        :closable="false"
        style="margin-bottom: 16px"
      >
        建议使用"AI智能创建"获得更好的配置效果
      </el-alert>

      <el-form :model="quickStartForm" label-width="80px">
        <el-form-item label="搜索关键词">
          <el-input
            v-model="quickStartForm.query"
            placeholder="例如: 人工智能、AI大模型、ChatGPT"
          />
        </el-form-item>
        <el-form-item label="主题名称">
          <el-input
            v-model="quickStartForm.name"
            placeholder="可选，不填则自动生成"
          />
        </el-form-item>
      </el-form>

      <template #footer>
        <el-button @click="showQuickStartDialog = false">取消</el-button>
        <el-button
          type="primary"
          @click="handleQuickStart"
          :loading="loading"
        >
          创建
        </el-button>
      </template>
    </el-dialog>

    <!-- Delete Confirmation Dialog -->
    <el-dialog
      v-model="showDeleteDialog"
      title="确认删除"
      width="400px"
    >
      <el-icon color="#f56c6c" :size="60" style="display: block; margin: 0 auto 16px;">
        <WarningFilled />
      </el-icon>
      <p style="text-align: center; margin-bottom: 8px;">
        <strong>确定要删除这个主题吗？</strong>
      </p>
      <p style="text-align: center; color: #666; font-size: 14px;">
        删除后将无法恢复，所有相关的情报数据和报告也会被删除。
      </p>
      <p v-if="topicToDelete" style="text-align: center; margin-top: 12px;">
        <el-tag>{{ topicToDelete.name }}</el-tag>
      </p>

      <template #footer>
        <el-button @click="showDeleteDialog = false">取消</el-button>
        <el-button
          type="danger"
          @click="confirmDelete"
          :loading="deleting"
        >
          确认删除
        </el-button>
      </template>
    </el-dialog>

    <!-- Delete All Confirmation Dialog -->
    <el-dialog
      v-model="showDeleteAllDialog"
      title="⚠️ 危险操作"
      width="450px"
    >
      <el-icon color="#f56c6c" :size="60" style="display: block; margin: 0 auto 16px;">
        <WarningFilled />
      </el-icon>
      <p style="text-align: center; margin-bottom: 8px;">
        <strong>确定要清空所有主题吗？</strong>
      </p>
      <p style="text-align: center; color: #666; font-size: 14px;">
        这将删除所有 {{ topics.length }} 个主题及其所有数据，此操作不可恢复！
      </p>
      <p style="text-align: center; color: #f56c6c; font-weight: bold; margin-top: 12px;">
        请输入 "DELETE" 来确认此操作
      </p>
      <el-input
        v-model="deleteAllConfirmText"
        placeholder="输入 DELETE"
        style="margin-top: 16px;"
      />

      <template #footer>
        <el-button @click="showDeleteAllDialog = false">取消</el-button>
        <el-button
          type="danger"
          @click="confirmDeleteAll"
          :loading="deleting"
          :disabled="deleteAllConfirmText !== 'DELETE'"
        >
          确认清空
        </el-button>
      </template>
    </el-dialog>
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted } from 'vue'
import { useRouter } from 'vue-router'
import { ElMessage, ElMessageBox } from 'element-plus'
import {
  Plus,
  Refresh,
  Document,
  Clock,
  MoreFilled,
  Delete,
  View,
  ArrowDown,
  WarningFilled,
  MagicStick,
  Back,
  Check,
} from '@element-plus/icons-vue'
import { useIntelligenceStore } from '@/stores/intelligence'
import { storeToRefs } from 'pinia'
import axios from 'axios'

const router = useRouter()
const intelligenceStore = useIntelligenceStore()
const { topics, loading, collecting } = storeToRefs(intelligenceStore)

// Dialog states
const showAIDialog = ref(false)
const showQuickStartDialog = ref(false)
const showDeleteDialog = ref(false)
const showDeleteAllDialog = ref(false)

// AI Analysis state
const aiStep = ref<'input' | 'review'>('input')
const analyzing = ref(false)
const creating = ref(false)
const activeTab = ref('keywords')
const enableAISummary = ref(true)
const aiAnalysisResult = ref<any>({
  primary_keywords: [],
  expanded_keywords: [],
  topic_name: '',
  topic_description: '',
  schedule: 'daily',
  category: '',
  insights: [],
  recommended_sources: [],
})

const aiInputForm = ref({
  keywords: '',
  language: 'zh',
})

// Quick start form
const quickStartForm = ref({
  query: '',
  name: '',
})

// Delete state
const topicToDelete = ref<any>(null)
const deleting = ref(false)
const deleteAllConfirmText = ref('')
const collectingTopicIds = ref<string[]>([])

// Fetch topics
async function fetchTopics() {
  try {
    await intelligenceStore.fetchTopics()
  } catch (error) {
    ElMessage.error('加载情报主题失败')
  }
}

// Handle refresh
function handleRefresh() {
  fetchTopics()
}

// Start AI Analysis
function startAIAnalysis() {
  aiStep.value = 'input'
  aiInputForm.value = { keywords: '', language: 'zh' }
  aiAnalysisResult.value = {
    primary_keywords: [],
    expanded_keywords: [],
    topic_name: '',
    topic_description: '',
    schedule: 'daily',
    category: '',
    insights: [],
    recommended_sources: [],
  }
  enableAISummary.value = true
  showAIDialog.value = true
}

// Analyze keywords with AI
async function analyzeKeywords() {
  if (!aiInputForm.value.keywords.trim()) {
    ElMessage.warning('请输入关键词或描述')
    return
  }

  analyzing.value = true

  try {
    const response = await axios.post('/api/v1/intelligence/analyze-keywords', {
      keywords: aiInputForm.value.keywords,
      language: aiInputForm.value.language,
    })

    aiAnalysisResult.value = response.data
    aiStep.value = 'review'
    activeTab.value = 'keywords'

    ElMessage.success('AI分析完成！')
  } catch (error: any) {
    ElMessage.error(error.response?.data?.detail || 'AI分析失败')
  } finally {
    analyzing.value = false
  }
}

// Create topic from AI analysis
async function createTopicFromAI() {
  if (!aiAnalysisResult.value.primary_keywords?.length) {
    ElMessage.warning('请至少添加一个核心关键词')
    return
  }

  creating.value = true

  try {
    const response = await axios.post('/api/v1/intelligence/create-from-analysis', {
      keywords: aiInputForm.value.keywords,
      language: aiInputForm.value.language,
    })

    ElMessage.success('主题创建成功！')
    showAIDialog.value = false

    // 刷新列表
    await fetchTopics()

    // 跳转到详情页
    router.push({ name: 'IntelligenceDetail', params: { id: response.data.id } })
  } catch (error: any) {
    ElMessage.error(error.response?.data?.detail || '创建主题失败')
  } finally {
    creating.value = false
  }
}

// Quick start (传统方式)
async function handleQuickStart() {
  if (!quickStartForm.value.query) {
    ElMessage.warning('请输入搜索关键词')
    return
  }

  try {
    const topic = await intelligenceStore.quickStartTopic(
      quickStartForm.value.query,
      quickStartForm.value.name || undefined
    )

    ElMessage.success('情报主题创建成功')
    showQuickStartDialog.value = false

    // 重置表单
    quickStartForm.value = { query: '', name: '' }

    // 跳转到详情页
    router.push({ name: 'IntelligenceDetail', params: { id: topic.id } })
  } catch (error: any) {
    ElMessage.error(error.message || '创建主题失败')
  }
}

// View topic detail
function viewTopic(topicId: string) {
  router.push({ name: 'IntelligenceDetail', params: { id: topicId } })
}

// Collect intelligence
async function handleCollect(topic: any) {
  collectingTopicIds.value.push(topic.id)

  try {
    const response = await intelligenceStore.collectIntelligence(topic.id, false)

    ElMessage.success(
      `收集完成！新增 ${response.new_items} 条情报`
    )

    // 刷新主题状态
    await fetchTopics()
  } catch (error: any) {
    ElMessage.error(error.message || '情报收集失败')
  } finally {
    collectingTopicIds.value = collectingTopicIds.value.filter(
      id => id !== topic.id
    )
  }
}

// Handle card action (dropdown menu)
function handleCardAction(command: string, topic: any) {
  switch (command) {
    case 'collect':
      handleCollect(topic)
      break
    case 'view':
      viewTopic(topic.id)
      break
    case 'delete':
      showDeleteDialog.value = true
      topicToDelete.value = topic
      break
  }
}

// Confirm delete topic
async function confirmDelete() {
  if (!topicToDelete.value) return

  deleting.value = true

  try {
    await intelligenceStore.deleteTopic(topicToDelete.value.id)

    ElMessage.success('主题删除成功')
    showDeleteDialog.value = false
    topicToDelete.value = null
  } catch (error: any) {
    ElMessage.error(error.message || '删除主题失败')
  } finally {
    deleting.value = false
  }
}

// Handle batch action (page header dropdown)
function handleBatchAction(command: string) {
  switch (command) {
    case 'deleteAll':
      showDeleteAllDialog.value = true
      deleteAllConfirmText.value = ''
      break
  }
}

// Confirm delete all topics
async function confirmDeleteAll() {
  if (deleteAllConfirmText.value !== 'DELETE') {
    return
  }

  deleting.value = true

  try {
    const result = await intelligenceStore.deleteAllTopics()

    ElMessage.success(`已删除 ${result.count} 个主题`)
    showDeleteAllDialog.value = false
    deleteAllConfirmText.value = ''
  } catch (error: any) {
    ElMessage.error(error.message || '删除失败')
  } finally {
    deleting.value = false
  }
}

// Get schedule label
function getScheduleLabel(schedule: string) {
  const labels: Record<string, string> = {
    manual: '手动',
    hourly: '每小时',
    daily: '每天',
    weekly: '每周',
  }
  return labels[schedule] || schedule
}

// Format datetime
function formatDateTime(dateStr: string) {
  return new Date(dateStr).toLocaleString('zh-CN')
}

onMounted(() => {
  fetchTopics()
})
</script>

<style scoped>
.intelligence-topics {
  padding: 0;
}

.page-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 24px;
}

.page-title h1 {
  margin: 0;
  font-size: 24px;
  font-weight: 600;
}

.subtitle {
  margin: 4px 0 0;
  color: #666;
  font-size: 14px;
}

.page-actions {
  display: flex;
  gap: 8px;
}

.topic-card {
  margin-bottom: 16px;
  cursor: pointer;
  transition: transform 0.2s;
  position: relative;
}

.topic-card:hover {
  transform: translateY(-4px);
}

.card-actions {
  position: absolute;
  top: 12px;
  right: 12px;
  z-index: 10;
}

.topic-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 12px;
  padding-right: 40px; /* 为右上角按钮留空间 */
}

.topic-name {
  margin: 0;
  font-size: 18px;
  font-weight: 600;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.topic-keywords {
  margin-bottom: 12px;
}

.keyword-tag {
  margin-right: 4px;
  margin-bottom: 4px;
}

.more-keywords {
  font-size: 12px;
  color: #999;
}

.topic-stats {
  display: flex;
  gap: 16px;
  margin-bottom: 12px;
  padding: 8px 0;
  border-top: 1px solid #f0f0f0;
  border-bottom: 1px solid #f0f0f0;
}

.stat-item {
  display: flex;
  align-items: center;
  gap: 4px;
  font-size: 14px;
  color: #666;
}

.topic-actions {
  display: flex;
  gap: 8px;
  margin-top: 12px;
}

.last-run {
  margin-top: 8px;
}

/* AI Analysis Styles */
.ai-input-step,
.ai-review-step {
  padding: 8px 0;
}

.analysis-section {
  padding: 16px 0;
}

.section-desc {
  margin: 0 0 12px;
  font-weight: 500;
  color: #666;
}
</style>
