<template>
  <div class="prompt-monitoring" v-loading="loading">
    <el-page-header @back="handleBack" class="page-header">
      <template #content>
        <span class="header-title">
          <el-icon><TrendCharts /></el-icon>
          提示词性能监控
        </span>
      </template>
    </el-page-header>

    <!-- 统计概览 -->
    <el-row :gutter="20" class="stats-row">
      <el-col :span="6">
        <el-card class="stat-card">
          <el-statistic title="总提示词" :value="stats.totalPrompts" />
        </el-card>
      </el-col>
      <el-col :span="6">
        <el-card class="stat-card">
          <el-statistic title="活跃版本" :value="stats.activeVersions" />
        </el-card>
      </el-col>
      <el-col :span="6">
        <el-card class="stat-card">
          <el-statistic
            title="平均成功率"
            :value="stats.avgSuccessRate"
            suffix="%"
            :precision="1"
          />
        </el-card>
      </el-col>
      <el-col :span="6">
        <el-card class="stat-card">
          <el-statistic
            title="今日执行次数"
            :value="stats.todayExecutions"
          />
        </el-card>
      </el-col>
    </el-row>

    <!-- Top提示词 -->
    <el-card class="top-prompts-card" shadow="never">
      <template #header>
        <div class="card-header">
          <span class="card-title">
            <el-icon><Trophy /></el-icon>
            Top 提示词
          </span>
          <el-button type="primary" size="small" @click="refreshData">
            <el-icon><Refresh /></el-icon>
            刷新
          </el-button>
        </div>
      </template>

      <el-table :data="topPrompts" stripe>
        <el-table-column prop="prompt_id" label="提示词ID" width="200" />
        <el-table-column prop="avg_score" label="平均评分" width="120">
          <template #default="scope">
            <el-tag :type="getScoreType(scope.row.avg_score)">
              {{ scope.row.avg_score.toFixed(2) }}
            </el-tag>
          </template>
        </el-table-column>
        <el-table-column prop="total_count" label="使用次数" width="100" />
        <el-table-column prop="success_rate" label="成功率" width="100">
          <template #default="scope">
            {{ (scope.row.success_rate * 100).toFixed(1) }}%
          </template>
        </el-table-column>
        <el-table-column prop="last_updated" label="最后更新" />
      </el-table>
    </el-card>

    <!-- 详细统计 -->
    <el-row :gutter="20" class="detail-row">
      <!-- 按策略类型统计 -->
      <el-col :span="12">
        <el-card class="chart-card" shadow="never">
          <template #header>
            <span class="card-title">
              <el-icon><PieChart /></el-icon>
              按策略类型统计
            </span>
          </template>

          <div v-if="strategyStats.length > 0" class="strategy-stats">
            <div v-for="stat in strategyStats" :key="stat.type" class="strategy-item">
              <div class="strategy-header">
                <span class="strategy-name">{{ getStrategyLabel(stat.type) }}</span>
                <span class="strategy-count">{{ stat.count }} 个</span>
              </div>
              <el-progress
                :percentage="stat.percentage"
                :color="getStrategyColor(stat.type)"
                :show-text="false"
              />
            </div>
          </div>
          <el-empty v-else description="暂无数据" />
        </el-card>
      </el-col>

      <!-- 性能趋势 -->
      <el-col :span="12">
        <el-card class="chart-card" shadow="never">
          <template #header>
            <span class="card-title">
              <el-icon><DataLine /></el-icon>
              性能趋势
            </span>
          </template>

          <div class="trend-chart">
            <el-empty description="图表功能开发中..." />
            <!-- TODO: 集成ECharts显示趋势图 -->
          </div>
        </el-card>
      </el-col>
    </el-row>

    <!-- 演化建议 -->
    <el-card class="evolution-card" shadow="never">
      <template #header>
        <span class="card-title">
          <el-icon><MagicStick /></el-icon>
          演化建议
        </span>
      </template>

      <el-timeline>
        <el-timeline-item
          v-for="(suggestion, index) in evolutionSuggestions"
          :key="index"
          :timestamp="suggestion.timestamp"
          :type="suggestion.type"
        >
          <el-card>
            <h4>{{ suggestion.title }}</h4>
            <p>{{ suggestion.description }}</p>
            <div class="suggestion-actions">
              <el-tag v-if="suggestion.impact" :type="getImpactType(suggestion.impact)">
                {{ suggestion.impact }}
              </el-tag>
              <el-button size="small" type="primary" @click="handleSuggestion(suggestion)">
                查看详情
              </el-button>
            </div>
          </el-card>
        </el-timeline-item>
      </el-timeline>
    </el-card>
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted } from 'vue'
import { useRouter } from 'vue-router'
import { ElMessage } from 'element-plus'
import {
  TrendCharts,
  Trophy,
  Refresh,
  PieChart,
  DataLine,
  MagicStick
} from '@element-plus/icons-vue'
import intelligenceApi from '@/api/intelligence'

const router = useRouter()
const loading = ref(false)

// 统计数据
const stats = ref({
  totalPrompts: 0,
  activeVersions: 0,
  avgSuccessRate: 0,
  todayExecutions: 0
})

// Top提示词
const topPrompts = ref([])

// 策略统计
const strategyStats = ref([])

// 演化建议
const evolutionSuggestions = ref([
  {
    title: '财经分析提示词成功率下降',
    description: '检测到财经分析提示词的成功率从92%下降到85%，建议进行演化优化。',
    timestamp: '2小时前',
    type: 'warning',
    impact: 'high'
  },
  {
    title: '技术分析提示词v2.0可用',
    description: '新生成的技术分析提示词v2.0在测试中表现优异，建议部署到生产环境。',
    timestamp: '5小时前',
    type: 'success',
    impact: 'medium'
  }
])

// 加载数据
async function loadData() {
  loading.value = true

  try {
    // 获取提示词统计
    const statsResponse = await intelligenceApi.getPromptStats()

    if (statsResponse.success) {
      const promptStats = statsResponse.stats

      // 更新统计
      stats.value.totalPrompts = promptStats.length
      stats.value.activeVersions = promptStats.filter((p: any) => p.total_count > 0).length

      if (promptStats.length > 0) {
        const totalSuccess = promptStats.reduce((sum: number, p: any) => sum + p.success_rate, 0)
        stats.value.avgSuccessRate = (totalSuccess / promptStats.length) * 100
      }

      // Top提示词
      topPrompts.value = promptStats.map((p: any) => ({
        prompt_id: p.prompt_id.substring(0, 8) + '...',
        avg_score: p.total_count > 0 ? p.total_score / p.total_count : 0,
        total_count: p.total_count,
        success_rate: p.success_rate,
        last_updated: new Date(p.last_updated).toLocaleString('zh-CN')
      }))

      // 策略统计
      const strategyMap = new Map()
      promptStats.forEach((p: any) => {
        const type = p.prompt_id.split('_')[0] || 'unknown'
        strategyMap.set(type, (strategyMap.get(type) || 0) + 1)
      })

      const total = promptStats.length
      strategyStats.value = Array.from(strategyMap.entries()).map(([type, count]) => ({
        type,
        count,
        percentage: Math.round((count / total) * 100)
      }))
    }

  } catch (error: any) {
    console.error('Failed to load monitoring data:', error)
    ElMessage.error('加载数据失败')
  } finally {
    loading.value = false
  }
}

function refreshData() {
  loadData()
  ElMessage.success('数据已刷新')
}

function handleBack() {
  router.back()
}

function handleSuggestion(suggestion: any) {
  ElMessage.info(`查看建议: ${suggestion.title}`)
  // TODO: 跳转到详细页面
}

function getScoreType(score: number) {
  if (score >= 4.5) return 'success'
  if (score >= 3.5) return ''
  if (score >= 2.5) return 'warning'
  return 'danger'
}

function getStrategyLabel(type: string) {
  const labels: Record<string, string> = {
    'finance': '财经分析',
    'technology': '技术分析',
    'startup': '创业投资',
    'general': '通用分析'
  }
  return labels[type] || type
}

function getStrategyColor(type: string) {
  const colors: Record<string, string> = {
    'finance': '#409eff',
    'technology': '#67c23a',
    'startup': '#e6a23c',
    'general': '#909399'
  }
  return colors[type] || '#909399'
}

function getImpactType(impact: string) {
  if (impact === 'high') return 'danger'
  if (impact === 'medium') return 'warning'
  return 'info'
}

onMounted(() => {
  loadData()
})
</script>

<style scoped>
.prompt-monitoring {
  padding: 20px;
}

.page-header {
  margin-bottom: 20px;
}

.header-title {
  display: flex;
  align-items: center;
  gap: 8px;
  font-size: 20px;
  font-weight: 600;
}

.stats-row {
  margin-bottom: 20px;
}

.stat-card {
  text-align: center;
}

.top-prompts-card,
.chart-card,
.evolution-card {
  margin-bottom: 20px;
}

.card-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.card-title {
  display: flex;
  align-items: center;
  gap: 8px;
  font-weight: 600;
}

.detail-row {
  margin-bottom: 20px;
}

.strategy-stats {
  padding: 10px 0;
}

.strategy-item {
  margin-bottom: 16px;
}

.strategy-header {
  display: flex;
  justify-content: space-between;
  margin-bottom: 8px;
}

.strategy-name {
  font-weight: 500;
}

.strategy-count {
  color: #909399;
  font-size: 14px;
}

.trend-chart {
  height: 200px;
  display: flex;
  align-items: center;
  justify-content: center;
}

.suggestion-actions {
  display: flex;
  align-items: center;
  gap: 12px;
  margin-top: 12px;
}
</style>
