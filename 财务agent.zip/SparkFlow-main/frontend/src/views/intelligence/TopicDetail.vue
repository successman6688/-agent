<template>
  <div class="intelligence-detail" v-loading="loading">
    <div v-if="topic">
      <!-- Page Header -->
      <el-page-header @back="handleBack" class="page-header">
        <template #content>
          <div class="header-content">
            <span class="topic-name">{{ topic.name }}</span>
            <el-tag :type="topic.is_active ? 'success' : 'info'">
              {{ topic.is_active ? '激活' : '未激活' }}
            </el-tag>
          </div>
        </template>
        <template #extra>
          <div class="header-actions">
            <el-switch
              v-model="autoRefresh"
              active-text="自动刷新"
              @change="handleAutoRefreshChange"
              style="margin-right: 12px"
            />
            <el-text type="info" size="small" style="margin-right: 12px">
              更新于: {{ lastUpdateTime }}
            </el-text>
            <el-button
              :icon="Refresh"
              @click="manualRefresh"
              :loading="loading"
              circle
            />
            <el-button
              type="success"
              @click="goToMonitoring"
            >
              <el-icon><TrendCharts /></el-icon>
              性能监控
            </el-button>
            <el-button
              type="primary"
              @click="handleCollect"
              :loading="collecting"
            >
              <el-icon><Refresh /></el-icon>
              立即收集
            </el-button>
          </div>
        </template>
      </el-page-header>

      <!-- Topic Info -->
      <el-card class="info-card" shadow="never">
        <template #header>
          <span class="card-title">主题信息</span>
        </template>

        <el-descriptions :column="2" border>
          <el-descriptions-item label="关键词">
            <el-tag
              v-for="keyword in (topic.keywords || [])"
              :key="keyword"
              style="margin-right: 4px"
            >
              {{ keyword }}
            </el-tag>
          </el-descriptions-item>

          <el-descriptions-item label="更新频率">
            {{ getScheduleLabel(topic.schedule) }}
          </el-descriptions-item>

          <el-descriptions-item label="数据源" :span="2">
            {{ (topic.sources || []).map(s => s.name).join(', ') }}
          </el-descriptions-item>

          <el-descriptions-item label="总情报数">
            {{ topic.total_items }}
          </el-descriptions-item>

          <el-descriptions-item label="今日新增">
            {{ topic.today_items }}
          </el-descriptions-item>

          <el-descriptions-item label="最后运行" :span="2">
            {{ topic.last_run_time ? formatDateTime(topic.last_run_time) : '未运行' }}
          </el-descriptions-item>
        </el-descriptions>
      </el-card>

      <!-- Filters -->
      <el-card class="filter-card" shadow="never">
        <el-form :model="filters" inline>
          <el-form-item label="最小评分">
            <el-slider
              v-model="filters.minScore"
              :min="0"
              :max="1"
              :step="0.1"
              :marks="{ 0: '0', 0.5: '0.5', 1: '1' }"
              :format="(value) => `${(value * 100).toFixed(0)}%`"
              style="width: 200px"
              @change="handleFilter"
            />
          </el-form-item>

          <el-form-item label="数量">
            <el-select v-model="filters.limit" @change="handleFilter">
              <el-option :value="20" label="20条" />
              <el-option :value="50" label="50条" />
              <el-option :value="100" label="100条" />
            </el-select>
          </el-form-item>

          <el-form-item>
            <el-button type="primary" @click="handleFilter">筛选</el-button>
          </el-form-item>
        </el-form>
      </el-card>

      <!-- Intelligence Items -->
      <el-card class="items-card" shadow="never">
        <template #header>
          <div class="items-header">
            <span class="card-title">情报列表</span>
            <el-tag>{{ items.length }} 条</el-tag>
          </div>
        </template>

        <div v-if="items.length > 0">
          <div
            v-for="item in items"
            :key="item.id"
            class="intelligence-item"
            @click="openItem(item)"
          >
            <!-- Header -->
            <div class="item-header">
              <h4 class="item-title">{{ item.title }}</h4>

              <div class="item-scores">
                <el-tag
                  :type="getScoreType(item.overall_score)"
                  size="small"
                >
                  {{ (item.overall_score * 100).toFixed(0) }}%
                </el-tag>
              </div>
            </div>

            <!-- Content -->
            <div class="item-content">
              {{ truncateText(item.content, 200) }}
            </div>

            <!-- Meta -->
            <div class="item-meta">
              <el-text size="small" type="info">
                <el-icon><Link /></el-icon>
                {{ item.source }}
              </el-text>
              <el-text size="small" type="info">
                <el-icon><Clock /></el-icon>
                {{ formatDateTime(item.published_at) }}
              </el-text>
              <el-text size="small" type="info">
                <el-icon><Document /></el-icon>
                相关性: {{ (item.relevance_score * 100).toFixed(0) }}%
              </el-text>
            </div>

            <!-- AI Summary -->
            <div v-if="item.ai_summary" class="ai-summary">
              <div class="ai-summary-content">
                <el-text size="small" type="primary">
                  <el-icon><MagicStick /></el-icon>
                  AI总结:
                </el-text>
                <el-text size="small">{{ item.ai_summary }}</el-text>
              </div>

              <!-- Feedback Buttons -->
              <div class="feedback-section" @click.stop>
                <FeedbackButtons
                  :item-id="item.id"
                  :prompt-id="item.metadata?.analysis_details?.analysis_strategy || 'default'"
                  @feedback="handleFeedback(item.id, $event)"
                />
              </div>

              <!-- Priority Actions (如果有) -->
              <div v-if="item.key_insights && item.key_insights.length > 0" class="priority-actions">
                <el-divider content-position="left">
                  <el-text size="small" type="success">
                    <el-icon><Check /></el-icon>
                    立即行动
                  </el-text>
                </el-divider>
                <ul class="actions-list">
                  <li v-for="(action, idx) in (item.key_insights || []).slice(0, 3)" :key="idx">
                    <el-text size="small">{{ action }}</el-text>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>

        <!-- Empty State -->
        <el-empty
          v-else
          description="暂无情报数据，点击立即收集开始使用"
        >
          <el-button type="primary" @click="handleCollect">
            立即收集
          </el-button>
        </el-empty>
      </el-card>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted, onUnmounted } from 'vue'
import { useRouter, useRoute } from 'vue-router'
import { ElMessage } from 'element-plus'
import FeedbackButtons from '@/components/intelligence/FeedbackButtons.vue'
import {
  Refresh,
  Link,
  Check,
  Clock,
  Document,
  MagicStick,
  TrendCharts,
} from '@element-plus/icons-vue'
import { useIntelligenceStore } from '@/stores/intelligence'
import { storeToRefs } from 'pinia'
import { useWebSocket } from '@/utils/websocket'
import type { IntelligenceTopic, IntelligenceItem } from '@/types/intelligence'

const router = useRouter()
const route = useRoute()
const intelligenceStore = useIntelligenceStore()
const { loading, collecting } = storeToRefs(intelligenceStore)

const topic = ref<IntelligenceTopic | null>(null)
const items = ref<IntelligenceItem[]>([])
const ws = ref<ReturnType<typeof useWebSocket> | null>(null)

const filters = ref({
  minScore: 0.0,
  limit: 50,
})

const topicId = route.params.id as string

// 自动刷新相关
const autoRefresh = ref(false)
const lastUpdateTime = ref('刚刚')
const refreshTimer = ref<any>(null)
const AUTO_REFRESH_INTERVAL = 10000 // 10秒

// 更新最后更新时间
function updateLastUpdateTime() {
  const now = new Date()
  lastUpdateTime.value = now.toLocaleTimeString('zh-CN', { hour: '2-digit', minute: '2-digit', second: '2-digit' })
}

// 刷新所有数据
async function refreshAll() {
  await loadTopic()
  await loadItems()
  updateLastUpdateTime()
}

// 手动刷新
async function manualRefresh() {
  await refreshAll()
  ElMessage.success('数据已更新')
}

// 自动刷新开关
function handleAutoRefreshChange(enabled: boolean) {
  if (enabled) {
    // 启动自动刷新
    refreshAll()
    refreshTimer.value = setInterval(() => {
      refreshAll()
    }, AUTO_REFRESH_INTERVAL)
    ElMessage.info('已开启自动刷新（每10秒）')
  } else {
    // 停止自动刷新
    if (refreshTimer.value) {
      clearInterval(refreshTimer.value)
      refreshTimer.value = null
    }
    ElMessage.info('已关闭自动刷新')
  }
}

// Load topic
async function loadTopic() {
  try {
    topic.value = await intelligenceStore.getTopic(topicId)
  } catch (error: any) {
    ElMessage.error(error.message || '加载主题失败')
    router.back()
  }
}

// Load items
async function loadItems() {
  if (!topic.value) return

  try {
    items.value = await intelligenceStore.fetchTopicItems(
      topic.value.id,
      undefined, // date
      filters.value.limit,
      filters.value.minScore
    )
  } catch (error: any) {
    ElMessage.error(error.message || '加载情报失败')
  }
}

// Handle collect
async function handleCollect() {
  if (!topic.value) return

  try {
    await intelligenceStore.collectIntelligence(topic.value.id)

    // WebSocket 会在任务完成时自动显示结果并刷新数据
    // 这里不需要手动刷新或显示消息
  } catch (error: any) {
    ElMessage.error(error.message || '情报收集失败')
  }
}

// Handle filter
function handleFilter() {
  loadItems()
}

// Open item
function openItem(item: IntelligenceItem) {
  window.open(item.url, '_blank')
}

// Handle back
function handleBack() {
  router.back()
}

// Go to monitoring
function goToMonitoring() {
  router.push('/intelligence/' + topicId + '/monitoring')
}

// Handle feedback
function handleFeedback(itemId: string, type: string) {
  console.log('Feedback ' + type + ' submitted for item ' + itemId)
  // 可以在这里添加额外的逻辑，比如更新UI显示已反馈状态
}

// Get schedule label
function getScheduleLabel(schedule: string) {
  const labels: Record<string, string> = {
    manual: '手动',
    hourly: '每小时',
    daily: '每天',
    weekly: '每周',
  }
  return labels[schedule] || schedule
}

// Get score type for tag
function getScoreType(score: number) {
  if (score >= 0.8) return 'success'
  if (score >= 0.6) return 'info'
  if (score >= 0.4) return 'warning'
  return 'danger'
}

// Truncate text
function truncateText(text: string, maxLength: number) {
  if (text.length <= maxLength) return text
  return text.substring(0, maxLength) + '...'
}

// Format datetime
function formatDateTime(dateStr: string) {
  const date = new Date(dateStr)
  const now = new Date()
  const diff = now.getTime() - date.getTime()
  const hours = Math.floor(diff / (1000 * 60 * 60))

  if (hours < 1) {
    return '刚刚'
  } else if (hours < 24) {
    return hours + '小时前'
  } else {
    return date.toLocaleDateString('zh-CN')
  }
}

onMounted(async () => {
  await loadTopic()
  await loadItems()
  updateLastUpdateTime()

  // 连接 WebSocket
  if (topicId) {
    ws.value = useWebSocket(topicId)

    // 监听任务更新
    ws.value.on('task_update', async (message: any) => {
      console.log('📨 WebSocket 消息接收:', message)
      console.log('  - status:', message.status)
      console.log('  - result:', message.result)
      console.log('  - result 类型:', typeof message.result)

      if (message.status === 'completed') {
        // 任务完成，刷新数据
        await loadTopic()
        await loadItems()
        updateLastUpdateTime()

        // 安全获取 new_items - 更详细的日志
        console.log('🔍 开始解析 new_items...')
        let newItems = 0

        if (message.result) {
          console.log('  result 存在')

          if (typeof message.result === 'string') {
            console.log('  result 是字符串，尝试解析 JSON')
            try {
              const parsedResult = JSON.parse(message.result)
              console.log('  解析后的 result:', parsedResult)
              newItems = parsedResult.new_items || parsedResult['new_items'] || 0
            } catch (e) {
              console.error('  JSON 解析失败:', e)
            }
          } else if (typeof message.result === 'object') {
            console.log('  result 是对象')
            console.log('  - 直接访问 new_items:', message.result.new_items)
            console.log('  - 字符串访问 new_items:', message.result['new_items'])

            newItems = message.result.new_items || message.result['new_items'] || 0
          }
        }

        console.log('✅ 最终 newItems 值:', newItems)
        console.log('✅ 显示消息: 收集完成！新增', newItems, '条情报')
        ElMessage.success('收集完成！新增 ' + newItems + ' 条情报')
      } else if (message.status === 'failed') {
        // 任务失败
        const errorMsg = message.error || '未知错误'
        ElMessage.error('收集失败：' + errorMsg)
      } else if (message.status === 'running') {
        // 任务开始
        console.log('🔄 Task is running...')
      }
    })

    // 连接
    ws.value.connect()
  }
})

onUnmounted(() => {
  // 清理自动刷新定时器
  if (refreshTimer.value) {
    clearInterval(refreshTimer.value)
    refreshTimer.value = null
  }

  // 断开 WebSocket
  if (ws.value) {
    ws.value.disconnect()
    ws.value = null
  }
})
</script>

<style scoped>
.intelligence-detail {
  padding: 0;
}

.page-header {
  margin-bottom: 24px;
}

.header-content {
  display: flex;
  align-items: center;
  gap: 12px;
}

.topic-name {
  font-size: 20px;
  font-weight: 600;
}

.header-actions {
  display: flex;
  align-items: center;
  gap: 8px;
  flex-wrap: wrap;
}

.info-card,
.filter-card,
.items-card {
  margin-bottom: 16px;
}

.card-title {
  font-weight: 600;
}

.items-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.intelligence-item {
  padding: 16px;
  margin-bottom: 12px;
  border: 1px solid #f0f0f0;
  border-radius: 8px;
  cursor: pointer;
  transition: all 0.2s;
}

.intelligence-item:hover {
  border-color: #409eff;
  box-shadow: 0 2px 8px rgba(64, 158, 255, 0.1);
}

.item-header {
  display: flex;
  justify-content: space-between;
  align-items: flex-start;
  margin-bottom: 8px;
}

.item-title {
  margin: 0;
  font-size: 16px;
  font-weight: 600;
  flex: 1;
  padding-right: 12px;
}

.item-scores {
  flex-shrink: 0;
}

.item-content {
  color: #606266;
  font-size: 14px;
  line-height: 1.6;
  margin-bottom: 12px;
}

.item-meta {
  display: flex;
  gap: 16px;
  margin-bottom: 8px;
}

.ai-summary {
  padding: 12px;
  background: #f0f9ff;
  border-left: 3px solid #409eff;
  border-radius: 4px;
}

.ai-summary-content {
  margin-bottom: 12px;
}

.ai-summary-content .el-text {
  display: block;
  margin-bottom: 6px;
}

.feedback-section {
  margin-top: 12px;
  padding-top: 12px;
  border-top: 1px dashed #dcdfe6;
}

.priority-actions {
  margin-top: 12px;
  padding-top: 12px;
  border-top: 1px dashed #dcdfe6;
}

.actions-list {
  margin: 8px 0 0 0;
  padding-left: 20px;
}

.actions-list li {
  margin-bottom: 6px;
  color: #606266;
  font-size: 13px;
  line-height: 1.5;
}

.actions-list li:last-child {
  margin-bottom: 0;
}
</style>
