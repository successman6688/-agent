/**
 * Intelligence store using Pinia
 */

import { defineStore } from 'pinia'
import { ref, computed } from 'vue'
import { ElMessage } from 'element-plus'
import type {
  IntelligenceTopic,
  IntelligenceItem,
  IntelligenceReport,
  TopicCreate,
  CollectionResponse,
} from '@/types/intelligence'
import { intelligenceApi } from '@/api'

export const useIntelligenceStore = defineStore('intelligence', () => {
  // State
  const topics = ref<IntelligenceTopic[]>([])
  const currentTopic = ref<IntelligenceTopic | null>(null)
  const items = ref<IntelligenceItem[]>([])
  const currentReport = ref<IntelligenceReport | null>(null)
  const loading = ref(false)
  const collecting = ref(false)
  const error = ref<string | null>(null)

  // Computed
  const activeTopicsCount = computed(() =>
    topics.value.filter(t => t.is_active).length
  )

  // Actions
  async function fetchTopics() {
    loading.value = true
    error.value = null
    try {
      // 添加时间戳避免缓存
      const response = await intelligenceApi.listTopics()
      topics.value = response.data

      console.log(`✅ 已加载 ${topics.value.length} 个主题`, {
        topics: topics.value.map(t => ({
          name: t.name,
          total_items: t.total_items,
          today_items: t.today_items
        }))
      })
    } catch (err: any) {
      error.value = err.message || 'Failed to fetch topics'
      throw err
    } finally {
      loading.value = false
    }
  }

  async function createTopic(data: TopicCreate) {
    loading.value = true
    error.value = null
    try {
      const response = await intelligenceApi.createTopic(data)
      topics.value.unshift(response.data)
      return response.data
    } catch (err: any) {
      error.value = err.message || 'Failed to create topic'
      throw err
    } finally {
      loading.value = false
    }
  }

  async function quickStartTopic(query: string, name?: string) {
    loading.value = true
    error.value = null
    try {
      const response = await intelligenceApi.quickStartTopic(query, name)
      topics.value.unshift(response.data)
      return response.data
    } catch (err: any) {
      error.value = err.message || 'Failed to create topic'
      throw err
    } finally {
      loading.value = false
    }
  }

  async function getTopic(topicId: string) {
    loading.value = true
    error.value = null
    try {
      const response = await intelligenceApi.getTopic(topicId)
      currentTopic.value = response.data
      return response.data
    } catch (err: any) {
      error.value = err.message || 'Failed to fetch topic'
      throw err
    } finally {
      loading.value = false
    }
  }

  async function collectIntelligence(topicId: string, force = false) {
    collecting.value = true
    error.value = null
    try {
      // 调用异步收集接口，立即返回task_id
      const response = await intelligenceApi.collectIntelligence(topicId, force)
      const taskId = response.data.task_id

      console.log('Collection task created:', taskId)

      // 立即提示用户
      ElMessage.info('情报收集任务已启动，正在后台执行...')

      // WebSocket 会在任务完成时自动刷新数据
      return { task_id: taskId }
    } catch (err: any) {
      error.value = err.message || 'Failed to start collection'
      throw err
    } finally {
      collecting.value = false
    }
  }

  async function fetchTopicItems(
    topicId: string,
    date?: string,
    limit = 50,
    minScore = 0.0
  ) {
    loading.value = true
    error.value = null
    try {
      const response = await intelligenceApi.getTopicItems(
        topicId,
        date,
        limit,
        minScore
      )
      items.value = response.data
      return response.data
    } catch (err: any) {
      error.value = err.message || 'Failed to fetch items'
      throw err
    } finally {
      loading.value = false
    }
  }

  async function fetchLatestReport(topicId: string) {
    loading.value = true
    error.value = null
    try {
      const response = await intelligenceApi.getLatestReport(topicId)
      currentReport.value = response.data
      return response.data
    } catch (err: any) {
      error.value = err.message || 'Failed to fetch report'
      throw err
    } finally {
      loading.value = false
    }
  }

  async function deleteTopic(topicId: string) {
    loading.value = true
    error.value = null
    try {
      const response = await intelligenceApi.deleteTopic(topicId)

      // 从列表中移除
      topics.value = topics.value.filter(t => t.id !== topicId)

      // 清空当前主题（如果删除的是当前主题）
      if (currentTopic.value?.id === topicId) {
        currentTopic.value = null
      }

      return response.data
    } catch (err: any) {
      error.value = err.message || 'Failed to delete topic'
      throw err
    } finally {
      loading.value = false
    }
  }

  async function deleteAllTopics() {
    loading.value = true
    error.value = null
    try {
      const response = await intelligenceApi.deleteAllTopics()

      // 清空所有数据
      topics.value = []
      currentTopic.value = null
      items.value = []
      currentReport.value = null

      return response.data
    } catch (err: any) {
      error.value = err.message || 'Failed to delete all topics'
      throw err
    } finally {
      loading.value = false
    }
  }

  return {
    // State
    topics,
    currentTopic,
    items,
    currentReport,
    loading,
    collecting,
    error,

    // Computed
    activeTopicsCount,

    // Actions
    fetchTopics,
    createTopic,
    quickStartTopic,
    getTopic,
    collectIntelligence,
    fetchTopicItems,
    fetchLatestReport,
    deleteTopic,
    deleteAllTopics,
  }
})
