/**
 * Product store using Pinia
 */

import { defineStore } from 'pinia'
import { ref, computed } from 'vue'
import type { Product, ProductCreate, ProductUpdate, ProductFilters, ProductStats } from '@/types/product'
import { productApi } from '@/api'

export const useProductsStore = defineStore('products', () => {
  // State
  const products = ref<Product[]>([])
  const activeProduct = ref<Product | null>(null)
  const stats = ref<ProductStats | null>(null)
  const loading = ref(false)
  const error = ref<string | null>(null)

  // Computed
  const activeProductsCount = computed(() =>
    products.value.filter(p => p.status === 'active').length
  )

  const productById = computed(() => {
    return (id: string) => products.value.find(p => p.id === id)
  })

  const productsByType = computed(() => {
    return (type: string) => products.value.filter(p => p.type === type)
  })

  // Actions
  async function fetchProducts(filters?: ProductFilters) {
    loading.value = true
    error.value = null
    try {
      const response = await productApi.list(filters)
      products.value = response.data
    } catch (err: any) {
      error.value = err.message || 'Failed to fetch products'
      throw err
    } finally {
      loading.value = false
    }
  }

  async function fetchActiveProduct() {
    loading.value = true
    error.value = null
    try {
      const response = await productApi.getActive()
      activeProduct.value = response.data
    } catch (err: any) {
      error.value = err.message || 'Failed to fetch active product'
      throw err
    } finally {
      loading.value = false
    }
  }

  async function fetchProduct(id: string) {
    loading.value = true
    error.value = null
    try {
      const response = await productApi.get(id)
      const product = response.data

      // Update or add to list
      const index = products.value.findIndex(p => p.id === id)
      if (index >= 0) {
        products.value[index] = product
      } else {
        products.value.push(product)
      }

      return product
    } catch (err: any) {
      error.value = err.message || 'Failed to fetch product'
      throw err
    } finally {
      loading.value = false
    }
  }

  async function createProduct(data: ProductCreate) {
    loading.value = true
    error.value = null
    try {
      const response = await productApi.create(data)
      products.value.unshift(response.data)
      return response.data
    } catch (err: any) {
      error.value = err.message || 'Failed to create product'
      throw err
    } finally {
      loading.value = false
    }
  }

  async function updateProduct(id: string, data: ProductUpdate) {
    loading.value = true
    error.value = null
    try {
      const response = await productApi.update(id, data)
      const product = response.data

      // Update in list
      const index = products.value.findIndex(p => p.id === id)
      if (index >= 0) {
        products.value[index] = product
      }

      // Update active product if needed
      if (activeProduct.value?.id === id) {
        activeProduct.value = product
      }

      return product
    } catch (err: any) {
      error.value = err.message || 'Failed to update product'
      throw err
    } finally {
      loading.value = false
    }
  }

  async function deleteProduct(id: string) {
    loading.value = true
    error.value = null
    try {
      await productApi.delete(id)

      // Remove from list
      products.value = products.value.filter(p => p.id !== id)

      // Clear active product if needed
      if (activeProduct.value?.id === id) {
        activeProduct.value = null
      }
    } catch (err: any) {
      error.value = err.message || 'Failed to delete product'
      throw err
    } finally {
      loading.value = false
    }
  }

  async function activateProduct(id: string) {
    loading.value = true
    error.value = null
    try {
      const response = await productApi.activate(id)
      const product = response.data

      // Update active product
      activeProduct.value = product

      // Update product in list
      const index = products.value.findIndex(p => p.id === id)
      if (index >= 0) {
        products.value[index] = product
      }

      // Deactivate previous active product
      products.value.forEach(p => {
        if (p.id !== id && p.is_active) {
          p.is_active = false
          p.status = 'inactive' as any
        }
      })

      return product
    } catch (err: any) {
      error.value = err.message || 'Failed to activate product'
      throw err
    } finally {
      loading.value = false
    }
  }

  async function fetchStats() {
    loading.value = true
    error.value = null
    try {
      const response = await productApi.getStats()
      stats.value = response.data
    } catch (err: any) {
      error.value = err.message || 'Failed to fetch stats'
      throw err
    } finally {
      loading.value = false
    }
  }

  return {
    // State
    products,
    activeProduct,
    stats,
    loading,
    error,

    // Computed
    activeProductsCount,
    productById,
    productsByType,

    // Actions
    fetchProducts,
    fetchActiveProduct,
    fetchProduct,
    createProduct,
    updateProduct,
    deleteProduct,
    activateProduct,
    fetchStats,
  }
})
