/**
 * Global type definitions
 */

export interface ApiResponse<T> {
  data: T
  message?: string
}

export interface ApiError {
  error: string
  detail: string
}

export interface PaginationParams {
  limit?: number
  offset?: number
}

export interface ListResponse<T> {
  items: T[]
  total: number
  limit: number
  offset: number
}
