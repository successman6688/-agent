/**
 * Intelligence type definitions
 */

export enum SourceType {
  RSS = 'rss',
  API = 'api',
  WEB = 'web',
  CUSTOM = 'custom',
}

export enum ScheduleType {
  MANUAL = 'manual',
  HOURLY = 'hourly',
  DAILY = 'daily',
  WEEKLY = 'weekly',
}

export interface TopicConfig {
  max_items: number
  min_relevance: number
  enable_ai_summary: boolean
  languages: string[]
  ai_summary_threshold: number
  keyword_weight: number
  timeliness_weight: number
  authority_weight: number
}

export interface SourceConfig {
  type: SourceType
  name: string
  enabled: boolean
  url?: string
  query?: string
  base_url?: string
  endpoints?: Record<string, string>
  params?: Record<string, any>
  headers?: Record<string, string>
  update_interval?: number
}

export interface IntelligenceTopic {
  id: string
  name: string
  keywords: string[]
  sources: SourceConfig[]
  schedule: ScheduleType
  description?: string
  is_active: boolean
  last_run_time?: string
  last_status?: string
  total_items: number
  config: TopicConfig
  today_items: number
  weekly_items: number
  created_at: string
  updated_at: string
}

export interface IntelligenceItem {
  id: string
  topic_id: string
  title: string
  content: string
  url: string
  source: string
  author?: string
  published_at: string
  collected_at: string
  relevance_score: number
  timeliness_score: number
  authority_score: number
  overall_score: number
  ai_summary?: string
  key_insights: string[]
  tags: string[]
  guid?: string
  url_hash: string
  content_hash?: string
  embedding_id?: string
  metadata: Record<string, any>
}

export interface IntelligenceReport {
  id: string
  topic_id: string
  period_start: string
  period_end: string
  total_items: number
  new_items: number
  sources_breakdown: Record<string, number>
  summary?: string
  key_trends: string[]
  hot_topics: string[]
  sentiment?: string
  top_items: string[]
  created_at: string
}

export interface CollectionRequest {
  topic_id: string
  force_refresh?: boolean
}

export interface CollectionResponse {
  topic_id: string
  status: string
  total_collected: number
  new_items: number
  duration_seconds: number
  report_id?: string
  message?: string
}

export interface TopicCreate {
  name: string
  keywords: string[]
  sources: SourceConfig[]
  schedule: ScheduleType
  description?: string
  config?: TopicConfig
}

export interface TopicUpdate {
  name?: string
  keywords?: string[]
  sources?: SourceConfig[]
  schedule?: ScheduleType
  description?: string
  config?: TopicConfig
  is_active?: boolean
}
