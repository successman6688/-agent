/**
 * Product type definitions
 */

export enum ProductType {
  MINI_PROGRAM = 'mini_program',
  APP = 'app',
  WEBSITE = 'website',
  SAAS = 'saas',
  COURSE = 'course',
  PHYSICAL = 'physical',
  SERVICE = 'service',
  OTHER = 'other',
}

export enum ProductStatus {
  ACTIVE = 'active',
  INACTIVE = 'inactive',
  ARCHIVED = 'archived',
}

export enum PricingModel {
  FREE = 'free',
  ONE_TIME = 'one_time',
  SUBSCRIPTION = 'subscription',
  FREEMIUM = 'freemium',
}

export interface Product {
  id: string
  name: string
  type: ProductType
  description: string
  target_audience: string
  selling_points: string[]
  website_url?: string
  cta_text?: string
  cta_link?: string
  wechat_appid?: string
  wechat_path?: string
  app_store_url?: string
  google_play_url?: string
  yingyongbao_url?: string
  download_links: Record<string, string>
  price?: string
  pricing_model?: PricingModel
  category?: string
  tags: string[]
  status: ProductStatus
  is_active: boolean
  content_count: number
  publish_count: number
  created_at: string
  updated_at: string
}

export interface ProductCreate {
  name: string
  type: ProductType
  description: string
  target_audience: string
  selling_points?: string[]
  website_url?: string
  cta_text?: string
  cta_link?: string
  wechat_appid?: string
  wechat_path?: string
  app_store_url?: string
  google_play_url?: string
  yingyongbao_url?: string
  download_links?: Record<string, string>
  price?: string
  pricing_model?: PricingModel
  category?: string
  tags?: string[]
}

export interface ProductUpdate {
  name?: string
  type?: ProductType
  description?: string
  target_audience?: string
  selling_points?: string[]
  website_url?: string
  cta_text?: string
  cta_link?: string
  wechat_appid?: string
  wechat_path?: string
  app_store_url?: string
  google_play_url?: string
  yingyongbao_url?: string
  download_links?: Record<string, string>
  price?: string
  pricing_model?: PricingModel
  category?: string
  tags?: string[]
  status?: ProductStatus
}

export interface ProductFilters {
  type?: ProductType
  status?: ProductStatus
  category?: string
  tags?: string[]
  search?: string
}

export interface ProductStats {
  total: number
  active: number
  by_type: Record<string, number>
}

export interface ScrapeRequest {
  url: string
}

export interface ScrapeResponse {
  name?: string
  type?: string
  description?: string
  target_audience?: string
  selling_points?: string[]
  website_url?: string
  cta_text?: string
  cta_link?: string
  app_store_url?: string
  google_play_url?: string
  price?: string
  pricing_model?: string
  category?: string
  tags?: string[]
  metadata?: Record<string, any>
}
