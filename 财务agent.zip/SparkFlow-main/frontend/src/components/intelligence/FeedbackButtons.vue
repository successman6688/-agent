<template>
  <div class="feedback-buttons">
    <el-tooltip content="这个分析有帮助" placement="top">
      <el-button
        :type="feedback === 'thumbs_up' ? 'primary' : 'default'"
        :icon="Top"
        circle
        size="small"
        @click="handleFeedback('thumbs_up')"
        :loading="loading"
      />
    </el-tooltip>

    <el-tooltip content="这个分析没帮助" placement="top">
      <el-button
        :type="feedback === 'thumbs_down' ? 'danger' : 'default'"
        :icon="Bottom"
        circle
        size="small"
        @click="handleFeedback('thumbs_down')"
        :loading="loading"
      />
    </el-tooltip>

    <el-divider direction="vertical" />

    <el-tooltip content="建议有用" placement="top">
      <el-button
        :type="feedback === 'useful' ? 'success' : 'default'"
        :icon="CircleCheck"
        size="small"
        @click="handleFeedback('useful')"
        :loading="loading"
      >
        有用
      </el-button>
    </el-tooltip>

    <el-tooltip content="建议没用" placement="top">
      <el-button
        :type="feedback === 'not_useful' ? 'warning' : 'default'"
        :icon="CircleClose"
        size="small"
        @click="handleFeedback('not_useful')"
        :loading="loading"
      >
        没用
      </el-button>
    </el-tooltip>
  </div>
</template>

<script setup lang="ts">
import { ref } from 'vue'
import { Top, Bottom, CircleCheck, CircleClose } from '@element-plus/icons-vue'
import { ElMessage } from 'element-plus'
import { intelligenceApi } from '@/api/intelligence'

interface Props {
  itemId: string
  promptId?: string
}

const props = defineProps<Props>()

const feedback = ref<string | null>(null)
const loading = ref(false)

const emit = defineEmits<{
  feedback: [type: string]
}>()

const handleFeedback = async (type: string) => {
  // 如果已经点击过这个类型，取消
  if (feedback.value === type) {
    feedback.value = null
    return
  }

  loading.value = true

  try {
    await intelligenceApi.submitFeedback({
      item_id: props.itemId,
      prompt_id: props.promptId,
      feedback_type: type,
      value: true
    })

    feedback.value = type
    emit('feedback', type)

    ElMessage.success('感谢您的反馈！')

  } catch (error: any) {
    console.error('Failed to submit feedback:', error)
    ElMessage.error(error.message || '提交反馈失败')
  } finally {
    loading.value = false
  }
}
</script>

<style scoped>
.feedback-buttons {
  display: flex;
  align-items: center;
  gap: 8px;
}
</style>
