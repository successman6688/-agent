<template>
  <div class="rating-stars">
    <span class="rating-label">{{ label }}</span>

    <el-rate
      v-model="rating"
      :icons="icons"
      :void-icon="StarFilled"
      :colors="['#F7BA2A', '#F7BA2A', '#F7BA2A']"
      show-score
      :texts="texts"
      @change="handleRatingChange"
      :disabled="disabled"
    />

    <span v-if="showCount && totalRatings > 0" class="rating-count">
      ({{ totalRatings }} 人评分)
    </span>
  </div>
</template>

<script setup lang="ts">
import { ref, watch } from 'vue'
import { StarFilled } from '@element-plus/icons-vue'
import { ElMessage } from 'element-plus'
import intelligenceApi from '@/api/intelligence'

interface Props {
  itemId: string
  promptId?: string
  initialRating?: number
  label?: string
  disabled?: boolean
  showCount?: boolean
  totalRatings?: number
}

const props = withDefaults(defineProps<Props>(), {
  label: '评分',
  disabled: false,
  showCount: false,
  totalRatings: 0,
  initialRating: 0
})

const emit = defineEmits<{
  rating: [value: number]
}>()

const rating = ref(props.initialRating)
const hasRated = ref(false)
const submitting = ref(false)

const icons = [StarFilled, StarFilled, StarFilled]
const texts = ['极差', '失望', '一般', '满意', '惊喜']

watch(() => props.initialRating, (newVal) => {
  rating.value = newVal
})

const handleRatingChange = async (value: number) => {
  if (hasRated.value || submitting.value) {
    return
  }

  submitting.value = true

  try {
    await intelligenceApi.submitFeedback({
      item_id: props.itemId,
      prompt_id: props.promptId,
      feedback_type: 'rating',
      value: value
    })

    hasRated.value = true
    emit('rating', value)

    ElMessage.success('感谢您的评分！')

  } catch (error: any) {
    console.error('Failed to submit rating:', error)

    // 如果提交失败，重置评分
    rating.value = 0
    hasRated.value = false

    ElMessage.error(error.message || '提交评分失败')
  } finally {
    submitting.value = false
  }
}

// 暴露方法供父组件调用
defineExpose({
  reset: () => {
    rating.value = 0
    hasRated.value = false
  }
})
</script>

<style scoped>
.rating-stars {
  display: flex;
  align-items: center;
  gap: 12px;
}

.rating-label {
  font-size: 14px;
  color: #606266;
}

.rating-count {
  font-size: 12px;
  color: #909399;
}
</style>
