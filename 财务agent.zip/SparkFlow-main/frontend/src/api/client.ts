/**
 * Axios HTTP client configuration
 */

import axios from 'axios'
import type { AxiosInstance, AxiosError } from 'axios'
import { ElMessage } from 'element-plus'

const baseURL: string = import.meta.env.VITE_API_BASE_URL || '/api/v1'

export const client: AxiosInstance = axios.create({
  baseURL,
  timeout: 30000,
  headers: {
    'Content-Type': 'application/json',
    'Cache-Control': 'no-cache',
    'Pragma': 'no-cache',
  },
})

// Request interceptor
client.interceptors.request.use(
  (config) => {
    // Add auth token if available
    // const token = localStorage.getItem('token')
    // if (token) {
    //   config.headers.Authorization = `Bearer ${token}`
    // }
    return config
  },
  (error) => {
    return Promise.reject(error)
  }
)

// Response interceptor
client.interceptors.response.use(
  (response) => {
    return response
  },
  (error: AxiosError) => {
    const message = error.response?.data
      ? (error.response.data as any).detail || error.response.data as string
      : error.message

    ElMessage.error({
      message: message || '请求失败',
      duration: 5000,
    })

    return Promise.reject(error)
  }
)

export default client
