/**
 * Product scraping API endpoints
 */

import client from './client'
import type { ScrapeRequest, ScrapeResponse } from '@/types/product'

export const scrapeApi = {
  /**
   * Scrape product from URL (auto-detects source)
   */
  scrapeProduct: (data: ScrapeRequest) =>
    client.post<ScrapeResponse>('/scrape/product', data),

  /**
   * Scrape App Store app
   */
  scrapeAppStore: (data: ScrapeRequest) =>
    client.post<ScrapeResponse>('/scrape/app-store', data),

  /**
   * Scrape Google Play app
   */
  scrapeGooglePlay: (data: ScrapeRequest) =>
    client.post<ScrapeResponse>('/scrape/google-play', data),

  /**
   * Scrape website metadata
   */
  scrapeWebsite: (data: ScrapeRequest) =>
    client.post<ScrapeResponse>('/scrape/website', data),
}
