/**
 * Product API endpoints
 */

import client from './client'
import type {
  Product,
  ProductCreate,
  ProductUpdate,
  ProductFilters,
  ProductStats,
  PaginationParams,
} from '@/types/product'

export const productApi = {
  /**
   * Get product list with filters
   */
  list: (filters?: ProductFilters, params?: PaginationParams) =>
    client.get<Product[]>('/products', { params: { ...filters, ...params } }),

  /**
   * Get current active product
   */
  getActive: () =>
    client.get<Product>('/products/active/current'),

  /**
   * Get product by ID
   */
  get: (id: string) =>
    client.get<Product>(`/products/${id}`),

  /**
   * Create a new product
   */
  create: (data: ProductCreate) =>
    client.post<Product>('/products', data),

  /**
   * Update a product
   */
  update: (id: string, data: ProductUpdate) =>
    client.put<Product>(`/products/${id}`, data),

  /**
   * Delete a product
   */
  delete: (id: string) =>
    client.delete(`/products/${id}`),

  /**
   * Set product as active
   */
  activate: (id: string) =>
    client.post<Product>(`/products/${id}/activate`),

  /**
   * Clear active product
   */
  clearActive: () =>
    client.post('/products/active/clear'),

  /**
   * Get product statistics
   */
  getStats: () =>
    client.get<ProductStats>('/products/stats/overview'),
}
