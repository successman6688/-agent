/**
 * Intelligence API endpoints
 */

import client from './client'
import type {
  IntelligenceTopic,
  TopicCreate,
  TopicUpdate,
  IntelligenceItem,
  IntelligenceReport,
  CollectionResponse,
} from '@/types/intelligence'

export const intelligenceApi = {
  // Topic Management
  listTopics: () =>
    client.get<IntelligenceTopic[]>('/intelligence/topics', {
      params: { _t: Date.now() } // 时间戳避免缓存
    }),

  createTopic: (data: TopicCreate) =>
    client.post<IntelligenceTopic>('/intelligence/topics', data),

  getTopic: (id: string) =>
    client.get<IntelligenceTopic>(`/intelligence/topics/${id}`),

  updateTopic: (id: string, data: TopicUpdate) =>
    client.put<IntelligenceTopic>(`/intelligence/topics/${id}`, data),

  deleteTopic: (id: string) =>
    client.delete(`/intelligence/topics/${id}`),

  deleteAllTopics: () =>
    client.delete('/intelligence/topics'),

  // Collection
  collectIntelligence: (topicId: string, force = false) =>
    client.post<CollectionResponse>(
      `/intelligence/topics/${topicId}/collect`,
      null,
      { params: { force } }
    ),

  // Items
  getTopicItems: (
    topicId: string,
    date?: string,
    limit = 50,
    minScore = 0.0
  ) =>
    client.get<IntelligenceItem[]>(
      `/intelligence/topics/${topicId}/items`,
      { params: { date, limit, min_score: minScore } }
    ),

  getItem: (id: string) =>
    client.get<IntelligenceItem>(`/intelligence/items/${id}`),

  // Reports
  getLatestReport: (topicId: string) =>
    client.get<IntelligenceReport>(`/intelligence/topics/${topicId}/reports/latest`),

  // Quick Start
  quickStartTopic: (query: string, name?: string) =>
    client.post<IntelligenceTopic>(
      '/intelligence/quick-start',
      null,
      { params: { query, name } }
    ),

  // Feedback
  submitFeedback: (data: {
    item_id: string
    prompt_id?: string
    feedback_type: string
    value: any
  }) =>
    client.post('/intelligence/feedback', data),

  getPromptStats: () =>
    client.get('/intelligence/prompts/stats'),

  getTopPrompts: (limit = 5) =>
    client.get('/intelligence/prompts/top', { params: { limit } }),
}
