/**
 * Vue Router configuration
 */

import { createRouter, createWebHistory, type RouteRecordRaw } from 'vue-router'
import MainLayout from '@/layouts/MainLayout.vue'

const routes: RouteRecordRaw[] = [
  {
    path: '/',
    component: MainLayout,
    redirect: '/products',
    children: [
      {
        path: 'products',
        name: 'ProductList',
        component: () => import('@/views/products/ProductList.vue'),
        meta: { title: '产品列表' },
      },
      {
        path: 'products/new',
        name: 'ProductCreate',
        component: () => import('@/views/products/ProductForm.vue'),
        meta: { title: '创建产品' },
      },
      {
        path: 'products/:id',
        name: 'ProductDetail',
        component: () => import('@/views/products/ProductDetail.vue'),
        meta: { title: '产品详情' },
      },
      {
        path: 'products/:id/edit',
        name: 'ProductEdit',
        component: () => import('@/views/products/ProductForm.vue'),
        meta: { title: '编辑产品' },
      },
      {
        path: 'intelligence',
        name: 'IntelligenceList',
        component: () => import('@/views/intelligence/TopicList.vue'),
        meta: { title: '情报监控' },
      },
      {
        path: 'intelligence/:id',
        name: 'IntelligenceDetail',
        component: () => import('@/views/intelligence/TopicDetail.vue'),
        meta: { title: '情报详情' },
      },
      {
        path: 'intelligence/:id/monitoring',
        name: 'PromptMonitoring',
        component: () => import('@/views/intelligence/PromptMonitoring.vue'),
        meta: { title: '提示词监控' },
      },
      {
        path: 'topics',
        name: 'TopicList',
        component: () => import('@/views/topics/TopicList.vue'),
        meta: { title: '话题发现' },
      },
      {
        path: 'contents/generate',
        name: 'ContentGenerate',
        component: () => import('@/views/contents/ContentGenerate.vue'),
        meta: { title: '内容生成' },
      },
      {
        path: 'contents',
        name: 'ContentList',
        component: () => import('@/views/contents/ContentList.vue'),
        meta: { title: '内容管理' },
      },
      {
        path: 'publications',
        name: 'PublicationList',
        component: () => import('@/views/publications/PublicationList.vue'),
        meta: { title: '发布记录' },
      },
      {
        path: 'analytics',
        name: 'Analytics',
        component: () => import('@/views/analytics/Analytics.vue'),
        meta: { title: '数据分析' },
      },
    ],
  },
]

const router = createRouter({
  history: createWebHistory(),
  routes,
})

// Navigation guard to update page title
router.beforeEach((to, _from, next) => {
  const title = to.meta.title as string
  if (title) {
    document.title = `${title} - SparkFlow`
  }
  next()
})

export default router
