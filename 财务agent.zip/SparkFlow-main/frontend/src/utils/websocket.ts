/**
 * WebSocket 客户端
 */

export type TaskStatus = 'pending' | 'running' | 'completed' | 'failed'

export interface TaskMessage {
  type: string
  topic_id: string
  task_id: string
  status: TaskStatus
  result?: any
  error?: string
  timestamp?: string
}

export class WebSocketClient {
  private ws: WebSocket | null = null
  private reconnectTimer: any = null
  private reconnectAttempts = 0
  private maxReconnectAttempts = 5
  private reconnectDelay = 3000
  private messageHandlers: Map<string, (message: any) => void> = new Map()

  constructor(public url: string) {
    console.log('🔌 WebSocket Client initialized with URL:', url)
  }

  connect() {
    if (this.ws?.readyState === WebSocket.OPEN) {
      console.log('✅ WebSocket already connected')
      return
    }

    console.log('🔌 Connecting to WebSocket:', this.url)

    try {
      this.ws = new WebSocket(this.url)

      this.ws.onopen = () => {
        console.log('✅ WebSocket connected successfully')
        console.log('📡 URL:', this.url)
        console.log('📡 ReadyState:', this.ws?.readyState)
        this.reconnectAttempts = 0
      }

      this.ws.onmessage = (event) => {
        try {
          const rawMessage = event.data
          console.log('[WebSocket] 原始消息:', rawMessage)

          const message: TaskMessage = JSON.parse(rawMessage)
          console.log('[WebSocket] 解析后消息:', message)

          this.handleMessage(message)
        } catch (error) {
          console.error('[WebSocket] Error parsing message:', error)
          console.error('[WebSocket] 原始数据:', event.data)
        }
      }

      this.ws.onerror = (error) => {
        console.error('[WebSocket] Error event:', error)
        console.error('[WebSocket] ReadyState:', this.ws?.readyState)
      }

      this.ws.onclose = (event) => {
        console.log('[WebSocket] Disconnected')
        console.log('  - code:', event.code)
        console.log('  - reason:', event.reason)
        console.log('  - wasClean:', event.wasClean)
        this.attemptReconnect()
      }
    } catch (error) {
      console.error('Error creating WebSocket:', error)
      this.attemptReconnect()
    }
  }

  disconnect() {
    if (this.reconnectTimer) {
      clearTimeout(this.reconnectTimer)
      this.reconnectTimer = null
    }

    if (this.ws) {
      this.ws.close()
      this.ws = null
    }
  }

  private attemptReconnect() {
    if (this.reconnectAttempts >= this.maxReconnectAttempts) {
      console.error('Max reconnect attempts reached')
      return
    }

    this.reconnectAttempts++

    console.log(`Attempting to reconnect (${this.reconnectAttempts}/${this.maxReconnectAttempts})...`)

    this.reconnectTimer = setTimeout(() => {
      this.connect()
    }, this.reconnectDelay)
  }

  private handleMessage(message: TaskMessage) {
    const handler = this.messageHandlers.get(message.type)

    if (handler) {
      handler(message)
    }

    // 通用处理函数
    const defaultHandler = this.messageHandlers.get('*')
    if (defaultHandler) {
      defaultHandler(message)
    }
  }

  on(event: string, handler: (message: any) => void) {
    this.messageHandlers.set(event, handler)
  }

  off(event: string) {
    this.messageHandlers.delete(event)
  }

  send(data: any) {
    if (this.ws?.readyState === WebSocket.OPEN) {
      this.ws.send(JSON.stringify(data))
    } else {
      console.warn('WebSocket is not connected')
    }
  }
}

let wsClient: WebSocketClient | null = null

export function useWebSocket(topicId: string) {
  const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:'

  // 开发环境：直接连接后端（不走代理）
  // 生产环境：使用当前域名
  let host: string
  if (import.meta.env.DEV) {
    host = 'localhost:8000'
  } else {
    // 生产环境从 location 获取
    host = window.location.host
  }

  const url = `${protocol}//${host}/api/v1/intelligence/ws/topics/${topicId}`

  console.log('🌐 WebSocket URL 生成:')
  console.log('  protocol:', protocol)
  console.log('  host:', host)
  console.log('  topicId:', topicId)
  console.log('  完整URL:', url)

  // 每次都创建新客户端，避免单例模式的问题
  const client = new WebSocketClient(url)

  return {
    connect: () => client.connect(),
    disconnect: () => client.disconnect(),
    on: (event: string, handler: (message: any) => void) => client.on(event, handler),
    off: (event: string) => client.off(event),
    send: (data: any) => client.send(data)
  }
}
