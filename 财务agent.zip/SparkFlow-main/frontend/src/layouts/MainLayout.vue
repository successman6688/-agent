<template>
  <el-container class="main-layout">
    <!-- Sidebar -->
    <el-aside width="240px" class="sidebar">
      <div class="logo">
        <h2>SparkFlow</h2>
        <p class="tagline">AI营销自动化</p>
      </div>

      <el-menu
        :default-active="activeMenu"
        router
        class="nav-menu"
      >
        <el-menu-item index="/products">
          <el-icon><Box /></el-icon>
          <span>产品管理</span>
        </el-menu-item>

        <el-menu-item index="/intelligence">
          <el-icon><Monitor /></el-icon>
          <span>情报监控</span>
        </el-menu-item>

        <el-menu-item index="/topics">
          <el-icon><Compass /></el-icon>
          <span>话题发现</span>
        </el-menu-item>

        <el-menu-item index="/contents/generate">
          <el-icon><MagicStick /></el-icon>
          <span>内容生成</span>
        </el-menu-item>

        <el-menu-item index="/contents">
          <el-icon><Document /></el-icon>
          <span>内容管理</span>
        </el-menu-item>

        <el-menu-item index="/publications">
          <el-icon><Promotion /></el-icon>
          <span>发布记录</span>
        </el-menu-item>

        <el-menu-item index="/analytics">
          <el-icon><DataAnalysis /></el-icon>
          <span>数据分析</span>
        </el-menu-item>
      </el-menu>

      <!-- Active Product Display -->
      <div v-if="activeProduct" class="active-product">
        <div class="active-product-header">
          <el-icon class="icon"><Star /></el-icon>
          <span>当前产品</span>
        </div>
        <div class="active-product-info">
          <div class="product-name">{{ activeProduct.name }}</div>
          <el-tag size="small" type="success">激活</el-tag>
        </div>
      </div>
    </el-aside>

    <!-- Main Content -->
    <el-container>
      <el-header class="header">
        <div class="header-left">
          <el-breadcrumb separator="/">
            <el-breadcrumb-item :to="{ path: '/' }">首页</el-breadcrumb-item>
            <el-breadcrumb-item v-if="currentRouteMeta.title">
              {{ currentRouteMeta.title }}
            </el-breadcrumb-item>
          </el-breadcrumb>
        </div>
        <div class="header-right">
          <el-button text @click="handleRefresh">
            <el-icon><Refresh /></el-icon>
          </el-button>
        </div>
      </el-header>

      <el-main class="main-content">
        <router-view v-slot="{ Component }">
          <transition name="fade" mode="out-in">
            <component :is="Component" />
          </transition>
        </router-view>
      </el-main>
    </el-container>
  </el-container>
</template>

<script setup lang="ts">
import { computed, onMounted } from 'vue'
import { useRoute } from 'vue-router'
import { useProductsStore } from '@/stores/products'
import {
  Box,
  Compass,
  MagicStick,
  Document,
  Promotion,
  DataAnalysis,
  Star,
  Refresh,
  Monitor,
} from '@element-plus/icons-vue'

const route = useRoute()
const productsStore = useProductsStore()

const activeMenu = computed(() => route.path)
const currentRouteMeta = computed(() => route.meta)
const activeProduct = computed(() => productsStore.activeProduct)

const handleRefresh = () => {
  // Refresh current route
  window.location.reload()
}

onMounted(async () => {
  // Load active product on mount
  try {
    await productsStore.fetchActiveProduct()
  } catch (error) {
    console.error('Failed to load active product:', error)
  }
})
</script>

<style scoped>
.main-layout {
  height: 100vh;
}

.sidebar {
  background: #001529;
  color: #fff;
  display: flex;
  flex-direction: column;
}

.logo {
  padding: 24px 20px;
  text-align: center;
  border-bottom: 1px solid rgba(255, 255, 255, 0.1);
}

.logo h2 {
  margin: 0;
  font-size: 24px;
  font-weight: 600;
  color: #fff;
}

.logo .tagline {
  margin: 4px 0 0;
  font-size: 12px;
  color: rgba(255, 255, 255, 0.65);
}

.nav-menu {
  flex: 1;
  border: none;
  background: transparent;
}

.nav-menu .el-menu-item {
  color: rgba(255, 255, 255, 0.85);
}

.nav-menu .el-menu-item:hover {
  background: rgba(255, 255, 255, 0.08);
}

.nav-menu .el-menu-item.is-active {
  background: #1890ff;
}

.active-product {
  padding: 16px;
  border-top: 1px solid rgba(255, 255, 255, 0.1);
  background: rgba(255, 255, 255, 0.05);
}

.active-product-header {
  display: flex;
  align-items: center;
  gap: 8px;
  margin-bottom: 8px;
  font-size: 12px;
  color: rgba(255, 255, 255, 0.65);
}

.active-product-header .icon {
  color: #fadb14;
}

.active-product-info {
  display: flex;
  align-items: center;
  justify-content: space-between;
}

.product-name {
  font-size: 14px;
  font-weight: 500;
  color: #fff;
}

.header {
  background: #fff;
  border-bottom: 1px solid #f0f0f0;
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 0 24px;
}

.main-content {
  background: #f0f2f5;
  overflow-y: auto;
}

/* Transition */
.fade-enter-active,
.fade-leave-active {
  transition: opacity 0.2s ease;
}

.fade-enter-from,
.fade-leave-to {
  opacity: 0;
}
</style>
