# 🚀 SparkFlow

**AI-Powered Marketing Automation Platform**

SparkFlow 是一个通用的 AI 营销自动化平台，帮助个人开发者、创业者和企业自动化营销内容生产和多平台发布。

## ✨ 核心功能

- 🔥 **智能监控** - 自动发现与你产品相关的热点话题
- 🤖 **内容生成** - AI 自动生成高质量的营销内容
- 🚀 **多平台发布** - 一键发布到 Twitter、Reddit、博客等多个平台
- 📊 **数据分析** - 追踪效果，持续优化策略
- ⚙️ **产品配置** - 灵活配置你的产品信息和卖点

## 🛠️ 技术栈

### 后端
- **框架**: FastAPI + Python 3.11+
- **AI/ML**: Anthropic Claude + LangChain + LangGraph
- **数据库**: PostgreSQL + Redis + ChromaDB
- **集成**: Twitter API, Reddit API

### 前端
- **框架**: Vue 3 + TypeScript
- **构建工具**: Vite
- **UI组件库**: Element Plus
- **状态管理**: Pinia
- **路由**: Vue Router 4

## 📦 快速开始

### 方式 1: Docker (推荐)

```bash
# 启动所有服务
docker-compose up -d

# 查看日志
docker-compose logs -f

# 停止服务
docker-compose down
```

访问：
- 前端: http://localhost
- 后端 API: http://localhost:8000
- API 文档: http://localhost:8000/docs

### 方式 2: 本地开发

#### 1. 克隆项目

```bash
git clone <your-repo-url>
cd SparkFlow
```

#### 2. 后端设置

```bash
# 创建虚拟环境
python3 -m venv venv
source venv/bin/activate  # Linux/Mac

# 安装依赖
pip install -r requirements.txt

# 配置环境变量
cp .env.example .env
# 编辑 .env 文件，添加必要的 API keys

# 启动后端服务
python main.py
```

后端将在 http://localhost:8000 启动

#### 3. 前端设置

```bash
# 进入前端目录
cd frontend

# 安装依赖
npm install

# 配置环境变量（已包含默认配置）
# .env 文件已配置为指向本地后端

# 启动开发服务器
npm run dev
```

前端将在 http://localhost:5173 启动

## 📖 使用指南

### 第一步：配置产品信息

1. 打开 Web 界面
2. 进入 **产品管理** 页面
3. 点击 **添加产品**
4. 填写产品信息：
   - 产品名称、类型、描述
   - 目标用户
   - 产品卖点
   - 营销信息（CTA文本、链接等）
   - 平台信息（App Store、Google Play等）

### 第二步：激活产品

1. 在产品列表中找到你要营销的产品
2. 点击 **激活** 按钮
3. 激活后的产品将用于内容生成

### 第三步：发现热点话题（开发中）

1. 进入 **话题发现** 页面
2. 查看系统发现的热点话题
3. 筛选与你的产品相关的话题

### 第四步：生成营销内容（开发中）

1. 进入 **内容生成** 页面
2. 选择一个热点话题
3. 选择目标平台（Twitter、Reddit、Blog）
4. AI 自动生成多个内容版本

### 第五步：发布内容（开发中）

1. 进入 **发布记录** 页面
2. 查看待发布内容
3. 一键发布或定时发布

### 第六步：分析效果（开发中）

1. 进入 **数据分析** 页面
2. 查看各平台数据
3. 分析哪些内容效果好

## 🗂️ 项目结构

```
SparkFlow/
├── app/                         # 后端应用
│   ├── api/                     # API 路由
│   │   └── v1/
│   │       ├── router.py        # 路由聚合
│   │       └── endpoints/       # API 端点
│   │           ├── products.py  # 产品 API
│   │           └── scrape.py    # 抓取 API
│   ├── agents/                  # Agent 实现（待实现）
│   ├── core/                    # 核心配置
│   │   ├── config.py            # 设置管理
│   │   └── logging.py           # 日志配置
│   ├── integrations/            # 平台集成
│   │   ├── llm/                 # LLM 集成
│   │   ├── twitter/             # Twitter 集成
│   │   └── reddit/              # Reddit 集成
│   ├── models/                  # 数据模型
│   │   ├── product.py           # 产品模型
│   │   └── content.py           # 内容模型
│   ├── services/                # 业务服务
│   │   ├── product_service.py   # 产品服务
│   │   └── product_scraper.py   # 产品抓取
│   └── web/                     # Streamlit Web UI (旧版)
│
├── frontend/                    # Vue3 前端应用
│   ├── src/
│   │   ├── api/                 # API 客户端
│   │   │   ├── client.ts        # Axios 配置
│   │   │   ├── products.ts      # 产品 API
│   │   │   └── scrape.ts        # 抓取 API
│   │   ├── components/          # 公共组件（待实现）
│   │   ├── layouts/             # 布局组件
│   │   │   └── MainLayout.vue   # 主布局
│   │   ├── router/              # 路由配置
│   │   │   └── index.ts         # 路由定义
│   │   ├── stores/              # Pinia 状态管理
│   │   │   └── products.ts      # 产品 store
│   │   ├── types/               # TypeScript 类型
│   │   │   ├── product.ts       # 产品类型
│   │   │   └── index.ts         # 通用类型
│   │   ├── views/               # 页面视图
│   │   │   ├── products/        # 产品页面
│   │   │   ├── topics/          # 话题页面
│   │   │   ├── contents/        # 内容页面
│   │   │   ├── publications/    # 发布页面
│   │   │   └── analytics/       # 分析页面
│   │   ├── App.vue              # 根组件
│   │   └── main.ts              # 入口文件
│   ├── package.json             # 前端依赖
│   ├── vite.config.ts           # Vite 配置
│   └── tsconfig.json            # TypeScript 配置
│
├── data/                        # 数据存储
├── docs/                        # 项目文档
├── scripts/                     # 工具脚本
├── main.py                      # FastAPI 入口
├── docker-compose.yml           # Docker Compose 配置
├── Dockerfile                   # Docker 镜像配置
├── requirements.txt             # Python 依赖
├── .env.example                 # 环境变量示例
└── README.md                    # 项目说明
```

## 🔌 API 文档

启动后端服务后，访问 http://localhost:8000/docs 查看完整的 API 文档。

### 主要 API 端点

#### 产品管理
- `GET /api/v1/products` - 获取产品列表
- `POST /api/v1/products` - 创建产品
- `GET /api/v1/products/{id}` - 获取产品详情
- `PUT /api/v1/products/{id}` - 更新产品
- `DELETE /api/v1/products/{id}` - 删除产品
- `POST /api/v1/products/{id}/activate` - 激活产品
- `GET /api/v1/products/active/current` - 获取当前激活产品
- `GET /api/v1/products/stats/overview` - 获取产品统计

#### 产品抓取
- `POST /api/v1/scrape/product` - 抓取产品信息（自动识别来源）
- `POST /api/v1/scrape/app-store` - 抓取 App Store 应用
- `POST /api/v1/scrape/google-play` - 抓取 Google Play 应用
- `POST /api/v1/scrape/website` - 抓取网站信息

## 🔧 开发路线图

### ✅ 已完成
- [x] 项目框架搭建
- [x] FastAPI 后端架构
- [x] Vue3 + TypeScript 前端架构
- [x] 产品管理功能（完整 CRUD）
- [x] 产品信息抓取功能
- [x] RESTful API 设计
- [x] Docker 部署配置

### 🚧 开发中
- [ ] 话题发现功能
- [ ] AI 内容生成功能
- [ ] 多平台发布功能
- [ ] 数据分析功能

### 🚀 计划中
- [ ] 用户认证和权限管理
- [ ] 内容编辑器
- [ ] 定时发布
- [ ] A/B 测试
- [ ] 更多平台集成（LinkedIn、Medium等）

## 🧪 测试

```bash
# 测试后端 API
python -m pytest tests/

# 测试前端
cd frontend
npm run test
```

## 📝 常见问题

### Q: 如何切换到不同的 LLM 提供商？
A: 编辑 `.env` 文件，设置 `API_TYPE` 为 `openai` 或 `anthropic`，并配置相应的 API keys。

### Q: 前端无法连接后端？
A: 确保：
1. 后端服务正在运行 (http://localhost:8000)
2. 检查 `frontend/.env` 中的 `VITE_API_BASE_URL` 配置
3. 检查后端 CORS 配置是否允许前端域名

### Q: 如何部署到生产环境？
A: 使用 Docker Compose：
```bash
docker-compose -f docker-compose.yml up -d
```
或单独部署前后端服务，配置 nginx 反向代理。

## 🤝 贡献

欢迎贡献！请随时提交 Issue 或 Pull Request。

## 📄 许可证

MIT License

---

**用 AI 自动化你的营销，让增长更简单！** 🚀
