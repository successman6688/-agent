"""FastAPI application entry point."""

from contextlib import asynccontextmanager
from typing import AsyncGenerator

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse

from app.core.config import settings
from app.core.logging import get_logger
from app.api.v1.router import api_router

logger = get_logger(__name__)


@asynccontextmanager
async def lifespan(app: FastAPI) -> AsyncGenerator:
    """Application lifespan manager."""
    # Startup
    logger.info("Starting SparkFlow API...")
    logger.info(f"Environment: {settings.APP_ENV}")
    logger.info(f"Debug mode: {settings.APP_DEBUG}")

    # Ensure data directory exists
    from pathlib import Path
    data_dir = Path("data")
    data_dir.mkdir(exist_ok=True)

    # Initialize all databases (PostgreSQL, Redis, ChromaDB)
    from app.db.connection import init_all_databases
    try:
        await init_all_databases()
        logger.info("All databases initialized successfully")
    except Exception as e:
        logger.warning(f"Database initialization failed (continuing): {e}")

    # Product service now uses database, no need to initialize global singleton

    yield

    # Shutdown
    logger.info("Shutting down SparkFlow API...")

    # Close all database connections
    from app.db.connection import close_all_databases
    try:
        await close_all_databases()
    except Exception as e:
        logger.warning(f"Error closing databases: {e}")


# Create FastAPI application
app = FastAPI(
    title="SparkFlow API",
    description="AI-powered marketing automation platform",
    version="1.0.0",
    docs_url="/docs",
    redoc_url="/redoc",
    openapi_url="/openapi.json",
    lifespan=lifespan,
)


# CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        "http://localhost:5173",  # Vite dev server
        "http://localhost:3000",  # Alternative frontend port
        "http://127.0.0.1:5173",
        "http://127.0.0.1:3000",
    ],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


# Include API router
app.include_router(api_router, prefix="/api/v1")


# Root endpoint
@app.get("/")
async def root() -> dict:
    """Root endpoint."""
    return {
        "message": "SparkFlow API",
        "version": "1.0.0",
        "docs": "/docs",
        "status": "healthy"
    }


# Health check
@app.get("/health")
async def health_check() -> dict:
    """Health check endpoint."""
    return {"status": "healthy"}


# Global exception handlers
@app.exception_handler(ValueError)
async def value_error_handler(request, exc):
    """Handle ValueError exceptions."""
    return JSONResponse(
        status_code=400,
        content={"error": "Bad Request", "detail": str(exc)}
    )


@app.exception_handler(KeyError)
async def key_error_handler(request, exc):
    """Handle KeyError exceptions."""
    return JSONResponse(
        status_code=404,
        content={"error": "Not Found", "detail": f"Resource not found: {str(exc)}"}
    )


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(
        "main:app",
        host="0.0.0.0",
        port=settings.APP_PORT,
        reload=settings.APP_DEBUG,
        log_level=settings.LOG_LEVEL.lower()
    )
