# 产品管理功能设计

## 一、需求分析

### 核心需求
1. **多产品支持** - 用户可以添加和管理多个产品
2. **产品类型** - 小程序、APP、网站、SaaS、课程、实体商品等
3. **完整的产品管理** - 增删改查（CRUD）
4. **产品激活** - 可以选择当前激活的产品进行营销

### 产品信息字段

#### 基础信息
- 产品名称*（必填）
- 产品类型*（必填）
- 产品描述*（必填）
- 目标用户*（必填）

#### 产品类型枚举
```
- 小程序 (Mini Program)
- APP (移动应用)
- 网站 (Website)
- SaaS (软件服务)
- 课程 (Course)
- 实体商品 (Physical Product)
- 服务 (Service)
- 其他 (Other)
```

#### 营销信息
- 产品卖点（多行文本）
- 网站/下载链接
- CTA 文本
- CTA 链接
- 价格信息（可选）

#### 分类标签
- 产品分类
- 标签（逗号分隔）

#### 平台账号
- 微信小程序 AppID
- App Store 链接
- Google Play 链接
- 官网链接

#### 状态管理
- 是否激活（用于当前营销）
- 创建时间
- 更新时间

---

## 二、数据模型设计

```python
class ProductType(str, Enum):
    """产品类型枚举"""
    MINI_PROGRAM = "mini_program"      # 小程序
    APP = "app"                        # APP
    WEBSITE = "website"                # 网站
    SAAS = "saas"                      # SaaS
    COURSE = "course"                  # 课程
    PHYSICAL = "physical"              # 实体商品
    SERVICE = "service"                # 服务
    OTHER = "other"                    # 其他

class ProductStatus(str, Enum):
    """产品状态"""
    ACTIVE = "active"                  # 激活（用于营销）
    INACTIVE = "inactive"              # 未激活
    ARCHIVED = "archived"              # 已归档

class Product(BaseModel):
    """产品模型"""
    # 基础信息
    id: str
    name: str
    type: ProductType
    description: str
    target_audience: str

    # 营销信息
    selling_points: List[str]
    website_url: Optional[str]
    download_links: Dict[str, str]     # 各平台下载链接
    cta_text: Optional[str]
    cta_link: Optional[str]

    # 价格信息
    price: Optional[str]
    pricing_model: Optional[str]       # 免费/付费/订阅/一次性

    # 分类标签
    category: Optional[str]
    tags: List[str]

    # 状态
    status: ProductStatus
    is_active: bool                    # 是否当前激活

    # 时间戳
    created_at: datetime
    updated_at: datetime
```

---

## 三、产品管理功能设计

### 3.1 产品列表页面

**功能**：
- 显示所有产品（卡片/列表视图）
- 筛选：按类型、状态、标签
- 搜索：按名称搜索
- 排序：按创建时间、更新时间
- 快速操作：激活/停用、编辑、删除

**布局**：
```
┌────────────────────────────────────────────────────────┐
│  产品管理                                   [+ 添加产品] │
├────────────────────────────────────────────────────────┤
│  [全部] [小程序] [APP] [网站] [SaaS] [课程]            │
│  🔍 搜索产品...                        排序: 最新 │
├────────────────────────────────────────────────────────┤
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐ │
│  │ SparkFlow    │  │ 儿童学习App  │  │ Python课程   │ │
│  │ SaaS         │  │ APP         │  │ 课程         │ │
│  │ ✓ 激活       │  │             │  │              │ │
│  │ [编辑][删除] │  │ [编辑][删除] │  │ [编辑][删除] │ │
│  └──────────────┘  └──────────────┘  └──────────────┘ │
└────────────────────────────────────────────────────────┘
```

### 3.2 添加/编辑产品页面

**表单分页**：

#### 第一步：基础信息
- 产品名称*
- 产品类型*（下拉选择）
- 产品描述*
- 目标用户*

#### 第二步：营销信息
- 产品卖点（每行一个）
- 网站/官方链接
- CTA 文本
- CTA 链接

#### 第三步：平台信息（根据产品类型动态显示）
**小程序**：
- 微信小程序 AppID
- 小程序路径

**APP**：
- App Store 链接
- Google Play 链接
- 应用宝链接

**网站/SaaS**：
- 官网链接
- 注册链接

**课程**：
- 课程平台（网易云课堂、腾讯课堂等）
- 课程链接

#### 第四步：价格信息（可选）
- 价格
- 定价模式（免费/付费/订阅/一次性）

#### 第五步：分类标签
- 产品分类
- 标签（逗号分隔）

### 3.3 产品详情页面

**显示内容**：
- 产品基本信息
- 营销统计（为该产品生成的内容数、发布数等）
- 快速操作：
  - 设为当前产品
  - 编辑产品
  - 删除产品
- 相关内容列表

---

## 四、产品管理服务（Service Layer）

```python
class ProductService:
    """产品管理服务"""

    async def create_product(product: ProductCreate) -> Product:
        """创建产品"""

    async def list_products(
        filters: ProductFilters,
        pagination: Pagination
    ) -> List[Product]:
        """获取产品列表"""

    async def get_product(product_id: str) -> Product:
        """获取产品详情"""

    async def update_product(product_id: str, updates: ProductUpdate) -> Product:
        """更新产品"""

    async def delete_product(product_id: str) -> bool:
        """删除产品"""

    async def set_active_product(product_id: str) -> Product:
        """设置当前激活产品"""

    async def get_active_product() -> Optional[Product]:
        """获取当前激活产品"""
```

---

## 五、数据存储方案

### 方案 A：内存存储（MVP）
```python
# 使用 session state 存储产品列表
st.session_state.products = []
st.session_state.active_product_id = None
```

**优点**：
- 简单快速
- 无需数据库
- 适合演示

**缺点**：
- 刷新后数据丢失
- 不支持持久化

### 方案 B：文件存储（JSON）
```python
# 存储在 data/products.json
{
    "products": [],
    "active_product_id": null
}
```

**优点**：
- 数据持久化
- 简单易实现

**缺点**：
- 并发问题
- 不适合大量数据

### 方案 C：数据库存储（正式版）
```sql
CREATE TABLE products (
    id UUID PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    type VARCHAR(50) NOT NULL,
    description TEXT,
    target_audience TEXT,
    selling_points JSONB,
    website_url TEXT,
    cta_text TEXT,
    cta_link TEXT,
    price VARCHAR(100),
    category VARCHAR(100),
    tags TEXT[],
    status VARCHAR(50) DEFAULT 'inactive',
    is_active BOOLEAN DEFAULT false,
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);
```

**推荐**：
- MVP：方案 A（内存）
- 测试版：方案 B（JSON）
- 正式版：方案 C（数据库）

---

## 六、实现步骤

### 阶段 1：数据模型（1小时）
- [ ] 创建 ProductType 枚举
- [ ] 更新 Product 模型
- [ ] 创建 ProductCreate、ProductUpdate 模型

### 阶段 2：产品服务（1小时）
- [ ] 实现 ProductService
- [ ] 实现内存存储方案
- [ ] 添加单元测试

### 阶段 3：产品管理 UI（2小时）
- [ ] 产品列表页面
- [ ] 添加产品表单
- [ ] 编辑产品表单
- [ ] 产品详情页面

### 阶段 4：集成（1小时）
- [ ] 更新导航，添加"产品管理"菜单
- [ ] 在其他页面使用当前激活产品
- [ ] 测试完整流程

---

## 七、UI 界面预览

### 产品列表
```
┌──────────────────────────────────────────────────────┐
│  📦 产品管理                          ➕ 添加新产品   │
├──────────────────────────────────────────────────────┤
│                                                      │
│  筛选: [全部▼] [小程序] [APP] [SaaS] [课程]          │
│  🔍 搜索产品名称...                    [最新创建 ▼]  │
│                                                      │
│  找到 3 个产品                                        │
│                                                      │
│  ┌──────────────────────────────────────────────┐  │
│  │ 🚀 SparkFlow                          ⭐ 激活  │  │
│  │ SaaS · AI 营销自动化平台                     │  │
│  │ 目标用户: 独立开发者、创业团队                │  │
│  │ 创建: 2024-01-15  |  内容: 24  |  发布: 18   │  │
│  │                                              │  │
│  │ [✏️ 编辑]  [🗑️ 删除]  [📊 查看数据]           │  │
│  └──────────────────────────────────────────────┘  │
│                                                      │
│  ┌──────────────────────────────────────────────┐  │
│  │ 📱 儿童数学学习 APP                          │  │
│  │ APP · 3-12岁儿童数学启蒙                     │  │
│  │ 目标用户: 家长、小学生                        │  │
│  │ 创建: 2024-01-10  |  内容: 15  |  发布: 12   │  │
│  │                                              │  │
│  │ [⭐ 激活] [✏️ 编辑]  [🗑️ 删除]                │  │
│  └──────────────────────────────────────────────┘  │
└──────────────────────────────────────────────────────┘
```

---

## 八、下一步

1. **确认需求** - 产品类型是否需要调整？
2. **选择方案** - 数据存储方案选哪个？
3. **开始实现** - 从哪个阶段开始？

请告诉我你的想法，我们开始实现！
