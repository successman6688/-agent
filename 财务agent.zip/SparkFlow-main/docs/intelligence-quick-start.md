# 🔍 SparkFlow 情报系统 - 快速开始指南

## 📋 系统概述

SparkFlow情报系统是一个可扩展的全网情报监控平台，支持：
- ✅ **多源聚合** - 可扩展的数据源架构
- ✅ **智能去重** - 三重去重机制
- ✅ **相关性评分** - 多维自动评分
- ✅ **异步并发** - 高性能数据抓取
- ✅ **完全免费** - 使用免费数据源

---

## 🚀 快速开始

### 1. 启动后端服务

```bash
# 在项目根目录
cd /Users/houziqiang/workspace/marketing/SparkFlow

# 启动FastAPI服务器
python main.py
```

后端将在 http://localhost:8000 启动

API文档：http://localhost:8000/docs

### 2. 启动前端服务

```bash
# 进入前端目录
cd frontend

# 启动Vite开发服务器
npm run dev
```

前端将在 http://localhost:5173 启动

---

## 📖 使用方法

### 方式一：通过Web界面（推荐）

#### 1. 快速创建情报主题

1. 打开浏览器访问 http://localhost:5173
2. 点击左侧菜单 "情报监控"
3. 点击 "快速创建" 按钮
4. 输入搜索关键词，例如：`人工智能`
5. 点击 "创建"

系统将自动创建一个情报主题，并配置Google News RSS数据源。

#### 2. 收集情报

1. 在主题卡片上点击 "立即收集" 按钮
2. 等待收集完成（通常需要几秒钟）
3. 系统会显示收集到的情报数量

#### 3. 查看情报详情

1. 点击主题卡片或 "查看详情" 按钮
2. 进入情报详情页面
3. 可以看到：
   - 主题基本信息
   - 情报列表（按相关性排序）
   - 每条情报的评分、来源、时间
   - 点击情报可打开原文链接

---

### 方式二：通过API调用

#### 1. 创建主题

```bash
curl -X POST "http://localhost:8000/api/v1/intelligence/quick-start?query=人工智能&name=AI动态"
```

#### 2. 查看所有主题

```bash
curl http://localhost:8000/api/v1/intelligence/topics
```

#### 3. 收集情报

```bash
# 替换 {topic_id} 为实际的主题ID
curl -X POST "http://localhost:8000/api/v1/intelligence/topics/{topic_id}/collect"
```

#### 4. 获取情报列表

```bash
curl "http://localhost:8000/api/v1/intelligence/topics/{topic_id}/items?limit=50"
```

---

## 🎯 已实现功能

### ✅ 后端功能

#### 数据模型
- [x] IntelligenceTopic - 情报主题模型
- [x] IntelligenceItem - 情报项模型
- [x] IntelligenceReport - 情报报告模型
- [x] SourceConfig - 数据源配置

#### 核心模块
- [x] BaseFetcher - 可扩展的数据源接口
- [x] GoogleNewsRSSFetcher - Google News RSS采集器
- [x] Deduplicator - 三重去重器
- [x] RelevanceScorer - 相关性评分器
- [x] IntelligenceCoordinator - 情报协调器
- [x] IntelligenceStorage - 存储管理器

#### API端点（10个）
```
GET    /api/v1/intelligence/topics                 # 获取主题列表
POST   /api/v1/intelligence/topics                 # 创建主题
GET    /api/v1/intelligence/topics/{id}            # 获取主题详情
PUT    /api/v1/intelligence/topics/{id}            # 更新主题
DELETE /api/v1/intelligence/topics/{id}            # 删除主题
POST   /api/v1/intelligence/topics/{id}/collect    # 收集情报
GET    /api/v1/intelligence/topics/{id}/items      # 获取情报列表
POST   /api/v1/intelligence/quick-start            # 快速创建主题
GET    /api/v1/intelligence/items/{id}             # 获取情报详情
GET    /api/v1/intelligence/topics/{id}/reports/latest  # 获取最新报告
```

### ✅ 前端功能

#### 页面
- [x] TopicList - 情报主题列表页
- [x] TopicDetail - 情报详情页

#### 功能
- [x] 快速创建主题
- [x] 一键收集情报
- [x] 情报列表展示
- [x] 相关性评分可视化
- [x] 筛选和排序
- [x] 响应式布局

---

## 🏗️ 架构特点

### 可扩展的数据源设计

所有数据源采集器都继承自 `BaseFetcher`，只需实现以下方法：

```python
class CustomFetcher(BaseFetcher):
    async def fetch(self) -> List[IntelligenceItem]:
        # 实现抓取逻辑
        pass

    def validate_config(self) -> bool:
        # 验证配置
        pass
```

然后注册到工厂：

```python
FetcherFactory.register("custom_source", CustomFetcher)
```

### 数据处理流程

```
用户创建主题
    ↓
选择数据源（当前支持：Google News RSS）
    ↓
点击"立即收集"
    ↓
协调器并行抓取数据
    ↓
三重去重（GUID + URL + 内容）
    ↓
多维评分（关键词 + 时效 + 权威）
    ↓
过滤低分项
    ↓
存储到JSON文件
    ↓
前端展示
```

---

## 📊 Google News RSS 数据源

### URL格式

```
https://news.google.com/rss/search?q={query}&hl={language}&gl={country}&ceid={country}:{language}
```

### 参数说明

| 参数 | 说明 | 示例 |
|------|------|------|
| q | 搜索关键词 | 人工智能 |
| hl | 界面语言 | zh-CN（简体中文） |
| gl | 地理位置 | CN（中国） |
| ceid | 版本ID | CN:zh |

### 示例URL

```
# 中文AI新闻
https://news.google.com/rss/search?q=人工智能&hl=zh-CN&gl=CN&ceid=CN:zh

# 英文科技新闻
https://news.google.com/rss/search?q=AI&hl=en-US&gl=US&ceid=US:en

# 印度印地语新闻
https://news.google.com/rss/search?q=technology&hl=hi&gl=IN&ceid=IN:hi
```

---

## 🔧 配置说明

### 主题配置 (TopicConfig)

```json
{
  "max_items": 50,              // 最大情报条数
  "min_relevance": 0.5,         // 最小相关性评分
  "enable_ai_summary": true,    // 启用AI总结（待实现）
  "languages": ["zh", "en"],    // 语言偏好
  "ai_summary_threshold": 0.7,  // AI总结阈值
  "keyword_weight": 0.4,        // 关键词权重
  "timeliness_weight": 0.3,     // 时效性权重
  "authority_weight": 0.3       // 权威性权重
}
```

### 数据源配置 (SourceConfig)

```json
{
  "type": "rss",                // 数据源类型
  "name": "Google News",        // 数据源名称
  "enabled": true,              // 是否启用
  "query": "人工智能",           // 搜索关键词
  "params": {                   // 自定义参数
    "hl": "zh-CN",
    "gl": "CN",
    "ceid": "CN:zh"
  }
}
```

---

## 📂 数据存储

情报数据存储在 `data/intelligence/` 目录：

```
data/intelligence/
├── topics/           # 主题配置
│   └── {topic_id}.json
├── items/            # 情报项（按日期和主题组织）
│   └── {topic_id}/
│       └── {date}.jsonl
└── reports/          # 情报报告
    └── {topic_id}/
        └── {date}_{report_id}.json
```

---

## 🚦 测试示例

### 1. 创建主题并收集情报

```python
# 使用Python测试
import requests

# 1. 创建主题
response = requests.post(
    "http://localhost:8000/api/v1/intelligence/quick-start",
    params={"query": "大语言模型", "name": "LLM动态"}
)
topic = response.json()
topic_id = topic["id"]

print(f"创建主题: {topic['name']} (ID: {topic_id})")

# 2. 收集情报
response = requests.post(
    f"http://localhost:8000/api/v1/intelligence/topics/{topic_id}/collect"
)
result = response.json()

print(f"收集完成: {result['new_items']} 条新情报")
```

### 2. 查看情报列表

```python
# 获取情报列表
response = requests.get(
    f"http://localhost:8000/api/v1/intelligence/topics/{topic_id}/items",
    params={"limit": 10, "min_score": 0.6}
)
items = response.json()

for item in items:
    print(f"[{item['overall_score']:.2f}] {item['title']}")
    print(f"  来源: {item['source']}")
    print(f"  时间: {item['published_at']}")
    print()
```

---

## 🎉 下一步

系统已经可以正常使用！你可以：

1. **创建多个主题** - 监控不同领域的情报
2. **定期收集** - 使用定时任务自动收集
3. **扩展数据源** - 添加Hacker News、Reddit等
4. **添加AI总结** - 集成你的API进行智能分析

### 即将实现的功能

- [ ] Hacker News API数据源
- [ ] Reddit API数据源
- [ ] AI自动总结（使用自建API）
- [ ] 定时任务调度
- [ ] 邮件/消息通知
- [ ] 情报报告生成

---

## 📞 常见问题

### Q: 如何修改数据源配置？

A: 在创建主题时，可以在 `sources` 参数中自定义配置：

```json
{
  "sources": [
    {
      "type": "google_news",
      "name": "Google News",
      "query": "AI",
      "params": {
        "hl": "en-US",
        "gl": "US",
        "ceid": "US:en"
      }
    }
  ]
}
```

### Q: 如何调整评分权重？

A: 在 `config` 参数中修改权重：

```json
{
  "config": {
    "keyword_weight": 0.5,      // 提高关键词权重
    "timeliness_weight": 0.2,    // 降低时效性权重
    "authority_weight": 0.3      // 保持权威性权重
  }
}
```

### Q: 情报数据保存在哪里？

A: 目前保存在 `data/intelligence/` 目录的JSON文件中。未来可以升级到数据库。

### Q: 如何添加新的数据源？

A: 参考 `GoogleNewsRSSFetcher` 的实现，创建新的采集器类，继承 `BaseFetcher`，然后注册到 `FetcherFactory`。

---

**文档版本**: v1.0
**最后更新**: 2024-02-28
**状态**: ✅ MVP完成，Google News RSS数据源已可用
