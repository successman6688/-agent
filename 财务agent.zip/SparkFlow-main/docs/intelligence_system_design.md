# 🔍 SparkFlow 情报系统设计方案

## 📋 目录
- [1. 系统概述](#1-系统概述)
- [2. 技术架构](#2-技术架构)
- [3. 数据模型设计](#3-数据模型设计)
- [4. 核心功能模块](#4-核心功能模块)
- [5. API设计](#5-api设计)
- [6. 数据源配置](#6-数据源配置)
- [7. 前端设计](#7-前端设计)
- [8. 实施计划](#8-实施计划)

---

## 1. 系统概述

### 1.1 功能定位
**全网主题情报监控** - 自动收集、整理、总结指定主题的最新信息

### 1.2 核心特性
- ✅ **多源聚合** - 整合RSS、API、网页爬取等多种数据源
- ✅ **智能去重** - 基于GUID、URL、内容相似度的三重去重
- ✅ **AI总结** - 使用自建API进行智能摘要和趋势分析
- ✅ **实时更新** - 支持定时自动刷新和手动触发
- ✅ **成本控制** - 分层处理策略，优化API调用
- ✅ **历史追踪** - 保存历史情报，支持趋势分析

### 1.3 免费数据源
| 数据源 | 类型 | 限制 | 覆盖范围 |
|-------|------|------|---------|
| Google News RSS | RSS | 无限 | 全球新闻 |
| Hacker News API | API | 有限 | 科技圈 |
| Reddit API | API | 有限 | 英文社区 |
| GitHub Trending RSS | RSS | 无限 | 开源项目 |
| 36kr/TechCrunch RSS | RSS | 无限 | 科技媒体 |

---

## 2. 技术架构

### 2.1 整体架构图

```
┌─────────────────────────────────────────────────────────┐
│                     Vue3 前端                           │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐ │
│  │  主题管理    │  │  情报列表    │  │  详情分析    │ │
│  └──────────────┘  └──────────────┘  └──────────────┘ │
└─────────────────────────────────────────────────────────┘
                         ↕ HTTP/REST
┌─────────────────────────────────────────────────────────┐
│                   FastAPI 后端                          │
│  ┌──────────────────────────────────────────────────┐  │
│  │              API 路由层                          │  │
│  │  /intelligence/topics                            │  │
│  │  /intelligence/items                             │  │
│  │  /intelligence/reports                           │  │
│  └──────────────────────────────────────────────────┘  │
│  ┌──────────────────────────────────────────────────┐  │
│  │              业务逻辑层                          │  │
│  │  ┌──────────────┐  ┌──────────────┐            │  │
│  │  │ 情报协调器   │  │  AI总结器    │            │  │
│  │  └──────────────┘  └──────────────┘            │  │
│  └──────────────────────────────────────────────────┘  │
│  ┌──────────────────────────────────────────────────┐  │
│  │              数据采集层                          │  │
│  │  ┌──────────┐  ┌──────────┐  ┌──────────┐     │  │
│  │  │ RSS读取器│  │ API抓取器│  │ 爬虫器   │     │  │
│  │  └──────────┘  └──────────┘  └──────────┘     │  │
│  └──────────────────────────────────────────────────┘  │
│  ┌──────────────────────────────────────────────────┐  │
│  │              数据处理层                          │  │
│  │  ┌──────────┐  ┌──────────┐  ┌──────────┐     │  │
│  │  │ 去重器   │  │ 评分器   │  │ 存储器   │     │  │
│  │  └──────────┘  └──────────┘  └──────────┘     │  │
│  └──────────────────────────────────────────────────┘  │
└─────────────────────────────────────────────────────────┘
                         ↕
┌─────────────────────────────────────────────────────────┐
│                   数据存储                              │
│  ┌──────────────┐        ┌──────────────┐              │
│  │ JSON 文件    │        │ ChromaDB     │              │
│  │ (情报数据)   │        │ (向量检索)   │              │
│  └──────────────┘        └──────────────┘              │
└─────────────────────────────────────────────────────────┘
```

### 2.2 核心流程图

```
用户输入主题
    ↓
[情报协调器] IntelligenceCoordinator
    ↓
┌───────────────────────────────────────┐
│ 1. 并行采集 (异步并发)                │
│    - RSS Feeds                        │
│    - API 数据                         │
│    - 网页抓取                         │
└───────────────────────────────────────┘
    ↓
┌───────────────────────────────────────┐
│ 2. 数据处理                           │
│    - GUID去重                         │
│    - URL哈希去重                      │
│    - 内容清洗                         │
└───────────────────────────────────────┘
    ↓
┌───────────────────────────────────────┐
│ 3. 智能评分                           │
│    - 相关性评分                       │
│    - 时效性评分                       │
│    - 权威性评分                       │
└───────────────────────────────────────┘
    ↓
┌───────────────────────────────────────┐
│ 4. AI总结 (分层处理)                  │
│    - 重要情报 → Claude深度分析        │
│    - 普通情报 → 快速摘要              │
│    - 生成情报报告                     │
└───────────────────────────────────────┘
    ↓
┌───────────────────────────────────────┐
│ 5. 存储与索引                         │
│    - JSON持久化                       │
│    - 向量化入库 (ChromaDB)            │
└───────────────────────────────────────┘
    ↓
返回给前端展示
```

### 2.3 技术栈

#### 后端
```python
核心框架:
- FastAPI         # Web框架
- Pydantic        # 数据验证
- asyncio        # 异步并发
- aiohttp        # 异步HTTP

数据采集:
- feedparser     # RSS解析
- requests       # HTTP请求
- beautifulsoup4 # HTML解析

AI处理:
- langchain      # LLM框架
- langchain-anthropic  # Claude集成
- chromadb       # 向量数据库

数据处理:
- tenacity       # 重试机制
- hashlib        # 哈希去重
- jinja2         # 模板引擎
```

#### 前端
```typescript
框架:
- Vue 3          # 前端框架
- TypeScript     # 类型系统
- Vite           # 构建工具

UI:
- Element Plus   # 组件库
- ECharts        # 数据可视化

状态管理:
- Pinia          # 状态管理
```

---

## 3. 数据模型设计

### 3.1 情报主题 (IntelligenceTopic)

```python
class IntelligenceTopic(BaseModel):
    """情报主题"""
    id: str                    # 主题ID
    name: str                  # 主题名称
    keywords: List[str]        # 关键词列表
    sources: List[str]         # 数据源配置
    schedule: str              # 更新频率 (hourly/daily/weekly)
    is_active: bool            # 是否激活
    last_run: Optional[datetime]  # 最后运行时间
    created_at: datetime       # 创建时间
    updated_at: datetime       # 更新时间

    # 配置选项
    config: TopicConfig = Field(default_factory=TopicConfig)

class TopicConfig(BaseModel):
    """主题配置"""
    max_items: int = 50        # 最大情报条数
    min_relevance: float = 0.5 # 最小相关性
    enable_ai_summary: bool = True  # 启用AI总结
    languages: List[str] = ["zh", "en"]  # 语言偏好
```

### 3.2 情报项 (IntelligenceItem)

```python
class IntelligenceItem(BaseModel):
    """单条情报"""
    id: str                    # 情报ID
    topic_id: str              # 所属主题

    # 原始内容
    title: str                 # 标题
    content: str               # 内容摘要
    url: str                   # 来源链接
    source: str                # 来源平台
    author: Optional[str]      # 作者

    # 元数据
    published_at: datetime     # 发布时间
    collected_at: datetime     # 采集时间

    # 评分
    relevance_score: float     # 相关性评分 (0-1)
    timeliness_score: float    # 时效性评分 (0-1)
    authority_score: float     # 权威性评分 (0-1)
    overall_score: float       # 综合评分 (0-1)

    # AI处理结果
    ai_summary: Optional[str]  # AI总结
    key_insights: List[str]    # 关键洞察
    tags: List[str]            # 自动标签

    # 去重标识
    guid: Optional[str]        # RSS GUID
    url_hash: str              # URL哈希
    content_hash: Optional[str] # 内容哈希

    # 向量检索
    embedding_id: Optional[str] # 向量ID
```

### 3.3 情报报告 (IntelligenceReport)

```python
class IntelligenceReport(BaseModel):
    """情报分析报告"""
    id: str                    # 报告ID
    topic_id: str              # 所属主题
    period_start: datetime     # 统计周期开始
    period_end: datetime       # 统计周期结束

    # 统计信息
    total_items: int           # 总情报数
    new_items: int             # 新增情报数
    sources_breakdown: Dict[str, int]  # 来源分布

    # AI分析
    summary: str               # 整体总结
    key_trends: List[str]      # 关键趋势
    hot_topics: List[str]      # 热点话题
    sentiment: str             # 情感倾向

    # 重要情报
    top_items: List[IntelligenceItem]  # Top情报

    created_at: datetime       # 报告生成时间
```

---

## 4. 核心功能模块

### 4.1 情报协调器 (IntelligenceCoordinator)

```python
class IntelligenceCoordinator:
    """情报收集协调器 - 核心控制器"""

    def __init__(self):
        self.rss_fetcher = RSSFetcher()
        self.api_fetcher = APIFetcher()
        self.scraper = WebScraper()
        self.deduplicator = Deduplicator()
        self.scorer = RelevanceScorer()
        self.ai_summarizer = AISummarizer()
        self.storage = IntelligenceStorage()

    async def collect_intelligence(
        self,
        topic: IntelligenceTopic
    ) -> IntelligenceReport:
        """
        执行情报收集流程
        """
        # 1. 并行采集
        raw_items = await self._fetch_all_sources(topic)

        # 2. 去重
        unique_items = self.deduplicator.deduplicate(raw_items)

        # 3. 相关性评分
        scored_items = await self.scorer.score(
            unique_items,
            topic.keywords
        )

        # 4. 过滤低分项
        filtered_items = [
            item for item in scored_items
            if item.overall_score >= topic.config.min_relevance
        ]

        # 5. AI总结 (分层处理)
        await self._summarize_items(filtered_items, topic)

        # 6. 存储
        await self.storage.save_items(filtered_items)

        # 7. 生成报告
        report = await self._generate_report(topic, filtered_items)

        return report

    async def _fetch_all_sources(self, topic):
        """并行抓取所有数据源"""
        tasks = []

        # RSS源
        for source in topic.sources:
            if source['type'] == 'rss':
                tasks.append(self.rss_fetcher.fetch(source['url']))

        # API源
        if 'hackernews' in [s['type'] for s in topic.sources]:
            tasks.append(self.api_fetcher.fetch_hackernews(topic.keywords))

        # 并发执行
        results = await asyncio.gather(*tasks, return_exceptions=True)

        # 合并结果
        all_items = []
        for result in results:
            if isinstance(result, Exception):
                logger.error(f"Fetch error: {result}")
            else:
                all_items.extend(result)

        return all_items
```

### 4.2 RSS采集器 (RSSFetcher)

```python
class RSSFetcher:
    """RSS订阅源采集器"""

    # 预定义的RSS源
    RSS_SOURCES = {
        'google_news': 'https://news.google.com/rss/search?q={query}&hl=zh-CN&gl=CN',
        'hacker_news': 'https://news.ycombinator.com/rss',
        'github_trending': 'https://github.com/trending',
        '36kr': 'https://36kr.com/feed',
        'techcrunch': 'https://techcrunch.com/feed/',
    }

    async def fetch(self, url: str) -> List[IntelligenceItem]:
        """
        抓取单个RSS源
        """
        import feedparser
        import aiohttp

        try:
            async with aiohttp.ClientSession() as session:
                async with session.get(url, timeout=30) as response:
                    if response.status != 200:
                        logger.warning(f"RSS fetch failed: {url}")
                        return []

                    feed_content = await response.text()

            # 解析RSS
            feed = feedparser.parse(feed_content)
            items = []

            for entry in feed.entries:
                item = IntelligenceItem(
                    id=str(uuid4()),
                    title=entry.get('title', ''),
                    content=entry.get('summary', ''),
                    url=entry.get('link', ''),
                    source='rss',
                    published_at=self._parse_date(entry.get('published')),
                    collected_at=datetime.utcnow(),
                    guid=entry.get('id'),
                    url_hash=hashlib.md5(entry.get('link', '').encode()).hexdigest(),
                )
                items.append(item)

            logger.info(f"Fetched {len(items)} items from {url}")
            return items

        except Exception as e:
            logger.error(f"RSS fetch error: {url}, {e}")
            return []

    def _parse_date(self, date_str: Optional[str]) -> datetime:
        """解析日期"""
        if not date_str:
            return datetime.utcnow()
        try:
            from email.utils import parsedate_to_datetime
            return parsedate_to_datetime(date_str)
        except:
            return datetime.utcnow()
```

### 4.3 去重器 (Deduplicator)

```python
class Deduplicator:
    """三重去重器"""

    def __init__(self):
        self.seen_guids = set()      # GUID集合
        self.seen_urls = set()       # URL哈希集合
        self.seen_content = set()    # 内容哈希集合

    def deduplicate(
        self,
        items: List[IntelligenceItem]
    ) -> List[IntelligenceItem]:
        """
        三重去重:
        1. GUID去重 (RSS标准)
        2. URL哈希去重
        3. 内容相似度去重 (可选)
        """
        unique_items = []

        for item in items:
            # 第一层: GUID去重
            if item.guid and item.guid in self.seen_guids:
                logger.debug(f"Duplicate by GUID: {item.guid}")
                continue

            # 第二层: URL哈希去重
            if item.url_hash in self.seen_urls:
                logger.debug(f"Duplicate by URL: {item.url}")
                continue

            # 第三层: 内容哈希去重 (可选)
            if item.content:
                content_hash = hashlib.md5(
                    item.content[:500].encode()
                ).hexdigest()

                if content_hash in self.seen_content:
                    logger.debug(f"Duplicate by content: {item.title}")
                    continue

                self.seen_content.add(content_hash)

            # 通过所有去重检查
            unique_items.append(item)

            # 记录已见
            if item.guid:
                self.seen_guids.add(item.guid)
            self.seen_urls.add(item.url_hash)

        logger.info(f"Deduplication: {len(items)} -> {len(unique_items)}")
        return unique_items
```

### 4.4 相关性评分器 (RelevanceScorer)

```python
class RelevanceScorer:
    """相关性评分器"""

    async def score(
        self,
        items: List[IntelligenceItem],
        keywords: List[str]
    ) -> List[IntelligenceItem]:
        """
        为每条情报计算相关性评分
        """
        for item in items:
            # 1. 关键词匹配度 (40%)
            keyword_score = self._score_keywords(item, keywords)

            # 2. 时间新鲜度 (30%)
            time_score = self._score_timeliness(item.published_at)

            # 3. 来源权威性 (30%)
            authority_score = self._score_authority(item.source)

            # 综合评分
            item.overall_score = (
                keyword_score * 0.4 +
                time_score * 0.3 +
                authority_score * 0.3
            )

            # 同时保存单项分数
            item.relevance_score = keyword_score
            item.timeliness_score = time_score
            item.authority_score = authority_score

        # 按综合评分排序
        items.sort(key=lambda x: x.overall_score, reverse=True)

        return items

    def _score_keywords(
        self,
        item: IntelligenceItem,
        keywords: List[str]
    ) -> float:
        """计算关键词匹配度"""
        text = f"{item.title} {item.content}".lower()
        matches = sum(1 for kw in keywords if kw.lower() in text)
        return min(matches / len(keywords), 1.0)

    def _score_timeliness(self, published_at: datetime) -> float:
        """计算时间新鲜度"""
        age_hours = (datetime.utcnow() - published_at).total_seconds() / 3600

        if age_hours < 6:
            return 1.0
        elif age_hours < 24:
            return 0.8
        elif age_hours < 72:
            return 0.5
        else:
            return 0.2

    def _score_authority(self, source: str) -> float:
        """计算来源权威性"""
       权威度 = {
            'hacker_news': 0.9,
            'reddit': 0.7,
            'google_news': 0.8,
            '36kr': 0.7,
            'techcrunch': 0.8,
        }
        return 权威度.get(source, 0.5)
```

### 4.5 AI总结器 (AISummarizer)

```python
class AISummarizer:
    """AI智能总结器"""

    def __init__(self):
        # 使用自定义API
        self.llm = ChatAnthropic(
            model="claude-sonnet-4-20250514",
            anthropic_api_key="your-api-key",
            anthropic_api_url="https://api.z.ai/api/anthropic",
            temperature=0.3,
            max_tokens=2000,
        )

        # 分层处理配置
        self.high_priority_threshold = 0.8  # 高质量阈值

    async def summarize_items(
        self,
        items: List[IntelligenceItem],
        topic: IntelligenceTopic
    ):
        """
        分层处理:
        - 高质量情报 → Claude深度分析
        - 普通情报 → 快速摘要
        """
        for item in items:
            if item.overall_score >= self.high_priority_threshold:
                # 深度分析
                await self._deep_analysis(item, topic)
            else:
                # 快速摘要
                await self._quick_summary(item)

    async def _deep_analysis(
        self,
        item: IntelligenceItem,
        topic: IntelligenceTopic
    ):
        """深度分析 - 用于重要情报"""
        prompt = f"""你是一个专业的情报分析师。请对以下情报进行深度分析:

**主题**: {topic.name}
**关键词**: {', '.join(topic.keywords)}

**情报标题**: {item.title}
**情报内容**: {item.content}
**来源**: {item.source}
**链接**: {item.url}

请提供:
1. 摘要 (2-3句话)
2. 关键洞察 (3-5点)
3. 标签 (3-5个)

以JSON格式返回:
{{
    "summary": "...",
    "key_insights": ["...", "...", "..."],
    "tags": ["...", "...", "..."]
}}
"""

        try:
            response = await self.llm.ainvoke(prompt)
            result = self._parse_json_response(response.content)

            item.ai_summary = result['summary']
            item.key_insights = result['key_insights']
            item.tags = result['tags']

        except Exception as e:
            logger.error(f"AI analysis error: {e}")

    async def _quick_summary(self, item: IntelligenceItem):
        """快速摘要 - 用于普通情报"""
        # 可以提取关键句子作为摘要
        from langchain.text_splitter import RecursiveCharacterTextSplitter

        splitter = RecursiveCharacterTextSplitter(
            chunk_size=200,
            chunk_overlap=50,
            length_function=len,
        )

        chunks = splitter.split_text(item.content)
        item.ai_summary = chunks[0] if chunks else item.content[:200]
```

### 4.6 存储管理器 (IntelligenceStorage)

```python
class IntelligenceStorage:
    """情报存储管理器"""

    def __init__(self, storage_path: str = "data/intelligence"):
        self.storage_path = Path(storage_path)
        self.storage_path.mkdir(parents=True, exist_ok=True)

    async def save_items(
        self,
        items: List[IntelligenceItem]
    ):
        """保存情报到JSON文件"""
        # 按日期组织
        today = datetime.utcnow().strftime("%Y-%m-%d")
        file_path = self.storage_path / f"{today}.jsonl"

        # 追加写入
        with open(file_path, 'a', encoding='utf-8') as f:
            for item in items:
                json.dump(item.model_dump(), f, ensure_ascii=False)
                f.write('\n')

        logger.info(f"Saved {len(items)} items to {file_path}")

    async def load_items(
        self,
        date: Optional[str] = None
    ) -> List[IntelligenceItem]:
        """加载指定日期的情报"""
        if date is None:
            date = datetime.utcnow().strftime("%Y-%m-%d")

        file_path = self.storage_path / f"{date}.jsonl"

        if not file_path.exists():
            return []

        items = []
        with open(file_path, 'r', encoding='utf-8') as f:
            for line in f:
                data = json.loads(line)
                items.append(IntelligenceItem(**data))

        return items
```

---

## 5. API设计

### 5.1 情报主题管理

#### 创建主题
```http
POST /api/v1/intelligence/topics
Content-Type: application/json

{
    "name": "AI大模型动态",
    "keywords": ["GPT", "Claude", "大模型", "AI"],
    "sources": [
        {"type": "rss", "url": "google_news"},
        {"type": "api", "name": "hacker_news"}
    ],
    "schedule": "hourly",
    "config": {
        "max_items": 50,
        "min_relevance": 0.6
    }
}
```

#### 获取主题列表
```http
GET /api/v1/intelligence/topics
```

#### 触发情报收集
```http
POST /api/v1/intelligence/topics/{topic_id}/collect
```

#### 获取主题情报列表
```http
GET /api/v1/intelligence/topics/{topic_id}/items?limit=20&offset=0
```

### 5.2 情报项查询

#### 获取情报详情
```http
GET /api/v1/intelligence/items/{item_id}
```

#### 搜索情报
```http
GET /api/v1/intelligence/search?q=关键词&days=7
```

### 5.3 情报报告

#### 生成报告
```http
POST /api/v1/intelligence/reports
{
    "topic_id": "...",
    "period_start": "2024-01-01",
    "period_end": "2024-01-07"
}
```

#### 获取最新报告
```http
GET /api/v1/intelligence/topics/{topic_id}/reports/latest
```

---

## 6. 数据源配置

### 6.1 预设数据源

```python
INTELLIGENCE_SOURCES = {
    "rss": {
        "google_news": {
            "name": "Google News",
            "url_template": "https://news.google.com/rss/search?q={query}&hl=zh-CN&gl=CN",
            "update_interval": 3600,  # 1小时
        },
        "hacker_news": {
            "name": "Hacker News",
            "url": "https://news.ycombinator.com/rss",
            "update_interval": 1800,  # 30分钟
        },
        "36kr": {
            "name": "36氪",
            "url": "https://36kr.com/feed",
            "update_interval": 3600,
        },
        "techcrunch": {
            "name": "TechCrunch",
            "url": "https://techcrunch.com/feed/",
            "update_interval": 3600,
        },
    },
    "api": {
        "hacker_news": {
            "name": "Hacker News API",
            "base_url": "https://hacker-news.firebaseio.com/v0",
            "endpoints": {
                "new_stories": "/newstories.json",
                "best_stories": "/beststories.json",
                "item": "/item/{id}.json"
            }
        },
        "reddit": {
            "name": "Reddit API",
            "base_url": "https://www.reddit.com",
            "endpoints": {
                "search": "/search.json?q={query}"
            }
        }
    }
}
```

### 6.2 添加自定义源

```python
# 用户可以添加自定义RSS源
custom_sources = [
    {
        "type": "rss",
        "name": "行业博客",
        "url": "https://example.com/rss"
    }
]
```

---

## 7. 前端设计

### 7.1 页面结构

```
/intelligence
├── /topics          # 主题管理
│   ├── list         # 主题列表
│   ├── create       # 创建主题
│   └── detail       # 主题详情
├── /items           # 情报列表
│   └── detail       # 情报详情
└── /reports         # 分析报告
```

### 7.2 核心页面

#### 主题列表页
```vue
<template>
  <div class="intelligence-topics">
    <!-- 主题卡片列表 -->
    <el-card v-for="topic in topics" :key="topic.id">
      <h3>{{ topic.name }}</h3>
      <p>关键词: {{ topic.keywords.join(', ') }}</p>
      <el-progress
        :percentage="topic.progress"
        :status="topic.is_active ? 'success' : 'info'"
      />
      <el-button @click="collect(topic.id)">立即收集</el-button>
      <el-button @click="viewReport(topic.id)">查看报告</el-button>
    </el-card>
  </div>
</template>
```

#### 情报详情页
```vue
<template>
  <div class="intelligence-detail">
    <!-- 情报头部 -->
    <div class="header">
      <h1>{{ item.title }}</h1>
      <el-tag :type="getScoreType(item.overall_score)">
        评分: {{ (item.overall_score * 100).toFixed(0) }}
      </el-tag>
    </div>

    <!-- AI总结 -->
    <el-card class="ai-summary">
      <h3>AI分析</h3>
      <p>{{ item.ai_summary }}</p>
      <el-tag v-for="insight in item.key_insights" :key="insight">
        {{ insight }}
      </el-tag>
    </el-card>

    <!-- 原文内容 -->
    <el-card class="content">
      <div v-html="item.content"></div>
    </el-card>

    <!-- 相关情报 -->
    <div class="related">
      <h3>相关情报</h3>
      <intelligence-card
        v-for="related in relatedItems"
        :key="related.id"
        :item="related"
      />
    </div>
  </div>
</template>
```

---

## 8. 实施计划

### Phase 1: MVP基础版 (2-3天)

**目标**: 实现核心情报收集流程

- [ ] 数据模型定义
- [ ] RSS采集器
- [ ] 基础去重
- [ ] 简单关键词匹配
- [ ] JSON文件存储
- [ ] 基础API端点
- [ ] 前端主题列表页

**交付物**:
- 可运行的情报收集系统
- 支持2-3个RSS源
- 基本的列表展示

### Phase 2: 增强版 (1周)

**目标**: 添加AI能力和高级功能

- [ ] API数据源集成 (Hacker News)
- [ ] 异步并发采集
- [ ] 相关性评分系统
- [ ] AI总结器集成 (自定义API)
- [ ] ChromaDB向量检索
- [ ] 前端情报详情页
- [ ] 搜索功能

**交付物**:
- 完整的情报分析系统
- AI自动总结
- 相关性排序

### Phase 3: 自动化版 (3-5天)

**目标**: 添加自动化和监控

- [ ] APScheduler定时任务
- [ ] 情报报告生成
- [ ] 趋势分析
- [ ] 邮件/消息通知
- [ ] 性能监控
- [ ] 错误处理和重试

**交付物**:
- 全自动情报监控系统
- 定期报告生成
- 完整的错误处理

### Phase 4: 优化版 (可选)

- [ ] 向量数据库优化
- [ ] 多语言支持
- [ ] 用户订阅管理
- [ ] API限流控制
- [ ] 缓存优化
- [ ] Docker部署

---

## 9. 技术亮点

### 9.1 性能优化

```python
# 1. 异步并发抓取
async def fetch_multiple_sources(sources):
    tasks = [fetch(source) for source in sources]
    results = await asyncio.gather(*tasks)
    return results

# 2. 连接池复用
connector = aiohttp.TCPConnector(limit=100)
session = aiohttp.ClientSession(connector=connector)

# 3. 智能缓存
from functools import lru_cache

@lru_cache(maxsize=1000)
def get_authority_score(source: str) -> float:
    # 缓存权威性评分
    pass
```

### 9.2 成本控制

```python
# 分层处理策略
class CostOptimizer:
    def process_items(self, items):
        # 高优先级: 深度AI分析 (~10%)
        high_priority = [i for i in items if i.score > 0.8]

        # 中优先级: 快速摘要 (~30%)
        medium_priority = [i for i in items if 0.5 < i.score <= 0.8]

        # 低优先级: 不处理 (~60%)
        low_priority = [i for i in items if i.score <= 0.5]

        return {
            'high': deep_analyze(high_priority),
            'medium': quick_summarize(medium_priority),
            'low': low_priority
        }
```

### 9.3 可靠性保障

```python
# 重试机制
from tenacity import retry, stop_after_attempt, wait_exponential

@retry(
    stop=stop_after_attempt(3),
    wait=wait_exponential(multiplier=1, min=4, max=10)
)
async def fetch_with_retry(url):
    async with aiohttp.ClientSession() as session:
        async with session.get(url) as response:
            return await response.text()

# 熔断器
from pybreaker import CircuitBreaker

cb = CircuitBreaker(fail_max=5, reset_timeout=60)

@cb
async def protected_api_call():
    # 如果连续失败5次，熔断器打开，阻止调用
    pass
```

---

## 10. 配置示例

### 环境变量 (.env)

```bash
# 自建AI API
ANTHROPIC_API_BASE=https://api.z.ai/api/anthropic
ANTHROPIC_API_KEY=your-api-key
MODEL_NAME=claude-sonnet-4-20250514

# 情报系统配置
INTELLIGENCE_STORAGE_PATH=data/intelligence
INTELLIGENCE_MAX_ITEMS_PER_TOPIC=100
INTELLIGENCE_DEFAULT_SCHEDULE=hourly

# 向量数据库
CHROMADB_PATH=data/chromadb

# 日志
LOG_LEVEL=INFO
```

### 主题配置示例

```json
{
    "name": "AI大模型动态",
    "keywords": ["GPT", "Claude", "Gemini", "大模型", "LLM"],
    "sources": [
        {"type": "rss", "url": "google_news", "query": "AI大模型"},
        {"type": "api", "name": "hacker_news"},
        {"type": "rss", "url": "36kr"}
    ],
    "schedule": "hourly",
    "config": {
        "max_items": 50,
        "min_relevance": 0.6,
        "enable_ai_summary": true,
        "languages": ["zh", "en"]
    }
}
```

---

## 11. 总结

### 核心优势

✅ **完全免费** - 所有数据源均为免费API
✅ **AI增强** - 使用自建API进行智能分析
✅ **高性能** - 异步并发，处理效率高
✅ **易扩展** - 模块化设计，易于添加新数据源
✅ **成本可控** - 分层处理，优化AI调用
✅ **开箱即用** - 预设主流数据源，快速上手

### 技术亮点

- 🚀 异步并发抓取 (2-3倍速度提升)
- 🧠 三重去重机制 (精准去重)
- 📊 智能评分系统 (多维评估)
- 🤖 AI分层处理 (成本优化)
- 💾 JSON + ChromaDB (灵活存储)

### 适用场景

- 行业动态监控
- 竞品情报追踪
- 技术趋势分析
- 新闻热点聚合
- 科研文献追踪

---

**文档版本**: v1.0
**最后更新**: 2024-02-28
**作者**: SparkFlow Team
