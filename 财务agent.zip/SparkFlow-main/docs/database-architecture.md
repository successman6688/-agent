# 🗄️ SparkFlow 数据库架构文档

## 📊 数据库架构概览

SparkFlow现在支持**三数据库架构**：
- **PostgreSQL** - 核心业务数据
- **Redis** - 缓存和会话管理
- **ChromaDB** - 向量存储和AI检索
- **本地文件** - 图片和附件存储

---

## 🗄️ PostgreSQL - 核心业务数据

### 连接配置
```python
# app/core/config.py
DATABASE_URL = "postgresql+asyncpg://user:password@localhost:5432/sparkflow"
```

### 数据表

#### 1. products - 产品表
```sql
CREATE TABLE products (
    id UUID PRIMARY KEY,
    name VARCHAR(200) NOT NULL,
    type VARCHAR(50) NOT NULL,
    description TEXT NOT NULL,
    target_audience VARCHAR(200) NOT NULL,
    selling_points JSONB,
    website_url VARCHAR(500),
    cta_text VARCHAR(200),
    cta_link VARCHAR(500),
    download_links JSONB,
    price VARCHAR(100),
    pricing_model VARCHAR(50),
    category VARCHAR(100),
    tags JSONB,
    status VARCHAR(50) DEFAULT 'inactive',
    is_active BOOLEAN DEFAULT FALSE,
    content_count INTEGER DEFAULT 0,
    publish_count INTEGER DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

#### 2. intelligence_topics - 情报主题表
```sql
CREATE TABLE intelligence_topics (
    id UUID PRIMARY KEY,
    name VARCHAR(200) NOT NULL,
    keywords JSONB NOT NULL,
    description TEXT,
    sources JSONB NOT NULL,
    schedule VARCHAR(50) DEFAULT 'daily',
    config JSONB NOT NULL,
    is_active BOOLEAN DEFAULT TRUE,
    total_items INTEGER DEFAULT 0,
    today_items INTEGER DEFAULT 0,
    weekly_items INTEGER DEFAULT 0,
    last_run_time TIMESTAMP,
    last_status VARCHAR(100),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

#### 3. intelligence_items - 情报项表
```sql
CREATE TABLE intelligence_items (
    id UUID PRIMARY KEY,
    topic_id UUID NOT NULL REFERENCES intelligence_topics(id) ON DELETE CASCADE,
    title TEXT NOT NULL,
    content TEXT NOT NULL,
    url VARCHAR(1000) NOT NULL,
    source VARCHAR(200) NOT NULL,
    author VARCHAR(200),
    published_at TIMESTAMP NOT NULL,
    collected_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

    -- 评分
    relevance_score FLOAT DEFAULT 0.0,
    timeliness_score FLOAT DEFAULT 0.0,
    authority_score FLOAT DEFAULT 0.0,
    overall_score FLOAT DEFAULT 0.0,

    -- AI处理
    ai_summary TEXT,
    key_insights JSONB,
    tags JSONB,

    -- 去重
    guid VARCHAR(500),
    url_hash VARCHAR(64) NOT NULL,
    content_hash VARCHAR(64),

    -- 向量
    embedding_id VARCHAR(100),

    -- 元数据
    data_metadata JSONB,

    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_intelligence_items_topic_id ON intelligence_items(topic_id);
CREATE INDEX idx_intelligence_items_published_at ON intelligence_items(published_at);
CREATE INDEX idx_intelligence_items_overall_score ON intelligence_items(overall_score);
CREATE INDEX idx_intelligence_items_guid ON intelligence_items(guid);
CREATE INDEX idx_intelligence_items_url_hash ON intelligence_items(url_hash);
```

#### 4. intelligence_reports - 情报报告表
```sql
CREATE TABLE intelligence_reports (
    id UUID PRIMARY KEY,
    topic_id UUID NOT NULL REFERENCES intelligence_topics(id) ON DELETE CASCADE,
    period_start TIMESTAMP NOT NULL,
    period_end TIMESTAMP NOT NULL,
    total_items INTEGER DEFAULT 0,
    new_items INTEGER DEFAULT 0,
    sources_breakdown JSONB,
    summary TEXT,
    key_trends JSONB,
    hot_topics JSONB,
    sentiment VARCHAR(50),
    top_items JSONB,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

### Repository层

```python
# 使用示例
from app.db.connection import get_db_session
from app.db.repository import product_repository

async def example():
    async with get_db_session() as session:
        # 获取所有产品
        products = await product_repository.list(session)

        # 获取激活产品
        active = await product_repository.get_active(session)

        # 创建产品
        new_product = await product_repository.create(
            session,
            name="测试产品",
            type="saas",
            description="测试描述",
            target_audience="开发者"
        )
```

---

## 🔴 Redis - 缓存层

### 连接配置
```python
# app/core/config.py
REDIS_URL = "redis://localhost:6379"
```

### 缓存使用示例

```python
from app.cache.redis_cache import get_cache_service, cached

# 基础缓存操作
cache = get_cache_service()

# 设置缓存
await cache.set("product:123", product_data, ttl=3600)

# 获取缓存
cached_data = await cache.get("product:123")

# 删除缓存
await cache.delete("product:123")

# 装饰器缓存
@cached(ttl=1800, key_prefix="product")
async def get_product(product_id: str):
    # 函数结果会自动缓存30分钟
    pass
```

### 缓存策略

| 数据类型 | TTL (秒) | 说明 |
|---------|----------|------|
| 产品列表 | 1800 (30分钟) | 变化频率低 |
| 情报列表 | 300 (5分钟) | 变化频率高 |
| 情报详情 | 600 (10分钟) | 中等频率 |
| 用户会话 | 86400 (24小时) | 长期有效 |

---

## 🎨 ChromaDB - 向量存储

### 存储配置
```python
# ChromaDB存储在本地
data/chromadb/
```

### 向量集合

**集合名称**: `intelligence_items`

**用途**: 情报内容的向量化存储和语义检索

### 使用示例

```python
from app.vector.chroma_store import get_vector_store

vector_store = get_vector_store()

# 添加单个情报项
await vector_store.add_item(
    item_id="123",
    content="这是一篇关于AI的文章内容...",
    metadata={"source": "google_news", "topic": "AI"}
)

# 语义搜索
results = await vector_store.search(
    query="人工智能最新进展",
    n_results=10
)

# 删除情报项
await vector_store.delete_item("123")

# 统计数量
count = await vector_store.count_items()
```

### 向量检索应用场景

- 🔍 **语义搜索** - 根据内容含义搜索情报
- 🤝 **相似推荐** - 推荐相关的情报
- 📊 **聚类分析** - 对情报进行主题聚类
- 🧠 **AI增强** - 为AI RAG提供检索能力

---

## 📁 文件存储 - 图片/附件

### 存储服务

```python
from app.db.connection import get_file_storage

file_storage = get_file_storage()

# 保存文件
file_path = await file_storage.save_file(
    file_data=image_bytes,
    filename="screenshot.png",
    category="images"
)
# 返回: data/files/images/20240228_abc12345.png
```

### 目录结构

```
data/files/
├── images/          # 图片
├── attachments/     # 附件
└── exports/         # 导出文件
```

---

## 🚀 初始化流程

### 应用启动时

```python
# main.py
async def lifespan(app: FastAPI):
    # 启动时自动初始化所有数据库
    await init_all_databases()
```

初始化顺序：
1. ✅ **PostgreSQL** - 创建表结构
2. ✅ **Redis** - 建立连接
3. ✅ **ChromaDB** - 初始化向量存储
4. ⚠️ **文件存储** - 创建目录结构

---

## 📊 数据流转图

```
                    ┌─────────────────┐
                    │   FastAPI App    │
                    └─────────────────┘
                               ↓
    ┌──────────────────┬──────────────┬──────────────┐
    ↓                    ↓              ↓              ↓
┌─────────┐      ┌──────────┐   ┌──────┐   ┌─────────┐
│PostgreSQL│   │   Redis   │   │Chroma│   │ Files   │
(核心数据)      │  (缓存)   │   │   DB │ (图片文件)│
└─────────┘      └──────────┘   └──────┘   └─────────┘
```

---

## 🔧 使用示例

### 1. PostgreSQL - 创建产品

```python
from app.db.connection import get_db_session
from app.db.repository import product_repository

async def create_product():
    async with get_db_session() as session:
        product = await product_repository.create(
            session,
            name="新产品",
            type="saas",
            description="这是一个新产品",
            target_audience="开发者",
            selling_points=["功能1", "功能2"],
            tags=["AI", "自动化"]
        )
        # 自动提交事务
```

### 2. Redis - 缓存产品列表

```python
from app.cache.redis_cache import get_cache_service

async def get_products_with_cache():
    cache = get_cache_service()

    # 尝试从缓存获取
    cached = await cache.get("products:all")
    if cached:
        return cached

    # 缓存未命中，从数据库获取
    async with get_db_session() as session:
        products = await product_repository.list(session)

    # 存入缓存（1小时）
    await cache.set("products:all", products, ttl=3600)
    return products
```

### 3. ChromaDB - 语义搜索

```python
from app.vector.chroma_store import get_vector_store

async def search_intelligence(query: str):
    vector_store = get_vector_store()

    # 语义搜索最相关的情报
    results = await vector_store.search(
        query=query,
        n_results=10,
        where={"source": "google_news"}  # 元数据过滤
    )

    return results
```

### 4. 文件存储 - 保存图片

```python
from app.db.connection import get_file_storage

async def upload_image(image_data: bytes, filename: str):
    file_storage = get_file_storage()

    # 保存图片
    file_path = await file_storage.save_file(
        file_data=image_data,
        filename=filename,
        category="images"
    )

    return file_path
```

---

## 📈 性能优化

### PostgreSQL
- ✅ **连接池** - 10个连接，最大溢出20
- ✅ **索引优化** - 关键字段已添加索引
- ✅ **异步操作** - 使用asyncpg异步驱动
- ✅ **级联删除** - 自动清理关联数据

### Redis
- ✅ **连接池** - 50个最大连接
- ✅ **自动序列化** - JSON格式存储
- ✅ **TTL管理** - 自动过期机制

### ChromaDB
- ✅ **持久化存储** - 本地磁盘持久化
- ✅ **余弦相似度** - 高效向量检索
- ✅ **元数据过滤** - 支持条件查询

---

## 🧪 测试数据库连接

### 1. 测试PostgreSQL连接

```bash
# 确保PostgreSQL正在运行
docker ps | grep postgres

# 或检查本地PostgreSQL
pg_isready -h localhost -p 5432
```

### 2. 测试Redis连接

```bash
# 确保Redis正在运行
redis-cli ping
# 应该返回 PONG
```

### 3. 查看数据库状态

```bash
# 启动应用后会自动初始化
python main.py

# 查看日志
# 应该看到 "All databases initialized successfully"
```

---

## 🛠️ 数据库迁移指南

### 从文件存储迁移到数据库

当前系统使用文件存储，迁移到数据库的步骤：

#### Phase 1: 数据导出
```python
# 从products.json导出数据
import json

with open('data/products.json', 'r') as f:
    data = json.load(f)

for product_data in data['products']:
    # 产品数据已准备好，可以直接插入数据库
    pass
```

#### Phase 2: 数据导入
```python
from app.db.connection import get_db_session
from app.db.repository import product_repository

async def migrate_products():
    async with get_db_session() as session:
        for product_data in products_data['products']:
            await product_repository.create(session, **product_data)
```

#### Phase 3: 验证
```bash
# 查询数据库
psql -h localhost -U user -d sparkflow -c "SELECT COUNT(*) FROM products;"
```

---

## 🔐 安全配置

### 环境变量

```bash
# .env
DATABASE_URL=postgresql+asyncpg://user:password@localhost:5432/sparkflow
REDIS_URL=redis://localhost:6379

# 如果使用Docker
DATABASE_URL=postgresql+asyncpg://postgres:password@host.docker.internal:5432/sparkflow
REDIS_URL=redis://redis:6379/0
```

### Docker Compose配置

```yaml
# docker-compose.yml
services:
  postgres:
    image: postgres:15
    environment:
      POSTGRES_DB: sparkflow
      POSTGRES_USER: user
      POSTGRES_PASSWORD: password
    ports:
      - "5432:5432"
    volumes:
      - postgres_data:/var/lib/postgresql/data

  redis:
    image: redis:7
    ports:
      - "6379:6379"
    volumes:
      - redis_data:/data

volumes:
  postgres_data:
  redis_data:
```

---

## 📊 性能指标

### 预期性能

| 操作 | PostgreSQL | Redis | ChromaDB |
|------|------------|-------|----------|
| 简单查询 | < 10ms | < 1ms | < 100ms |
| 复杂查询 | < 100ms | N/A | N/A |
| 向量搜索 | N/A | N/A | < 500ms |
| 批量插入 | < 1000ms | N/A | N/A |

### 容量规划

| 数据量 | PostgreSQL | Redis | ChromaDB |
|--------|------------|-------|----------|
| < 10K条 | ⭐⭐⭐⭐⭐ | - | - |
| 10K-100K条 | ⭐⭐⭐⭐ | ⭐⭐⭐⭐ | ⭐⭐⭐ |
| > 100K条 | ⭐⭐⭐ | ⭐⭐⭐⭐ | ⭐⭐⭐⭐ |

---

## 🎯 最佳实践

### 1. PostgreSQL
- ✅ 使用Repository层，避免直接SQL
- ✅ 利用连接池，避免频繁创建连接
- ✅ 添加适当的索引，优化查询性能
- ⚠️ 避免N+1查询，使用JOIN

### 2. Redis
- ✅ 缓存读多写少的数据
- ✅ 设置合理的TTL，避免内存溢出
- ✅ 使用批量操作提高性能
- ⚠️ 不要缓存大量数据

### 3. ChromaDB
- ✅ 只向量化需要搜索的文本
- ✅ 定期清理过期数据
- ✅ 使用元数据过滤，提高搜索精度
- ⚠️ 向量化操作较慢，异步执行

---

## 📞 常见问题

### Q: PostgreSQL无法连接？
A: 检查以下几点：
1. PostgreSQL服务是否运行
2. 数据库URL配置是否正确
3. 用户名密码是否正确
4. 数据库是否已创建

```bash
# 测试连接
psql -h localhost -U user -d sparkflow
```

### Q: Redis无法连接？
A:
```bash
# 检查Redis服务
redis-cli ping

# 查看Redis日志
tail -f /usr/local/var/log/redis.log
```

### Q: ChromaDB初始化失败？
A: ChromaDB不依赖外部服务，只使用本地文件存储，检查：
```bash
ls -la data/chromadb/
```

### Q: 如何清空所有数据？
A:
```sql
-- 清空PostgreSQL表（保留结构）
TRUNCATE products CASCADE;
TRUNCATE intelligence_topics CASCADE;
TRUNCATE intelligence_items CASCADE;
TRUNCATE intelligence_reports CASCADE;

-- 清空Redis
redis-cli FLUSHALL

-- 清空ChromaDB
rm -rf data/chromadb/*
```

---

**文档版本**: v1.0
**最后更新**: 2024-02-28
**状态**: ✅ 数据库架构已完成，可以使用
