# SparkFlow 技术架构文档

## 一、系统概览

### 1.1 架构设计原则

- **简单优先**：个人开发可维护
- **模块化**：各模块独立可测试
- **可扩展**：易于添加新平台和功能
- **成本可控**：优化 API 调用
- **快速迭代**：MVP 快速上线

### 1.2 整体架构图

```
┌─────────────────────────────────────────────────────────────────┐
│                         应用层 (Application)                      │
├─────────────────────────────────────────────────────────────────┤
│                                                                  │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐         │
│  │   Web API    │  │   Scheduler  │  │   Webhook    │         │
│  │   (FastAPI)  │  │   (定时任务)  │  │  (回调处理)   │         │
│  └──────┬───────┘  └──────┬───────┘  └──────┬───────┘         │
│         │                 │                 │                  │
│         └─────────────────┼─────────────────┘                  │
│                           ↓                                    │
├─────────────────────────────────────────────────────────────────┤
│                      业务逻辑层 (Business Logic)                 │
├─────────────────────────────────────────────────────────────────┤
│                                                                  │
│  ┌──────────────────────────────────────────────────────────┐  │
│  │              LangGraph 编排层 (Orchestration)             │  │
│  │                                                           │  │
│  │  ┌──────────┐   ┌──────────┐   ┌──────────┐            │  │
│  │  │Monitor   │→  │Generate  │→  │Publish   │            │  │
│  │  │Agent     │   │Agent     │   │Agent     │            │  │
│  │  └──────────┘   └──────────┘   └──────────┘            │  │
│  │        ↓                              ↑                  │  │
│  │  ┌──────────┐                   ┌──────────┐            │  │
│  │  │Analyze   │                   │Optimize  │            │  │
│  │  │Agent     │←──────────────────│Agent     │            │  │
│  │  └──────────┘   数据反馈循环    └──────────┘            │  │
│  └──────────────────────────────────────────────────────────┘  │
│                                                                  │
├─────────────────────────────────────────────────────────────────┤
│                       服务层 (Services)                          │
├─────────────────────────────────────────────────────────────────┤
│                                                                  │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐         │
│  │  Content     │  │  Platform    │  │   Analytics  │         │
│  │  Service     │  │  Service     │  │   Service    │         │
│  └──────────────┘  └──────────────┘  └──────────────┘         │
│                                                                  │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐         │
│  │  Monitor     │  │   Storage    │  │    Cache     │         │
│  │  Service     │  │  Service     │  │   Service    │         │
│  └──────────────┘  └──────────────┘  └──────────────┘         │
│                                                                  │
├─────────────────────────────────────────────────────────────────┤
│                       数据层 (Data Layer)                        │
├─────────────────────────────────────────────────────────────────┤
│                                                                  │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐         │
│  │   PostgreSQL │  │  ChromaDB    │  │    Redis     │         │
│  │  (业务数据)   │  │  (向量存储)   │  │   (缓存)     │         │
│  └──────────────┘  └──────────────┘  └──────────────┘         │
│                                                                  │
├─────────────────────────────────────────────────────────────────┤
│                    外部集成层 (Integrations)                     │
├─────────────────────────────────────────────────────────────────┤
│                                                                  │
│  ┌──────────┐  ┌──────────┐  ┌──────────┐  ┌──────────┐       │
│  │ Twitter  │  │  Reddit  │  │ OpenAI   │  │  Hacker  │       │
│  │   API    │  │   API    │  │   API    │  │   News   │       │
│  └──────────┘  └──────────┘  └──────────┘  └──────────┘       │
│                                                                  │
└─────────────────────────────────────────────────────────────────┘
```

---

## 二、技术选型

### 2.1 核心框架

| 技术 | 版本 | 用途 | 选择理由 |
|------|------|------|----------|
| **Python** | 3.11+ | 主要开发语言 | AI 生态最好 |
| **FastAPI** | 0.104+ | Web 框架 | 高性能、异步、自动文档 |
| **LangGraph** | 0.0.30+ | Agent 编排 | 状态管理、可视化 |
| **Pydantic** | 2.0+ | 数据验证 | 类型安全、自动验证 |

### 2.2 AI/ML

| 技术 | 版本 | 用途 | 选择理由 |
|------|------|------|----------|
| **OpenAI** | 1.0+ | LLM 主要模型 | 效果最好、稳定 |
| **LangChain** | 0.1.0+ | LLM 框架 | 生态完善 |
| **ChromaDB** | 0.4.0+ | 向量数据库 | 轻量级、易部署 |

### 2.3 数据存储

| 技术 | 版本 | 用途 | 选择理由 |
|------|------|------|----------|
| **PostgreSQL** | 15+ | 主数据库 | 关系型、可靠 |
| **Redis** | 7.0+ | 缓存/队列 | 高性能、支持队列 |
| **ChromaDB** | 0.4.0+ | 向量存储 | 轻量级、本地可运行 |

### 2.4 平台集成

| 平台 | SDK | 用途 |
|------|-----|------|
| **Twitter** | tweepy | 发布内容、监控热点 |
| **Reddit** | praw | 监控话题、发布内容 |
| **HackerNews** | requests | 抓取热门帖子 |

### 2.5 工具库

| 库 | 版本 | 用途 |
|----|------|------|
| **httpx** | 0.25+ | 异步 HTTP 请求 |
| **schedule** | 1.2+ | 定时任务 |
| **apscheduler** | 3.10+ | 高级调度 |
| **beautifulsoup4** | 4.12+ | HTML 解析 |
| **feedparser** | 6.0+ | RSS 解析 |

---

## 三、核心模块设计

### 3.1 目录结构

```
sparkflow/
├── app/                          # 应用根目录
│   ├── api/                      # API 层
│   │   ├── v1/                   # API v1
│   │   │   ├── endpoints/        # 路由端点
│   │   │   │   ├── content.py    # 内容相关
│   │   │   │   ├── campaigns.py  # 营销活动
│   │   │   │   ├── analytics.py  # 数据分析
│   │   │   │   └── platforms.py  # 平台管理
│   │   │   └── api.py            # API 聚合
│   │   └── deps.py               # 依赖注入
│   │
│   ├── core/                     # 核心配置
│   │   ├── config.py             # 配置管理
│   │   ├── security.py           # 安全相关
│   │   └── logging.py            # 日志配置
│   │
│   ├── agents/                   # Agent 层
│   │   ├── base.py               # Agent 基类
│   │   ├── monitor_agent.py      # 监控 Agent
│   │   ├── generate_agent.py     # 生成 Agent
│   │   ├── publish_agent.py      # 发布 Agent
│   │   ├── analyze_agent.py      # 分析 Agent
│   │   └── optimize_agent.py     # 优化 Agent
│   │
│   ├── services/                 # 服务层
│   │   ├── content_service.py    # 内容服务
│   │   ├── platform_service.py   # 平台服务
│   │   ├── monitor_service.py    # 监控服务
│   │   ├── analytics_service.py  # 分析服务
│   │   └── storage_service.py    # 存储服务
│   │
│   ├── integrations/             # 集成层
│   │   ├── twitter/              # Twitter 集成
│   │   │   ├── client.py         # API 客户端
│   │   │   ├── models.py         # 数据模型
│   │   │   └── webhook.py        # Webhook 处理
│   │   ├── reddit/               # Reddit 集成
│   │   │   ├── client.py
│   │   │   ├── models.py
│   │   │   └── webhook.py
│   │   ├── hackernews/           # HackerNews 集成
│   │   │   └── client.py
│   │   └── llm/                  # LLM 集成
│   │       ├── openai_client.py
│   │       └── prompts.py        # Prompt 模板
│   │
│   ├── models/                   # 数据模型
│   │   ├── content.py            # 内容模型
│   │   ├── campaign.py           # 活动模型
│   │   ├── platform.py           # 平台模型
│   │   └── analytics.py          # 分析模型
│   │
│   ├── workflows/                # 工作流
│   │   ├── marketing_workflow.py # 营销主流程
│   │   └── graphs/               # LangGraph 定义
│   │       ├── monitor_graph.py
│   │       ├── generate_graph.py
│   │       └── optimize_graph.py
│   │
│   ├── db/                       # 数据库
│   │   ├── session.py            # 数据库会话
│   │   ├── base.py               # 基类
│   │   └── repositories/         # 仓储模式
│   │       ├── content_repo.py
│   │       ├── campaign_repo.py
│   │       └── analytics_repo.py
│   │
│   ├── utils/                    # 工具函数
│   │   ├── text.py               # 文本处理
│   │   ├── date.py               # 日期处理
│   │   └── rate_limit.py         # 限流
│   │
│   └── main.py                   # 应用入口
│
├── tests/                        # 测试
│   ├── unit/                     # 单元测试
│   ├── integration/              # 集成测试
│   └── e2e/                      # 端到端测试
│
├── scripts/                      # 脚本
│   ├── init_db.py                # 初始化数据库
│   ├── migrate.py                # 数据迁移
│   └── seed_data.py              # 种子数据
│
├── docs/                         # 文档
│   ├── api.md                    # API 文档
│   ├── deployment.md             # 部署文档
│   └── development.md            # 开发文档
│
├── .env.example                  # 环境变量示例
├── .gitignore
├── docker-compose.yml            # Docker 编排
├── Dockerfile
├── requirements.txt              # 依赖列表
├── pyproject.toml                # 项目配置
└── README.md
```

### 3.2 核心模块详解

#### 3.2.1 Agent 基类设计

```python
# app/agents/base.py

from abc import ABC, abstractmethod
from typing import Any, Dict, Optional
from langgraph.graph import StateGraph

class AgentState(TypedDict):
    """Agent 状态定义"""
    input: Dict[str, Any]
    output: Dict[str, Any]
    context: Dict[str, Any]
    errors: List[str]
    metadata: Dict[str, Any]

class BaseAgent(ABC):
    """Agent 基类"""

    def __init__(self, config: Dict[str, Any]):
        self.config = config
        self.llm = self._init_llm()
        self.graph = self._build_graph()

    @abstractmethod
    def _init_llm(self):
        """初始化 LLM"""
        pass

    @abstractmethod
    def _build_graph(self) -> StateGraph:
        """构建工作流图"""
        pass

    @abstractmethod
    async def run(self, state: AgentState) -> AgentState:
        """执行 Agent 逻辑"""
        pass

    async def stream(self, state: AgentState):
        """流式输出"""
        async for chunk in self.graph.astream(state):
            yield chunk
```

#### 3.2.2 监控 Agent

```python
# app/agents/monitor_agent.py

class MonitorAgent(BaseAgent):
    """监控热点和趋势的 Agent"""

    def _build_graph(self) -> StateGraph:
        """构建监控流程图"""
        graph = StateGraph(AgentState)

        graph.add_node("fetch_sources", self._fetch_sources)
        graph.add_node("extract_topics", self._extract_topics)
        graph.add_node("score_relevance", self._score_relevance)
        graph.add_node("filter_topics", self._filter_topics)

        graph.set_entry_point("fetch_sources")
        graph.add_edge("fetch_sources", "extract_topics")
        graph.add_edge("extract_topics", "score_relevance")
        graph.add_edge("score_relevance", "filter_topics")
        graph.set_finish_point("filter_topics")

        return graph.compile()

    async def _fetch_sources(self, state: AgentState) -> AgentState:
        """从多个数据源获取数据"""
        sources = []

        # Twitter 热门推文
        twitter_data = await self.twitter_client.get_trending_tweets(
            query="AI OR marketing OR automation",
            count=100
        )
        sources.extend(twitter_data)

        # HackerNews 热门帖子
        hn_data = await self.hn_client.get_front_page()
        sources.extend(hn_data)

        # Reddit AI 相关帖子
        reddit_data = await self.reddit_client.get_hot_posts(
            subreddits=["MachineLearning", "artificial", "Marketing"]
        )
        sources.extend(reddit_data)

        state["context"]["sources"] = sources
        return state

    async def _extract_topics(self, state: AgentState) -> AgentState:
        """提取热门话题和关键词"""
        sources = state["context"]["sources"]

        prompt = f"""
        分析以下内容，提取热门话题和关键词：

        {json.dumps(sources, ensure_ascii=False)}

        请返回：
        1. top_topics: 前 10 个热门话题
        2. keywords: 相关关键词
        3. sentiment: 情感倾向
        4. viral_score: 病毒传播潜力分数 (0-100)
        """

        result = await self.llm.ainvoke(prompt)
        state["output"]["topics"] = parse_llm_response(result)
        return state

    async def _score_relevance(self, state: AgentState) -> AgentState:
        """评分话题相关性"""
        topics = state["output"]["topics"]

        # 向量搜索历史数据
        for topic in topics:
            similar = await self.vector_store.search(
                query=topic["title"],
                top_k=5
            )
            topic["historical_performance"] = similar

        state["output"]["scored_topics"] = topics
        return state

    async def _filter_topics(self, state: AgentState) -> AgentState:
        """筛选最值得跟进的话题"""
        scored = state["output"]["scored_topics"]

        # 过滤条件
        filtered = [
            t for t in scored
            if t["viral_score"] > 70
            and t["relevance_score"] > 60
        ]

        state["output"]["selected_topics"] = filtered[:5]
        return state
```

#### 3.2.3 内容生成 Agent

```python
# app/agents/generate_agent.py

class GenerateAgent(BaseAgent):
    """内容生成 Agent"""

    def _build_graph(self) -> StateGraph:
        graph = StateGraph(AgentState)

        graph.add_node("analyze_topic", self._analyze_topic)
        graph.add_node("select_template", self._select_template)
        graph.add_node("generate_content", self._generate_content)
        graph.add_node("optimize_for_platform", self._optimize_for_platform)
        graph.add_node("quality_check", self._quality_check)

        graph.set_entry_point("analyze_topic")
        graph.add_edge("analyze_topic", "select_template")
        graph.add_edge("select_template", "generate_content")
        graph.add_edge("generate_content", "optimize_for_platform")
        graph.add_edge("optimize_for_platform", "quality_check")
        graph.set_finish_point("quality_check")

        return graph.compile()

    async def _generate_content(self, state: AgentState) -> AgentState:
        """生成营销内容"""
        topic = state["input"]["topic"]
        platform = state["input"]["platform"]

        # 获取产品信息
        product_info = await self._get_product_info()

        # 获取历史表现好的内容
        top_performing = await self.db.get_top_content(
            platform=platform,
            limit=3
        )

        prompt = ChatPromptTemplate.from_messages([
            ("system", self._get_system_prompt()),
            ("human", self._get_user_prompt())
        ])

        messages = prompt.format_messages(
            topic=topic,
            product=product_info,
            platform=platform,
            examples=top_performing
        )

        content = await self.llm.ainvoke(messages)

        # 生成多个版本
        state["output"]["content_variants"] = [
            {
                "version": i,
                "content": variant,
                "platform": platform
            }
            for i, variant in enumerate(self._create_variants(content))
        ]

        return state

    def _get_system_prompt(self) -> str:
        return """你是一位专业的营销内容创作者。

你的专长是：
1. 将热点话题与产品自然结合
2. 创作引人入胜的开头
3. 使用清晰的价值主张
4. 包含强有力的 CTA
5. 适配不同平台的风格

输出要求：
- Twitter: 短小精悍，使用表情符号，包含话题标签
- Reddit: 深度讨论型，提供价值，避免过度营销
- Blog: 结构清晰，SEO 友好，1500+ 字

重要：避免明显的营销话术，要自然、真诚、有价值。"""

    def _get_user_prompt(self) -> str:
        return """基于以下信息生成营销内容：

热点话题：
{topic}

产品信息：
{product}

目标平台：
{platform}

参考案例（表现好的内容）：
{examples}

请生成 3 个不同版本的内容，每个版本都要：
1. 有独特的角度
2. 自然地融入产品
3. 符合平台风格
4. 包含 CTA

返回 JSON 格式：
{{
  "versions": [
    {{"angle": "角度描述", "content": "内容文本", "cta": "行动号召"}},
    ...
  ]
}}
"""
```

#### 3.2.4 发布 Agent

```python
# app/agents/publish_agent.py

class PublishAgent(BaseAgent):
    """发布内容 Agent"""

    async def run(self, state: AgentState) -> AgentState:
        """发布到各个平台"""
        content = state["input"]["content"]
        platforms = state["input"]["platforms"]

        results = []

        for platform in platforms:
            try:
                # 平台特定处理
                if platform == "twitter":
                    result = await self._publish_to_twitter(content)
                elif platform == "reddit":
                    result = await self._publish_to_reddit(content)
                elif platform == "blog":
                    result = await self._publish_to_blog(content)

                results.append({
                    "platform": platform,
                    "status": "success",
                    "post_id": result["id"],
                    "url": result["url"]
                })

                # 记录发布
                await self.db.create_publication_record(result)

            except Exception as e:
                results.append({
                    "platform": platform,
                    "status": "failed",
                    "error": str(e)
                })

        state["output"]["publish_results"] = results
        return state

    async def _publish_to_twitter(self, content: str) -> Dict:
        """发布到 Twitter"""
        # 检查长度限制
        if len(content) > 280:
            content = self._split_thread(content)

        response = await self.twitter_client.create_tweet(text=content)

        return {
            "id": response.data["id"],
            "url": f"https://twitter.com/user/status/{response.data['id']}"
        }

    async def _publish_to_reddit(
        self,
        content: Dict[str, str]
    ) -> Dict:
        """发布到 Reddit"""
        subreddit = content["subreddit"]
        title = content["title"]
        body = content["body"]

        submission = await self.reddit_client.submit(
            subreddit=subreddit,
            title=title,
            selftext=body
        )

        return {
            "id": submission.id,
            "url": f"https://reddit.com{submission.permalink}"
        }
```

### 3.3 服务层设计

#### 3.3.1 内容服务

```python
# app/services/content_service.py

class ContentService:
    """内容管理服务"""

    def __init__(
        self,
        db: AsyncSession,
        llm: BaseLLM,
        vector_store: VectorStore
    ):
        self.db = db
        self.llm = llm
        self.vector_store = vector_store

    async def create_campaign(
        self,
        name: str,
        goals: List[str],
        platforms: List[str],
        duration: int
    ) -> Campaign:
        """创建营销活动"""
        campaign = Campaign(
            name=name,
            goals=goals,
            platforms=platforms,
            duration_days=duration,
            status="active"
        )

        self.db.add(campaign)
        await self.db.commit()

        # 启动监控工作流
        await self._start_monitoring(campaign.id)

        return campaign

    async def generate_content(
        self,
        topic_id: str,
        platforms: List[str],
        variants: int = 3
    ) -> List[Content]:
        """生成内容"""
        # 获取话题详情
        topic = await self.db.get_topic(topic_id)

        # 运行生成 Agent
        agent = GenerateAgent(self.config)
        result = await agent.run({
            "input": {
                "topic": topic,
                "platforms": platforms
            }
        })

        # 保存生成的内容
        contents = []
        for variant in result["output"]["content_variants"]:
            content = Content(
                topic_id=topic_id,
                platform=variant["platform"],
                content=variant["content"],
                version=variant["version"],
                status="pending_review"
            )
            contents.append(content)
            self.db.add(content)

        await self.db.commit()
        return contents

    async def approve_content(
        self,
        content_id: str,
        user_id: str
    ) -> Content:
        """审核通过内容"""
        content = await self.db.get_content(content_id)
        content.status = "approved"
        content.reviewed_by = user_id
        content.reviewed_at = datetime.utcnow()

        await self.db.commit()

        # 自动发布
        await self._schedule_publish(content)

        return content

    async def get_analytics(
        self,
        campaign_id: str,
        date_range: DateRange
    ) -> Analytics:
        """获取分析数据"""
        # 获取所有发布的内容
        publications = await self.db.get_publications(
            campaign_id=campaign_id,
            start_date=date_range.start,
            end_date=date_range.end
        )

        # 聚合指标
        analytics = Analytics(
            total_posts=len(publications),
            total_impressions=sum(p.impressions for p in publications),
            total_engagement=sum(p.engagement for p in publications),
            avg_engagement_rate=self._calculate_avg_rate(publications),
            top_performing=self._get_top_posts(publications)
        )

        return analytics
```

---

## 四、数据模型设计

### 4.1 数据库 Schema

```sql
-- 营销活动表
CREATE TABLE campaigns (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name VARCHAR(255) NOT NULL,
    description TEXT,
    goals JSONB,
    target_platforms VARCHAR(50)[],
    status VARCHAR(50) DEFAULT 'active',
    duration_days INTEGER,
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

-- 热点话题表
CREATE TABLE topics (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    title VARCHAR(500) NOT NULL,
    source VARCHAR(100) NOT NULL,
    source_url TEXT,
    viral_score INTEGER,
    relevance_score INTEGER,
    keywords VARCHAR(255)[],
    sentiment VARCHAR(50),
    discovered_at TIMESTAMP DEFAULT NOW(),
    status VARCHAR(50) DEFAULT 'pending'
);

-- 内容表
CREATE TABLE contents (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    topic_id UUID REFERENCES topics(id),
    campaign_id UUID REFERENCES campaigns(id),
    platform VARCHAR(50) NOT NULL,
    content TEXT NOT NULL,
    version INTEGER DEFAULT 1,
    status VARCHAR(50) DEFAULT 'draft',
    metadata JSONB,
    created_at TIMESTAMP DEFAULT NOW(),
    reviewed_at TIMESTAMP,
    reviewed_by UUID,
    published_at TIMESTAMP
);

-- 发布记录表
CREATE TABLE publications (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    content_id UUID REFERENCES contents(id),
    platform VARCHAR(50) NOT NULL,
    platform_post_id VARCHAR(255),
    platform_post_url TEXT,
    status VARCHAR(50) DEFAULT 'published',
    published_at TIMESTAMP DEFAULT NOW(),
    metadata JSONB
);

-- 分析数据表
CREATE TABLE analytics (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    publication_id UUID REFERENCES publications(id),
    impressions INTEGER DEFAULT 0,
    likes INTEGER DEFAULT 0,
    comments INTEGER DEFAULT 0,
    shares INTEGER DEFAULT 0,
    clicks INTEGER DEFAULT 0,
    conversions INTEGER DEFAULT 0,
    recorded_at TIMESTAMP DEFAULT NOW(),
    metadata JSONB
);

-- 向量存储表（通过 ChromaDB 管理）
-- collections: contents_history, topics_history
```

### 4.2 Pydantic 模型

```python
# app/models/content.py

from pydantic import BaseModel, Field
from typing import Optional, List, Dict, Any
from datetime import datetime
from enum import Enum

class Platform(str, Enum):
    TWITTER = "twitter"
    REDDIT = "reddit"
    BLOG = "blog"
    LINKEDIN = "linkedin"

class ContentStatus(str, Enum):
    DRAFT = "draft"
    PENDING_REVIEW = "pending_review"
    APPROVED = "approved"
    REJECTED = "rejected"
    PUBLISHED = "published"
    SCHEDULED = "scheduled"

class TopicBase(BaseModel):
    """话题基础模型"""
    title: str
    source: str
    source_url: Optional[str] = None
    viral_score: int = Field(ge=0, le=100)
    relevance_score: int = Field(ge=0, le=100)
    keywords: List[str] = []
    sentiment: Optional[str] = None

class TopicCreate(TopicBase):
    """创建话题"""
    pass

class Topic(TopicBase):
    """完整话题"""
    id: str
    discovered_at: datetime
    status: str

    class Config:
        from_attributes = True

class ContentBase(BaseModel):
    """内容基础模型"""
    platform: Platform
    content: str
    metadata: Optional[Dict[str, Any]] = None

class ContentCreate(ContentBase):
    """创建内容"""
    topic_id: str
    campaign_id: Optional[str] = None

class Content(ContentBase):
    """完整内容"""
    id: str
    topic_id: str
    version: int
    status: ContentStatus
    created_at: datetime
    reviewed_at: Optional[datetime] = None
    published_at: Optional[datetime] = None

    class Config:
        from_attributes = True

class PublicationMetrics(BaseModel):
    """发布指标"""
    impressions: int = 0
    likes: int = 0
    comments: int = 0
    shares: int = 0
    clicks: int = 0
    conversions: int = 0

    @property
    def engagement_rate(self) -> float:
        """互动率"""
        if self.impressions == 0:
            return 0.0
        return (self.likes + self.comments + self.shares) / self.impressions * 100

    @property
    def ctr(self) -> float:
        """点击率"""
        if self.impressions == 0:
            return 0.0
        return self.clicks / self.impressions * 100
```

---

## 五、API 设计

### 5.1 RESTful API 端点

```python
# app/api/v1/endpoints/content.py

from fastapi import APIRouter, Depends, HTTPException
from typing import List

router = APIRouter()

@router.post("/topics", response_model=Topic)
async def create_topic(
    topic: TopicCreate,
    service: ContentService = Depends(get_content_service)
):
    """创建新话题"""
    return await service.create_topic(topic)

@router.get("/topics", response_model=List[Topic])
async def list_topics(
    status: Optional[str] = None,
    limit: int = 20,
    service: ContentService = Depends(get_content_service)
):
    """获取话题列表"""
    return await service.list_topics(status=status, limit=limit)

@router.post("/contents/generate", response_model=List[Content])
async def generate_content(
    topic_id: str,
    platforms: List[Platform],
    variants: int = 3,
    service: ContentService = Depends(get_content_service)
):
    """生成内容"""
    return await service.generate_content(
        topic_id=topic_id,
        platforms=platforms,
        variants=variants
    )

@router.post("/contents/{content_id}/approve", response_model=Content)
async def approve_content(
    content_id: str,
    user_id: str,
    service: ContentService = Depends(get_content_service)
):
    """审核通过内容"""
    return await service.approve_content(content_id, user_id)

@router.get("/campaigns/{campaign_id}/analytics", response_model=Analytics)
async def get_campaign_analytics(
    campaign_id: str,
    start_date: datetime,
    end_date: datetime,
    service: ContentService = Depends(get_content_service)
):
    """获取活动分析数据"""
    return await service.get_analytics(
        campaign_id=campaign_id,
        date_range=DateRange(start=start_date, end=end_date)
    )
```

### 5.2 API 响应格式

```python
# 统一响应格式

class ApiResponse(BaseModel):
    """API 响应包装"""
    success: bool
    data: Optional[Any] = None
    error: Optional[str] = None
    metadata: Optional[Dict[str, Any]] = None

# 示例响应
{
    "success": true,
    "data": {
        "content_id": "uuid",
        "platform": "twitter",
        "content": "...",
        "status": "approved"
    },
    "error": null,
    "metadata": {
        "generated_at": "2024-01-01T00:00:00Z",
        "processing_time_ms": 1234
    }
}
```

---

## 六、部署架构

### 6.1 生产环境部署

```
┌─────────────────────────────────────────────────────────┐
│                      负载均衡器 (Nginx)                  │
└────────────────────┬────────────────────────────────────┘
                     │
                     ↓
┌─────────────────────────────────────────────────────────┐
│              应用服务器 (Gunicorn + FastAPI)             │
│                                                           │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐ │
│  │  Worker 1    │  │  Worker 2    │  │  Worker 3    │ │
│  │  (8 workers) │  │  (8 workers) │  │  (8 workers) │ │
│  └──────────────┘  └──────────────┘  └──────────────┘ │
└─────────────────────────────────────────────────────────┘
                     │
                     ↓
┌─────────────────────────────────────────────────────────┐
│                       数据层                             │
│                                                          │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐ │
│  │ PostgreSQL   │  │    Redis     │  │  ChromaDB    │ │
│  │  (主数据)     │  │  (缓存/队列)  │  │  (向量存储)   │ │
│  └──────────────┘  └──────────────┘  └──────────────┘ │
└─────────────────────────────────────────────────────────┘
                     │
                     ↓
┌─────────────────────────────────────────────────────────┐
│                      外部服务                             │
│                                                          │
│  ┌──────────┐  ┌──────────┐  ┌──────────┐             │
│  │ OpenAI   │  │ Twitter  │  │  Reddit  │             │
│  │   API    │  │   API    │  │   API    │             │
│  └──────────┘  └──────────┘  └──────────┘             │
└─────────────────────────────────────────────────────────┘
```

### 6.2 Docker Compose 配置

```yaml
# docker-compose.yml

version: '3.8'

services:
  app:
    build: .
    command: gunicorn app.main:app -w 4 -k uvicorn.workers.UvicornWorker
    volumes:
      - ./:/app
    ports:
      - "8000:8000"
    environment:
      - DATABASE_URL=postgresql://user:pass@db:5432/sparkflow
      - REDIS_URL=redis://redis:6379
      - OPENAI_API_KEY=${OPENAI_API_KEY}
    depends_on:
      - db
      - redis
    restart: unless-stopped

  worker:
    build: .
    command: python app/workers/worker.py
    environment:
      - DATABASE_URL=postgresql://user:pass@db:5432/sparkflow
      - REDIS_URL=redis://redis:6379
      - OPENAI_API_KEY=${OPENAI_API_KEY}
    depends_on:
      - db
      - redis
    restart: unless-stopped

  scheduler:
    build: .
    command: python app/workers/scheduler.py
    environment:
      - DATABASE_URL=postgresql://user:pass@db:5432/sparkflow
      - REDIS_URL=redis://redis:6379
    depends_on:
      - db
      - redis
    restart: unless-stopped

  db:
    image: postgres:15-alpine
    volumes:
      - postgres_data:/var/lib/postgresql/data
    environment:
      - POSTGRES_USER=user
      - POSTGRES_PASSWORD=pass
      - POSTGRES_DB=sparkflow
    ports:
      - "5432:5432"

  redis:
    image: redis:7-alpine
    ports:
      - "6379:6379"
    volumes:
      - redis_data:/data

  nginx:
    image: nginx:alpine
    ports:
      - "80:80"
      - "443:443"
    volumes:
      - ./nginx.conf:/etc/nginx/nginx.conf
      - ./ssl:/etc/nginx/ssl
    depends_on:
      - app

volumes:
  postgres_data:
  redis_data:
```

### 6.3 部署流程

```bash
# 1. 构建镜像
docker-compose build

# 2. 初始化数据库
docker-compose run app python scripts/init_db.py

# 3. 启动服务
docker-compose up -d

# 4. 检查健康状态
curl http://localhost:8000/health

# 5. 查看日志
docker-compose logs -f app
```

---

## 七、监控与日志

### 7.1 日志配置

```python
# app/core/logging.py

import logging
from datetime import datetime

class JsonFormatter(logging.Formatter):
    """JSON 格式日志"""

    def format(self, record):
        log_data = {
            "timestamp": datetime.utcnow().isoformat(),
            "level": record.levelname,
            "logger": record.name,
            "message": record.getMessage(),
            "module": record.module,
            "function": record.funcName,
            "line": record.lineno
        }

        if hasattr(record, "agent"):
            log_data["agent"] = record.agent
        if hasattr(record, "request_id"):
            log_data["request_id"] = record.request_id

        return json.dumps(log_data)

logging.basicConfig(
    level=logging.INFO,
    handlers=[logging.StreamHandler()]
)

logger = logging.getLogger("sparkflow")
logger.handlers[0].setFormatter(JsonFormatter())
```

### 7.2 监控指标

```python
# 关键指标
METRICS = {
    "agent": {
        "execution_time": "Agent 执行时间",
        "success_rate": "Agent 成功率",
        "error_count": "错误次数"
    },
    "content": {
        "generated_count": "生成内容数",
        "published_count": "发布内容数",
        "approval_rate": "审核通过率"
    },
    "platform": {
        "api_calls": "API 调用次数",
        "rate_limit_hits": "触发限流次数",
        "publish_success_rate": "发布成功率"
    },
    "llm": {
        "token_usage": "Token 使用量",
        "cost": "成本",
        "latency": "延迟"
    }
}
```

---

## 八、安全性设计

### 8.1 API 密钥管理

```python
# app/core/security.py

from cryptography.fernet import Fernet
import os

class SecretManager:
    """密钥管理器"""

    def __init__(self):
        key = os.environ.get("ENCRYPTION_KEY")
        if not key:
            key = Fernet.generate_key()
            os.environ["ENCRYPTION_KEY"] = key.decode()
        self.cipher = Fernet(key)

    def encrypt(self, data: str) -> str:
        """加密"""
        return self.cipher.encrypt(data.encode()).decode()

    def decrypt(self, encrypted: str) -> str:
        """解密"""
        return self.cipher.decrypt(encrypted.encode()).decode()

# 存储第三方 API 密钥时加密
secret_manager = SecretManager()
encrypted_key = secret_manager.encrypt("twitter_api_key")
```

### 8.2 速率限制

```python
# app/utils/rate_limit.py

from redis import Redis
from functools import wraps

def rate_limit(
    max_calls: int,
    time_window: int,
    key_prefix: str
):
    """速率限制装饰器"""
    def decorator(func):
        @wraps(func)
        async def wrapper(*args, **kwargs):
            redis = Redis.from_url(os.environ["REDIS_URL"])

            # 获取请求标识
            identifier = get_request_identifier()
            key = f"{key_prefix}:{identifier}"

            # 检查限制
            current = redis.incr(key)
            if current == 1:
                redis.expire(key, time_window)

            if current > max_calls:
                raise RateLimitExceeded(
                    f"Rate limit exceeded: {max_calls} calls per {time_window}s"
                )

            return await func(*args, **kwargs)
        return wrapper
    return decorator

# 使用示例
@rate_limit(max_calls=100, time_window=3600, key_prefix="twitter_api")
async def tweet(content: str):
    pass
```

---

## 九、扩展性设计

### 9.1 插件系统

```python
# app/plugins/base.py

class PlatformPlugin(ABC):
    """平台插件基类"""

    @abstractmethod
    async def authenticate(self, credentials: Dict) -> bool:
        """认证"""
        pass

    @abstractmethod
    async def publish(self, content: Content) -> Publication:
        """发布内容"""
        pass

    @abstractmethod
    async def get_metrics(self, post_id: str) -> Metrics:
        """获取指标"""
        pass

# 注册新平台
class LinkedInPlugin(PlatformPlugin):
    """LinkedIn 插件"""

    async def publish(self, content: Content) -> Publication:
        # LinkedIn 特定逻辑
        pass

# 插件管理器
plugin_manager = PluginManager()
plugin_manager.register("linkedin", LinkedInPlugin())
```

### 9.2 配置化工作流

```yaml
# workflows/marketing_workflow.yaml

name: "Marketing Workflow"
version: "1.0"

steps:
  - name: monitor
    agent: MonitorAgent
    config:
      sources: [twitter, reddit, hackernews]
      interval: 3600

  - name: generate
    agent: GenerateAgent
    depends_on: [monitor]
    config:
      platforms: [twitter, reddit]
      variants: 3
      llm: gpt-4

  - name: approve
    type: human_approval
    depends_on: [generate]

  - name: publish
    agent: PublishAgent
    depends_on: [approve]
    config:
      auto_publish: true

  - name: analyze
    agent: AnalyzeAgent
    depends_on: [publish]
    config:
      wait_time: 86400  # 24小时后分析

  - name: optimize
    agent: OptimizeAgent
    depends_on: [analyze]
```

---

## 十、性能优化

### 10.1 缓存策略

```python
# app/utils/cache.py

from functools import lru_cache
from redis import Redis

class CacheManager:
    """缓存管理器"""

    def __init__(self, redis: Redis):
        self.redis = redis

    async def get_or_set(
        self,
        key: str,
        factory: Callable,
        ttl: int = 3600
    ):
        """获取或设置缓存"""
        cached = await self.redis.get(key)
        if cached:
            return json.loads(cached)

        value = await factory()
        await self.redis.setex(
            key,
            ttl,
            json.dumps(value)
        )
        return value

# 使用示例
@lru_cache(maxsize=100)
def get_prompt_template(name: str) -> str:
    """缓存 Prompt 模板"""
    return load_template(name)
```

### 10.2 异步优化

```python
# 并发处理多个平台

async def publish_to_all_platforms(
    content: Content,
    platforms: List[Platform]
) -> List[Publication]:
    """并发发布到所有平台"""
    tasks = [
        publish_to_platform(content, platform)
        for platform in platforms
    ]

    results = await asyncio.gather(*tasks, return_exceptions=True)

    return [
        r for r in results
        if not isinstance(r, Exception)
    ]
```

---

## 十一、成本控制

### 11.1 LLM 成本优化

```python
# app/utils/c_optimizer.py

class LLMCostOptimizer:
    """LLM 成本优化器"""

    PRICING = {
        "gpt-4": {"input": 0.03, "output": 0.06},  # per 1K tokens
        "gpt-3.5-turbo": {"input": 0.001, "output": 0.002}
    }

    def estimate_cost(
        self,
        model: str,
        input_tokens: int,
        output_tokens: int
    ) -> float:
        """估算成本"""
        pricing = self.PRICING[model]
        input_cost = (input_tokens / 1000) * pricing["input"]
        output_cost = (output_tokens / 1000) * pricing["output"]
        return input_cost + output_cost

    def select_model(
        self,
        task_complexity: str,
        budget: float
    ) -> str:
        """根据预算选择模型"""
        if task_complexity == "high" and budget > 0.1:
            return "gpt-4"
        return "gpt-3.5-turbo"
```

### 11.2 API 调用优化

```python
# 批量处理

class BatchProcessor:
    """批量处理器"""

    async def process_topics_batch(
        self,
        topics: List[Topic],
        batch_size: int = 10
    ) -> List[Content]:
        """批量处理话题"""
        results = []

        for i in range(0, len(topics), batch_size):
            batch = topics[i:i + batch_size]

            # 并发处理一个批次
            batch_results = await asyncio.gather(*[
                self.generate_content(topic)
                for topic in batch
            ])

            results.extend(batch_results)

        return results
```

---

## 十二、测试策略

### 12.1 单元测试

```python
# tests/unit/test_agents.py

import pytest
from app.agents.monitor_agent import MonitorAgent

@pytest.fixture
def monitor_agent():
    return MonitorAgent(config=test_config)

@pytest.mark.asyncio
async def test_monitor_agent_fetch_sources(monitor_agent):
    """测试监控 Agent 获取数据源"""
    state = {
        "input": {"query": "AI marketing"},
        "context": {},
        "output": {},
        "errors": []
    }

    result = await monitor_agent._fetch_sources(state)

    assert "sources" in result["context"]
    assert len(result["context"]["sources"]) > 0

@pytest.mark.asyncio
async def test_monitor_agent_extract_topics(monitor_agent):
    """测试话题提取"""
    state = {
        "input": {},
        "context": {"sources": test_sources},
        "output": {},
        "errors": []
    }

    result = await monitor_agent._extract_topics(state)

    assert "topics" in result["output"]
    assert len(result["output"]["topics"]) > 0
```

### 12.2 集成测试

```python
# tests/integration/test_workflows.py

@pytest.mark.asyncio
async def test_marketing_workflow():
    """测试完整营销工作流"""
    # 1. 监控热点
    topics = await monitor_agent.run({"query": "AI"})

    # 2. 生成内容
    contents = await generate_agent.run({
        "topic": topics["output"]["selected_topics"][0]
    })

    # 3. 发布内容（测试环境，不实际发布）
    with patch.object(publish_agent, '_publish_to_twitter'):
        result = await publish_agent.run({
            "content": contents["output"]["content_variants"][0]
        })

    assert result["output"]["publish_results"][0]["status"] == "success"
```

---

## 十三、总结

这个技术架构设计具有以下特点：

✅ **模块化**：各模块职责清晰，易于维护和测试
✅ **可扩展**：插件系统支持快速添加新平台
✅ **可观测**：完善的日志和监控
✅ **安全**：密钥加密、速率限制
✅ **高效**：异步处理、缓存优化
✅ **成本可控**：LLM 成本优化、批量处理
✅ **可部署**：Docker 化、易于扩展

**下一步**：
1. 搭建项目框架
2. 实现核心 Agent
3. 集成第一个平台（Twitter）
4. 端到端测试
5. 部署上线
