# 🔧 删除功能修复说明

**问题**: `intelligenceApi.delete is not a function`

**原因**: 在 store 中错误地调用了不存在的 `intelligenceApi.delete()` 方法

**修复**: 已添加正确的 `deleteAllTopics` API 方法

---

## ✅ 修复内容

### 1. API 文件 (`frontend/src/api/intelligence.ts`)

**添加了 `deleteAllTopics` 方法：**

```typescript
deleteAllTopics: () =>
  client.delete('/intelligence/topics'),
```

**现在 API 完整支持：**
- ✅ `deleteTopic(id)` - 删除单个主题
- ✅ `deleteAllTopics()` - 删除所有主题

---

### 2. Store 文件 (`frontend/src/stores/intelligence.ts`)

**修复了调用方式：**

```typescript
// ❌ 之前（错误）:
const response = await intelligenceApi.delete('/intelligence/topics')

// ✅ 现在（正确）:
const response = await intelligenceApi.deleteAllTopics()
```

---

## 🧪 测试步骤

### 1. 重启前端开发服务器

```bash
cd frontend

# 停止当前服务（Ctrl+C）
# 然后重新启动
npm run dev
```

### 2. 测试单个删除

打开浏览器访问 `http://localhost:5174`：

1. 进入"情报监控"页面
2. 找到任意主题卡片
3. 点击右上角 **⋮** 按钮
4. 选择 **"删除主题"**
5. 在确认对话框中点击"确认删除"
6. ✅ 应该看到成功提示："主题删除成功"
7. ✅ 主题应该从列表中消失

### 3. 测试批量删除

1. 点击页面头部的 **"更多操作"** 下拉菜单
2. 选择 **"清空所有主题"**
3. 在对话框中输入 **"DELETE"**
4. 点击 **"确认清空"**
5. ✅ 所有主题应该被删除

---

## 📊 API 对应关系

| 前端调用 | API 方法 | HTTP 方法 | 端点 |
|---------|---------|-----------|------|
| `intelligenceApi.deleteTopic(id)` | `deleteTopic` | DELETE | `/api/v1/intelligence/topics/{id}` |
| `intelligenceApi.deleteAllTopics()` | `deleteAllTopics` | DELETE | `/api/v1/intelligence/topics` |

---

## 🔍 调试技巧

如果还有问题，可以在浏览器控制台检查：

### 查看网络请求
```javascript
// 打开浏览器开发者工具 (F12)
// 切换到 Network 标签
// 执行删除操作
// 查看是否有 DELETE 请求
```

### 查看 API 对象
```javascript
// 在浏览器控制台输入
import { intelligenceApi } from '@/api'
console.log(intelligenceApi)

// 应该看到：
// {
//   deleteTopic: ƒ(),
//   deleteAllTopics: ƒ(),
//   ...
// }
```

---

## ✅ 验证清单

- [x] API 方法已添加
- [x] Store 调用已修复
- [x] 导出已更新
- [ ] 重启前端服务器
- [ ] 测试单个删除
- [ ] 测试批量删除

---

## 📝 相关文件

修改的文件：
1. `frontend/src/api/intelligence.ts` - 添加 `deleteAllTopics` 方法
2. `frontend/src/stores/intelligence.ts` - 修复调用方式

无需修改：
- `frontend/src/views/intelligence/TopicList.vue` - 无需修改

---

**修复完成！现在删除功能应该可以正常工作了。** 🎉
