# 🗄️ SparkFlow 数据库快速设置指南

本指南将帮助您快速设置 SparkFlow 所需的三个数据库：PostgreSQL、Redis 和 ChromaDB。

## 📋 前置要求

- Docker 和 Docker Compose 已安装
- Python 3.10+

## 🚀 快速开始（推荐）

### 1. 使用自动设置脚本

我们提供了一个自动设置脚本，可以一键启动所有数据库：

```bash
# 运行设置脚本
./scripts/setup-databases.sh
```

脚本将自动：
- ✅ 检查 Docker 是否安装
- ✅ 启动 PostgreSQL 和 Redis 容器
- ✅ 等待数据库就绪
- ✅ 显示连接信息

### 2. 手动设置（如果脚本失败）

```bash
# 启动数据库
docker compose up -d postgres redis

# 检查状态
docker compose ps

# 查看日志
docker compose logs -f postgres redis
```

## 🔧 数据库连接信息

启动后，数据库连接信息如下：

### PostgreSQL
```
Host:     localhost:5432
Database: sparkflow
User:     sparkflow
Password: sparkflow_password
```

连接字符串：
```
postgresql+asyncpg://sparkflow:sparkflow_password@localhost:5432/sparkflow
```

### Redis
```
Host: localhost:6379
```

连接字符串：
```
redis://localhost:6379
```

### ChromaDB
```
路径: data/chromadb/ (本地文件存储)
```

## ✅ 验证安装

### 1. 测试 PostgreSQL

```bash
# 使用 psql 连接
docker exec -it sparkflow-postgres psql -U sparkflow -d sparkflow

# 在 psql 中运行
\dt  # 查看所有表
\q   # 退出
```

### 2. 测试 Redis

```bash
# 使用 redis-cli 连接
docker exec -it sparkflow-redis redis-cli

# 在 redis-cli 中运行
PING  # 应该返回 PONG
exit  # 退出
```

### 3. 启动应用并验证

```bash
# 启动 FastAPI 应用
python main.py
```

应用启动时会自动：
- 创建所有数据库表
- 初始化 Redis 连接
- 创建 ChromaDB 集合

您应该看到类似的日志：
```
INFO: All databases initialized successfully
```

## 🛠️ 常用命令

### 启动数据库

```bash
docker compose up -d postgres redis
```

### 停止数据库

```bash
docker compose down
```

### 重启数据库

```bash
docker compose restart postgres redis
```

### 查看日志

```bash
# 所有服务
docker compose logs -f

# 特定服务
docker compose logs -f postgres
docker compose logs -f redis
```

### 删除数据（警告：会删除所有数据）

```bash
# 停止并删除容器和数据卷
docker compose down -v

# 删除 ChromaDB 数据
rm -rf data/chromadb/
```

## 🔄 数据库管理

### 备份数据

#### PostgreSQL 备份

```bash
# 备份到 SQL 文件
docker exec sparkflow-postgres pg_dump -U sparkflow sparkflow > backup_$(date +%Y%m%d).sql

# 从备份恢复
docker exec -i sparkflow-postgres psql -U sparkflow sparkflow < backup_20250228.sql
```

#### Redis 备份

```bash
# Redis 自动持久化到 Docker volume
# 备份 volume 数据
docker run --rm -v sparkflow_redis_data:/data -v $(pwd):/backup \
  alpine tar czf /backup/redis_backup_$(date +%Y%m%d).tar.gz -C /data .
```

#### ChromaDB 备份

```bash
# ChromaDB 数据存储在本地文件系统
cp -r data/chromadb data/chromadb_backup_$(date +%Y%m%d)
```

### 监控数据库

#### PostgreSQL 监控

```bash
# 查看连接数
docker exec sparkflow-postgres psql -U sparkflow -d sparkflow -c \
  "SELECT count(*) FROM pg_stat_activity;"

# 查看表大小
docker exec sparkflow-postgres psql -U sparkflow -d sparkflow -c \
  "SELECT schemaname, tablename, pg_size_pretty(pg_total_relation_size(schemaname||'.'||tablename)) FROM pg_tables WHERE schemaname = 'public';"
```

#### Redis 监控

```bash
# 查看 Redis 信息
docker exec sparkflow-redis redis-cli INFO

# 查看内存使用
docker exec sparkflow-redis redis-cli INFO memory
```

## 🐛 故障排除

### 问题 1: PostgreSQL 无法连接

**症状**: `connection refused` 或 `role does not exist`

**解决方案**:
```bash
# 1. 检查容器是否运行
docker ps | grep sparkflow-postgres

# 2. 检查容器日志
docker compose logs postgres

# 3. 重启容器
docker compose restart postgres

# 4. 重新创建容器（会删除数据）
docker compose down -v postgres
docker compose up -d postgres
```

### 问题 2: Redis 无法连接

**症状**: `Error connecting to Redis`

**解决方案**:
```bash
# 1. 检查容器状态
docker ps | grep sparkflow-redis

# 2. 测试连接
docker exec sparkflow-redis redis-cli PING

# 3. 重启容器
docker compose restart redis
```

### 问题 3: 端口冲突

**症状**: `port is already allocated`

**解决方案**:
```bash
# 检查哪个进程占用了端口
# macOS:
lsof -i :5432  # PostgreSQL
lsof -i :6379  # Redis

# 停止冲突的服务或修改 docker-compose.yml 中的端口映射
```

### 问题 4: ChromaDB 初始化失败

**症状**: `ChromaDB initialization failed`

**解决方案**:
```bash
# 1. 确保 data 目录存在
mkdir -p data/chromadb

# 2. 检查权限
ls -la data/

# 3. 手动创建目录
mkdir -p data/chromadb
chmod 755 data/chromadb
```

## 📊 性能优化

### PostgreSQL 优化

编辑 `docker-compose.yml` 中的 PostgreSQL 配置：

```yaml
postgres:
  command: >
    postgres
    -c shared_buffers=256MB
    -c effective_cache_size=1GB
    -c maintenance_work_mem=64MB
    -c checkpoint_completion_target=0.9
    -c wal_buffers=16MB
    -c default_statistics_target=100
    -c random_page_cost=1.1
    -c effective_io_concurrency=200
    -c work_mem=1310kB
    -c min_wal_size=1GB
    -c max_wal_size=4GB
```

### Redis 优化

```yaml
redis:
  command: >
    redis-server
    --maxmemory 512mb
    --maxmemory-policy allkeys-lru
    --save 900 1
    --save 300 10
    --save 60 10000
```

## 🔐 安全建议

### 生产环境

在生产环境中，请务必：

1. **修改默认密码**
   ```yaml
   postgres:
     environment:
       POSTGRES_PASSWORD: ${POSTGRES_PASSWORD}  # 使用环境变量
   ```

2. **限制网络访问**
   ```yaml
   postgres:
     ports:
       - "127.0.0.1:5432:5432"  # 仅本地访问
   ```

3. **启用 SSL**
   ```bash
   DATABASE_URL=postgresql+asyncpg://user:pass@host:5432/db?sslmode=require
   ```

4. **定期备份**
   - 设置自动备份脚本
   - 使用 cron 任务定期备份

5. **监控**
   - 设置数据库监控告警
   - 监控连接数、磁盘使用等

## 📚 更多信息

- 完整数据库架构文档: [database-architecture.md](./database-architecture.md)
- Docker Compose 文档: https://docs.docker.com/compose/
- PostgreSQL 文档: https://www.postgresql.org/docs/
- Redis 文档: https://redis.io/documentation
- ChromaDB 文档: https://docs.trychroma.com/

## 💡 提示

- 首次启动应用时，表会自动创建
- 开发环境可以使用默认配置
- 生产环境请修改密码并启用 SSL
- 定期备份数据以防止数据丢失
- 使用 `docker compose` 而不是 `docker-compose`（新版 Docker）

---

**设置完成后，您就可以开始使用 SparkFlow 了！** 🎉
