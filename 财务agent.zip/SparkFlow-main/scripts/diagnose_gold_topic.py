#!/usr/bin/env python3
"""诊断黄金主题的采集问题"""

import asyncio
import sys
sys.path.append('/Users/houziqiang/workspace/marketing/SparkFlow')

from app.models.intelligence import (
    IntelligenceTopic,
    SourceConfig,
    SourceType,
    ScheduleType,
    TopicConfig,
)
from app.db.connection import get_db
from app.db.intelligence_repository import IntelligenceRepository
from app.services.intelligence.coordinator import IntelligenceCoordinator
from app.api.v1.endpoints.intelligence import db_to_pynamo_topic


async def diagnose():
    """诊断并修复黄金主题"""
    print("\n" + "="*60)
    print("🔍 黄金主题诊断工具")
    print("="*60)

    async with get_db() as session:
        repo = IntelligenceRepository(session)

        # 1. 检查现有主题
        print("\n📋 检查现有主题...")
        db_topics = await repo.list_topics()

        gold_topics = [t for t in db_topics if any(kw in t.name.lower() for kw in ['黄金', '金价', 'gold'])]

        if gold_topics:
            print(f"\n找到 {len(gold_topics)} 个黄金相关主题:")
            for db_topic in gold_topics:
                topic = db_to_pynamo_topic(db_topic)
                print(f"\n  ID: {topic.id}")
                print(f"  名称: {topic.name}")
                print(f"  关键词: {topic.keywords}")
                print(f"  激活: {topic.is_active}")
                print(f"  最后运行: {topic.last_run_time}")
                print(f"  总情报数: {topic.total_items}")

                # 检查该主题的情报数据
                stats = await repo.get_topic_statistics(topic.id)
                print(f"  当前数据库情报数: {stats['total_items']}")
                print(f"  今日新增: {stats['today_items']}")

                # 获取最新的10条情报
                db_items = await repo.get_items_by_topic(topic.id, limit=10)
                print(f"  最新情报数: {len(db_items)}")

                if db_items:
                    print(f"\n  最新3条情报:")
                    for i, db_item in enumerate(db_items[:3], 1):
                        print(f"    {i}. {db_item.title[:50]}...")
                        print(f"       发布: {db_item.published_at}")
                        print(f"       评分: {db_item.overall_score:.2f}")
        else:
            print("\n  ⚠️  没有找到黄金相关主题")

            # 创建一个推荐的黄金主题
            print("\n🆕 创建推荐的黄金主题...")
            topic = IntelligenceTopic(
                name="黄金金价监控",
                keywords=["黄金", "金价"],  # 使用多个关键词
                sources=[
                    SourceConfig(
                        type=SourceType.GOOGLE_NEWS,
                        name="Google News - 黄金金价",
                        enabled=True,
                        query="黄金金价 金价走势 黄金投资",
                        params={"gl": "CN", "hl": "zh-CN", "ceid": "CN:zh"}
                    ),
                ],
                schedule=ScheduleType.HOURLY,  # 每小时更新
                is_active=True,
                config=TopicConfig(
                    min_relevance=0.5,
                    enable_ai_summary=True,
                )
            )

            # 保存到数据库
            topic_data = topic.model_dump()
            db_topic = await repo.create_topic(topic_data)
            print(f"✅ 已创建主题: {db_topic.name} (ID: {db_topic.id})")

        print("\n" + "="*60)
        print("✅ 诊断完成")
        print("="*60)


if __name__ == "__main__":
    asyncio.run(diagnose())
