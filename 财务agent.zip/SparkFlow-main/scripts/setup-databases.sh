#!/bin/bash

# SparkFlow Database Setup Script
# This script helps you set up PostgreSQL and Redis using Docker Compose

set -e

echo "🚀 SparkFlow Database Setup"
echo "============================="
echo ""

# Check if Docker is installed
if ! command -v docker &> /dev/null; then
    echo "❌ Docker is not installed. Please install Docker first."
    echo "   Visit: https://docs.docker.com/get-docker/"
    exit 1
fi

# Check if Docker Compose is available
if ! docker compose version &> /dev/null; then
    echo "❌ Docker Compose is not available."
    echo "   Please install Docker Compose: https://docs.docker.com/compose/install/"
    exit 1
fi

echo "✅ Docker and Docker Compose are installed"
echo ""

# Ask if user wants to start databases
read -p "Do you want to start PostgreSQL and Redis? (y/n) " -n 1 -r
echo
if [[ ! $REPLY =~ ^[Yy]$ ]]; then
    echo "❌ Setup cancelled"
    exit 0
fi

echo ""
echo "🐳 Starting databases with Docker Compose..."
docker compose up -d postgres redis

echo ""
echo "⏳ Waiting for databases to be ready..."
sleep 5

# Check if PostgreSQL is running
if docker compose ps postgres | grep -q "Up"; then
    echo "✅ PostgreSQL is running"
else
    echo "❌ PostgreSQL failed to start"
    docker compose logs postgres
    exit 1
fi

# Check if Redis is running
if docker compose ps redis | grep -q "Up"; then
    echo "✅ Redis is running"
else
    echo "❌ Redis failed to start"
    docker compose logs redis
    exit 1
fi

echo ""
echo "🎉 Database setup complete!"
echo ""
echo "Database Connection Info:"
echo "  PostgreSQL:"
echo "    Host: localhost:5432"
echo "    Database: sparkflow"
echo "    User: sparkflow"
echo "    Password: sparkflow_password"
echo ""
echo "  Redis:"
echo "    Host: localhost:6379"
echo ""
echo "Next steps:"
echo "  1. Start the FastAPI backend:"
echo "     python main.py"
echo ""
echo "  2. The application will automatically initialize database tables"
echo ""
echo "To stop databases:"
echo "  docker compose down"
echo ""
echo "To view logs:"
echo "  docker compose logs -f postgres redis"
