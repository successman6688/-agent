#!/usr/bin/env python3
"""Test topic deletion functionality."""

import asyncio
import sys
sys.path.append('/Users/houziqiang/workspace/marketing/SparkFlow')

from app.models.intelligence import (
    IntelligenceTopic,
    SourceConfig,
    SourceType,
    ScheduleType,
    TopicConfig,
)
from app.services.intelligence import (
    get_intelligence_coordinator,
    IntelligenceStorage,
    get_intelligence_scheduler,
)


async def test_delete_topic():
    """测试主题删除功能"""
    print("\n" + "="*80)
    print("🗑️  主题删除功能测试")
    print("="*80)

    storage = IntelligenceStorage()
    coordinator = get_intelligence_coordinator()
    scheduler = get_intelligence_scheduler()

    # 1. 创建一个测试主题
    print("\n📝 步骤1: 创建测试主题...")
    topic = IntelligenceTopic(
        name="测试主题-将被删除",
        keywords=["测试"],
        sources=[
            SourceConfig(
                type=SourceType.RSS,
                name="Google News",
                query="测试",
                params={"hl": "zh-CN", "gl": "CN", "ceid": "CN:zh"}
            )
        ],
        schedule=ScheduleType.DAILY,
        description="这是一个用于测试删除的主题",
        config=TopicConfig(max_items=5)
    )

    await storage.save_topic(topic)
    print(f"   ✅ 主题创建成功: {topic.id}")

    # 2. 添加一些测试数据
    print(f"\n📊 步骤2: 添加测试数据...")
    response = await coordinator.collect_intelligence(topic)
    print(f"   ✅ 采集了 {response.new_items} 条情报")

    # 3. 验证数据存在
    print(f"\n🔍 步骤3: 验证数据存在...")
    items = await storage.load_items(topic.id)
    print(f"   ✅ 找到 {len(items)} 条情报")

    # 4. 获取主题列表
    print(f"\n📋 步骤4: 删除前的主题列表...")
    topics_before = await storage.list_topics()
    print(f"   当前共有 {len(topics_before)} 个主题")
    for t in topics_before[:3]:
        print(f"   - {t.name} ({t.id})")

    # 5. 删除主题
    print(f"\n🗑️  步骤5: 删除主题 {topic.id}...")
    success = await storage.delete_topic(topic.id)

    if success:
        print(f"   ✅ 删除成功")
    else:
        print(f"   ❌ 删除失败")
        return False

    # 6. 验证删除结果
    print(f"\n🔍 步骤6: 验证删除结果...")

    # 检查主题是否已被删除
    deleted_topic = await storage.load_topic(topic.id)
    if deleted_topic is None:
        print(f"   ✅ 主题文件已删除")
    else:
        print(f"   ❌ 主题文件仍然存在")
        return False

    # 检查情报数据是否已被删除
    items_after = await storage.load_items(topic.id)
    if len(items_after) == 0:
        print(f"   ✅ 情报数据已删除")
    else:
        print(f"   ❌ 情报数据仍然存在: {len(items_after)} 条")
        return False

    # 获取删除后的主题列表
    topics_after = await storage.list_topics()
    if len(topics_after) < len(topics_before):
        print(f"   ✅ 主题列表已更新: {len(topics_before)} -> {len(topics_after)}")
    else:
        print(f"   ⚠️  主题列表数量未变化")

    # 7. 测试API删除（如果需要）
    print(f"\n🧪 步骤7: 测试从调度器移除...")
    await scheduler.unschedule_topic(topic.id)
    print(f"   ✅ 已从调度器移除")

    return True


async def test_delete_all():
    """测试删除所有主题"""
    print("\n" + "="*80)
    print("🗑️  删除所有主题测试（危险操作）")
    print("="*80)

    storage = IntelligenceStorage()
    scheduler = get_intelligence_scheduler()

    # 查看当前主题
    topics = await storage.list_topics()
    print(f"\n📋 当前共有 {len(topics)} 个主题:")
    for i, t in enumerate(topics[:5], 1):
        print(f"   {i}. {t.name}")

    if len(topics) > 0:
        print(f"\n⚠️  注意: 这将删除所有 {len(topics)} 个主题!")
        confirm = input("   确认删除? (输入 'yes' 确认): ")

        if confirm.lower() == 'yes':
            count = await storage.delete_all_topics()
            await scheduler.unschedule_all()

            print(f"\n✅ 已删除 {count} 个主题")

            # 验证
            topics_after = await storage.list_topics()
            print(f"   剩余主题: {len(topics_after)}")
        else:
            print(f"\n❌ 取消删除")
    else:
        print(f"\n✅ 没有主题需要删除")


async def main():
    """运行测试"""
    print("\n" + "="*80)
    print("🚀 SparkFlow 主题删除功能测试")
    print("="*80)

    # 测试1: 删除单个主题
    success = await test_delete_topic()

    if success:
        print(f"\n✅ 删除功能测试通过!")
    else:
        print(f"\n❌ 删除功能测试失败!")

    # 测试2: 删除所有主题（需要手动确认）
    print("\n")
    await test_delete_all()


if __name__ == "__main__":
    asyncio.run(main())
