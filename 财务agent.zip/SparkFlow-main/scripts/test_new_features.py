#!/usr/bin/env python3
"""Test new intelligence features."""

import asyncio
import sys
sys.path.append('/Users/houziqiang/workspace/marketing/SparkFlow')

from app.models.intelligence import (
    IntelligenceTopic,
    SourceConfig,
    SourceType,
    ScheduleType,
    TopicConfig,
)
from app.services.intelligence import (
    get_intelligence_coordinator,
    get_intelligence_scheduler,
    IntelligenceStorage,
)


async def test_github_trending():
    """Test GitHub Trending fetcher"""
    print("\n" + "="*60)
    print("🧪 Test 1: GitHub Trending Fetcher")
    print("="*60)

    topic = IntelligenceTopic(
        name="Python热门项目",
        keywords=["python", "github"],
        sources=[
            SourceConfig(
                type=SourceType.RSS,  # Will be changed to github_trending
                name="GitHub Trending",
                params={
                    "language": "Python",
                    "time_range": "daily"
                }
            )
        ],
        schedule=ScheduleType.DAILY,
        description="监控GitHub上Python热门项目",
        config=TopicConfig(enable_ai_summary=False)  # Disable AI for quick test
    )

    # Change source type to github_trending
    topic.sources[0].type = "github_trending"

    coordinator = get_intelligence_coordinator()
    response = await coordinator.collect_intelligence(topic)

    print(f"\n✅ Collection Status: {response.status}")
    print(f"📊 Total Collected: {response.total_collected}")
    print(f"🆕 New Items: {response.new_items}")
    print(f"⏱️  Duration: {response.duration_seconds:.2f}s")

    # Get items
    storage = IntelligenceStorage()
    items = await storage.load_items(topic.id, limit=5)

    if items:
        print(f"\n📝 Top {len(items)} Items:")
        for i, item in enumerate(items[:3], 1):
            print(f"\n{i}. [{item.overall_score:.2f}] {item.title}")
            print(f"   📅 {item.published_at}")
            if item.ai_summary:
                print(f"   🤖 AI Summary: {item.ai_summary}")
            if item.key_insights:
                print(f"   💡 Insights: {', '.join(item.key_insights)}")
            if item.sentiment:
                print(f"   😊 Sentiment: {item.sentiment}")

    return response.new_items > 0


async def test_ai_analysis():
    """Test AI Analysis features"""
    print("\n" + "="*60)
    print("🧪 Test 2: AI Analysis (Summary, Insights, Sentiment)")
    print("="*60)

    topic = IntelligenceTopic(
        name="AI新闻监控",
        keywords=["AI", "人工智能", "机器学习"],
        sources=[
            SourceConfig(
                type=SourceType.RSS,
                name="Google News",
                query="AI人工智能",
                params={
                    "hl": "zh-CN",
                    "gl": "CN",
                    "ceid": "CN:zh"
                }
            )
        ],
        schedule=ScheduleType.DAILY,
        description="监控AI相关新闻",
        config=TopicConfig(
            enable_ai_summary=True,  # Enable AI
            max_items=3  # Only test 3 items for speed
        )
    )

    coordinator = get_intelligence_coordinator()
    response = await coordinator.collect_intelligence(topic)

    print(f"\n✅ Collection Status: {response.status}")
    print(f"📊 Total Collected: {response.total_collected}")
    print(f"🆕 New Items: {response.new_items}")
    print(f"⏱️  Duration: {response.duration_seconds:.2f}s")

    # Get items with AI analysis
    storage = IntelligenceStorage()
    items = await storage.load_items(topic.id, limit=3)

    print(f"\n🤖 AI Analysis Results:")
    for i, item in enumerate(items, 1):
        print(f"\n{i}. {item.title[:60]}...")
        if item.ai_summary:
            print(f"   📝 Summary: {item.ai_summary}")
        if item.key_insights:
            print(f"   💡 Insights:")
            for insight in item.key_insights:
                print(f"      - {insight}")
        if item.sentiment:
            emoji = {"positive": "😊", "negative": "😟", "neutral": "😐"}
            print(f"   {emoji.get(item.sentiment, '❓')} Sentiment: {item.sentiment}")
        if item.tags:
            print(f"   🏷️  Tags: {', '.join(item.tags)}")

    # Get report with trend analysis
    report = await storage.load_latest_report(topic.id)
    if report:
        print(f"\n📊 AI Trend Analysis:")
        print(f"   Summary: {report.summary}")
        if report.key_trends:
            print(f"   Key Trends:")
            for trend in report.key_trends:
                print(f"      - {trend}")
        if report.hot_topics:
            print(f"   Hot Topics: {', '.join(report.hot_topics)}")
        if report.sentiment:
            print(f"   Overall Sentiment: {report.sentiment}")

    return response.new_items > 0


async def test_scheduler():
    """Test Scheduler functionality"""
    print("\n" + "="*60)
    print("🧪 Test 3: Scheduler")
    print("="*60)

    scheduler = get_intelligence_scheduler()

    # Check status
    print(f"\n📊 Scheduler Running: {scheduler.is_running()}")

    # Get jobs
    jobs = scheduler.get_scheduled_topics()
    print(f"📋 Current Jobs: {len(jobs)}")
    for job in jobs:
        print(f"   - {job['name']} (next: {job['next_run_time']})")

    return True


async def main():
    """Run all tests"""
    print("\n" + "="*60)
    print("🚀 SparkFlow Intelligence System - New Features Test")
    print("="*60)

    results = {}

    try:
        # Test 1: GitHub Trending
        results["github_trending"] = await test_github_trending()
    except Exception as e:
        print(f"\n❌ GitHub Trending Test Failed: {e}")
        import traceback
        traceback.print_exc()
        results["github_trending"] = False

    try:
        # Test 2: AI Analysis
        results["ai_analysis"] = await test_ai_analysis()
    except Exception as e:
        print(f"\n❌ AI Analysis Test Failed: {e}")
        import traceback
        traceback.print_exc()
        results["ai_analysis"] = False

    try:
        # Test 3: Scheduler
        results["scheduler"] = await test_scheduler()
    except Exception as e:
        print(f"\n❌ Scheduler Test Failed: {e}")
        import traceback
        traceback.print_exc()
        results["scheduler"] = False

    # Summary
    print("\n" + "="*60)
    print("📊 Test Results Summary")
    print("="*60)

    for test_name, passed in results.items():
        status = "✅ PASSED" if passed else "❌ FAILED"
        print(f"{status}: {test_name}")

    all_passed = all(results.values())
    if all_passed:
        print("\n🎉 All tests passed!")
    else:
        print(f"\n⚠️  {sum(results.values())}/{len(results)} tests passed")

    return all_passed


if __name__ == "__main__":
    success = asyncio.run(main())
    sys.exit(0 if success else 1)
