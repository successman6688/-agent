#!/bin/bash

# SparkFlow 启动脚本

echo "🚀 Starting SparkFlow..."

# 检查虚拟环境
if [ ! -d "venv" ]; then
    echo "⚠️  Virtual environment not found. Creating one..."
    python -m venv venv
fi

# 激活虚拟环境
echo "📦 Activating virtual environment..."
source venv/bin/activate

# 检查依赖
echo "📥 Checking dependencies..."
pip install -q -r requirements.txt

# 检查 .env 文件
if [ ! -f ".env" ]; then
    echo "⚠️  .env file not found. Creating from .env.example..."
    cp .env.example .env
    echo "📝 Please edit .env file with your API keys!"
    echo "   Required: OPENAI_API_KEY, TWITTER_API_*, REDDIT_CLIENT_*"
    exit 1
fi

# 启动 Streamlit
echo "🌐 Starting Streamlit application..."
echo "📍 Open http://localhost:8501 in your browser"
streamlit run streamlit_app.py --server.port=8501
