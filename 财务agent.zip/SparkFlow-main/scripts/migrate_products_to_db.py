#!/usr/bin/env python3
"""迁移产品数据从JSON文件到PostgreSQL数据库"""

import sys
import os
import json
import asyncio
from pathlib import Path
from datetime import datetime

# Add project root to path
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from sqlalchemy.ext.asyncio import create_async_engine, AsyncSession
from sqlalchemy.orm import sessionmaker

from app.core.config import settings
from app.db import ProductDB
from app.core.logging import get_logger

logger = get_logger(__name__)


async def migrate_products():
    """迁移产品数据"""
    products_file = Path("data/products.json")

    if not products_file.exists():
        logger.error(f"Products file not found: {products_file}")
        return

    # 创建数据库连接（不创建表）
    database_url = settings.DATABASE_URL
    engine = create_async_engine(database_url, echo=False)
    async_session_maker = sessionmaker(
        engine,
        class_=AsyncSession,
        expire_on_commit=False,
        autocommit=False,
        autoflush=False,
    )

    try:
        async with async_session_maker() as session:
            # 读取JSON文件
            with open(products_file, 'r', encoding='utf-8') as f:
                data = json.load(f)

            migrated = 0

            for product_data in data.get('products', []):
                try:
                    # 检查是否已存在
                    from sqlalchemy import select
                    result = await session.execute(
                        select(ProductDB).where(
                            ProductDB.id == product_data['id']
                        )
                    )
                    existing = result.scalar_one_or_none()

                    if existing:
                        logger.info(f"Product {product_data['name']} already exists, skipping...")
                        continue

                    # 转换时间格式
                    if 'created_at' in product_data:
                        product_data['created_at'] = datetime.fromisoformat(product_data['created_at'])
                    if 'updated_at' in product_data:
                        product_data['updated_at'] = datetime.fromisoformat(product_data['updated_at'])

                    # 创建产品
                    db_product = ProductDB(**product_data)
                    session.add(db_product)
                    await session.commit()

                    migrated += 1
                    logger.info(f"✅ Migrated product: {product_data['name']}")

                except Exception as e:
                    logger.error(f"Error migrating product {product_data.get('name')}: {e}")
                    await session.rollback()

            logger.info(f"✅ Products migration complete: {migrated} products migrated")

    finally:
        await engine.dispose()


async def main():
    """主函数"""
    print("=" * 80)
    print("📦 产品数据迁移工具")
    print("=" * 80)
    print()

    print("1️⃣ 迁移产品数据...")
    await migrate_products()
    print()

    print("=" * 80)
    print("✅ 迁移完成！")
    print("=" * 80)
    print()
    print("下一步：")
    print("1. 系统将使用PostgreSQL数据库存储产品数据")
    print("2. products.json文件可以删除")


if __name__ == "__main__":
    asyncio.run(main())
