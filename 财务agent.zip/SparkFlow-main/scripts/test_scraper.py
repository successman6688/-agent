"""测试产品信息抓取功能。"""

import sys
import os

# 添加项目根目录到路径
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from app.services.product_scraper import get_product_scraper
import asyncio


async def test_scraper():
    """测试产品信息抓取。"""
    print("=" * 60)
    print("🧪 测试产品信息抓取功能")
    print("=" * 60)

    scraper = get_product_scraper()

    # 测试 URLs
    test_urls = [
        # iOS App Store
        "https://apps.apple.com/cn/app/wechat/id414478124",

        # Google Play
        "https://play.google.com/store/apps/details?id=com.tencent.mm",

        # 网站
        "https://www.openai.com"
    ]

    for i, url in enumerate(test_urls, 1):
        print(f"\n📍 测试 {i}: {url}")
        print("-" * 60)

        try:
            # 这里需要同步调用，因为 Streamlit 的 scraper 是同步的
            # 但 fetch_from_url 是 async 的，所以需要同步版本
            print("⏳ 抓取中...")

            # 对于同步环境，我们需要不同的处理方式
            # 让我先修改 scraper 支持同步调用
            product_info = scraper.fetch_from_url(url)

            if product_info:
                print(f"✅ 抓取成功！")
                print(f"\n产品名称: {product_info.get('name')}")
                print(f"产品类型: {product_info.get('type')}")
                print(f"描述: {product_info.get('description', '')[:100]}...")
                print(f"目标用户: {product_info.get('target_audience')}")

                if product_info.get('selling_points'):
                    print(f"\n卖点 ({len(product_info['selling_points'])} 个):")
                    for point in product_info['selling_points'][:3]:
                        print(f"  - {point}")

                if product_info.get('metadata', {}).get('rating'):
                    print(f"\n评分: {product_info['metadata']['rating']}/5")
            else:
                print("❌ 抓取失败")

        except Exception as e:
            print(f"❌ 错误: {str(e)}")

    print("\n" + "=" * 60)
    print("测试完成")
    print("=" * 60)

    # 关闭 scraper
    scraper.close()


# 修改 scraper 使其支持同步调用
def test_sync_scraper():
    """同步版本的测试。"""
    print("=" * 60)
    print("🧪 测试产品信息抓取功能（同步版本）")
    print("=" * 60)

    scraper = get_product_scraper()

    # 测试 iOS App Store（微信）
    url = "https://apps.apple.com/cn/app/wechat/id414478124"

    print(f"\n📍 测试: {url}")
    print("-" * 60)

    try:
        print("⏳ 抓取中...")
        product_info = scraper.fetch_from_url_sync(url)

        if product_info:
            print("✅ 抓取成功！")
            print(f"\n产品名称: {product_info.get('name')}")
            print(f"产品类型: {product_info.get('type')}")
            print(f"描述: {product_info.get('description', '')[:200]}...")
            print(f"目标用户: {product_info.get('target_audience')}")
            print(f"价格: {product_info.get('price')}")
            print(f"分类: {product_info.get('category')}")

            if product_info.get('selling_points'):
                print(f"\n卖点 ({len(product_info['selling_points'])} 个):")
                for point in product_info['selling_points'][:5]:
                    print(f"  - {point}")

            metadata = product_info.get('metadata', {})
            if metadata.get('rating'):
                print(f"\n评分: {metadata['rating']}/5 ({metadata.get('rating_count', 0)} 评价)")
            if metadata.get('icon'):
                print(f"图标: {metadata['icon'][:80]}...")

            print(f"\n完整数据:")
            import json
            print(json.dumps(product_info, indent=2, ensure_ascii=False, default=str))
        else:
            print("❌ 抓取失败")

    except Exception as e:
        print(f"❌ 错误: {str(e)}")
        import traceback
        traceback.print_exc()

    print("\n" + "=" * 60)
    print("测试完成")
    print("=" * 60)

    scraper.close()


if __name__ == "__main__":
    test_sync_scraper()
