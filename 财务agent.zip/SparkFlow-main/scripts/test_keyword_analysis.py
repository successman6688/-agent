#!/usr/bin/env python3
"""Test AI keyword analysis feature."""

import asyncio
import sys
import json
sys.path.append('/Users/houziqiang/workspace/marketing/SparkFlow')

from app.services.intelligence import get_keyword_analyzer


async def test_keyword_analysis():
    """测试关键词分析功能"""
    print("\n" + "="*80)
    print("🤖 AI关键词智能分析测试")
    print("="*80)

    analyzer = get_keyword_analyzer()

    # 测试案例
    test_cases = [
        "黄金、金价、中国金价",
        "人工智能 AI",
        "Python编程",
        "GPU显卡",
    ]

    for user_input in test_cases:
        print(f"\n{'='*80}")
        print(f"📝 用户输入: {user_input}")
        print(f"{'='*80}")

        try:
            analysis = await analyzer.analyze_keywords(user_input, language="zh")

            print(f"\n🎯 核心关键词:")
            for kw in analysis.get("primary_keywords", []):
                print(f"   - {kw}")

            print(f"\n🔍 扩展关键词:")
            for kw in analysis.get("expanded_keywords", []):
                print(f"   - {kw}")

            print(f"\n📡 优化搜索查询:")
            for sq in analysis.get("search_queries", []):
                print(f"   - [{sq.get('source')}] {sq.get('query')}")

            print(f"\n🎨 主题配置:")
            print(f"   名称: {analysis.get('topic_name')}")
            print(f"   描述: {analysis.get('topic_description')}")
            print(f"   分类: {analysis.get('category')}")
            print(f"   频率: {analysis.get('schedule')}")

            print(f"\n💡 AI洞察:")
            for i, insight in enumerate(analysis.get("insights", []), 1):
                print(f"   {i}. {insight}")

            print(f"\n📊 推荐数据源:")
            for source in analysis.get("recommended_sources", []):
                print(f"   - [{source.get('type')}] {source.get('name')}")
                print(f"     理由: {source.get('reason')}")

            print(f"\n💭 数据源建议:")
            print(f"   {analysis.get('data_sources_tips')}")

        except Exception as e:
            print(f"\n❌ 分析失败: {e}")
            import traceback
            traceback.print_exc()


async def test_create_from_analysis():
    """测试基于分析创建主题"""
    print("\n" + "="*80)
    print("🚀 测试基于AI分析自动创建主题")
    print("="*80)

    # 模拟API调用
    from app.models.intelligence import (
        IntelligenceTopic,
        SourceConfig,
        SourceType,
        ScheduleType,
    )
    from app.services.intelligence import IntelligenceStorage

    analyzer = get_keyword_analyzer()
    storage = IntelligenceStorage()

    user_input = "黄金 金价"

    print(f"\n📝 用户输入: {user_input}")

    # 1. AI分析
    print(f"\n🤖 步骤1: AI分析关键词...")
    analysis = await analyzer.analyze_keywords(user_input, language="zh")

    print(f"   ✅ 分析完成")
    print(f"   核心关键词: {analysis.get('primary_keywords')}")
    print(f"   主题名称: {analysis.get('topic_name')}")

    # 2. 构建数据源
    print(f"\n📡 步骤2: 构建数据源配置...")
    sources = []
    for source_rec in analysis.get("recommended_sources", [])[:2]:  # 只取前2个
        source_config = SourceConfig(
            type=SourceType.RSS,
            name=source_rec.get("name", "Google News"),
            query=user_input,  # 简化处理
            params={
                "hl": "zh-CN",
                "gl": "CN",
                "ceid": "CN:zh"
            }
        )
        sources.append(source_config)

    print(f"   ✅ 配置了 {len(sources)} 个数据源")

    # 3. 创建主题
    print(f"\n🆕 步骤3: 创建主题...")
    topic = IntelligenceTopic(
        name=analysis.get("topic_name"),
        keywords=analysis.get("primary_keywords"),
        sources=sources,
        schedule=ScheduleType.DAILY,
        description=analysis.get("topic_description"),
    )

    await storage.save_topic(topic)

    print(f"   ✅ 主题创建成功!")
    print(f"   ID: {topic.id}")
    print(f"   名称: {topic.name}")
    print(f"   关键词: {topic.keywords}")
    print(f"   数据源: {len(topic.sources)}个")

    return topic


async def main():
    """运行所有测试"""
    await test_keyword_analysis()
    await test_create_from_analysis()

    print("\n" + "="*80)
    print("✅ 测试完成")
    print("="*80)


if __name__ == "__main__":
    asyncio.run(main())
