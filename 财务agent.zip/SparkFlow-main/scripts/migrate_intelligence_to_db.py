#!/usr/bin/env python3
"""迁移情报数据从JSON文件到PostgreSQL数据库"""

import sys
import os
import json
import asyncio
from pathlib import Path
from datetime import datetime

# Add project root to path
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from sqlalchemy.ext.asyncio import create_async_engine, AsyncSession
from sqlalchemy.orm import sessionmaker

from app.db.connection import get_database_url, get_db_session
from app.db import IntelligenceTopicDB, IntelligenceItemDB, IntelligenceReportDB
from app.core.logging import get_logger

logger = get_logger(__name__)


async def migrate_topics():
    """迁移主题数据"""
    topics_dir = Path("data/intelligence/topics")

    if not topics_dir.exists():
        logger.error(f"Topics directory not found: {topics_dir}")
        return

    async with get_db_session() as session:
        migrated = 0

        for topic_file in topics_dir.glob("*.json"):
            try:
                with open(topic_file, 'r', encoding='utf-8') as f:
                    data = json.load(f)

                # 检查是否已存在
                from sqlalchemy import select
                result = await session.execute(
                    select(IntelligenceTopicDB).where(
                        IntelligenceTopicDB.id == data['id']
                    )
                )
                existing = result.scalar_one_or_none()

                if existing:
                    logger.info(f"Topic {data['name']} already exists, skipping...")
                    continue

                # 创建主题
                def parse_datetime(dt_str):
                    """解析datetime字符串，返回naive datetime"""
                    if not dt_str:
                        return None
                    dt = datetime.fromisoformat(dt_str)
                    # 移除timezone信息，使其变成naive datetime
                    if dt.tzinfo is not None:
                        dt = dt.replace(tzinfo=None)
                    return dt

                topic_data = {
                    **data,
                    'created_at': parse_datetime(data.get('created_at')) or datetime.utcnow(),
                    'updated_at': parse_datetime(data.get('updated_at')) or datetime.utcnow(),
                    'last_run_time': parse_datetime(data.get('last_run_time')),
                }

                db_topic = IntelligenceTopicDB(**topic_data)
                session.add(db_topic)
                await session.commit()

                migrated += 1
                logger.info(f"✅ Migrated topic: {data['name']}")

            except Exception as e:
                logger.error(f"Error migrating topic {topic_file}: {e}")
                await session.rollback()

        logger.info(f"✅ Topics migration complete: {migrated} topics migrated")


async def migrate_items():
    """迁移情报项数据"""
    items_dir = Path("data/intelligence/items")

    if not items_dir.exists():
        logger.error(f"Items directory not found: {items_dir}")
        return

    async with get_db_session() as session:
        migrated = 0

        # 遍历所有主题的items
        for topic_dir in items_dir.iterdir():
            if not topic_dir.is_dir():
                continue

            topic_id = topic_dir.name

            # 检查主题是否存在
            from sqlalchemy import select
            result = await session.execute(
                select(IntelligenceTopicDB).where(
                    IntelligenceTopicDB.id == topic_id
                )
            )
            topic = result.scalar_one_or_none()

            if not topic:
                logger.warning(f"Topic {topic_id} not found, skipping items...")
                continue

            # 处理该主题的所有items文件
            for items_file in topic_dir.glob("*.jsonl"):
                try:
                    with open(items_file, 'r', encoding='utf-8') as f:
                        for line_num, line in enumerate(f, 1):
                            if not line.strip():
                                continue

                            try:
                                data = json.loads(line)

                                # 检查是否已存在（通过URL哈希）
                                result = await session.execute(
                                    select(IntelligenceItemDB).where(
                                        IntelligenceItemDB.url_hash == data['url_hash']
                                    )
                                )
                                existing = result.scalar_one_or_none()

                                if existing:
                                    continue

                                # 转换时间格式
                                def parse_datetime(dt_str):
                                    """解析datetime字符串，返回naive datetime"""
                                    if not dt_str:
                                        return datetime.utcnow()
                                    dt = datetime.fromisoformat(dt_str)
                                    # 移除timezone信息，使其变成naive datetime
                                    if dt.tzinfo is not None:
                                        dt = dt.replace(tzinfo=None)
                                    return dt

                                item_data = {
                                    **data,
                                    'topic_id': topic_id,
                                    'published_at': parse_datetime(data.get('published_at')),
                                    'collected_at': parse_datetime(data.get('collected_at')),
                                }

                                # 移除数据库模型中不存在的字段
                                item_data.pop('sentiment', None)
                                # metadata -> data_metadata
                                if 'metadata' in item_data:
                                    item_data['data_metadata'] = item_data.pop('metadata')

                                # Truncate guid if too long (max 500 chars)
                                if item_data.get('guid') and len(item_data['guid']) > 500:
                                    item_data['guid'] = item_data['guid'][:500]

                                db_item = IntelligenceItemDB(**item_data)
                                session.add(db_item)
                                migrated += 1

                                # 每100条提交一次
                                if migrated % 100 == 0:
                                    await session.commit()
                                    logger.info(f"  Progress: {migrated} items migrated...")

                            except json.JSONDecodeError as e:
                                logger.error(f"Error parsing line {line_num} in {items_file}: {e}")
                            except Exception as e:
                                logger.error(f"Error migrating item at line {line_num}: {e}")

                    await session.commit()
                    logger.info(f"✅ Migrated items from {items_file.name}")

                except Exception as e:
                    logger.error(f"Error migrating file {items_file}: {e}")
                    await session.rollback()

        logger.info(f"✅ Items migration complete: {migrated} items migrated")


async def migrate_reports():
    """迁移报告数据"""
    reports_dir = Path("data/intelligence/reports")

    if not reports_dir.exists():
        logger.error(f"Reports directory not found: {reports_dir}")
        return

    async with get_db_session() as session:
        migrated = 0

        # 遍历所有主题的reports
        for topic_dir in reports_dir.iterdir():
            if not topic_dir.is_dir():
                continue

            topic_id = topic_dir.name

            # 检查主题是否存在
            from sqlalchemy import select
            result = await session.execute(
                select(IntelligenceTopicDB).where(
                    IntelligenceTopicDB.id == topic_id
                )
            )
            topic = result.scalar_one_or_none()

            if not topic:
                logger.warning(f"Topic {topic_id} not found, skipping reports...")
                continue

            # 处理该主题的所有report文件
            for report_file in topic_dir.glob("*.json"):
                try:
                    with open(report_file, 'r', encoding='utf-8') as f:
                        data = json.load(f)

                    # 检查是否已存在
                    result = await session.execute(
                        select(IntelligenceReportDB).where(
                            IntelligenceReportDB.id == data['id']
                        )
                    )
                    existing = result.scalar_one_or_none()

                    if existing:
                        continue

                    # 解析datetime函数
                    def parse_datetime(dt_str):
                        """解析datetime字符串，返回naive datetime"""
                        if not dt_str:
                            return None
                        dt = datetime.fromisoformat(dt_str)
                        # 移除timezone信息，使其变成naive datetime
                        if dt.tzinfo is not None:
                            dt = dt.replace(tzinfo=None)
                        return dt

                    # 转换时间格式
                    report_data = {
                        **data,
                        'period_start': parse_datetime(data.get('period_start')),
                        'period_end': parse_datetime(data.get('period_end')),
                        'created_at': parse_datetime(data.get('created_at')) or datetime.utcnow(),
                    }

                    db_report = IntelligenceReportDB(**report_data)
                    session.add(db_report)
                    migrated += 1

                    # 每100条提交一次
                    if migrated % 100 == 0:
                        await session.commit()
                        logger.info(f"  Progress: {migrated} reports migrated...")

                except json.JSONDecodeError as e:
                    logger.error(f"Error parsing file {report_file}: {e}")
                except Exception as e:
                    logger.error(f"Error migrating report {report_file}: {e}")

            await session.commit()
            logger.info(f"✅ Migrated reports from {topic_dir.name}")

        logger.info(f"✅ Reports migration complete: {migrated} reports migrated")


async def main():
    """主函数"""
    print("=" * 80)
    print("📦 情报数据迁移工具")
    print("=" * 80)
    print()

    # 初始化数据库连接（不创建表）
    print("1️⃣ 初始化数据库连接...")
    from app.db.connection import engine, async_session_maker

    database_url = get_database_url()
    print(f"连接数据库: {database_url.split('@')[1] if '@' in database_url else 'localhost'}")

    # 创建异步引擎
    engine = create_async_engine(
        database_url,
        echo=False,
        pool_size=10,
        max_overflow=20,
    )

    # 创建会话工厂
    from sqlalchemy.orm import sessionmaker
    async_session_maker = sessionmaker(
        engine,
        class_=AsyncSession,
        expire_on_commit=False,
        autocommit=False,
        autoflush=False,
    )

    # Update the global variable
    import app.db.connection as conn_module
    conn_module.engine = engine
    conn_module.async_session_maker = async_session_maker

    print("✅ Database connected\n")

    # 迁移主题
    print("2️⃣ 迁移主题数据...")
    await migrate_topics()
    print()

    # 迁移情报项
    print("3️⃣ 迁移情报项数据...")
    await migrate_items()
    print()

    # 迁移报告
    print("4️⃣ 迁移报告数据...")
    await migrate_reports()
    print()

    print("=" * 80)
    print("✅ 迁移完成！")
    print("=" * 80)
    print()
    print("下一步：")
    print("1. 重启后端服务器")
    print("2. 系统将使用PostgreSQL数据库存储")
    print("3. JSON文件将不再使用")


if __name__ == "__main__":
    asyncio.run(main())
