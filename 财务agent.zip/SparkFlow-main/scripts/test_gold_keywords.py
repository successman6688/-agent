#!/usr/bin/env python3
"""Test Google News RSS for gold-related keywords."""

import asyncio
import sys
sys.path.append('/Users/houziqiang/workspace/marketing/SparkFlow')

from app.models.intelligence import (
    IntelligenceTopic,
    SourceConfig,
    SourceType,
    ScheduleType,
    TopicConfig,
)
from app.services.intelligence import get_intelligence_coordinator, IntelligenceStorage
import feedparser


async def test_google_news_rss():
    """Test Google News RSS with gold keywords"""
    print("\n" + "="*60)
    print("🔍 测试Google News RSS - 黄金关键词")
    print("="*60)

    # 测试多个关键词组合
    test_keywords = [
        ["黄金"],
        ["金价"],
        ["中国金价"],
        ["黄金", "金价"],
        ["黄金价格"],
        ["gold price"],
    ]

    coordinator = get_intelligence_coordinator()
    storage = IntelligenceStorage()

    for keywords in test_keywords:
        print(f"\n{'='*60}")
        print(f"🔑 测试关键词: {keywords}")
        print(f"{'='*60}")

        # 创建主题
        topic = IntelligenceTopic(
            name=f"{'+'.join(keywords)}监控",
            keywords=keywords,
            sources=[
                SourceConfig(
                    type=SourceType.RSS,
                    name="Google News",
                    query=" ".join(keywords),  # 使用空格连接
                    params={
                        "hl": "zh-CN",
                        "gl": "CN",
                        "ceid": "CN:zh"
                    }
                )
            ],
            schedule=ScheduleType.DAILY,
            description=f"监控{', '.join(keywords)}相关新闻",
            config=TopicConfig(
                enable_ai_summary=False,  # 先不启用AI，快速测试
                max_items=50
            )
        )

        # 构建RSS URL
        from app.services.intelligence.fetchers.google_news import GoogleNewsRSSFetcher
        fetcher = GoogleNewsRSSFetcher(topic.sources[0], topic)

        # 打印实际RSS URL
        print(f"\n📡 RSS URL:")
        print(f"   {fetcher._build_url()}")

        # 先用feedparser测试
        print(f"\n🔎 直接用feedparser测试...")
        try:
            import urllib.parse
            url = fetcher._build_url()
            d = feedparser.parse(url)

            print(f"   Status: {d.get('status', 'N/A')}")
            print(f"   Entries: {len(d.entries)}")

            if len(d.entries) > 0:
                print(f"\n   前3条新闻:")
                for i, entry in enumerate(entries[:3], 1):
                    title = entry.get('title', 'N/A')
                    published = entry.get('published', 'N/A')
                    print(f"   {i}. {title[:60]}...")
                    print(f"      📅 {published}")
            else:
                print(f"   ⚠️  没有找到数据")

                # 检查feedparser的bozo异常
                if d.get('bozo'):
                    print(f"   ❌ Feed error: {d.get('bozo_exception')}")

        except Exception as e:
            print(f"   ❌ 错误: {e}")
            import traceback
            traceback.print_exc()

        # 使用采集器测试
        print(f"\n🤖 使用采集器测试...")
        try:
            response = await coordinator.collect_intelligence(topic)

            print(f"\n✅ 采集状态: {response.status}")
            print(f"📊 总采集数: {response.total_collected}")
            print(f"🆕 新增数: {response.new_items}")
            print(f"⏱️  耗时: {response.duration_seconds:.2f}s")

            if response.new_items > 0:
                # 获取前几条看看
                items = await storage.load_items(topic.id, limit=3)
                print(f"\n📝 示例情报:")
                for i, item in enumerate(items, 1):
                    print(f"\n{i}. {item.title}")
                    print(f"   来源: {item.source}")
                    print(f"   发布: {item.published_at}")
                    print(f"   评分: {item.overall_score:.2f}")
                    print(f"   链接: {item.url}")

        except Exception as e:
            print(f"❌ 采集失败: {e}")
            import traceback
            traceback.print_exc()


async def test_alternative_configs():
    """测试不同的配置选项"""
    print("\n" + "="*60)
    print("🔧 测试不同配置")
    print("="*60)

    # 测试英文关键词
    print("\n🌍 测试英文关键词 'gold price'")

    topic = IntelligenceTopic(
        name="Gold Price Monitor",
        keywords=["gold", "price"],
        sources=[
            SourceConfig(
                type=SourceType.RSS,
                name="Google News",
                query="gold price",
                params={
                    "hl": "en",
                    "gl": "US",
                    "ceid": "US:en"
                }
            )
        ],
        schedule=ScheduleType.DAILY,
        description="Monitor gold price news",
        config=TopicConfig(enable_ai_summary=False)
    )

    coordinator = get_intelligence_coordinator()
    response = await coordinator.collect_intelligence(topic)

    print(f"\n✅ 英文关键词结果:")
    print(f"   采集状态: {response.status}")
    print(f"   总采集数: {response.total_collected}")
    print(f"   新增数: {response.new_items}")


async def main():
    """运行所有测试"""
    print("\n" + "="*60)
    print("🔍 Google News RSS 调试 - 黄金关键词")
    print("="*60)

    await test_google_news_rss()
    await test_alternative_configs()

    print("\n" + "="*60)
    print("✅ 测试完成")
    print("="*60)


if __name__ == "__main__":
    asyncio.run(main())
