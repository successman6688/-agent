"""初始化提示词模板到数据库"""

import asyncio
from sqlalchemy import select
from app.db.connection import get_db_session
from app.db import PromptTemplateDB
from app.services.intelligence.prompt_manager import PromptManager
from app.core.logging import get_logger

logger = get_logger(__name__)


async def init_prompt_templates():
    """初始化默认提示词模板到数据库"""

    logger.info("Initializing prompt templates in database...")

    async with get_db_session() as session:
        # 检查是否已有模板
        result = await session.execute(select(PromptTemplateDB))
        existing_templates = result.scalars().all()

        if existing_templates:
            logger.info(f"Found {len(existing_templates)} existing templates, skipping initialization")
            return

        # 创建PromptManager获取默认模板
        prompt_manager = PromptManager()

        # 将默认模板写入数据库
        for strategy_type, template_data in prompt_manager.DEFAULT_TEMPLATES.items():
            db_template = PromptTemplateDB(
                name=template_data["name"],
                description=template_data["description"],
                strategy_type=strategy_type,
                category="default",
                system_prompt=template_data["system_prompt"],
                user_prompt_template=template_data["user_prompt_template"],
                output_schema=template_data["output_schema"],
                variables=template_data["variables"],
                version="1.0",
                is_active=True,
                is_default=True,
                created_by="system"
            )

            session.add(db_template)
            logger.info(f"Added template: {db_template.name} ({strategy_type})")

        await session.commit()
        logger.info(f"Successfully initialized {len(prompt_manager.DEFAULT_TEMPLATES)} prompt templates")


if __name__ == "__main__":
    # 需要先初始化数据库
    from app.db.connection import init_database

    async def main():
        await init_database()
        await init_prompt_templates()

    asyncio.run(main())
