# SparkFlow 启动脚本 (Windows)

Write-Host "🚀 Starting SparkFlow..." -ForegroundColor Green

# 检查虚拟环境
if (-not (Test-Path "venv")) {
    Write-Host "⚠️  Virtual environment not found. Creating one..." -ForegroundColor Yellow
    python -m venv venv
}

# 激活虚拟环境
Write-Host "📦 Activating virtual environment..." -ForegroundColor Cyan
& ".\venv\Scripts\Activate.ps1"

# 检查依赖
Write-Host "📥 Checking dependencies..." -ForegroundColor Cyan
pip install -q -r requirements.txt

# 检查 .env 文件
if (-not (Test-Path ".env")) {
    Write-Host "⚠️  .env file not found. Creating from .env.example..." -ForegroundColor Yellow
    Copy-Item .env.example .env
    Write-Host "📝 Please edit .env file with your API keys!" -ForegroundColor Red
    Write-Host "   Required: OPENAI_API_KEY, TWITTER_API_*, REDDIT_CLIENT_*"
    exit 1
}

# 启动 Streamlit
Write-Host "🌐 Starting Streamlit application..." -ForegroundColor Green
Write-Host "📍 Open http://localhost:8501 in your browser" -ForegroundColor Cyan
streamlit run streamlit_app.py --server.port=8501
