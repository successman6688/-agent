"""Test LLM configuration."""

import sys
import os

# Add project root to path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from app.integrations.llm import create_llm, get_api_type, get_default_model
from app.core.config import settings


def test_llm():
    """Test LLM connection and generation."""
    print("=" * 60)
    print("🧪 Testing LLM Configuration")
    print("=" * 60)

    # Show current configuration
    print(f"\n📋 Current Configuration:")
    print(f"   API Type: {get_api_type()}")
    print(f"   Model: {get_default_model()}")
    print(f"   API Base: {settings.ANTHROPIC_API_BASE}")

    try:
        # Create LLM instance
        print(f"\n🔧 Creating LLM instance...")
        llm = create_llm(temperature=0.7, max_tokens=500)
        print(f"   ✅ LLM instance created successfully")

        # Test simple generation
        print(f"\n💬 Testing content generation...")
        prompt = "Generate a short marketing tweet about AI productivity tools. Keep it under 280 characters."

        print(f"   Prompt: {prompt}")
        print(f"\n⏳ Generating response...")

        response = llm.invoke(prompt)

        print(f"\n✅ Response generated:")
        print("-" * 60)
        print(response.content)
        print("-" * 60)

        # Show token usage if available
        if hasattr(response, 'usage_metadata'):
            print(f"\n📊 Token Usage: {response.usage_metadata}")

        print(f"\n✅ LLM test PASSED!")
        return True

    except Exception as e:
        print(f"\n❌ LLM test FAILED!")
        print(f"   Error: {str(e)}")
        import traceback
        traceback.print_exc()
        return False


if __name__ == "__main__":
    success = test_llm()
    sys.exit(0 if success else 1)
