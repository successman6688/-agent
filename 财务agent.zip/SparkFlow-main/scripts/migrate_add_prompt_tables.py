"""数据库迁移：添加提示词相关表"""

import asyncio
from app.db.connection import init_database
from app.core.logging import get_logger

logger = get_logger(__name__)


async def migrate():
    """
    执行数据库迁移

    创建以下表：
    - prompt_templates: 提示词模板表
    - prompt_execution_logs: 提示词执行日志表
    - user_feedbacks: 用户反馈表
    - prompt_stats: 提示词统计汇总表
    """
    logger.info("Starting prompt evolution database migration...")

    # 初始化数据库（会自动创建所有表）
    await init_database()

    logger.info("✅ Migration completed successfully!")
    logger.info("")
    logger.info("Created tables:")
    logger.info("  - prompt_templates")
    logger.info("  - prompt_execution_logs")
    logger.info("  - user_feedbacks")
    logger.info("  - prompt_stats")
    logger.info("")
    logger.info("Next steps:")
    logger.info("  1. Run 'python scripts/init_prompt_templates.py' to initialize default prompts")
    logger.info("  2. Restart the application")


if __name__ == "__main__":
    asyncio.run(migrate())
